package com.suguretaventure.mymarriagegroup.dialogs;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.text.Html;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.suguretaventure.mymarriagegroup.R;

public class TermsAndPrivacy {
    public static void getTerms(Context ctx) {
        final Dialog dialog = new Dialog(ctx);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LayoutInflater inflater = ((Activity) ctx).getLayoutInflater();
        @SuppressLint("InflateParams") View alert = inflater.inflate(R.layout.layout_terms, null, false);
        alert.findViewById(R.id.tvTerms);
        alert.findViewById(R.id.btnCloseTerms);
        dialog.setContentView(alert);
        final TextView tvTerms = dialog.findViewById(R.id.tvTerms);
        final Button btnCloseTerms = dialog.findViewById(R.id.btnCloseTerms);
        String str = "<center><h1><font color='#DA4313'>Concept, Vision, Mission &amp; Values; Terms & Privacy Policy and FAQ</font></h1></center>" +
                "<h2><font color='#DA4313'>Concept:</font></h2>" +
                "<p><font size='24'>Anyone in the world can download this app &amp; can form a marriage/ matrimonial group for its own community. This group will be a special group only for its community. All profiles in your group are verified by admin first and then added. Therefore you have a group of genuine profiles amongst your community. It’s also a place for all marriage related commercials such as Marriage hall, catering, photographers etc available city wise, all over the world. As on today there is no such app in the world &amp; we are proud to launch the same.</font></p>" +
                "<h2><font color='#DA4313'>Vision:</font></h2>" +
                "<p>(i) Our vision is that in all parts of the world such marriage groups shall become functional. (ii) All marriage related commercials shall also be made available to these groups. (iii) To provide a perfect app for this purpose and make it number 1 in its category. </p>" +
                "<h2><font color='#DA4313'>Mission:</font></h2>" +
                "<p>(i) To connect you to such genuine &amp; eminent families in your community (ii) The genuineness can be verifiable through your known relatives, friends and admin. (iii) We shall provide this in a simplest form, user friendly manner, easy to use and at the same time provide security to members.</p>" +
                "<h2><font color='#DA4313'>Values:</font></h2>" +
                "<p>(i) Genuineness (ii) Verifiability and (iii) Security are the values of this app. We shall take all possible measures to implement the same.</p>";

        tvTerms.setText(Html.fromHtml(str));

        btnCloseTerms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        ((Activity) ctx).getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        dialog.setContentView(alert);
        final Window window = dialog.getWindow();
        assert window != null;
        dialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        window.setBackgroundDrawableResource(R.color.colorTransparent);
        window.setGravity(Gravity.CENTER);
        dialog.show();
    }
}
