package com.suguretaventure.mymarriagegroup.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.suguretaventure.mymarriagegroup.R;
import com.suguretaventure.mymarriagegroup.getsets.GTRegListGetSet;

import java.util.ArrayList;

/**
 * Created by ankitpatel on 29/03/19.
 */

public class GTRegListAdapter extends BaseAdapter
{
    private ArrayList<GTRegListGetSet> arr_adapter;
    private Context ctx;
    private LayoutInflater inflater=null;

    public GTRegListAdapter(Context ctx,ArrayList<GTRegListGetSet> arr_adapter)
    {
        this.ctx = ctx;
        this.arr_adapter = arr_adapter;
        inflater = ( LayoutInflater )ctx.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return arr_adapter.size();
    }

    @Override
    public Object getItem(int position) {
        return arr_adapter.get(position).getGtrno();
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Holder holder = null;
        View iView = convertView;
        if (iView==null)
        {
            inflater = (LayoutInflater)ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            iView = inflater.inflate(R.layout.row_gt_ulist,parent,false);
            holder = new Holder();
            holder.lblgtreguname = iView.findViewById(R.id.lblgtreguname);
            holder.lblgtreguno = iView.findViewById(R.id.lblgtreguno);
            iView.setTag(holder);
        }
        else
        {
            holder = (Holder) iView.getTag();
        }

        holder.lblgtreguname.setText(arr_adapter.get(position).getGtrname().toUpperCase());
        holder.lblgtreguno.setText(arr_adapter.get(position).getGtrno());
        return iView;
    }

    class Holder
    {
        TextView lblgtreguno,lblgtreguname;
    }
}
