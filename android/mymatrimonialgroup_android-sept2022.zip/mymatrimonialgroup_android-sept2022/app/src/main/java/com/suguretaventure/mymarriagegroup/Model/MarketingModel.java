package com.suguretaventure.mymarriagegroup.Model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

public class MarketingModel implements Serializable {

    @SerializedName("marketing")
    public ArrayList<DATA> data;

    public class DATA implements Serializable {

        @SerializedName("cid")
        public String cid;
        @SerializedName("cname")
        public String cname;
        @SerializedName("status")
        public String status;
        @SerializedName("icon")
        public String icon;
    }
}
