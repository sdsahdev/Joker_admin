package com.suguretaventure.mymarriagegroup;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.suguretaventure.mymarriagegroup.adapters.FavArcAdapter;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.common.NetworkConnetionState;
import com.suguretaventure.mymarriagegroup.getsets.PersonGetSet;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;

public class MyFav_Arc extends AppCompatActivity {
    private Context ctx = this;
    private RecyclerView rcv_fav_arc;
    private TextView lbllistof, txtdefault, lblempty_fa;
    private ArrayList<PersonGetSet> arr_adapter = new ArrayList<>();
    private FavArcAdapter favArcAdapter;
    private PersonGetSet personGetSet;
    private ProgressDialog pDialog;
    private String TAG = "MY_FAV_ARC";
    ActionBar toolbar;
    String groupId = "";
    private FirebaseAnalytics mFirebaseAnalytics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_fav_arc);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(getResources().getString(R.string.app_name_title));
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
//        setupToolbar();
        allocateMemory();
        if (new NetworkConnetionState().isNetworkAvailable(ctx)) {
            if (getIntent().getExtras().getString("from").equals("dashboard_fav")) {
                groupId = "";
                getMyFavArc("0");
                txtdefault.setText(Html.fromHtml(Constants.Favorite_MESSAGE));
            } else if (getIntent().getExtras().getString("from").equals("dashboard_arc")) {
                groupId = "";
                getMyFavArc("1");
                txtdefault.setText(Html.fromHtml(Constants.Archive_MESSAGE));
            } else if (getIntent().getExtras().getString("from").equals("dashboard_fav_group")) {

                groupId = getIntent().getExtras().getString("groupId");
                getMyFavArc("0");
                txtdefault.setText(Html.fromHtml(Constants.Archive_MESSAGE));
            } else if (getIntent().getExtras().getString("from").equals("dashboard_arc_group")) {

                groupId = getIntent().getExtras().getString("groupId");
                getMyFavArc("1");
                txtdefault.setText(Html.fromHtml(Constants.Archive_MESSAGE));
            }
        } else {
            networkAlert();
        }
    }

    private void networkAlert() {
        AlertDialog.Builder b1 = new AlertDialog.Builder(ctx);
        b1.setTitle("Network Error");
        b1.setMessage("No internet connection found. Please check your phone settings to turn on the internet.");
        b1.setPositiveButton("Retry", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (new NetworkConnetionState().isNetworkAvailable(ctx)) {
                    if (getIntent().getExtras().getString("from").equals("dashboard_fav")) {
                        groupId = "";
                        getMyFavArc("0");
                    } else if (getIntent().getExtras().getString("from").equals("dashboard_arc")) {
                        groupId = "";
                        getMyFavArc("1");
                    } else if (getIntent().getExtras().getString("from").equals("dashboard_fav_group")) {

                        groupId = getIntent().getExtras().getString("groupId");
                        getMyFavArc("0");

                    } else if (getIntent().getExtras().getString("from").equals("dashboard_arc_group")) {

                        groupId = getIntent().getExtras().getString("groupId");
                        getMyFavArc("1");

                    }
                } else {
                    networkAlert();
                }
            }
        });
        b1.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        b1.create().show();
    }

    public void allocateMemory() {
        rcv_fav_arc = findViewById(R.id.rcv_fav_arc);
        lbllistof = findViewById(R.id.lbllistof);
        txtdefault = findViewById(R.id.txtdefault);
        lblempty_fa = findViewById(R.id.lblempty_fa);

        if (getIntent().getExtras().getString("from").equals("dashboard_fav")) {
            lbllistof.setText("My Favourites");
            lblempty_fa.setText("No Favorite data found");
        } else if (getIntent().getExtras().getString("from").equals("dashboard_arc")) {
            lbllistof.setText("My Archives");
            lblempty_fa.setText("No Archive data found");
        }

        AdView adViewHome = findViewById(R.id.adViewHome);
        AdRequest adRequest = new AdRequest.Builder().build();

        adViewHome.loadAd(adRequest);
        adViewHome.setVisibility(View.VISIBLE);
    }

    public void getMyFavArc(final String fatype) {
        pDialog = new ProgressDialog(ctx);
        pDialog.setMessage("Please wait...");
        pDialog.setCancelable(false);
        showpDialog();
        String WebServiceUrl = Common.GetWebServiceUrl() + "my_fav_arc.php";

        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("rid", "" + Utils.getString(ctx, Constants.USER_ID));
        params.put("type", fatype);
        params.put("iGroupID", groupId);
        Log.d("MY_FAV", WebServiceUrl + "?" + params);
        client.post(WebServiceUrl, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                Utils.log(TAG, res.toString());
                try {
                    JSONArray response = new JSONArray(res);
                    String error = response.getJSONObject(0).getString("error");
                    if (error.equals("no error") == false) {
                        Common.showDialog(ctx);
                    } else {
                        //no error
                        int total = response.getJSONObject(1).getInt("total");
                        if (total == 0) {
                            rcv_fav_arc.setVisibility(View.GONE);
                        } else {
                            int size = response.length();
                            for (int i = 2; i < size; i++) //3
                            {
                                JSONObject object = response.getJSONObject(i);
                                personGetSet = new PersonGetSet();
                                personGetSet.setId(object.getString("id"));
                                personGetSet.setName(object.getString("name"));
                                personGetSet.setAge(object.getString("age"));
                                personGetSet.setEducation(object.getString("edu"));
                                personGetSet.setOccupation(object.getString("occu"));
                                personGetSet.setImage(object.getString("photo"));
                                personGetSet.setFaid(object.getString("faid"));
                                arr_adapter.add(personGetSet);
                            }
                            hidePDialog();
                            favArcAdapter = new FavArcAdapter(ctx, arr_adapter, fatype);
                            RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
                            rcv_fav_arc.setLayoutManager(mLayoutManager);
                            rcv_fav_arc.setAdapter(favArcAdapter);
                        }
                        hidePDialog();
                    }
                } catch (JSONException e) {
                    hidePDialog();
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

            }
        });
    }

    // show process Dialog box
    private void showpDialog() {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }

    // hide process Dialog box
    private void hidePDialog() {
        if (this.pDialog != null) {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }

    public void setupToolbar() {
        toolbar = getSupportActionBar();
        assert toolbar != null;
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_posts, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        int id = item.getItemId();
        if (id == R.id.dashboard) {
            startActivity(new Intent(ctx, Dashboard.class));
        } else if (id == R.id.myGroup) {
            startActivity(new Intent(ctx, MyGroup.class));
        }  else if (id == R.id.myDrafts) {
            startActivity(new Intent(ctx, MyDrafts.class));
        } else if (id == R.id.myPost) {
            startActivity(new Intent(ctx, MyPosts.class)
                    .putExtra("from", "dashboard")
                    .putExtra("gender", "-1"));
        } else if (id == R.id.myFev) {
            startActivity(new Intent(ctx, MyFav_Arc.class)
                    .putExtra("from", "dashboard_fav"));
        } else if (id == R.id.myArchive) {
            startActivity(new Intent(ctx, MyFav_Arc.class)
                    .putExtra("from", "dashboard_arc"));
        } else if (id == R.id.myMarketing) {
            startActivity(new Intent(ctx, MyMarketActivity.class));
        }
        return super.onOptionsItemSelected(item);
    }
}
