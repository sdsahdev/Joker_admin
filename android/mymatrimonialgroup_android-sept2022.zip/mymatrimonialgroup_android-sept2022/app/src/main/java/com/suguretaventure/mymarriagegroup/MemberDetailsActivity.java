package com.suguretaventure.mymarriagegroup;

import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.suguretaventure.mymarriagegroup.Model.BioData;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utils;

import cz.msebera.android.httpclient.Header;

public class MemberDetailsActivity extends AppCompatActivity {
    private BioData.Data details;
   private LinearLayout btnLl;
    private TextView lblupdateprofile, lblprofilename, lblprofileemail, lblprofilemobile, tvChangePassword,btnReqAccept ,btnReqReject;
    private ImageView imgprofileimg, myProfileAddress, copyImageView,callImageView,shareImageView;
    private ActionBar actionBar;
    private LayoutInflater inflater;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_profile);
        actionBar = getSupportActionBar();
        //actionBar.setTitle(title);

        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);
        details = (BioData.Data) getIntent().getSerializableExtra("memberDetail");
        Log.d("TAG", "onCreate: "+details.email);
        allocateMemory();

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
             finish();
        }
        return (super.onOptionsItemSelected(item));
    }

    private void allocateMemory() {
        btnLl=findViewById(R.id.LinRequest);
        btnLl.setVisibility(View.VISIBLE);
        lblprofileemail = findViewById(R.id.lblprofileemail);
        lblprofilemobile = findViewById(R.id.lblprofilemobile);
        lblprofilename = findViewById(R.id.lblprofilename);
        lblupdateprofile = findViewById(R.id.lblupdateprofile);
        lblupdateprofile.setVisibility(View.GONE);
        imgprofileimg = findViewById(R.id.imgprofileimg);
        myProfileAddress = findViewById(R.id.myProfileAddress);
        tvChangePassword = findViewById(R.id.tvChangePassword);
        btnReqAccept = findViewById(R.id.btnReqAccept);
        btnReqReject = findViewById(R.id.btnReqReject);

        copyImageView = findViewById(R.id.copyImageView);
        shareImageView = findViewById(R.id.shareImageView);
        callImageView = findViewById(R.id.callImageView);

        lblprofilename.setText(details.name);
        lblprofilemobile.setText(details.mobile);
        lblprofileemail.setText(details.email);


        Glide.with(MemberDetailsActivity.this)
                .load(Common.GetRegUserIDImageUrl() + details.photo)
                .apply(RequestOptions.circleCropTransform()).into(imgprofileimg);

        imgprofileimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MemberDetailsActivity.this);
                inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                View dialogLayout = inflater.inflate(R.layout.personimage_dialog, null);
                ImageView imgtabledesc = (ImageView) dialogLayout.findViewById(R.id.imgtabledesc);
                builder.setView(dialogLayout);
                Glide.with(MemberDetailsActivity.this)
                        .load(Common.GetRegUserIDImageUrl() + details.photo)
                        .placeholder(R.drawable.app_logo_new)
                        .into(imgtabledesc);
                Dialog dialog = builder.create();
                dialog.setCancelable(true);
                dialog.show();
            }
        });

        if (details.address==null){
            myProfileAddress.setVisibility(View.GONE);
        }else {
            Glide.with(MemberDetailsActivity.this)
                    .load(Common.GetRegUserAddressImageUrl() + details.address)
                    .into(myProfileAddress);
        }

       btnReqAccept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String status = "1";
                String toast = "Request Accepted";
                String id = details.req_id;
                setAction(status, toast, id);
            }
        });

        btnReqReject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which){
                            case DialogInterface.BUTTON_POSITIVE:
                                String status = "2";
                                String id = details.req_id;
                                String toast = "Request Rejected";
                                setAction(status, toast, id);
                                break;

                            case DialogInterface.BUTTON_NEGATIVE:
                                //No button clicked
                                break;
                        }
                    }
                };

                AlertDialog.Builder builder = new AlertDialog.Builder(MemberDetailsActivity.this);
                builder.setMessage("Do you want to reject invitation?").setPositiveButton("Yes", dialogClickListener)
                        .setNegativeButton("No", dialogClickListener).show();

            }
        });

        copyImageView.setOnClickListener(view -> {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            ClipData clip = ClipData.newPlainText("label", details.mobile);
            clipboard.setPrimaryClip(clip);
            Toast.makeText(MemberDetailsActivity.this, "Phone No. is copied.", Toast.LENGTH_SHORT).show();
        });

        callImageView.setOnClickListener(view -> {
            String[] phoneNo = details.mobile.split(" ");
            String phNo = "";
            for (int i = 0; i < phoneNo.length; i++) {
                if (!TextUtils.isEmpty(phoneNo[i]) && phoneNo[i].length() == 10) {
                    try {
                        Long.parseLong(phoneNo[i]);
                        phNo = phoneNo[i];
                        break;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
            if (!TextUtils.isEmpty(phNo)) {
                Intent intent = new Intent(Intent.ACTION_CALL);
                intent.setData(Uri.parse("tel:" + phNo));
                startActivity(intent);
            } else {
                Toast.makeText(MemberDetailsActivity.this, "Not a valid phone number.", Toast.LENGTH_SHORT).show();
            }
        });

        shareImageView.setOnClickListener(view -> {
            Intent intent = new Intent(android.content.Intent.ACTION_SEND);
            String shareBody = "Share Phone Number";
            intent.setType("text/plain");
            intent.putExtra(android.content.Intent.EXTRA_TEXT, details.mobile);
            /*Fire!*/
            startActivity(Intent.createChooser(intent, "Share Using"));
        });


    }

    public void setAction(final String status, final String toast, String id) {
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("rid", Utils.getString(MemberDetailsActivity.this, Constants.USER_ID));
        params.put("status", status);
        params.put("gr_req_id", id);

        Utils.log("MEMBER_LIST", "REQ_SEND_BIO-DATA_URL : " + Constants.SEND_GROUP_RESPONSE + "?" + params);
        client.post(Constants.SEND_GROUP_RESPONSE, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                Utils.log("SEND_GROUP_RESPONSE", "SEND_GROUP_RESPONSE "+status+":" + response);
                Toast.makeText(MemberDetailsActivity.this, toast, Toast.LENGTH_SHORT).show();
               finish();
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Toast.makeText(MemberDetailsActivity.this, "Something Went Wrong", Toast.LENGTH_SHORT).show();
            }
        });
    }

}
