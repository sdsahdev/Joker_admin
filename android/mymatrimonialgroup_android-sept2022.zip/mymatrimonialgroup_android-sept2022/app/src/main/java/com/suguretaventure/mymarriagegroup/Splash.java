package com.suguretaventure.mymarriagegroup;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.suguretaventure.mymarriagegroup.Model.Members;
import com.suguretaventure.mymarriagegroup.common.AppController;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.common.NetworkConnetionState;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.security.Security;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;

public class Splash extends AppCompatActivity {
    private String TAG = "SPLASH_ACTIVITY";
    private Context ctx = this;
    private ProgressDialog pDialog;
    private Object id;
    TextView versionText;
    private static final int PERMISSIONS_MULTIPLE_REQUEST = 456;
    private FirebaseAnalytics mFirebaseAnalytics;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
// clear FLAG_TRANSLUCENT_STATUS flag:
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

// add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);

// finally change the color
        window.setStatusBarColor(getResources().getColor(R.color.white));
        setContentView(R.layout.activity_splash);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        versionText = (TextView) findViewById(R.id.versionText);
        versionText.setText(BuildConfig.VERSION_NAME);
        getDevice();
        id = Utils.getString(ctx, Constants.USER_ID);
       /* if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (Splash.this.checkSelfPermission
                    (Manifest.permission.ACCESS_COARSE_LOCATION) !=
                    PackageManager.PERMISSION_GRANTED || Splash.this.checkSelfPermission
                    (Manifest.permission.ACCESS_FINE_LOCATION) !=
                    PackageManager.PERMISSION_GRANTED || Splash.this.checkSelfPermission
                    (Manifest.permission.CAMERA) !=
                    PackageManager.PERMISSION_GRANTED || Splash.this.checkSelfPermission
                    (Manifest.permission.READ_EXTERNAL_STORAGE) !=
                    PackageManager.PERMISSION_GRANTED || Splash.this.checkSelfPermission
                    (Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {

                String[] Permissions = {Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.CAMERA,
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE};
                Splash.this.requestPermissions(Permissions, PERMISSIONS_MULTIPLE_REQUEST);

            } else {
                if (NetworkConnetionState.isNetworkAvailable(ctx)) {
                    checkNetwork();
                } else {
                    NetworkErrorDialogbox(ctx);
                }
            }


        }*/

     /*   try {
            JSONObject paytmParams = new JSONObject();
            JSONObject body = new JSONObject();
            body.put("requestType", "Payment");
            body.put("mid", "NxVtlr01377332677277");
            body.put("websiteName", "YOUR_WEBSITE_NAME");
            body.put("orderId", "ORDERID_987654357");
//            body.put("callbackUrl", "https://<callback URL to be used by merchant>");

            JSONObject txnAmount = new JSONObject();
            txnAmount.put("value", "1.00");
            txnAmount.put("currency", "INR");

            JSONObject userInfo = new JSONObject();
            userInfo.put("custId", "CUST_001");
            body.put("txnAmount", txnAmount);
            body.put("userInfo", userInfo);

            *//*
         * Generate checksum by parameters we have in body
         * You can get Checksum JAR from https://developer.paytm.com/docs/checksum/
         * Find your Merchant Key in your Paytm Dashboard at https://dashboard.paytm.com/next/apikeys
         *//*

            String checksum = PaytmChecksum.generateSignature(body.toString(), "fWoWWO_nYvi1PgfX");

            JSONObject head = new JSONObject();
            head.put("signature", checksum);

            paytmParams.put("body", body);
            paytmParams.put("head", head);

            Log.d("paytmParams", new Gson().toJson(paytmParams));

        } catch (Exception e) {
            e.printStackTrace();
        }
*/

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean allgranted = false;
        for (int i = 0; i < grantResults.length; i++) {
            if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                allgranted = true;
            } else {
                allgranted = false;
                break;
            }
        }
        if (allgranted) {
            if (NetworkConnetionState.isNetworkAvailable(ctx)) {
                checkNetwork();
            } else {
                NetworkErrorDialogbox(ctx);
            }
        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
            builder.setTitle("Permission required.");
            builder.setCancelable(false);
            DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    switch (which) {
                        case DialogInterface.BUTTON_POSITIVE: //Yes button clicked...
                            finish();
                            System.exit(0);
                            break;
                    }
                }
            };
            builder.setMessage("You have to give permission to go ahead.")
                    .setPositiveButton("Ok", dialogClickListener).show();
        }
    }

    private void checkNetwork() {
        pDialog = new ProgressDialog(ctx);
        pDialog.setMessage("Please wait...");
        pDialog.setCancelable(false);
        //showpDialog();
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            public void run() {
                //checkUserStatus();

                if (Utils.isLogin(ctx) || BuildConfig.DEBUG){
                    startActivity(new Intent(getApplicationContext(), Dashboard.class));
                    finish();
                }else {
                    startActivity(new Intent(getApplicationContext(), Login.class));
                    finish();
                }



              /*  if (!Utils.getString(ctx, Constants.USER_ID).equals("")) {
                    startActivity(new Intent(getApplicationContext(), Dashboard.class));
                    finish();
                } else {
                    startActivity(new Intent(getApplicationContext(), Login.class));
                    finish();
                }*/
            }
        }, 1500);
    }

    private void NetworkErrorDialogbox(Context ctx) {
        new AlertDialog.Builder(ctx)
                .setMessage("No internet connection found. " +
                        "Please check your phone settings to turn on the internet.")
                .setPositiveButton("Close app", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                        System.exit(0);
                    }
                })
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    private void checkUserStatus() {
        String WebServiceUrl = Common.GetWebServiceUrl() +
                "verify_login.php?uid=" + id;
        JsonArrayRequest request = new JsonArrayRequest(WebServiceUrl,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Utils.log(TAG, response.toString());
                        try {
                            String error = response.getJSONObject(0).getString("error");
                            if (error.equals("no error") == false) {
                                hidePDialog();
                                Common.showDialog(ctx, error);
                            } else {
                                //no error
                                String success = response.getJSONObject(1).getString("success");
                                if (success.equals("yes") == true) {
                                    startActivity(new Intent(ctx, Dashboard.class));
                                    finish();
                                } else {
                                    startActivity(new Intent(ctx, Login.class));
                                    finish();
                                }
                                hidePDialog();
                            }
                            hidePDialog();
                        } catch (JSONException e) {
                            hidePDialog();
                            //Common.showDialog(ctx, "Error : " + e.getMessage());
                            android.app.AlertDialog.Builder b1 = new android.app.AlertDialog.Builder(ctx);
                            b1.setTitle("Error");
                            b1.setMessage(e.getMessage());
                            b1.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    finish();
                                }
                            });
                            b1.create().show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                hidePDialog();
            }
        });
        request.setRetryPolicy(new DefaultRetryPolicy(2000, 3, 1));
        AppController.getInstance().addToRequestQueue(request);
    }

    // show process Dialog box
    private void showpDialog() {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }

    // hide process Dialog box
    private void hidePDialog() {
        if (this.pDialog != null) {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }

    private void getDevice() {
        Dexter.withActivity(Splash.this)
                .withPermissions(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.READ_PHONE_STATE, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.READ_CONTACTS, Manifest.permission.CAMERA,
                        Manifest.permission.CALL_PHONE)
                .withListener(new MultiplePermissionsListener() {
                    @SuppressLint("HardwareIds")
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        Utils.log("SLPASH_ACTIVITY_STEP", "2");
                        /*if (report.areAllPermissionsGranted()) {*/
                        Utils.log("SLPASH_ACTIVITY_STEP", "3");
                        TelephonyManager telephonyManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
                        if (Build.VERSION.SDK_INT != Build.VERSION_CODES.Q && Build.VERSION.SDK_INT != Build.VERSION_CODES.R) {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                Utils.log("SLPASH_ACTIVITY_STEP", "4");
                                if (ActivityCompat.checkSelfPermission(ctx, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                                    // TODO: Consider calling
                                    //                                //    ActivityCompat#requestPermissions
                                    //                                // here to request the missing permissions, and then overriding
                                    //                                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                    //                                //                                          int[] grantResults)
                                    //                                // to handle the case where the user grants the permission. See the documentation
                                    //                                // for ActivityCompat#requestPermissions for more details.
                                    return;
                                }

                                if (Build.VERSION.SDK_INT <= Constants.ANDROID_API_LEVEL_28) {
                                    Utils.setString(ctx, Constants.IMEI, telephonyManager.getImei());
                                } else {
                                    String androidId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
                                    Utils.setString(ctx, Constants.IMEI, androidId);
                                }
                                Utils.log("EMIDIDID", Utils.getString(ctx, Constants.IMEI));

                                if (NetworkConnetionState.isNetworkAvailable(ctx)) {
                                    checkNetwork();
                                } else {
                                    NetworkErrorDialogbox(ctx);
                                }
                            } else {
                                Utils.log("SLPASH_ACTIVITY_STEP", "5");
                                //noinspection deprecation
                                if (ActivityCompat.checkSelfPermission(ctx, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                                    // TODO: Consider calling
                                    //    ActivityCompat#requestPermissions
                                    // here to request the missing permissions, and then overriding
                                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                    //                                          int[] grantResults)
                                    // to handle the case where the user grants the permission. See the documentation
                                    // for ActivityCompat#requestPermissions for more details.
                                    return;
                                }

                                Utils.log("SLPASH_ACTIVITY_STEP", "6");
                                Utils.setString(ctx, Constants.IMEI, telephonyManager.getDeviceId());
                                Utils.log("EMIDIDID", Utils.getString(ctx, Constants.IMEI));

                                if (NetworkConnetionState.isNetworkAvailable(ctx)) {
                                    checkNetwork();
                                } else {
                                    NetworkErrorDialogbox(ctx);
                                }
                                /*}*/
                            }
                        } else {
                            Utils.log("SLPASH_ACTIVITY_STEP", "4");
                            if (ActivityCompat.checkSelfPermission(ctx, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                                // TODO: Consider calling
                                //    ActivityCompat#requestPermissions
                                // here to request the missing permissions, and then overriding
                                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                //                                          int[] grantResults)
                                // to handle the case where the user grants the permission. See the documentation


                                // for ActivityCompat#requestPermissions for more details.
                                return;
                            }
                            //  Utils.setString(ctx, Constants.IMEI, telephonyManager.getImei());


                            Utils.setString(ctx, Constants.IMEI, UUID.randomUUID().toString());
                            Utils.log("EMIDIDID", Utils.getString(ctx, Constants.IMEI));

                            if (NetworkConnetionState.isNetworkAvailable(ctx)) {
                                checkNetwork();
                            } else {
                                NetworkErrorDialogbox(ctx);
                            }
                        }
//                        startSplash();
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }

                }).check();
    }
}
