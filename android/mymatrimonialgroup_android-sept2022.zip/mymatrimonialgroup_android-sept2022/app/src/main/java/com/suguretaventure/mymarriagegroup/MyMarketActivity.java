package com.suguretaventure.mymarriagegroup;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.provider.MediaStore;
import android.text.Html;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.gson.Gson;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;
import com.rilixtech.widget.countrycodepicker.Country;
import com.rilixtech.widget.countrycodepicker.CountryCodePicker;
import com.suguretaventure.mymarriagegroup.Model.MarketAddPersonModel;
import com.suguretaventure.mymarriagegroup.Model.MarketingListModel;
import com.suguretaventure.mymarriagegroup.Model.MarketingModel;
import com.suguretaventure.mymarriagegroup.adapters.AdapterMarket;
import com.suguretaventure.mymarriagegroup.adapters.MarketingPersonadapter;
import com.suguretaventure.mymarriagegroup.imageresize.core.ImageCompressTask;
import com.suguretaventure.mymarriagegroup.imageresize.listeners.IImageCompressTaskListener;
import com.suguretaventure.mymarriagegroup.imageresize.util.Util;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.ExifUtil;
import com.suguretaventure.mymarriagegroup.utils.Utility;
import com.suguretaventure.mymarriagegroup.utils.Utils;
import com.suguretaventure.mymarriagegroup.utils.WebServiceCaller;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import cz.msebera.android.httpclient.Header;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;

public class MyMarketActivity extends AppCompatActivity implements PaymentResultListener {
    private Context context = this;
    private String TAG = "MY_MARKET_ACTIVITY";
    private RecyclerView rcvMyMarket;
    private RelativeLayout relNoDataMyMarket;
    LinearLayout flt_newgroup;
    private SearchView searchView;
    private int counter = 60;
    private boolean isMobileVerified = false;
    private FirebaseAuth auth;
    List<MarketingModel> marketModels = new ArrayList<>();
    AdapterMarket adapterMarket;
    ProgressDialog dialogsending;
    ActionBar toolbar;
    private RecyclerView recyvCategoryList;
    String mgid, mgname, count, Iconimage, URL;
    private TextView txtGenderTitle, tvNoData, lblemptygrp;
    private ImageView imgGenderIcon, imgGenderBack;
    private Toolbar toolbar_top;
    private String CodeSend;
    String strcid, strcname, strname, straddress, stremail, strmobile, strdesc, strWeb, strCity;
    private Bitmap image = null;
    private String CameraFileAbsolutePath, CameraFileAbsolutePath1, CameraFileAbsolutePath2;
    private int imageUploadType;
    private ImageView imgphotoid, imgphotoid11, imgphotoid2, imgphotoid_select, imgphotoid_select1, imgphotoid_select2;
    private static final int GALLARY = 1;
    private static final int CAMERA = 2;
    private static final int REQUEST_MULTIPLE_PERMISSION = 100;
    private ExecutorService mExecutorService = Executors.newFixedThreadPool(1);
    private ImageCompressTask imageCompressTask;
    private ArrayList<String> ListCategory, ListCategoryId, ListCity;
    private String cid = "";
    private Spinner spnCategorySearch, spnCitySearch;
    private TextView tvSubmit, tvClear, txtdefault;
    private String cat_id = "0", city = "", payment_id = "";
    private LinearLayout LinSPN, LinCategory;
    Dialog alertDialog;
    private String CountryCode = "";
    private boolean isGroup = false;


    TextView linResend;
    Button btnsendotp, btnsubmitotp;
    LinearLayout LinAddOTP;
    TextView btn_create_grp;
    private FirebaseAnalytics mFirebaseAnalytics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_market);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        getSupportActionBar().setTitle(getResources().getString(R.string.app_name_title));

        txtGenderTitle = findViewById(R.id.txtGenderTitle);
        txtGenderTitle.setText(getResources().getString(R.string.app_name_title));
        toolbar_top = findViewById(R.id.toolbar_top);
        imgGenderBack = findViewById(R.id.imgGenderBack);
        setSupportActionBar(toolbar_top);
        imgGenderBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               onBackPressed();
            }
        });
        allocateMemory();
        lblemptygrp.setText(Html.fromHtml(Constants.MY_MARKET_MESSAGE));
        getDataFromServer();
        setclicklistner();
        setData();

    }

    public void setclicklistner() {
        flt_newgroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Utils.log(TAG, "USER ID : " + Utils.getString(context, Constants.USER_ID));
                if (!Utils.getString(context, Constants.USER_ID).equalsIgnoreCase("")) {
                    alertDialog = new Dialog(context);
                    alertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                    alertDialog.setContentView(R.layout.dialog_new_marketing_person);
                    alertDialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                    final EditText txtname, etAddOTP, txtaddress, txtemail, txtmobileno, txtdesc, txtCity, txtwebsite;

                    final Spinner spnCategory;

                    final CountryCodePicker txtAddmobileCode;

                    btnsendotp = alertDialog.findViewById(R.id.btnsendotp);
                    btnsubmitotp = alertDialog.findViewById(R.id.btnsubmitotp);
                    btn_create_grp = alertDialog.findViewById(R.id.btn_create_grp);
                    ImageView imgclose = alertDialog.findViewById(R.id.imgclose);
                    TextView tvPhoto = alertDialog.findViewById(R.id.tvPhoto);
                    isMobileVerified = false;

                    imgclose.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            alertDialog.dismiss();
                        }
                    });
                    txtAddmobileCode = alertDialog.findViewById(R.id.txtmobileCode);
                    txtname = alertDialog.findViewById(R.id.txtname);
                    etAddOTP = alertDialog.findViewById(R.id.etAddOTP);
                    txtaddress = alertDialog.findViewById(R.id.txtaddress);
                    txtemail = alertDialog.findViewById(R.id.txtemail);
                    txtmobileno = alertDialog.findViewById(R.id.txtmobileno);
                    txtdesc = alertDialog.findViewById(R.id.txtdesc);
                    imgphotoid_select = alertDialog.findViewById(R.id.imgphotoid_select);
                    imgphotoid_select1 = alertDialog.findViewById(R.id.imgphotoid_select1);
                    imgphotoid_select2 = alertDialog.findViewById(R.id.imgphotoid_select2);
                    imgphotoid = alertDialog.findViewById(R.id.imgphotoid);
                    imgphotoid11 = alertDialog.findViewById(R.id.imgphotoid11);
                    imgphotoid2 = alertDialog.findViewById(R.id.imgphotoid2);
                    txtCity = alertDialog.findViewById(R.id.txtCity);
                    txtwebsite = alertDialog.findViewById(R.id.txtwebsite);
                    spnCategory = alertDialog.findViewById(R.id.spnCategory);
                    LinSPN = alertDialog.findViewById(R.id.LinSPN);
                    LinCategory = alertDialog.findViewById(R.id.LinCategory);
                    linResend = alertDialog.findViewById(R.id.linResend);
                    tvPhoto = alertDialog.findViewById(R.id.tvPhoto);
                    LinAddOTP = alertDialog.findViewById(R.id.LinAddOTP);
                    LinSPN.setVisibility(View.VISIBLE);
                    CountryCode = "+" + txtAddmobileCode.getSelectedCountryCode();
                    LinCategory.setVisibility(View.GONE);
                    ArrayAdapter AgenttypeAdapter = new ArrayAdapter(context, R.layout.my_spinner, R.id.tvSpinner, ListCategory);
                    spnCategory.setAdapter(AgenttypeAdapter);
                    tvPhoto.setText("Upload Photo");
                    /*ArrayAdapter<String> customAdapter = new ArrayAdapter<String>(context, R.layout.custom_spinner_items1, ListCategory);
                    customAdapter.setDropDownViewResource(R.layout.custom_spinner_items_dropdown);
                    spnCategory.setAdapter(customAdapter);*/

                    imgphotoid_select.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            //storage.write("type","1"); //user image
                            imageUploadType = 1;
                            requestPermission();
                        }
                    });


                    imgphotoid_select1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            //storage.write("type","1"); //user image
                            imageUploadType = 2;
                            requestPermission();
                        }
                    });


                    imgphotoid_select2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            //storage.write("type","1"); //user image
                            requestPermission();
                            imageUploadType = 3;
                        }
                    });

                    /*etAddOTP.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                        @Override
                        public void onFocusChange(View v, boolean hasFocus) {
                            if (!hasFocus) {
                                if (etAddOTP.getText().length() == 6 && CodeSend != null) {
                                    ProgressDialog dialog = new ProgressDialog(context);
                                    dialog.setTitle("OTP Verification");
                                    dialog.setMessage("OTP Verifying");
                                    dialog.setCancelable(false);
                                    dialog.show();
                                    PhoneAuthCredential credential = PhoneAuthProvider.getCredential(CodeSend, etAddOTP.getText().toString());
                                    signInWithPhoneAuthCredential(credential, dialog, linResend , etAddOTP, txtmobileno);
                                } else {
                                    Toast.makeText(context, "Please enter valid OTP", Toast.LENGTH_LONG).show();
                                }
                            }
                        }
                    });*/
                    linResend.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            linResend.setVisibility(View.GONE);
                            if (txtname.getText().toString().length() == 0) {
                                txtname.setError("Enter Market title");
                            } else if (txtaddress.getText().toString().length() == 0) {
                                txtaddress.setError("Enter Market Address");
                            } else if (txtmobileno.getText().toString().length() < 9) {
                                txtmobileno.setError("Enter Mobile Number");
                            } else if (txtdesc.getText().toString().length() == 0) {
                                txtdesc.setError("Enter Description");
                            } else if (txtCity.getText().toString().length() == 0) {
                                txtCity.setError("Enter City");
                            } else if (CameraFileAbsolutePath == null) {
                                Toast.makeText(context, "Photo required...", Toast.LENGTH_SHORT).show();
                            } else if (CountryCode.equalsIgnoreCase("")) {
                                Toast.makeText(context, "enter country code", Toast.LENGTH_LONG).show();
                            } else if (txtmobileno.getText().length() < 9) {
                                txtmobileno.setError("Contact number required");
                                LinAddOTP.setVisibility(View.GONE);
                            } else {
                                LinAddOTP.setVisibility(View.VISIBLE);
                                sendSMS(CountryCode, txtmobileno.getText().toString(), linResend, btnsendotp, LinAddOTP);
                            }
                        }
                    });
                    /*txtmobileno.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                        @Override
                        public void onFocusChange(View v, boolean hasFocus) {
                            if (!hasFocus) {

                                if (CountryCode.equalsIgnoreCase("")) {
                                    Toast.makeText(context, "enter country code", Toast.LENGTH_LONG).show();
                                } else if (txtmobileno.getText().length() < 9) {
                                    txtmobileno.setError("Contact number required");
                                    LinAddOTP.setVisibility(View.GONE);
                                } else {
                                    LinAddOTP.setVisibility(View.VISIBLE);
                                    sendSMS(CountryCode, txtmobileno.getText().toString(), linResend);
                                }
                            }
                        }
                    });*/

                    txtAddmobileCode.setOnCountryChangeListener(new CountryCodePicker.OnCountryChangeListener() {
                        @Override
                        public void onCountrySelected(Country selectedCountry) {
                            CountryCode = "+" + selectedCountry.getPhoneCode();
                        }
                    });

                    spnCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                            if (position != 0) {
                                cid = ListCategoryId.get(position);
                            }
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> parent) {

                        }
                    });

                    btnsendotp.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (CountryCode.equalsIgnoreCase("")) {
                                Toast.makeText(context, "enter country code", Toast.LENGTH_LONG).show();
                            } else if (txtmobileno.getText().length() < 9) {
                                txtmobileno.setError("Contact number required");
                                LinAddOTP.setVisibility(View.GONE);
                            } else {
                                dialogsending = new ProgressDialog(context);
                                dialogsending.setMessage("Sending...");
                                dialogsending.setCancelable(true);
                                dialogsending.show();
                                sendSMS(CountryCode, txtmobileno.getText().toString(), linResend, btnsendotp, LinAddOTP);
                            }
                        }
                    });

                    btnsubmitotp.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (etAddOTP.getText().length() == 6 && CodeSend != null) {
                                ProgressDialog dialog = new ProgressDialog(context);
                                dialog.setTitle("OTP Verification");
                                dialog.setMessage("OTP Verifying");
                                dialog.setCancelable(false);
                                dialog.show();
                                PhoneAuthCredential credential = PhoneAuthProvider.getCredential(CodeSend, etAddOTP.getText().toString());
                                signInWithPhoneAuthCredential(credential, dialog, linResend, etAddOTP, txtmobileno);
                            } else {
                                Toast.makeText(context, "Please enter valid OTP", Toast.LENGTH_LONG).show();
                            }
                        }
                    });


                    RadioGroup rgPaymentOption = alertDialog.findViewById(R.id.rgPaymentOption);
                    final RadioButton rbtnYes = alertDialog.findViewById(R.id.rbtnYes);
                    RadioButton rbtnNo = alertDialog.findViewById(R.id.rbtnNo);
                    rbtnNo.setChecked(true);

                    rgPaymentOption.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                        @Override
                        public void onCheckedChanged(RadioGroup radioGroup, int i) {
                            if (radioGroup.getCheckedRadioButtonId() == R.id.rbtnYes) {
                                btn_create_grp.setText("Proceed to Pay");

                            }
                            if (radioGroup.getCheckedRadioButtonId() == R.id.rbtnNo)  {
                                btn_create_grp.setText("Create Market");
                            }
                        }
                    });



                    btn_create_grp.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (txtname.getText().toString().length() == 0) {
                                txtname.setError("Enter Market title");
                            } else if (txtaddress.getText().toString().length() == 0) {
                                txtaddress.setError("Enter Market Address");
                            } else if (txtmobileno.getText().toString().length() < 9) {
                                txtmobileno.setError("Enter Mobile Number");
                            } else if (txtdesc.getText().toString().length() == 0) {
                                txtdesc.setError("Enter Description");
                            } else if (txtCity.getText().toString().length() == 0) {
                                txtCity.setError("Enter City");
                            } else if (CameraFileAbsolutePath == null) {
                                Toast.makeText(context, "Photo required...", Toast.LENGTH_SHORT).show();
                            }  else {
                                strname = txtname.getText().toString();
                                straddress = txtaddress.getText().toString();
                                stremail = txtemail.getText().toString();
                                if (txtemail.getText().toString().length() == 0) {
                                    stremail = "-";
                                }
                                strmobile = txtmobileno.getText().toString();
                                strdesc = txtdesc.getText().toString();
                                strCity = txtCity.getText().toString();
                                strWeb = txtwebsite.getText().toString();
                                // createNewGroup(txtgtitle.getText().toString(),aldialog);
                                if (isMobileVerified) {
                                    if (rbtnYes.isChecked()) {
                                        startPayment();
                                    }else{
                                        addMrketingperson("0");
                                    }
                                    //addBiodata();
                                } else {
                                    Toast.makeText(context, "Verify mobile number to add bio-data", Toast.LENGTH_LONG).show();
                                }
                            }
                        }
                    });
                    alertDialog.show();
                } else {
                    Toast.makeText(context, "Login required to add market", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void getDataFromServer() {
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("rid", "" + Utils.getString(context, Constants.USER_ID));
        Utils.log(TAG, "MY_MARKETING_LIST_URL : " + Constants.APP_MY_MARKETING_LIST + "?" + params);
        client.post(Constants.APP_MY_MARKETING_LIST, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                Utils.log(TAG, "MY_MARKETING_LIST_RESPONSE : " + res);
                if (!res.equalsIgnoreCase("")) {
                    rcvMyMarket.setVisibility(View.VISIBLE);
                    MarketingListModel model = new Gson().fromJson(res, MarketingListModel.class);
                    rcvMyMarket.setLayoutManager(new LinearLayoutManager(context));
                    if (model.data.size() == 0) {
                        rcvMyMarket.setVisibility(View.GONE);
                    } else {
                        rcvMyMarket.setVisibility(View.VISIBLE);
                    }
                    rcvMyMarket.setAdapter(new MarketingPersonadapter(context, model, Utils.getString(context, Constants.USER_ID)));
                } else {
                    rcvMyMarket.setVisibility(View.GONE);
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "MY_MARKETING_LIST_ERROR : " + error.getMessage());
            }
        });
    }

    private void allocateMemory() {
        rcvMyMarket = findViewById(R.id.rcvMyMarket);
        relNoDataMyMarket = findViewById(R.id.relNoDataMyMarket);
        flt_newgroup = findViewById(R.id.flt_newgroup);
        lblemptygrp = findViewById(R.id.lblemptygrp);
        auth = FirebaseAuth.getInstance();
        isGroup = getIntent().getBooleanExtra("isGroup", false);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_posts, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        int id = item.getItemId();
        if (id == R.id.dashboard) {
            startActivity(new Intent(context, Dashboard.class));
        } else if (id == R.id.myGroup) {
            startActivity(new Intent(context, MyGroup.class));
        } else if (id == R.id.myPost) {
            startActivity(new Intent(context, MyPosts.class)
                    .putExtra("from", "dashboard")
                    .putExtra("gender", "-1"));
        } else if (id == R.id.myFev) {

            if (isGroup) {
                startActivity(new Intent(context, MyFav_Arc.class)
                        .putExtra("from", "dashboard_fav_group")
                        .putExtra("groupId", mgid));
            } else {
                startActivity(new Intent(context, MyFav_Arc.class)
                        .putExtra("from", "dashboard_fav"));
            }

        } else if (id == R.id.myArchive) {
            if (isGroup) {
                startActivity(new Intent(context, MyFav_Arc.class)
                        .putExtra("from", "dashboard_arc_group")
                        .putExtra("groupId", mgid));
            } else {
                startActivity(new Intent(context, MyFav_Arc.class)
                        .putExtra("from", "dashboard_arc"));
            }

        } else if (id == R.id.myMarketing) {
            startActivity(new Intent(context, MyMarketActivity.class));
        }
        return super.onOptionsItemSelected(item);
    }

    void requestPermission() {
        if (PackageManager.PERMISSION_GRANTED !=
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ||
                PackageManager.PERMISSION_GRANTED != ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)) {
            String[] PermissionList = {Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.CAMERA};
            if (ActivityCompat.shouldShowRequestPermissionRationale
                    (this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ||
                    ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA)) {

                ActivityCompat.requestPermissions(this, PermissionList,
                        REQUEST_MULTIPLE_PERMISSION);
            } else {
                ActivityCompat.requestPermissions(this, PermissionList,
                        REQUEST_MULTIPLE_PERMISSION);
            }
        } else {
            showDialogBox();
        }
    }

    private void showDialogBox() {
        androidx.appcompat.app.AlertDialog.Builder b1 = new androidx.appcompat.app.AlertDialog.Builder(context);
        b1.setTitle("Select Photo");
        b1.setIcon(R.drawable.logo1);
        b1.setMessage("I want to select photo");
        b1.setPositiveButton("Using CAMERA", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                File image = null;
                try {
                    image = Util.CreteFileWithUniqueName(context);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (imageUploadType == 1) {
                    CameraFileAbsolutePath = image.getAbsolutePath();
                }
                if (imageUploadType == 2) {
                    CameraFileAbsolutePath1 = image.getAbsolutePath();
                }
                if (imageUploadType == 3) {
                    CameraFileAbsolutePath2 = image.getAbsolutePath();
                }
                Uri photoURI = FileProvider.getUriForFile(context,
                        BuildConfig.APPLICATION_ID + ".provider", image);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(intent, CAMERA);
            }
        });
        b1.setNegativeButton("using Gallery", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent = new Intent(Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, GALLARY);
            }
        });

        b1.create().show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GALLARY && resultCode == RESULT_OK &&
                data != null) {
            Uri uri = data.getData();
            Cursor cursor = MediaStore.Images.Media.query(getContentResolver(),
                    uri, new String[]{MediaStore.Images.Media.DATA});
            if (cursor != null && cursor.moveToFirst()) {
                String imgPath = cursor.getString(cursor.getColumnIndexOrThrow
                        (MediaStore.Images.Media.DATA));
                imageCompressTask = new ImageCompressTask(this, imgPath,
                        iImageCompressTaskListener);
                mExecutorService.execute(imageCompressTask);
                if (imageUploadType == 1) {
                    CameraFileAbsolutePath = imgPath;
                    Bitmap bmp = BitmapFactory.decodeFile(imgPath);
                    imgphotoid.setRotation(ExifUtil.getCameraPhotoOrientation(CameraFileAbsolutePath));
                    imgphotoid.setImageBitmap(bmp);
                }

                if (imageUploadType == 2) {
                    CameraFileAbsolutePath1 = imgPath;
                    Bitmap bmp = BitmapFactory.decodeFile(imgPath);
                    imgphotoid11.setRotation(ExifUtil.getCameraPhotoOrientation(CameraFileAbsolutePath1));
                    imgphotoid11.setImageBitmap(bmp);
                }

                if (imageUploadType == 3) {
                    CameraFileAbsolutePath2 = imgPath;
                    Bitmap bmp = BitmapFactory.decodeFile(imgPath);
                    imgphotoid2.setRotation(ExifUtil.getCameraPhotoOrientation(CameraFileAbsolutePath2));
                    imgphotoid2.setImageBitmap(bmp);
                }
            }

        } else if (requestCode == CAMERA) {
            if (imageUploadType == 1) {
                File imgFile = new File(CameraFileAbsolutePath);
                if (imgFile.exists()) {
                    imageCompressTask = new ImageCompressTask(this, CameraFileAbsolutePath,
                            iImageCompressTaskListener);
                    mExecutorService.execute(imageCompressTask);
                    Bitmap bmp = BitmapFactory.decodeFile(CameraFileAbsolutePath);
                    imgphotoid.setRotation(ExifUtil.getCameraPhotoOrientation(CameraFileAbsolutePath));
                    imgphotoid.setImageBitmap(bmp);
                }
            }

            if (imageUploadType == 2) {
                File imgFile = new File(CameraFileAbsolutePath1);
                if (imgFile.exists()) {
                    imageCompressTask = new ImageCompressTask(this, CameraFileAbsolutePath1,
                            iImageCompressTaskListener);
                    mExecutorService.execute(imageCompressTask);
                    Bitmap bmp = BitmapFactory.decodeFile(CameraFileAbsolutePath1);
                    imgphotoid11.setRotation(ExifUtil.getCameraPhotoOrientation(CameraFileAbsolutePath1));
                    imgphotoid11.setImageBitmap(bmp);
                }
            }

            if (imageUploadType == 3) {
                File imgFile = new File(CameraFileAbsolutePath2);
                if (imgFile.exists()) {
                    imageCompressTask = new ImageCompressTask(this, CameraFileAbsolutePath2,
                            iImageCompressTaskListener);
                    mExecutorService.execute(imageCompressTask);
                    Bitmap bmp = BitmapFactory.decodeFile(CameraFileAbsolutePath2);
                    imgphotoid2.setRotation(ExifUtil.getCameraPhotoOrientation(CameraFileAbsolutePath2));
                    imgphotoid2.setImageBitmap(bmp);
                }
            }
        }
    }

    private void addMrketingperson(String razorpayPaymentID) {
        if (!Utility.isNetworkAvailable(context)) {
            /*Snackbar.make(rcvgrp, "Internet connection is not available", Snackbar.LENGTH_INDEFINITE).setAction("RETRY", new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    getMArketingperson(my_rid);
                }
            }).setActionTextColor(getResources().getColor(R.color.colorPrimary)).show();*/
        } else {
            final ProgressDialog progressDialog = new ProgressDialog(context);
            progressDialog.setTitle("Please wait...");
            progressDialog.show();
            progressDialog.setCancelable(false);

            File file = new File(CameraFileAbsolutePath);
            try {
                Bitmap bitmap = BitmapFactory.decodeFile(file.getPath());
                bitmap.compress(Bitmap.CompressFormat.JPEG, 70, new FileOutputStream(file));
            } catch (Throwable t) {
                Log.e("ERROR", "Error compressing file." + t.toString());
                t.printStackTrace();
            }
            // Create a request body with file and image media type
            RequestBody fileReqBody = RequestBody.create(MediaType.parse("image/*"), file);
            // Create MultipartBody.Part using file request-body,file name and part name
            MultipartBody.Part part = MultipartBody.Part.createFormData("image", file.getName(), fileReqBody);

            MultipartBody.Part part1 = MultipartBody.Part.createFormData("image1", "");
            if (CameraFileAbsolutePath1 != null) {
                File file1 = new File(CameraFileAbsolutePath1);
                try {
                    Bitmap bitmap = BitmapFactory.decodeFile(file1.getPath());
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 70, new FileOutputStream(file1));
                } catch (Throwable t) {
                    Log.e("ERROR", "Error compressing file." + t.toString());
                    t.printStackTrace();
                }

                // Create a request body with file and image media type
                RequestBody fileReqBody1 = RequestBody.create(MediaType.parse("image/*"), file1);
                // Create MultipartBody.Part using file request-body,file name and part name
                part1 = MultipartBody.Part.createFormData("image1", file1.getName(), fileReqBody1);
            }

            MultipartBody.Part part2 = MultipartBody.Part.createFormData("image2", "");
            if (CameraFileAbsolutePath2 != null) {
                File file2 = new File(CameraFileAbsolutePath2);
                try {
                    Bitmap bitmap = BitmapFactory.decodeFile(file2.getPath());
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 70, new FileOutputStream(file2));
                } catch (Throwable t) {
                    Log.e("ERROR", "Error compressing file." + t.toString());
                    t.printStackTrace();
                }

                // Create a request body with file and image media type
                RequestBody fileReqBody2 = RequestBody.create(MediaType.parse("image/*"), file2);
                // Create MultipartBody.Part using file request-body,file name and part name
                part2 = MultipartBody.Part.createFormData("image2", file2.getName(), fileReqBody2);
            }


            //Create request body with text description and text media type
            RequestBody description1 = RequestBody.create(MediaType.parse("text/plain"), cid);
            RequestBody description2 = RequestBody.create(MediaType.parse("text/plain"), Utils.getString(context, Constants.USER_ID));
            RequestBody description3 = RequestBody.create(MediaType.parse("text/plain"), strname);
            RequestBody description4 = RequestBody.create(MediaType.parse("text/plain"), straddress);
            RequestBody description5 = RequestBody.create(MediaType.parse("text/plain"), strmobile);
            RequestBody description6 = RequestBody.create(MediaType.parse("text/plain"), stremail);
            RequestBody description7 = RequestBody.create(MediaType.parse("text/plain"), strdesc);
            RequestBody description10 = RequestBody.create(MediaType.parse("text/plain"), strCity);
            RequestBody description12 = RequestBody.create(MediaType.parse("text/plain"), strWeb);
            RequestBody description11 = RequestBody.create(MediaType.parse("text/plain"), razorpayPaymentID);
            RequestBody description8 = RequestBody.create(MediaType.parse("text/plain"), "lat");
            RequestBody description9 = RequestBody.create(MediaType.parse("text/plain"), "lon");

            WebServiceCaller.getClient().marketAddPersonModelCall(part, part1, part2, description1, description2, description3, description4, description5, description6, description7, description8, description9, description10, description11, description12).enqueue(new Callback<MarketAddPersonModel>() {
                @Override
                public void onResponse(Call<MarketAddPersonModel> call, retrofit2.Response<MarketAddPersonModel> response) {
                    Log.d("API_RESPONSE", "DATA" + response.body().getMsg());
                    if (response.isSuccessful()) {
                        Toast.makeText(context, response.body().getMsg(), Toast.LENGTH_LONG).show();
                        CameraFileAbsolutePath = null;
                        CameraFileAbsolutePath1 = null;
                        CameraFileAbsolutePath2 = null;
                    } else {
                        Toast.makeText(context, "Error", Toast.LENGTH_LONG).show();

                    }
                    progressDialog.dismiss();
                }

                @Override
                public void onFailure(Call<MarketAddPersonModel> call, Throwable t) {
                    //swipeContainer.setRefreshing(false)
                    //
                    Log.d("ERRPR_API", t.toString());
                    progressDialog.dismiss();
                    Toast.makeText(context, "Error", Toast.LENGTH_LONG).show();
                }
            });
        }


    }

    private IImageCompressTaskListener iImageCompressTaskListener = new IImageCompressTaskListener() {
        @Override
        public void onComplete(List<File> compressed) {
            File file = compressed.get(0);
            if (imageUploadType == 1) {
                imgphotoid.setImageBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()));
            }
            if (imageUploadType == 2) {
                imgphotoid11.setImageBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()));
            }

            if (imageUploadType == 3) {
                imgphotoid2.setImageBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()));
            }

        }

        @Override
        public void onError(Throwable error) {
        }
    };

    public void startPayment() {
        final Activity activity = this;

        final Checkout co = new Checkout();

        try {
            JSONObject options = new JSONObject();
            options.put("name", "" + Utils.getString(context, Constants.USER_NAME));
            options.put("description", "Add Market Charge");
            //You can omit the image option to fetch the image from dashboard
            options.put("image", "");
            options.put("currency", "USD");
            options.put("amount", "100");

            JSONObject preFill = new JSONObject();
            preFill.put("email", "" + Utils.getString(context, Constants.USER_EMAIL));
            preFill.put("contact", "" + Utils.getString(context, Constants.USER_MOBILE));

            options.put("prefill", preFill);

            co.open(activity, options);
        } catch (Exception e) {
            Toast.makeText(activity, "Error in payment: " + e.getMessage(), Toast.LENGTH_SHORT)
                    .show();
            e.printStackTrace();
        }
    }

    /**
     * The name of the function has to be
     * onPaymentSuccess
     * Wrap your code in try catch, as shown, to ensure that this method runs correctly
     */
    @SuppressWarnings("unused")
    @Override
    public void onPaymentSuccess(String razorpayPaymentID) {
        try {
            addMrketingperson(razorpayPaymentID);
            alertDialog.dismiss();
        } catch (Exception e) {
            Utils.log(TAG, "Exception in onPaymentSuccess : " + e.getMessage());
        }
    }

    /**
     * The name of the function has to be
     * onPaymentError
     * Wrap your code in try catch, as shown, to ensure that this method runs correctly
     */
    @SuppressWarnings("unused")
    @Override
    public void onPaymentError(int code, String response) {
        try {
            Toast.makeText(this, "Payment failed: " + code + " " + response, Toast.LENGTH_SHORT).show();
            Log.d("PAYMENT_CODE", String.valueOf(code));
            Log.d("PAYMENT_RESPONSE", response);
            alertDialog.dismiss();
        } catch (Exception e) {
            Utils.log(TAG, "Exception in onPaymentError : " + e.getMessage());
        }
    }

    private void sendSMS(String countryCode, String mobile, final TextView linResend, Button btnsendotp, LinearLayout linAddOTP) {
        counter = 60;
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                countryCode + "" + mobile,        // Phone number to verify
                60,                 // Timeout duration
                TimeUnit.SECONDS,   // Unit of timeout
                this,               // Activity (for callback binding)
                mCallbacks);        // OnVerificationStateChangedCallbacks
        linResend.setVisibility(View.VISIBLE);
        btnsendotp.setVisibility(View.GONE);
        linAddOTP.setVisibility(View.VISIBLE);
        new CountDownTimer(60000, 1000) {
            public void onTick(long millisUntilFinished) {
                linResend.setText("Resend OTP within " + counter + " seconds.");
                linResend.setClickable(false);
                if (counter > 0) {
                    counter--;
                } else {
                    linResend.setClickable(true);
                    linResend.setText("Resend OTP?");
                }
            }

            public void onFinish() {
                counter = 0;
                linResend.setClickable(true);
                linResend.setText("Resend OTP?");
            }
        }.start();
    }

    PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
        @Override
        public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {
            Log.d(TAG, "onVerificationCompleted");
            dialogsending.dismiss();
            isMobileVerified = true;
            Toast.makeText(context, "OTP verification Successful", Toast.LENGTH_LONG).show();


            linResend.setVisibility(View.GONE);
            btnsendotp.setVisibility(View.GONE);
            LinAddOTP.setVisibility(View.GONE);

            btn_create_grp.setVisibility(View.VISIBLE);
        }

        @Override
        public void onVerificationFailed(FirebaseException e) {
            Log.d(TAG, "onVerificationFailed  : " + e.getMessage());
            Toast.makeText(context, "OTP invalid", Toast.LENGTH_LONG).show();
        }

        @Override
        public void onCodeSent(String code, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
            super.onCodeSent(code, forceResendingToken);
            CodeSend = code;
            dialogsending.dismiss();
            Toast.makeText(context, "OTP will be sent on this number", Toast.LENGTH_LONG).show();
            Log.d(TAG, "onCodeSent  : " + code);
        }
    };

    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential, final ProgressDialog dialog, final TextView linResend, final EditText etAddOTP, final EditText txtmobileno) {
        auth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d(TAG, "signInWithCredential:success");
                            /*sendDataToServer();*/
                            dialog.dismiss();
                            linResend.setVisibility(View.GONE);
                            isMobileVerified = true;
                            Toast.makeText(context, "OTP verification Successful", Toast.LENGTH_LONG).show();
                            txtmobileno.setEnabled(false);
                            txtmobileno.setCompoundDrawables(null, null, getResources().getDrawable(R.drawable.ic_done_green), null);
                            etAddOTP.setEnabled(false);
                        } else {
                            // Sign in failed, display a message and update the UI
                            Log.w(TAG, "signInWithCredential:failure", task.getException());
                            dialog.dismiss();

                            if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {
                                // The verification code entered was invalid
                                Toast.makeText(context, "The verification code entered was invalid", Toast.LENGTH_LONG).show();
                            }

                        }
                    }
                });
    }

    private void setData() {
        ListCategory = new ArrayList<>();
        ListCategoryId = new ArrayList<>();
        final ProgressDialog dialog = new ProgressDialog(context);
        dialog.setTitle("Please wait...");
        dialog.show();
        dialog.setCancelable(false);
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        Utils.log(TAG, Constants.APP_GET_MARKETING_LIST);
        client.post(Constants.APP_GET_MARKETING_LIST, null, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                Utils.log(TAG, "APP_GET_MARKETING_LIST_RESPONSE : " + new String(responseBody));
                MarketingModel model = new Gson().fromJson(new String(responseBody), MarketingModel.class);
                ListCategory.add("Select Category");
                ListCategoryId.add("0");
                for (int i = 0; i < model.data.size(); i++) {
                    ListCategory.add("" + model.data.get(i).cname);
                    ListCategoryId.add("" + model.data.get(i).cid);
                }

                ArrayAdapter AgenttypeAdapter = new ArrayAdapter(context, R.layout.my_spinner, R.id.tvSpinner, ListCategory);
                /*recyclerView.setLayoutManager(new LinearLayoutManager(context));
                adapterMarket = new AdapterMarket(context, model);
                recyclerView.setAdapter(adapterMarket);*/
                dialog.dismiss();
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "APP_GET_MARKETING_LIST_ERROR : " + error.getMessage());
                dialog.dismiss();
            }
        });
    }
  /*  @Override
    protected void onResume() {
        super.onResume();
        getDataFromServer();
    }*/
}
