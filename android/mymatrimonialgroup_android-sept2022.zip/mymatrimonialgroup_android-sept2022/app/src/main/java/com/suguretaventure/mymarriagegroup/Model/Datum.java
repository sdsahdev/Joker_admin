package com.suguretaventure.mymarriagegroup.Model;

public class Datum {

    private String name;
    private String register_userid;

    public Datum(String name, String register_userid) {
        this.name = name;
        this.register_userid = register_userid;
    }

    public String getRegister_userid() {
        return register_userid;
    }

    public void setRegister_userid(String register_userid) {
        this.register_userid = register_userid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
