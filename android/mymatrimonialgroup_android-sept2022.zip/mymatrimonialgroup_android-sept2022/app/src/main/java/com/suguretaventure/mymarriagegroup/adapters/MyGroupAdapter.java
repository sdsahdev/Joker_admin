package com.suguretaventure.mymarriagegroup.adapters;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.text.Html;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.gson.Gson;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.suguretaventure.mymarriagegroup.BuildConfig;
import com.suguretaventure.mymarriagegroup.Dashboard;

import com.suguretaventure.mymarriagegroup.Model.GroupListModel;
import com.suguretaventure.mymarriagegroup.R;
import com.suguretaventure.mymarriagegroup.SelectProfileActivity;
import com.suguretaventure.mymarriagegroup.UpdateGroupActivity;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.getsets.PersonGetSet;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;

import static com.suguretaventure.mymarriagegroup.utils.ExifUtil.rotate;

/**
 * Created by ankitpatel on 23/02/19.
 */

public class MyGroupAdapter extends RecyclerView.Adapter<MyGroupAdapter.MyViewHolder> {
    private String TAG = "MY_GROUP_ADAPTER";
    private Context context;
    private LayoutInflater inflater;
    private GroupListModel  groupListModel;
    public Dashboard dashboard= new Dashboard();
    private GroupListener groupListener;

    private String admin, group_status;

    public MyGroupAdapter(Context context, GroupListModel groupListModel, String admin,GroupListener groupListener) {
        //if admin = 1 Means User is admin or admin  = 0 not admin
        this.context = context;
        this.groupListModel = groupListModel;
        this.admin = admin;
        this.groupListener=groupListener;
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_my_group, parent, false);
        return new MyViewHolder(itemView);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, @SuppressLint("RecyclerView") final int i) {
        groupListener.showHideText(groupListModel.getGrouplist().get(i).getIsDefault());
        if (admin.equals("1")) {
            holder.buttonViewOption.setVisibility(View.VISIBLE);
        } else {
            holder.buttonViewOption.setVisibility(View.GONE);
        }
        holder.lblgrptitle.setText(groupListModel.getGrouplist().get(i).getTitle());
        holder.txtgrpcount.setText("Members: " + groupListModel.getGrouplist().get(i).getGrptotal() +
                                "  Brides "+groupListModel.getGrouplist().get(i).getFemale() +
                                "  Grooms "+groupListModel.getGrouplist().get(i).getMale());

        holder.lay_mygrp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Utils.log("GroupListModel", new Gson().toJson(groupListModel.getGrouplist()));
                if (groupListModel.getGrouplist().get(i).getIsDefault().equals("0") || BuildConfig.DEBUG) {
                    Utils.setString(context, "isAdmin", String.valueOf(groupListModel.getGrouplist().get(i).getIsAdmin()) );
                    Utils.setString(context, "isSubadmin", String.valueOf(groupListModel.getGrouplist().get(i).getIsSubadmin()) );
                    context.startActivity(new Intent(context, SelectProfileActivity.class)
                            .putExtra("mgid", groupListModel.getGrouplist().get(i).getId())
                            .putExtra("mgname", groupListModel.getGrouplist().get(i).getTitle())
                            .putExtra("image", groupListModel.getGrouplist().get(i).getPhoto())
                            .putExtra("URL", groupListModel.getGrouplist().get(i).getUrl())
                            .putExtra("GROUP_MEMBER", groupListModel.getGrouplist().get(i).getGrptotal())
                            .putExtra("Brides", groupListModel.getGrouplist().get(i).getFemale())
                            .putExtra("Grooms", groupListModel.getGrouplist().get(i).getMale()));

                    Utils.setString(context, Constants.MEMBER, groupListModel.getGrouplist().get(i).getGrptotal());
                   // dashboard.txt.setVisibility(View.GONE);


                }else {
                   /* dashboard.adViewHome.setVisibility(View.GONE);
                    dashboard.txt.setVisibility(View.VISIBLE);
                    dashboard.txt.setText("Now create a special Marriage Group for your own Community, Religion, Caste, City etc. all over the world ! You can see your Groups here.");
*/
                    final Dialog alertDialog = new Dialog(context);
                    alertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                    alertDialog.setContentView(R.layout.dialog_my_group_layout);
                    // Setting Dialog Title
                    TextView btnsendreq = alertDialog.findViewById(R.id.btnsendreq);
                    TextView btncancel = alertDialog.findViewById(R.id.btncancel);

                    btnsendreq.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            sendGroupRequest(groupListModel.getGrouplist().get(i).getId(),alertDialog);
                           // Toast.makeText(context, "Request sent to Admin Successfully.", Toast.LENGTH_SHORT).show();
                         //   builder.setMessage("Request sent to Admin Successfully.");
                            notifyDataSetChanged();
                        }
                    });

                    btncancel.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            alertDialog.dismiss();
                        }
                    });
                    // Showing Alert Message
                    final Window window = alertDialog.getWindow();
                    assert window != null;
                    alertDialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                    window.setBackgroundDrawableResource(R.color.colorTransparent);
                    window.setGravity(Gravity.CENTER);
                    alertDialog.show();
                  /*  final AlertDialog.Builder builder = new AlertDialog.Builder(context);
                  //  builder.setTitle("Interested in joining group?");
                    builder.setTitle(Html.fromHtml("Interested in joining group?"+"<b>"*//*+"World"+"</b>"*//*));
                    builder.setMessage("Are you from this community? And interested in joining your community marriage group? Then please ask your relatives (who is already a member of this group) to add you in this group or send your request to Admin, Just click the button below.");

                    builder.setPositiveButton("Send Request", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            sendGroupRequest(groupListModel.getGrouplist().get(i).getId(),dialog);
                            builder.setMessage("Request sent to Admin Successfully.");
                            notifyDataSetChanged();
                        }
                    });
                    builder.setNegativeButton(Html.fromHtml("<font color='#808080'>Cancel</font>"), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                            dialog.dismiss();
                        }
                    });
                    builder.show();*/
                }
            }
        });

        Utils.log(TAG, groupListModel.getGrouplist().get(i).getUrl() + groupListModel.getGrouplist().get(i).getPhoto());
        Glide.with(context)
                .load(groupListModel.getGrouplist().get(i).getUrl() + groupListModel.getGrouplist().get(i).getPhoto())
                .apply(RequestOptions.circleCropTransform())
                .into(holder.img);

        Utils.log("IMAGE_URL",groupListModel.getGrouplist().get(i).getUrl() + groupListModel.getGrouplist().get(i).getPhoto());

        holder.buttonViewOption.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //creating a popup menu
                PopupMenu popup = new PopupMenu(context, holder.buttonViewOption);
                //inflating menu from xml resource
                popup.inflate(R.menu.options_menu);
                if (groupListModel.getGrouplist().get(i).getGrptotal().equals("1")){
                    popup.getMenu().findItem(R.id.menu2).setTitle("Delete Group");
                    group_status = "Delete Group";
                }else {
                    popup.getMenu().findItem(R.id.menu2).setTitle("Leave Group");
                    group_status = "Leave Group";
                }
                //adding click listener
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.menu1:
                                context.startActivity(new Intent(context, UpdateGroupActivity.class).putExtra("title", groupListModel.getGrouplist().get(i).getTitle())
                                        .putExtra("gid", groupListModel.getGrouplist().get(i).getId()).putExtra("URL", groupListModel.getGrouplist().get(i).getUrl())
                                        .putExtra("photo", groupListModel.getGrouplist().get(i).getPhoto()));
                                break;
                            case R.id.menu2:
                                //handle menu2 click
                                final AlertDialog.Builder builder = new AlertDialog.Builder(context);
                                builder.setIcon(R.drawable.ic_remove_blue);
                                builder.setTitle(group_status);
                                builder.setMessage("Do you want to " +group_status+ " " + groupListModel.getGrouplist().get(i).getTitle() + " group?");

                                builder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        deleteGroup(dialog, i, groupListModel.getGrouplist().get(i).getId(), Utils.getString(context, Constants.USER_ID));
                                        notifyDataSetChanged();
                                    }
                                });
                                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.cancel();
                                        dialog.dismiss();
                                    }
                                });
                                builder.show();
                                break;
                        }
                        return false;
                    }
                });
                //displaying the popup
                popup.show();

            }
        });

    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return groupListModel.getGrouplist().size();
    }

    public interface GroupListener {
        void showHideText(String isDefault);
    }


    class MyViewHolder extends RecyclerView.ViewHolder {
        TextView lblgrptitle, txtgrpcount;
        LinearLayout lay_mygrp;
        ImageView img, buttonViewOption;

        MyViewHolder(View view) {
            super(view);
            lblgrptitle = view.findViewById(R.id.lblgrptitle);
            txtgrpcount = view.findViewById(R.id.txtgrpcount);
            lay_mygrp = view.findViewById(R.id.lay_mygrp);
            img = view.findViewById(R.id.imggrpicon);
            buttonViewOption = view.findViewById(R.id.buttonViewOption);
        }
    }

    private void deleteGroup(final DialogInterface dialog, final int i, final String gid, String rid) {
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("rid", rid);
        params.put("gid", gid);
        Utils.log(TAG, "DELETE_GROUP_URL : " + Constants.APP_MY_GROUP_DELETE + "?" + params);
        client.post(Constants.APP_MY_GROUP_DELETE, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                Utils.log(TAG, "DELETE_GROUP_RESPONSE : " + response);
                groupListModel.getGrouplist().remove(i);
                notifyItemChanged(i);
                notifyDataSetChanged();
                String success = "", message = "";
                try {
                    JSONObject res = new JSONObject(response);
                    success = res.getString("success");
                    message = res.getString("msg");
                    Log.d("API_RESPONSE", success);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (message.equals("Delete")) {
                    deleteGroupFinal(gid);
                } else {
                    Toast.makeText(context, group_status + " Successfully", Toast.LENGTH_SHORT).show();
                    context.startActivity(new Intent(context, Dashboard.class));
                }
                dialog.dismiss();
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "DELETE_GROUP_ERROR : " + error.getMessage());
            }
        });
    }

    public void deleteGroupFinal(String gid){
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        final RequestParams params = new RequestParams();
        params.put("rid", Utils.getString(context, Constants.USER_ID));
        params.put("gid", gid);
        Utils.log(TAG, "DELETE_GROUP_URL : " + Constants.Delete_Group_Final + "?" + params);
        client.post(Constants.Delete_Group_Final, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                Utils.log(TAG, "DELETE_GROUP_RESPONSE : " + response);
                String success = "", message = "";
                try {
                    JSONObject res = new JSONObject(response);
                    success = res.getString("success");
                    message = res.getString("message");
                    Log.d("API_RESPONSE",success);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                Toast.makeText(context, "Group Deleted Successfully", Toast.LENGTH_SHORT).show();
                context.startActivity(new Intent(context,Dashboard.class));
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "REMOVE_MEMBER_ERROR : " + error.getMessage());
                Toast.makeText(context, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void sendGroupRequest(String gid, final DialogInterface dialog){
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        final RequestParams params = new RequestParams();
        params.put("rid", Utils.getString(context, Constants.USER_ID));
        params.put("gid", gid);
        Utils.log(TAG, "SEND_GROUP_REQUEST_URL : " + Constants.SEND_GROUP_REQUEST + "?" + params);
        client.post(Constants.SEND_GROUP_REQUEST, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                Utils.log(TAG, "SEND_GROUP_REQUEST_RESPONSE : " + response);
                String success = "", message = "";
                try {
                    JSONObject res = new JSONObject(response);
                    success = res.getString("success");
                    message = res.getString("message");
                    Log.d("API_RESPONSE",success);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                dialog.dismiss();
                Toast.makeText(context, "Group request sent to Admin/Sub-Admin successfully.", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "\"SEND_GROUP_REQUEST_ERROR : " + error.getMessage());
                dialog.dismiss();
                Toast.makeText(context, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    
}
