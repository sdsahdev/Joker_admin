package com.suguretaventure.mymarriagegroup;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.common.NetworkConnetionState;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;

import cz.msebera.android.httpclient.Header;

public class GetTogetherRegister extends AppCompatActivity {
    private EditText txtgtrname, txtgtrdetail;
    private Button btnsendgtr;
    private Context ctx = this;
    private NetworkConnetionState connection;
    private ProgressDialog pDialog;
    private String reguid, desc;
    private String gtid;
    ActionBar toolbar;
    private FirebaseAnalytics mFirebaseAnalytics;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_together_register);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        getSupportActionBar().setTitle(getResources().getString(R.string.app_name_title));
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
//        setupToolbar();
        allocateMemory();

        if (connection.isNetworkAvailable(ctx)) {
            btnsendgtr.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    desc = txtgtrdetail.getText().toString();
                    reguid = Utils.getString(ctx, Constants.USER_ID);
                    if (desc.length() == 0) {
                        txtgtrdetail.setError("You have to specify with whom you come in get together bride or groom");
                    } else
                        registerInGT();
                }
            });
        } else {
            Toast.makeText(ctx, "No internet connection found. " +
                    "Please check your phone settings to turn on the internet.", Toast.LENGTH_LONG).show();
        }
    }

    private void registerInGT() {
        this.pDialog = new ProgressDialog(this);
        this.pDialog.setMessage("Sending...");
        this.pDialog.setCancelable(false);
        showpDialog();

        String url = Common.GetWebServiceUrl() + "gt_register.php";
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("gtid", gtid);
        params.put("detail", desc);
        params.put("regid", reguid);
        client.post(url, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                try {
                    JSONArray response = new JSONArray(res);
                    String error = response.getJSONObject(0).getString("error");
                    if (error.equals("no error") == false) {
                        Common.showDialog(ctx, error);
                    } else {
                        String success = response.getJSONObject(1).getString("success");
                        String message = response.getJSONObject(2).getString("message");
                        Toast.makeText(ctx, message, Toast.LENGTH_LONG).show();
                        if (success.equals("yes") == true) {
                            finish();
                        }
                    }
                    hidePDialog();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Common.showDialog(ctx);
                hidePDialog();
            }
        });
    }

    private void allocateMemory() {
        connection = new NetworkConnetionState();
        txtgtrname = findViewById(R.id.txtgtrname);
        txtgtrdetail = findViewById(R.id.txtgtrdesc);
        btnsendgtr = findViewById(R.id.btnsendgtr);
        gtid = getIntent().getExtras().getString("gtid");
        txtgtrname.setEnabled(false);
        txtgtrname.setText(Utils.getString(ctx, Constants.USER_NAME).toUpperCase());
        txtgtrdetail.requestFocus();
    }

    // show process Dialog box
    private void showpDialog() {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }

    // hide process Dialog box
    private void hidePDialog() {
        if (this.pDialog != null) {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }

    public void setupToolbar() {
        toolbar = getSupportActionBar();
        assert toolbar != null;
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (android.R.id.home == item.getItemId()) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
