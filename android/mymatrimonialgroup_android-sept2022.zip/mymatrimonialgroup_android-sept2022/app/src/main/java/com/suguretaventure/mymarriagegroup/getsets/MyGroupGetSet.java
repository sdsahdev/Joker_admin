package com.suguretaventure.mymarriagegroup.getsets;

/**
 * Created by ankitpatel on 29/03/19.
 */

public class MyGroupGetSet
{
    private String grpname,grpcount,grpid;

    public String getGrpid() {
        return grpid;
    }

    public void setGrpid(String grpid) {
        this.grpid = grpid;
    }

    public String getGrpname() {
        return grpname;
    }

    public void setGrpname(String grpname) {
        this.grpname = grpname;
    }

    public String getGrpcount() {
        return grpcount;
    }

    public void setGrpcount(String grpcount) {
        this.grpcount = grpcount;
    }
}
