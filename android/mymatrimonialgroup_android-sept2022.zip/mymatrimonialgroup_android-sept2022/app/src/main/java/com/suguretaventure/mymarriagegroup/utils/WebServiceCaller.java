package com.suguretaventure.mymarriagegroup.utils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.suguretaventure.mymarriagegroup.Model.AddGroupModel;
import com.suguretaventure.mymarriagegroup.Model.CheckId;
import com.suguretaventure.mymarriagegroup.Model.GroupListModel;
import com.suguretaventure.mymarriagegroup.Model.MarketAddPersonModel;
import com.suguretaventure.mymarriagegroup.Model.MarketingPesrsonModel;
import com.suguretaventure.mymarriagegroup.Model.PesonDetailsModel;
import com.suguretaventure.mymarriagegroup.Model.PreForgotResponse;
import com.suguretaventure.mymarriagegroup.Model.Profile;
import com.suguretaventure.mymarriagegroup.Model.RegisterModel;

import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Headers;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

public class WebServiceCaller {

    private static WebServiceApiInterface webApiInterface;

    public static WebServiceApiInterface getClient() {
        if (webApiInterface == null) {
            HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
            logging.setLevel(HttpLoggingInterceptor.Level.BODY);
            OkHttpClient okclient = new OkHttpClient.Builder()
                    .addInterceptor(logging)
                    .connectTimeout(10, TimeUnit.MINUTES)
                    .readTimeout(10, TimeUnit.MINUTES)
                    .writeTimeout(10, TimeUnit.MINUTES)
                    .build();
            Gson gson = new GsonBuilder()
                    .setDateFormat("yyyy-MM-dd'T'HH:mm:ssZ")
                    .create();

            Retrofit client = new Retrofit.Builder()
                    .baseUrl("https://mymarriagegroup.com/ws2/demo/")
                    .client(okclient)
                    .addConverterFactory(GsonConverterFactory.create(gson))
                    .build();
            webApiInterface = client.create(WebServiceApiInterface.class);
        }
        return webApiInterface;
    }


    public interface WebServiceApiInterface {

        /*  @GET("get_category.php")
          Call<CategoryModel> getCategoryModelCall(

          );*/

        @Multipart
        @POST("registerm.php")
        Call<RegisterModel> getRegisterModelCall(@Part MultipartBody.Part image
                ,@Part("fname") RequestBody fname
                , @Part("surname") RequestBody surname
                , @Part("email") RequestBody email
                , @Part("mobile") RequestBody mobile
                /*, @Part("gender") RequestBody gender*/
                , @Part("password") RequestBody password
                , @Part("code") RequestBody code
        );

        @FormUrlEncoded
        @POST("loginm.php")
        Call<RegisterModel> getlogin(
                @Field(value = "mobile", encoded = true) String mobile,
                @Field(value = "password", encoded = true) String password
        );


        @FormUrlEncoded
        @POST("save_device_token.php")
        Call<RegisterModel> saveDeviceToken(
                @Field(value = "id") String id,
                @Field(value = "device_token") String device_token
        );


        @FormUrlEncoded
        @POST("biodata_request.php")
        Call<RegisterModel> send_request(
                @Field(value = "bid") String bid,
                @Field(value = "ids") StringBuffer ids
        );

        @FormUrlEncoded
        @POST("bio_req_send.php")
        Call<RegisterModel> sendRequest(
                @Field(value = "rid") String rid,
                @Field(value = "bid") String bid
        );

        @FormUrlEncoded
        @POST("bio_req_send_new_1")
        Call<RegisterModel> sendRequest_from(
                @Field(value = "rid") String rid,
                @Field(value = "bid") String bid,
                @Field(value = "from_bid") String from_bid

        );

        @FormUrlEncoded
        @POST("bio_req_send_new.php")
        Call<RegisterModel> sendRequest1(
                @Field(value = "rid") String rid,
                @Field(value = "bid") String bid,
                @Field(value = "from_bio_id") String from_bio_id
        );


        @FormUrlEncoded
        @POST("get_my_list.php")
        Call<RegisterModel> verifiedBioList(
                @Field(value = "rid") String rid
        );

        @FormUrlEncoded
        @POST("delete_marketing.php")
        Call<RegisterModel> deleteMarket(
                @Field(value = "id") String id,
                @Field(value = "photo") String photo
        );

        @Multipart
        @POST("add_marketing.php")
        Call<MarketAddPersonModel> marketAddPersonModelCall(@Part MultipartBody.Part image
                ,@Part MultipartBody.Part image1
                ,@Part MultipartBody.Part image2
                , @Part("cid") RequestBody cid
                , @Part("rid") RequestBody rid
                , @Part("name") RequestBody name
                , @Part("address") RequestBody address
                , @Part("mobile") RequestBody mobile
                , @Part("email") RequestBody email
                , @Part("description") RequestBody description
                , @Part("lat") RequestBody lat
                , @Part("lon") RequestBody lon
                , @Part("city") RequestBody city
                , @Part("pay_id") RequestBody pay_id
                , @Part("website") RequestBody website
        );

        @Multipart
        @POST("update_marketing.php")
        Call<MarketAddPersonModel> marketUpdatePersonModelCall(@Part MultipartBody.Part image
                ,@Part MultipartBody.Part image1
                ,@Part MultipartBody.Part image2
                , @Part("id") RequestBody id
                , @Part("oldimage") RequestBody oldimage
                , @Part("oldimage1") RequestBody oldimage1
                , @Part("oldimage2") RequestBody oldimage2
                , @Part("name") RequestBody name
                , @Part("address") RequestBody address
                , @Part("mobile") RequestBody mobile
                , @Part("email") RequestBody email
                , @Part("description") RequestBody description
                , @Part("lat") RequestBody lat
                , @Part("lon") RequestBody lon
                , @Part("city") RequestBody city
                , @Part("cid") RequestBody cid
                , @Part("website") RequestBody website
                , @Part("pay_status") RequestBody pay_status
        );

        @FormUrlEncoded
        @POST("get_marketing.php")
        Call<MarketingPesrsonModel> getMarketingPesrsonModelCall(
                @Field(value = "cid", encoded = true) String cid
        );

        @FormUrlEncoded
        @POST("myprofile.php")
        Call<Profile> getProfileCall(@Field(value = "rid", encoded = true) String rid
        );

        @FormUrlEncoded
        @POST("preforgotpassword.php")
        Call<PreForgotResponse> getPreForgotCall(@Field(value = "mobile", encoded = true) String mobile
        );

        @Multipart
        @POST("add_new_group.php")
        Call<AddGroupModel> addGroupModelCall(@Part MultipartBody.Part image
                , @Part("rid") RequestBody rid
                , @Part("title") RequestBody title

        );

        @Multipart
        @POST("update_group.php")
        Call<AddGroupModel> updateGroupModelCall(@Part MultipartBody.Part image
                , @Part("gid") RequestBody rid
                , @Part("title") RequestBody title
                , @Part("oldimg") RequestBody oldImg
        );


        @Multipart
        @POST("register_update.php")
        Call<AddGroupModel> updateProfileCall(@Part MultipartBody.Part image
                , @Part MultipartBody.Part aimage
                , @Part("rid") RequestBody rid
                , @Part("fname") RequestBody fname
                , @Part("surname") RequestBody surname
                , @Part("email") RequestBody email
                , @Part("oldimage") RequestBody oldimg
                , @Part("oldaimage") RequestBody oldaimg
        );

        @FormUrlEncoded
        @POST("my_groups.php")
        Call<GroupListModel> getGroupListModelCall(
                @Field(value = "rid", encoded = true) String cid
        );

        @FormUrlEncoded
        @POST("my_groups_list.php")
        Call<GroupListModel> getMyGroupsModelCall(
                @Field(value = "rid", encoded = true) String cid
        );

        //BIO-DATA List
        @FormUrlEncoded
        @POST("list.php")
        Call<PesonDetailsModel> getPesonDetailsModelCall(
                @Field(value = "mygroupid", encoded = true) String mygroupid
        );

        @FormUrlEncoded
        @POST("check_email.php")
        Call<CheckId> getCheckEmailModelCall(@Field("email") RequestBody email);

        @FormUrlEncoded
        @POST("check_mobile.php")
        Call<CheckId> getCheckMobileModelCall(@Field("mobile") RequestBody mobile);


        @Multipart
        @POST("register_update.php")
        Call<AddGroupModel> updateLoginCall(@Part("rid") RequestBody rid
                , @Part("fname") RequestBody fname
                , @Part("surname") RequestBody surname
                , @Part("email") RequestBody email
                , @Part("password") RequestBody password

        );

    }
}

//                    .baseUrl("http://sailaser.com/marriage/ws/")
//                    .baseUrl("http://isparrowsolutions.com/NGO/APIE/")