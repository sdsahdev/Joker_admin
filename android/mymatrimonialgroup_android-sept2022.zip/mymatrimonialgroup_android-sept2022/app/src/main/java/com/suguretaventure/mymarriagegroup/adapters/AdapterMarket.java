package com.suguretaventure.mymarriagegroup.adapters;

import android.content.Context;
import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.suguretaventure.mymarriagegroup.MarketingPerson;
import com.suguretaventure.mymarriagegroup.Model.MarketingModel;
import com.suguretaventure.mymarriagegroup.R;

import java.util.ArrayList;

public class AdapterMarket extends RecyclerView.Adapter<AdapterMarket.ViewHolder> implements Filterable {

    private Context activity;
    MarketingModel model;
    ArrayList<MarketingModel.DATA> marketModelsFiltered;

    public AdapterMarket(Context activity, MarketingModel model) {
        this.model = model;
        this.activity = activity;
        this.marketModelsFiltered = model.data;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemView = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.layout_market_category, viewGroup, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder viewHolder, final int i) {
        viewHolder.tvName.setText(model.data.get(i).cname);
        /*viewHolder.imgCategory.setImageResource(marketModels.get(i).getImgUrl());*/
        Glide.with(activity).load(model.data.get(i).icon).into(viewHolder.imgCategory);
        viewHolder.mainCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(activity, MarketingPerson.class);
                intent.putExtra("cid", model.data.get(i).cid);
                intent.putExtra("cname", model.data.get(i).cname);
                activity.startActivity(intent);
                //  Toast.makeText(activity, "This Work Remaining !!", Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return model.data.size();
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                if (charString.isEmpty()) {
                    marketModelsFiltered = model.data;
                } else {
                    ArrayList<MarketingModel.DATA> filteredList = new ArrayList<>();

                    for (MarketingModel.DATA row : model.data) {
                        // name match condition. this might differ depending on your requirement
                        // here we are looking for name or phone number match
                        if (row.cname.toLowerCase().contains(charString.toLowerCase())) {
                            filteredList.add(row);
                        }
                    }
                    marketModelsFiltered = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = marketModelsFiltered;

                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                marketModelsFiltered = (ArrayList<MarketingModel.DATA>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgCategory;
        CardView mainCard;
        TextView tvName;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgCategory = itemView.findViewById(R.id.imgCategory);
            mainCard = itemView.findViewById(R.id.mainCard);
            tvName = itemView.findViewById(R.id.tvName);
        }
    }
}
