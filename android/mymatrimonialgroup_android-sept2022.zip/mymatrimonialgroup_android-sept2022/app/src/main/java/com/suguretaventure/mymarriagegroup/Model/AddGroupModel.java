package com.suguretaventure.mymarriagegroup.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AddGroupModel {
    @SerializedName("success")
    @Expose
    private Boolean success;

    @SerializedName("msg")
    @Expose
    private String msg;

    @SerializedName("gid")
    @Expose
    private String gid;

    @SerializedName("photoid")
    @Expose
    private String photoid;

    public String getPhotoid() {
        return photoid;
    }

    public void setPhotoid(String photoid) {
        this.photoid = photoid;
    }

    public String getGid() {
        return gid;
    }

    public void setGid(String gid) {
        this.gid = gid;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
