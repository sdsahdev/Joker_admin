package com.suguretaventure.mymarriagegroup;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.suguretaventure.mymarriagegroup.adapters.GTRegListAdapter;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.common.NetworkConnetionState;
import com.suguretaventure.mymarriagegroup.getsets.GTRegListGetSet;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import cz.msebera.android.httpclient.Header;

public class GetTogetherDetail extends AppCompatActivity {
    private TextView lblgtdtitle, lblgtddetail, lblgtddt, lblgtdvenue;
    private Context ctx = this;
    private ListView gt_reguserlist;
    NetworkConnetionState connection;
    private String gtid;
    private ProgressDialog pDialog;
    private ArrayList<GTRegListGetSet> arr_adapter = new ArrayList<>();
    private GTRegListAdapter gtrAdapter;
    private GTRegListGetSet gtrGetSet;
    ActionBar toolbar;
    private FirebaseAnalytics mFirebaseAnalytics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_together_detail);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(getResources().getString(R.string.app_name_title));
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
//        setupToolbar();
        allocateMemory();
        setData();
    }

    private void setData() {
        if (connection.isNetworkAvailable(ctx)) {
            getData();
        } else {
            Toast.makeText(ctx, "No internet connection found. " + "Please check your phone settings to turn on the internet.", Toast.LENGTH_LONG).show();
        }
    }

    private void getData() {
        this.pDialog = new ProgressDialog(this);
        this.pDialog.setMessage("Sending...");
        this.pDialog.setCancelable(false);
        showpDialog();
        String url = Common.GetWebServiceUrl() + "gt_regu_list.php";
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("gtid", gtid);
        client.post(url, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                try {
                    JSONArray response = new JSONArray(res);
                    String error = response.getJSONObject(0).getString("error");
                    if (error.equals("no error") == false) {
                        Common.showDialog(ctx, error);
                    } else {
                        Integer total = response.getJSONObject(1).getInt("total");
                        if (total == 0) {
                            Toast.makeText(ctx, "No registered users found", Toast.LENGTH_LONG).show();
                        } else {
                            JSONObject obj = response.getJSONObject(2);
                            String inputPattern = "yyyy-MM-dd hh:mm:ss";
                            String outputPattern = "dd-MMM-yyyy hh:mm";
                            SimpleDateFormat inputFormat = new SimpleDateFormat(inputPattern);
                            SimpleDateFormat outputFormat = new SimpleDateFormat(outputPattern);
                            Date date = null;
                            String str = null;
                            try {
                                date = inputFormat.parse(obj.getString("gdatetime"));
                                str = outputFormat.format(date);
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }

                            lblgtdtitle.setText(obj.getString("title"));
                            lblgtddetail.setText(obj.getString("detail"));
                            lblgtddt.setText(str);
                            lblgtdvenue.setText("Venue: " + obj.getString("venue"));

                            int co = 1;
                            for (int i = 3; i < response.length(); i++) {
                                JSONObject ob = response.getJSONObject(i);
                                gtrGetSet = new GTRegListGetSet();
                                gtrGetSet.setGtrno("" + co);
                                gtrGetSet.setGtrname(ob.getString("name"));
                                arr_adapter.add(gtrGetSet);
                                co++;
                            }
                        }
                        hidePDialog();
                        gtrAdapter = new GTRegListAdapter(ctx, arr_adapter);
                        gt_reguserlist.setAdapter(gtrAdapter);
                    }
                    hidePDialog();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Common.showDialog(ctx);
                hidePDialog();
            }
        });
    }

    private void allocateMemory() {
        connection = new NetworkConnetionState();
        lblgtdtitle = findViewById(R.id.lblgtdtitle);
        lblgtddetail = findViewById(R.id.lblgtddetail);
        lblgtddt = findViewById(R.id.lblgtddt);
        lblgtdvenue = findViewById(R.id.lblgtdvenue);
        gt_reguserlist = findViewById(R.id.gt_reguserlist);

        gtid = getIntent().getExtras().getString("gtid");
    }

    // show process Dialog box
    private void showpDialog() {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }

    // hide process Dialog box
    private void hidePDialog() {
        if (this.pDialog != null) {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }

    public void setupToolbar() {
        toolbar = getSupportActionBar();
        assert toolbar != null;
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (android.R.id.home == item.getItemId()) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
