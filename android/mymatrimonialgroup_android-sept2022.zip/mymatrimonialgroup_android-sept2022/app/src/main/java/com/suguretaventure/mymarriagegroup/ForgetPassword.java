package com.suguretaventure.mymarriagegroup;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.common.NetworkConnetionState;

import org.json.JSONArray;
import org.json.JSONException;

import cz.msebera.android.httpclient.Header;

public class ForgetPassword extends AppCompatActivity {
    private Context ctx = this;
    private EditText txtfgtemail,txtmobileno;
    private TextView btnsendpwd,btncancel;
    private String email;
    private String mobileno;
    private NetworkConnetionState connection;
    private ProgressDialog pDialog;
    ActionBar toolbar;
    private FirebaseAnalytics mFirebaseAnalytics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(getResources().getString(R.string.app_name_title));
        allocateMemory();
//        setupToolbar();
        btnsendpwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ValidateInput()==true)
                {
                    if(connection.isNetworkAvailable(ctx))
                    {
                        sendEmail();
                    }
                    else
                    {
                        Toast.makeText(ctx, "No internet connection found. Please check your phone settings to turn on the internet.", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
    }

    private void sendEmail() {
        pDialog = new ProgressDialog(ctx);
        pDialog.setMessage("Please wait...");
        pDialog.setCancelable(false);
        showpDialog();

        String WebServiceUrl = Common.GetWebServiceUrl() + "forgotpassword.php";
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("email",email);
     //   params.put("mobileno",mobileno);
        client.post(WebServiceUrl, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                try
                {
                    JSONArray response = new JSONArray(res);
                    String error = response.getJSONObject(0).getString("error");
                    if(error.equals("no error")==false)
                    {
                        hidePDialog();
                        Common.showDialog(ctx,error);
                    }
                    else
                    {
                        //no error
                        String success = response.getJSONObject(1).getString("success");
                        String message = response.getJSONObject(2).getString("message");
                        Toast.makeText(ctx,message,Toast.LENGTH_LONG).show();
                        if(success.equals("yes")==true)
                        {
                            finish();
                        }
                        hidePDialog();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                hidePDialog();
                Common.showDialog(ctx);
            }
        });
    }

    private void allocateMemory() {
        connection = new NetworkConnetionState();
        txtfgtemail = findViewById(R.id.txtfgtemail);
        txtmobileno = findViewById(R.id.txtmobileno);
        btnsendpwd = findViewById(R.id.btnsendpwd);
    }

    public boolean ValidateInput()
    {
        boolean isvalid = true;
        email = txtfgtemail.getText().toString().trim().toLowerCase();
        mobileno = txtmobileno.getText().toString().trim();

        if(email.length()==0)
        {
            isvalid=false;
            txtfgtemail.setError("Email required");
        }
        return isvalid;
    }

    private void showpDialog()
    {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }

    // hide process Dialog box
    private void hidePDialog()
    {
        if (this.pDialog != null)
        {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }

    public void setupToolbar(){
        toolbar = getSupportActionBar();
        assert toolbar != null;
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (android.R.id.home == item.getItemId()){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
