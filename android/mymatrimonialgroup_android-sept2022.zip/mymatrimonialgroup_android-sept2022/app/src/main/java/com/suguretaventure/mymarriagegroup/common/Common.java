package com.suguretaventure.mymarriagegroup.common;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

public class Common {
    //private static final String HOST = "http://192.168.1.124:8888/";
//    private static final String HOST = "http://universalnewspapers.com/";
    public static final String emailPattern = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$\n";
    //    private static final String HOST = "http://sailaser.com/";
    private static String HOST = "https://mymarriagegroup.com/";

    public static String GetBaseUrl() {
        return HOST + "";
    }

    public static String GetWebServiceUrl() {
        return GetBaseUrl() + "ws2/demo/";
    }

    public static String GetProfileImageUrl() {
        return GetBaseUrl() + "jowbcsjfos/jnasdfjnjs/";
    }

    public static String GetRegUserIDImageUrl() {
        return GetBaseUrl() + "jowbcsjfos/oejdnalfjr/";
    }
    public static String GetRegUserAddressImageUrl() {
        return GetBaseUrl() + "jowbcsjfos/ehfksjvoab/";
    }

    public static String GetOccIcon() {
        return GetBaseUrl() + "jowbcsjfos/pwefjisjfo/";
    }

    public static void showDialog(Context ctx) {
        AlertDialog.Builder b1 = new AlertDialog.Builder(ctx);
        b1.setTitle("Warning Message");
        b1.setMessage("Make sure you are connected with internet");
        b1.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        b1.create().show();
    }

    public static void showforgotDialog(Context ctx) {
        AlertDialog.Builder b1 = new AlertDialog.Builder(ctx);
        b1.setTitle("Warning Message");
        b1.setMessage("Number not registered. Please register first.");
        b1.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        b1.create().show();
    }

    public static void showBioDataDialog(Context ctx, String msg) {
        AlertDialog.Builder b1 = new AlertDialog.Builder(ctx);
        b1.setTitle("Warning Message");
        b1.setMessage(msg);
        b1.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        b1.create().show();
    }

    public static void showDialog(Context ctx, String msg) {
        AlertDialog.Builder b1 = new AlertDialog.Builder(ctx);
        b1.setTitle("Error");
        b1.setMessage(msg);
        b1.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        b1.create().show();
    }
}
