package com.suguretaventure.mymarriagegroup.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class GroupListModel {
    @SerializedName("grouplist")
    @Expose
    private List<Grouplist> grouplist = null;

    public List<Grouplist> getGrouplist() {
        return grouplist;
    }

    @SerializedName("user_data")
    public Members.Member members;

    @SerializedName("0")
    String[] zero;
    @SerializedName("1")
    String one;

    public void setGrouplist(List<Grouplist> grouplist) {
        this.grouplist = grouplist;
    }

    public class Grouplist {

        @SerializedName("id")
        @Expose
        private String id;
        @SerializedName("title")
        @Expose
        private String title;
        @SerializedName("url")
        @Expose
        private String url;
        @SerializedName("photo")
        @Expose
        private String photo;

        @SerializedName("male")
        private String male;
        @SerializedName("female")
        private String female;

        @SerializedName("isDefault")
        private String isDefault;

        @SerializedName("isAdmin")
        private int isAdmin;

        @SerializedName("isSubadmin")
        private int isSubadmin;

        public int getIsAdmin() {
            return isAdmin;
        }

        public void setIsAdmin(int isAdmin) {
            this.isAdmin = isAdmin;
        }

        public int getIsSubadmin() {
            return isSubadmin;
        }

        public void setIsSubadmin(int isSubadmin) {
            this.isSubadmin = isSubadmin;
        }

        public String getIsDefault() {
            return isDefault;
        }

        public void setIsDefault(String isDefault) {
            this.isDefault = isDefault;
        }

        public String getMale() {
            return male;
        }

        public void setMale(String male) {
            this.male = male;
        }

        public String getFemale() {
            return female;
        }

        public void setFemale(String female) {
            this.female = female;
        }

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }

        @SerializedName("cdate")
        @Expose
        private String cdate;
        @SerializedName("grptotal")
        @Expose
        private String grptotal;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getPhoto() {
            return photo;
        }

        public void setPhoto(String photo) {
            this.photo = photo;
        }

        public String getCdate() {
            return cdate;
        }

        public void setCdate(String cdate) {
            this.cdate = cdate;
        }

        public String getGrptotal() {
            return grptotal;
        }

        public void setGrptotal(String grptotal) {
            this.grptotal = grptotal;
        }

    }
}
