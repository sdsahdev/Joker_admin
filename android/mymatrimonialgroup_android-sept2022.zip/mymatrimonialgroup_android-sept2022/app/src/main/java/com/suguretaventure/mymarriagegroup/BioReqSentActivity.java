package com.suguretaventure.mymarriagegroup;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.suguretaventure.mymarriagegroup.Model.Members;
import com.suguretaventure.mymarriagegroup.adapters.ReqApprovalAdapter;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utils;

import cz.msebera.android.httpclient.Header;

public class BioReqSentActivity extends AppCompatActivity {
    String rid, bid;
    RecyclerView rcvRequest;
    Members details;
    private Context context = this;
    TextView lblemptygrp;
    private FirebaseAnalytics mFirebaseAnalytics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Request Sent For Approval");
        setContentView(R.layout.activity_bio_req_sent);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        rid = getIntent().getStringExtra("rid");
        bid = getIntent().getStringExtra("bid");
        rcvRequest = findViewById(R.id.rcvRequest);
        lblemptygrp = findViewById(R.id.lblemptygrp);
        lblemptygrp.setText(Html.fromHtml(Constants.INVITATION_SENT_BIO));
        getReqList(rid, bid);
    }

    private void getReqList(String rid, String bid) {
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("rid", rid);
        params.put("bid", bid);
        client.post(Constants.Bio_Approval_Sent, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                Log.d("RESPONSE_LIST", response);

                details = new Gson().fromJson(response, Members.class);
                if (details.members.size() != 0){
                    rcvRequest.setVisibility(View.VISIBLE);
                    rcvRequest.setLayoutManager(new LinearLayoutManager(context));
                    rcvRequest.setAdapter(new ReqApprovalAdapter(details, context));
                }else {
                    rcvRequest.setVisibility(View.GONE);
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Log.d("RESPONSE_LIST", error.getMessage());
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_invitation, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        int id = item.getItemId();
        if (id == R.id.dashboard) {
            startActivity(new Intent(context, Dashboard.class));
        }else if (id == R.id.myGroup) {
            startActivity(new Intent(context, MyGroup.class));
        } else if (id == R.id.myPost) {
            startActivity(new Intent(context, MyPosts.class)
                    .putExtra("from", "dashboard")
                    .putExtra("gender", "-1"));
        } else if (id == R.id.MyFav_Arc) {
            startActivity(new Intent(context, MyFav_Arc.class)
                    .putExtra("from", "dashboard_fav"));
        } else if (id == R.id.myarchieved) {
            startActivity(new Intent(context, MyFav_Arc.class)
                    .putExtra("from", "dashboard_arc"));
        } else if (id == R.id.logout) {
            final AlertDialog alertDialog = new AlertDialog.Builder(context).create();
            alertDialog.setMessage("Are you sure you want to logout ?");
            alertDialog.setButton(DialogInterface.BUTTON_POSITIVE, "Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    String FCM_KEY = "" + Utils.getString(context, Constants.TOKEN);
                    Utils.clearPreference(context);
                    Utils.setString(context, Constants.TOKEN, FCM_KEY);
                    startActivity(new Intent(context, Login.class));
                    finish();
                }
            });
            alertDialog.setButton(DialogInterface.BUTTON_NEGATIVE, "No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    alertDialog.dismiss();
                }
            });
            alertDialog.show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}