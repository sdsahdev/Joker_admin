package com.suguretaventure.mymarriagegroup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.suguretaventure.mymarriagegroup.Model.Members;
import com.suguretaventure.mymarriagegroup.Model.RegisterModel;
import com.suguretaventure.mymarriagegroup.adapters.MemberRequestAdapter;
import com.suguretaventure.mymarriagegroup.adapters.PersonAdapter;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.getsets.PersonGetSet;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utils;
import com.suguretaventure.mymarriagegroup.utils.WebServiceCaller;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;
import retrofit2.Call;
import retrofit2.Callback;

public class SendInvitationActivity extends AppCompatActivity {


    RecyclerView rvBiodataList;
    private ProgressDialog pDialog;
    private ArrayList<PersonGetSet> arr_adapter = new ArrayList<>();
    private String TAG = "SEND_INVITATION";
    private PersonGetSet personGetSet;
    private  TextView tvEmptyView;
    BiodataListAdapter memberRequestAdapter;
    TextView btnSendSelfInv;

    Bundle bundle;
    private FirebaseAnalytics mFirebaseAnalytics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_verified);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);

        getSupportActionBar().setTitle("Select biodata");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        bundle = getIntent().getExtras();

        rvBiodataList = findViewById(R.id.rcvMemberList);
        tvEmptyView = findViewById(R.id.tvEmptyView);
        btnSendSelfInv = findViewById(R.id.btnSendSelfInv);
        btnSendSelfInv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendSelfRequest();
            }
        });
        getMyPosts();
    }

    // show process Dialog box
    private void showpDialog() {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }

    // hide process Dialog box
    private void hidePDialog() {
        if (this.pDialog != null) {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }

    public void getMyPosts() {
        pDialog = new ProgressDialog(this);
        pDialog.setMessage("Please wait...");
        pDialog.setCancelable(false);
        showpDialog();
        String WebServiceUrl = Common.GetWebServiceUrl() + "person_list.php";

        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        RequestParams params = new RequestParams();
        params.put("rid", Utils.getString(this, Constants.USER_ID));
        params.put("gender", "-1");
        client.post(WebServiceUrl, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                Log.d("trace response", res);
                try {
                    JSONArray response = new JSONArray(res);
                    String error = response.getJSONObject(0).getString("error");
                    if (error.equals("no error") == false) {
                        Common.showDialog(SendInvitationActivity.this);
                    } else {
                        arr_adapter.clear();
                        int total = response.getJSONObject(1).getInt("total");
                        if (total == 0) {
                            tvEmptyView.setVisibility(View.VISIBLE);
                            tvEmptyView.setText("No Result Found of Approved Biodatas");
                            rvBiodataList.setVisibility(View.GONE);
                            /*rcvpersonlist.setVisibility(View.GONE);
                            lblempty_biodata.setVisibility(View.VISIBLE);
                            lbl_nodata.setVisibility(View.VISIBLE);*/
                        } else {
                          /*  lblempty_biodata.setVisibility(View.GONE);
                            lbl_nodata.setVisibility(View.GONE);*/
                            int size = response.length();
                            for (int i = 2; i < size; i++) //3
                            {


                                JSONObject object = response.getJSONObject(i);
                                if (object.getString("verified").equals("1")) {
                                    personGetSet = new PersonGetSet();
                                    personGetSet.setId(object.getString("id"));
                                    personGetSet.setName(object.getString("name"));
                                    personGetSet.setAge(object.getString("age"));
                                    personGetSet.setEducation(object.getString("edu"));
                                    personGetSet.setOccupation(object.getString("occu"));
                                    personGetSet.setImage(object.getString("photo"));
                                    personGetSet.setVerified(object.getString("verified"));
                                    personGetSet.setGender(object.getString("gen"));
                                    personGetSet.setPay_date(object.getString("pay_date"));
                                    personGetSet.setRid_name(object.getString("rid_name"));
                                    arr_adapter.add(personGetSet);
                                }
                            }
                            hidePDialog();

                            if (arr_adapter.size()>0) {
                                memberRequestAdapter = new BiodataListAdapter(SendInvitationActivity.this, arr_adapter);
                                rvBiodataList.setLayoutManager(new LinearLayoutManager(SendInvitationActivity.this));
                                rvBiodataList.setAdapter(memberRequestAdapter);
                            }else{
                                tvEmptyView.setVisibility(View.VISIBLE);
                                tvEmptyView.setText("No Result Found of Approved Biodatas");
                                rvBiodataList.setVisibility(View.GONE);
                            }
                        }
                        hidePDialog();
                    }
                    hidePDialog();

                } catch (JSONException e) {
                    hidePDialog();
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

            }
        });
    }


    public void sendSelfRequest() {
        pDialog = new ProgressDialog(this);
        pDialog.setMessage("Please wait...");
        pDialog.setCancelable(false);
        showpDialog();
        WebServiceCaller.getClient().sendRequest(Utils.getString(this, Constants.USER_ID), bundle.getString("bid")).enqueue(new Callback<RegisterModel>() {
            @Override
            public void onResponse(Call<RegisterModel> call, retrofit2.Response<RegisterModel> response) {
                if (response.isSuccessful()) {
                    String res = new String(String.valueOf(response));
                    Utils.log(TAG, "RESPONSE  : " + res);
                    RegisterModel registerModel;
                    registerModel = response.body();
                    if (registerModel.getSuccess()) {
                        Toast.makeText(SendInvitationActivity.this, "Request Sent Successful", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(SendInvitationActivity.this, InvitationSent.class)
                                .putExtra("from", "dashboard_invitation_sent"));

                    } else {
                        Toast.makeText(SendInvitationActivity.this, registerModel.getMsg(), Toast.LENGTH_SHORT).show();

                    }
                }
                hidePDialog();

            }

            @Override
            public void onFailure(Call<RegisterModel> call, Throwable t) {
                //swipeContainer.setRefreshing(false)
                //
                hidePDialog();
                Log.d("Error_Message", t.getMessage());

                Toast.makeText(SendInvitationActivity.this, "Server Error  :   " + t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }


    public void sendRequest( String b_from_id) {
        pDialog = new ProgressDialog(this);
        pDialog.setMessage("Please wait...");
        pDialog.setCancelable(false);
        showpDialog();
        WebServiceCaller.getClient().sendRequest1(Utils.getString(this, Constants.USER_ID), bundle.getString("bid"),b_from_id).enqueue(new Callback<RegisterModel>() {
            @Override
            public void onResponse(Call<RegisterModel> call, retrofit2.Response<RegisterModel> response) {
                if (response.isSuccessful()) {
                    String res = new String(String.valueOf(response));
                    Utils.log(TAG, "RESPONSE  : " + res);
                    RegisterModel registerModel;
                    registerModel = response.body();
                    if (registerModel.getSuccess()) {
                        Toast.makeText(SendInvitationActivity.this, "Request Sent Successful", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(SendInvitationActivity.this, InvitationSent.class)
                                .putExtra("from", "dashboard_invitation_sent"));

                    } else {
                        Toast.makeText(SendInvitationActivity.this, registerModel.getMsg(), Toast.LENGTH_SHORT).show();

                    }
                }
                hidePDialog();

            }

            @Override
            public void onFailure(Call<RegisterModel> call, Throwable t) {
                //swipeContainer.setRefreshing(false)
                //
                hidePDialog();
                Log.d("Error_Message", t.getMessage());

                Toast.makeText(SendInvitationActivity.this, "Server Error  :   " + t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull @NotNull MenuItem item) {
        if (item.getItemId() == android.R.id.home){
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    static class BiodataListAdapter extends RecyclerView.Adapter<BiodataListAdapter.ViewHolder> {
        private Context context;
        private ArrayList<PersonGetSet> arr_adapter;

        public BiodataListAdapter(Context context, ArrayList<PersonGetSet> arr_adapter) {
            this.context = context;
            this.arr_adapter = arr_adapter;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
            View view = layoutInflater.inflate(R.layout.list_item_biodata, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, final int i) {


            SimpleDateFormat fromUser = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            SimpleDateFormat myFormat = new SimpleDateFormat("MMM dd, yyyy");
            String reformattedStr = "";
            try {

                reformattedStr = myFormat.format(fromUser.parse(arr_adapter.get(i).getPay_date()));
            } catch (ParseException e) {
                e.printStackTrace();
            }

            holder.lblpersonname.setText(arr_adapter.get(i).getName());
            holder.lblpersonedu.setText(arr_adapter.get(i).getEducation());
            holder.lblpersonocu.setText(arr_adapter.get(i).getOccupation());
            holder.lblpersonage.setText("Age: " + arr_adapter.get(i).getAge());

            Glide.with(context)
                    .load(Common.GetProfileImageUrl() + arr_adapter.get(i).getImage())
                    .apply(RequestOptions.circleCropTransform()).into(holder.imgperson);


            holder.btnSendRequest.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final AlertDialog.Builder alert = new AlertDialog.Builder(context);
                    alert.setTitle("Alert!");
                    alert.setMessage("Are you sure you want to send invitation request for "+arr_adapter.get(i).getName());
                    alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int index) {
                            ((SendInvitationActivity)context).sendRequest(arr_adapter.get(i).getId());
                            return;
                        }
                    });

                    alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            return;
                        }
                    });
                    alert.show();
                }
            });
        }

        @Override
        public int getItemCount() {
            return arr_adapter.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView lblpersonname, lblpersonedu, lblpersonage, lblpersonocu;
            Button btnSendRequest;
            ImageView imgperson;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                lblpersonname = itemView.findViewById(R.id.lblpersonname);
                lblpersonedu = itemView.findViewById(R.id.lblpersonedu);
                lblpersonage = itemView.findViewById(R.id.lblpersonage);
                lblpersonocu = itemView.findViewById(R.id.lblpersonocu);
                btnSendRequest = itemView.findViewById(R.id.btnSendRequest);
                imgperson = itemView.findViewById(R.id.imgperson);
            }
        }
    }
}