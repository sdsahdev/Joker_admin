package com.suguretaventure.mymarriagegroup.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.suguretaventure.mymarriagegroup.Model.Members;
import com.suguretaventure.mymarriagegroup.R;
import com.suguretaventure.mymarriagegroup.common.Common;
import de.hdodenhof.circleimageview.CircleImageView;

public class ReqApprovalAdapter extends RecyclerView.Adapter<ReqApprovalAdapter.ViewHolder>{

    Members details;
    Context context;

    public ReqApprovalAdapter(Members details, Context context) {
        this.details = details;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_my_grp_reg, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.tvAdmin.setVisibility(View.GONE);
        holder.imgRemove.setVisibility(View.GONE);
        holder.imgLeave.setVisibility(View.GONE);
        holder.lblgrpregmobno.setText(details.members.get(position).mobile);
        holder.lblgrpregname.setText(details.members.get(position).name);
        Glide.with(context).load(Common.GetRegUserIDImageUrl() + details.members.get(position).image).into(holder.imgreguser);
    }

    @Override
    public int getItemCount() {
        return details.members.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder{
        private TextView lblgrpregname, lblgrpregmobno, tvAdmin;
        private ImageView imgRemove,imgLeave;
        CircleImageView imgreguser;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            lblgrpregname = itemView.findViewById(R.id.lblgrpregname);
            lblgrpregmobno = itemView.findViewById(R.id.lblgrpregmobno);
            imgRemove = itemView.findViewById(R.id.imgRemove);
            imgLeave = itemView.findViewById(R.id.imgLeave);
            tvAdmin = itemView.findViewById(R.id.tvAdmin);
            imgreguser = itemView.findViewById(R.id.imgreguser);
        }
    }
}
