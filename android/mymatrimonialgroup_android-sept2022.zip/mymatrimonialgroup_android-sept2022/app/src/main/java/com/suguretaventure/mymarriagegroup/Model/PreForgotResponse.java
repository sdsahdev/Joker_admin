package com.suguretaventure.mymarriagegroup.Model;

import com.google.gson.annotations.SerializedName;

public class PreForgotResponse{

	@SerializedName("msg")
	private String msg;

	@SerializedName("firstname")
	private String firstname;

	@SerializedName("surname")
	private String surname;

	@SerializedName("success")
	private boolean success;

	@SerializedName("mobile")
	private String mobile;

	@SerializedName("regid")
	private String regid;

	@SerializedName("email")
	private String email;

	public void setMsg(String msg){
		this.msg = msg;
	}

	public String getMsg(){
		return msg;
	}

	public void setFirstname(String firstname){
		this.firstname = firstname;
	}

	public String getFirstname(){
		return firstname;
	}

	public void setSurname(String surname){
		this.surname = surname;
	}

	public String getSurname(){
		return surname;
	}

	public void setSuccess(boolean success){
		this.success = success;
	}

	public boolean isSuccess(){
		return success;
	}

	public void setMobile(String mobile){
		this.mobile = mobile;
	}

	public String getMobile(){
		return mobile;
	}

	public void setRegid(String regid){
		this.regid = regid;
	}

	public String getRegid(){
		return regid;
	}

	public void setEmail(String email){
		this.email = email;
	}

	public String getEmail(){
		return email;
	}
}