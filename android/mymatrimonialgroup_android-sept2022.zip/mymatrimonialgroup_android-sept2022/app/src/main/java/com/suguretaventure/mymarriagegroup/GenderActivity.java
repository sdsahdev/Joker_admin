package com.suguretaventure.mymarriagegroup;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.suguretaventure.mymarriagegroup.Model.BioData;
import com.suguretaventure.mymarriagegroup.Model.MemberData;
import com.suguretaventure.mymarriagegroup.Model.Members;
import com.suguretaventure.mymarriagegroup.common.AppController;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.common.NetworkConnetionState;
import com.suguretaventure.mymarriagegroup.imageresize.util.Util;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utils;
import com.wafflecopter.multicontactpicker.ContactResult;
import com.wafflecopter.multicontactpicker.LimitColumn;
import com.wafflecopter.multicontactpicker.MultiContactPicker;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;

public class GenderActivity extends AppCompatActivity {
    TextView txtmale, txtfemale, btnHowWork, btngettogether2, btnfeedback2, btnPremiumProfiles,btnAddFreeData;
    RelativeLayout lay_woman, lay_man, lay_mkt;
    String mgid, mgname, count, image, URL, group_member;
    ImageView imgback;
    View headerView;
    LinearLayout fab;
    ActionBar toolbar;
    private Context ctx = this;
    private TextView lblcountm, lblcountf, lblregpersonname, lblprofile, txtGenderTitle;
    private ImageView imgregperson;
    private String TAG = "GENDER_ACTIVITY";
    private ProgressDialog pDialog;
    private MenuItem menu_get_to;
    private ImageView imgGenderBack, imgGenderIcon, imgGenderMore;
    private Toolbar toolbar_top;
    String requestCount = "0";
    String requestSentCount = "0";
    TextView btnAddMember,tvCountInvReceived, tvCountInvSent,btnShareApp,btnShareYoutubeLink;
    LinearLayout llInvReceived, llInvSent;
    private AdView adViewGender;
    private static final int READ_CONTACT_REQUEST = 1;
    private static final int CONTACT_PICKER_REQUEST = 2;
    private List<ContactResult> mContacts = new ArrayList<>();
    private FirebaseAnalytics mFirebaseAnalytics;
    String admin_id,subadmin;
    private Members myData;
    NetworkConnetionState connection;


    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(getResources().getColor(R.color.colorPrimaryDark));

        setContentView(R.layout.activity_gender);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        init();
        allocateMemory();
        setSupportActionBar(toolbar_top);
        getCountPerson();
        setListener();


        adViewGender = findViewById(R.id.adViewGender);
        AdRequest adRequest = new AdRequest.Builder().build();
        adViewGender.loadAd(adRequest);
    }

    private void setListener() {

        btnPremiumProfiles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                String is_vip_flag = Utils.getString(ctx, Constants.USER_IS_VIP);
//                if (is_vip_flag.equals("1")) {
                startActivity(new Intent(ctx, PrimiumBiodataActivity.class).putExtra("mgid", mgid)
                        .putExtra("mgname", mgname)
                        .putExtra("image", image)
                        .putExtra("URL", URL)
                        .putExtra("GROUP_MEMBER", group_member));

//                }
            }
        });
        btnAddMember.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchContactPicker();
            }
        });

        btnAddFreeData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addBiodata();
            }
        });


        imgGenderBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GenderActivity.super.onBackPressed();
            }
        });
        lay_man.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ctx, Occupations.class)
                        .putExtra("gender", "1")
                        .putExtra("mgid", mgid)
                        .putExtra("mgname", mgname)
                        .putExtra("image", image)
                        .putExtra("is_premium_flag", false)
                        .putExtra("URL", URL));
            }
        });
        lay_woman.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ctx, Occupations.class)
                        .putExtra("gender", "0")
                        .putExtra("mgid", mgid)
                        .putExtra("mgname", mgname)
                        .putExtra("image", image)
                        .putExtra("is_premium_flag", false)
                        .putExtra("URL", URL));
            }
        });
        lay_mkt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ctx, MarketActivity.class).putExtra("isGroup", true));
            }
        });
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (Integer.parseInt(Utils.getString(ctx, Constants.MEMBER)) > 1 && Utils.getString(ctx, Constants.USER_DOCUMENT).equalsIgnoreCase("1")) {
                    startActivity(new Intent(ctx, AddBiodata.class)
                            .putExtra("mgid", mgid)
                            .putExtra("mgname", mgname)
                            .putExtra("image", image)
                            .putExtra("gender", "")
                            .putExtra("is_premium_flag", false)
                            .putExtra("URL", URL));

                } else if (!Utils.getString(ctx, Constants.USER_DOCUMENT).equalsIgnoreCase("1")) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
                    builder.setTitle("Update Your Profile");
                    builder.setMessage("Please update your profile first by adding your photo.");
                    builder.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    builder.setPositiveButton("Go to My Profile", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            startActivity(new Intent(GenderActivity.this, ProfileUpdateActivity.class));
                        }
                    });
                    builder.show();
                } else if (Integer.parseInt(Utils.getString(ctx, Constants.MEMBER)) < 2) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
                    builder.setTitle("Alert!!");
                    builder.setMessage("Minimum 2 members are required in a group to upload any bio-data. ");
                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    /*builder.setPositiveButton("Go to My Profile", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            startActivity(new Intent(GenderActivity.this, ProfileUpdateActivity.class));
                        }
                    });*/
                    builder.show();
                }
            }
        });
        btnHowWork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ctx, HowWorks.class));
            }
        });


        btngettogether2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "admin: "+Utils.getString(ctx,"isSubadmin"));
                if(Utils.getString(ctx,"isAdmin").equals("1") || Utils.getString(ctx,"isSubadmin").equals("1") ) {

                    startActivity(new Intent(ctx, GetTogether.class)
                            .putExtra("mgid", mgid)
                            .putExtra("mgname", mgname)
                            .putExtra("image", image)
                            .putExtra("URL", URL));
                }else
                {
                    final AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
                    builder.setTitle("Alert");
                    builder.setMessage("Only admin/ Sub-Admin is allowed. Please contact Admin");
                    builder.show();
                }
               /* String admin_id = myData.aid;
                for (int i = 0; i < myData.members.size(); i++) {

                    if (myData.members.get(i).isSelected()) {

                        if (admin_id.equals("1") || myData.members.get(i).is_subadmin.equals("1")) {
                            startActivity(new Intent(ctx, GetTogether.class)
                                    .putExtra("mgid", mgid)
                                    .putExtra("mgname", mgname)
                                    .putExtra("image", image)
                                    .putExtra("URL", URL));
                        }
                        else
                        {
                            final AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
                            builder.setTitle("Alert");
                            builder.setMessage("Only admin is allowed. Please contact Admin");
                        }
                    }
                }*/

            }
        });
        btnfeedback2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ctx, Feedback.class));
            }
        });

        llInvSent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ctx, InvitationSent.class)
                        .putExtra("from", "dashboard_invitation_sent_group")
                        .putExtra("groupId", mgid));
            }
        });

        llInvReceived.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ctx, InvitationReceived.class)
                        .putExtra("from", "dashboard_invitation_receive_group")
                        .putExtra("groupId", mgid));
            }
        });

        btnShareApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                shareMessage("https://play.google.com/store/apps/details?id=com.suguretaventure.mymarriagegroup");
            }
        });

        btnShareYoutubeLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openYoutubeLink();
            }
        });
    }

    private void openYoutubeLink(){
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/channel/UCD51w3xpsCC1SM0F5aEYNjw"));
        try {
            this.startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void allocateMemory() {
        txtfemale = findViewById(R.id.lblcountf);
        txtmale = findViewById(R.id.lblcountm);
        lay_woman = findViewById(R.id.lay_woman);
        lay_man = findViewById(R.id.lay_man);
        lay_mkt = findViewById(R.id.lay_mkt);
        fab = findViewById(R.id.flt_newgroup);
        btnHowWork = findViewById(R.id.btnHowWork);
        toolbar_top = findViewById(R.id.toolbar_top);
        txtGenderTitle = toolbar_top.findViewById(R.id.txtGenderTitle);
        imgGenderBack = toolbar_top.findViewById(R.id.imgGenderBack);
        imgGenderIcon = toolbar_top.findViewById(R.id.imgGenderIcon);

        tvCountInvReceived = findViewById(R.id.tvCountInvReceived);
        tvCountInvSent = findViewById(R.id.tvCountInvSent);
        //imgGenderMore = toolbar_top.findViewById(R.id.imgGenderMore);

        // imgback=findViewById(R.id.imgback);
        mgid = getIntent().getExtras().getString("mgid");
        mgname = getIntent().getExtras().getString("mgname");
        URL = getIntent().getExtras().getString("URL");
        image = getIntent().getExtras().getString("image");
        group_member = getIntent().getExtras().getString("GROUP_MEMBER");
        txtGenderTitle.setText(mgname);

//        tvCountInvReceived.setText(AppController.INV_RECEIVED_COUNT+"");
//        tvCountInvReceived.setText(AppController.INV_SENT_COUNT+"");


        if (!image.equalsIgnoreCase("")) {
            Glide.with(ctx)
                    .load(URL + image)
                    .apply(RequestOptions.circleCropTransform())
                    .into(imgGenderIcon);
        }

        if (connection.isNetworkAvailable(ctx)) {
            getMemberList(mgid);
        } else {
            Toast.makeText(ctx, "No internet connection found. Please check your phone settings to turn on the internet.", Toast.LENGTH_LONG).show();
        }
    }

    private void getMemberList(String g_id) {
        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        RequestParams params = new RequestParams();
        params.put("gid", g_id);
        Utils.log(TAG, Constants.APP_MEMBER_LIST + "?" + params);
        client.post(Constants.APP_MEMBER_LIST, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {

                try {
                    String res = new String(responseBody);
                    Utils.log(TAG, "RESPONSE : " + res);
                    myData = new Gson().fromJson(res, Members.class);

                    Log.d("myData List :", new Gson().toJson(myData));
                    Utils.log(TAG, "SURNAME : " + myData.members.get(0).surname);
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "ERROR : " + error.getMessage());
            }
        });
    }

    private void getDataFromServer(final MenuItem request) {
        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        RequestParams params = new RequestParams();
        params.put("rid", Utils.getString(ctx, Constants.USER_ID));
        params.put("iGroupID", mgid);
        Utils.log(TAG, "REQUEST_URL : " + Constants.APP_BIODATA_REQUEST + "?" + params);
        client.post(Constants.APP_BIODATA_REQUEST, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                Utils.log(TAG, "REQUEST_RESPONSE : " + response);
                BioData data = new Gson().fromJson(response, BioData.class);
                Utils.log("REQ_RESPONSE", data.totalRequest);
                requestCount = data.totalRequest;
                request.setTitle("Pending to Publish (" + requestCount + ")");
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "REQUEST_ERROR : " + error.getMessage());
            }
        });
    }

    /*
     * Premium Pending Profiles
     * */
    private void getDataFromServerPrem(final MenuItem request) {
        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        RequestParams params = new RequestParams();
        params.put("rid", Utils.getString(ctx, Constants.USER_ID));
        params.put("iGroupID", mgid);
        params.put("is_premium", "1");
        Utils.log(TAG, "REQUEST_URL : " + Constants.APP_BIODATA_REQUEST + "?" + params);
        client.post(Constants.APP_BIODATA_REQUEST, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                Utils.log(TAG, "REQUEST_RESPONSE Premium: " + response);
                BioData data = new Gson().fromJson(response, BioData.class);
                Utils.log("REQ_RESPONSE", data.totalRequest);
                requestCount = data.totalRequest;
                request.setTitle("Premium Pending Profile (" + requestCount + ")");
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "REQUEST_ERROR : " + error.getMessage());
            }
        });
    }


    private void getDataFromServerAllRequest(final MenuItem request_all) {
        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        RequestParams params = new RequestParams();
        params.put("rid", Utils.getString(ctx, Constants.USER_ID));
        params.put("iGroupID", mgid);
        Utils.log(TAG, "REQUEST_URL : " + Constants.APP_BIODATA_ALL_REQUEST + "?" + params);
        client.post(Constants.APP_BIODATA_ALL_REQUEST, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                Utils.log(TAG, "REQUEST_RESPONSE : " + response);
                BioData data = new Gson().fromJson(response, BioData.class);
                Utils.log("REQ_RESPONSE", data.totalRequest);
                int count = data.detail.size();
                if (count == 0) {
                    request_all.setVisible(false);
                } else {
                    request_all.setTitle("Adm Pending to Publish (" + count + ")");
                }

            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "REQUEST_ERROR : " + error.getMessage());
            }
        });
    }


    private void getSentDataFromServer(final MenuItem requestSent) {
        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        RequestParams params = new RequestParams();
        params.put("rid", Utils.getString(ctx, Constants.USER_ID));
        params.put("iGroupID", mgid);
        Utils.log(TAG, "REQUEST_URL : " + Constants.APP_BIODATA_REQUEST_SENT + "?" + params);
        client.post(Constants.APP_BIODATA_REQUEST_SENT, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                Utils.log(TAG, "REQUEST_RESPONSE : " + response);
                BioData data = new Gson().fromJson(response, BioData.class);
                Utils.log("REQ_RESPONSE", data.totalRequest);
                requestSentCount = data.totalRequest;

                requestSent.setTitle("Sent to Publish (" + requestSentCount + ")");
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "REQUEST_ERROR : " + error.getMessage());
            }
        });
    }


    public void getSentRequest(final MenuItem invtationSent) {
        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        RequestParams params = new RequestParams();
        params.put("rid", Utils.getString(ctx, Constants.USER_ID));
        params.put("sent", "1");
        params.put("iGroupID", mgid);
        Utils.log(TAG, "REQ_SEND_BIO-DATA_URL : " + Constants.BIO_REQ_VIEW + "?" + params);
        client.post(Constants.BIO_REQ_VIEW, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                try {
                    JSONArray object = new JSONArray(response);
                    int total = object.getJSONObject(1).getInt("total");
                    invtationSent.setTitle("Invitation Sent (" + String.valueOf(total) + ")");
                    tvCountInvSent.setText(String.valueOf(total));
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Toast.makeText(ctx, "Something Went Wrong", Toast.LENGTH_SHORT).show();

            }
        });
    }


    public void getRecievedRequest(final MenuItem invtationRecieved) {
        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        RequestParams params = new RequestParams();
        params.put("rid", Utils.getString(ctx, Constants.USER_ID));
        params.put("receive", "1");
        params.put("iGroupID", mgid);
        Utils.log(TAG, "REQ_SEND_BIO-DATA_URL : " + Constants.BIO_REQ_VIEW + "?" + params);
        client.post(Constants.BIO_REQ_VIEW, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                try {
                    JSONArray object = new JSONArray(response);
                    int total = object.getJSONObject(1).getInt("total");
                    invtationRecieved.setTitle("Invitation Received (" + String.valueOf(total) + ")");
                    tvCountInvReceived.setText(String.valueOf(total));
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Toast.makeText(ctx, "Something Went Wrong", Toast.LENGTH_SHORT).show();

            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_group, menu);
        MenuItem request, requestSent,menuAllMemberRequest, menuAllRequest, menuInvSent, menuInvRecieved, menuPremiumRequest,myBioData;
        request = menu.findItem(R.id.myRequest);
        requestSent = menu.findItem(R.id.myRequestSent);
        menuAllRequest = menu.findItem(R.id.menuAllRequest);
        menuAllMemberRequest = menu.findItem(R.id.menuAllMemberRequest);
        menuPremiumRequest = menu.findItem(R.id.menuPremiumRequest);
        menuInvSent = menu.findItem(R.id.invsent);
        myBioData = menu.findItem(R.id.MyBioData);
        menuInvRecieved = menu.findItem(R.id.invreceive);
//        menuAllRequest.setVisible(false);
        getDataFromServer(request);
        getDataFromServerAllRequest(menuAllRequest);
        getDataFromServerAllMemberRequest(menuAllMemberRequest);
        getDataFromServerPrem(menuPremiumRequest);
        getSentDataFromServer(requestSent);
        getSentRequest(menuInvSent);
        getRecievedRequest(menuInvRecieved);

        return true;
    }

    private void getDataFromServerAllMemberRequest(final MenuItem menuAllMemberRequest) {
        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        RequestParams params = new RequestParams();
        params.put("rid", Utils.getString(ctx, Constants.USER_ID));
        params.put("gid", mgid);
        Utils.log(TAG, "REQUEST_URL : " + Constants.GROUP_ALL_REQUEST + "?" + params);
        client.post(Constants.GROUP_ALL_REQUEST, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                Utils.log(TAG, "REQUEST_RESPONSE Member: " + response.replace("[\\]",""));
                BioData data = new Gson().fromJson(response, BioData.class);
                Utils.log("REQ_RESPONSE", data.totalRequest);
                int count = data.detail.size();
                if (count == 0) {
                    menuAllMemberRequest.setVisible(false);
                } else {
                    menuAllMemberRequest.setTitle("All Pending Members (" + count + ")");
                }

            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "REQUEST_ERROR : " + error.getMessage());
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.home2:
                startActivity(new Intent(ctx, Dashboard.class));
                break;
            case R.id.addGrpmember:
                launchContactPicker();
                break;

            case R.id.myDrafts:
                startActivity(new Intent(ctx, MyDrafts.class).putExtra("mg_id",mgid).putExtra("mgname",mgname));
                break;

            case R.id.grpmembar:
                startActivity(new Intent(GenderActivity.this, MyGroupMembers.class)
                        .putExtra("mgid", mgid)
                        .putExtra("mgname", mgname)
                        .putExtra("image", image)
                        .putExtra("URL", URL)
                        .putExtra("gendar", "2")
                        .putExtra("GROUP_MEMBER", group_member));
                break;
            case R.id.AddBiodata:
                addBiodata();
                break;

            case R.id.MyBioData:
                 startActivity(new Intent(ctx, MyPosts.class)
                    .putExtra("from", "dashboard")
                         .putExtra("mgid",mgid)
                    .putExtra("gender", "-1"));
                break;

            case R.id.myFavourites:
                startActivity(new Intent(ctx, MyFav_Arc.class)
                        .putExtra("from", "dashboard_fav_group")
                        .putExtra("groupId", mgid));
                break;

            case R.id.myArchive:
                startActivity(new Intent(ctx, MyFav_Arc.class)
                        .putExtra("from", "dashboard_arc_group")
                        .putExtra("groupId", mgid));
                break;

            case R.id.addGetTo:
                startActivity(new Intent(ctx, GetTogether.class).putExtra("mgid", mgid));
                break;

            case R.id.terms:
                startActivity(new Intent(ctx, TermsActivity.class));
                break;

            case R.id.myRequest:
                startActivity(new Intent(ctx, MyRequestActivity.class).putExtra("from", "group_req")
                        .putExtra("groupId", mgid).putExtra("showFlag", 0).putExtra("is_premium", 0));
                break;

            case R.id.menuAllRequest:
                startActivity(new Intent(ctx, MyRequestActivity.class).putExtra("from", "group_req")
                        .putExtra("groupId", mgid).putExtra("showFlag", 1).putExtra("is_premium", 0));
                break;
            case R.id.menuPremiumRequest:
                startActivity(new Intent(ctx, MyRequestActivity.class).putExtra("from", "group_req")
                        .putExtra("groupId", mgid).putExtra("showFlag", 2).putExtra("is_premium", 1));
                break;

            case R.id.menuAllMemberRequest:
                startActivity(new Intent(ctx, MyRequestActivity.class).putExtra("from", "group_req").putExtra("isFor","member")
                        .putExtra("groupId", mgid).putExtra("showFlag", 1).putExtra("is_premium", 0));
                break;

            case R.id.myRequestSent:
                startActivity(new Intent(ctx, MyRequestSentActivity.class).putExtra("from", "group_req")
                        .putExtra("groupId", mgid));
                break;

            case R.id.invsent:
                startActivity(new Intent(ctx, InvitationSent.class)
                        .putExtra("from", "dashboard_invitation_sent_group")
                        .putExtra("groupId", mgid));
                break;
            case R.id.invreceive:
                startActivity(new Intent(ctx, InvitationReceived.class)
                        .putExtra("from", "dashboard_invitation_receive_group")
                        .putExtra("groupId", mgid));

                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void addBiodata() {
        if (Integer.parseInt(Utils.getString(ctx, Constants.MEMBER)) > 1 && Utils.getString(ctx, Constants.USER_DOCUMENT).equalsIgnoreCase("1")) {
            startActivity(new Intent(ctx, AddBiodata.class)
                    .putExtra("mgid", mgid)
                    .putExtra("mgname", mgname)
                    .putExtra("image", image)
                    .putExtra("gender", "")
                    .putExtra("URL", URL));
        } else if (!Utils.getString(ctx, Constants.USER_DOCUMENT).equalsIgnoreCase("1")) {
            AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
            builder.setTitle("Update Your Profile");
            builder.setMessage("Please update your profile first by adding your photo.");
            builder.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            builder.setPositiveButton("Go to My Profile", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    startActivity(new Intent(GenderActivity.this, ProfileUpdateActivity.class));
                }
            });
            builder.show();
        } else if (Integer.parseInt(Utils.getString(ctx, Constants.MEMBER)) < 2) {
            AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
            builder.setTitle("Alert!!");
            builder.setMessage("Minimum 2 members are required in a group to upload any bio-data. ");
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
                    /*builder.setPositiveButton("Go to My Profile", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            startActivity(new Intent(GenderActivity.this, ProfileUpdateActivity.class));
                        }
                    });*/
            builder.show();
        }
    }

    public void openTermsPolicy() {
        final Dialog dialog = new Dialog(ctx);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LayoutInflater inflater = getLayoutInflater();
        @SuppressLint("InflateParams") View alert = inflater.inflate(R.layout.layout_terms, null, false);
        alert.findViewById(R.id.tvTerms);
        alert.findViewById(R.id.btnCloseTerms);
        dialog.setContentView(alert);
        final TextView tvTerms = dialog.findViewById(R.id.tvTerms);
        final Button btnCloseTerms = dialog.findViewById(R.id.btnCloseTerms);

        tvTerms.setText(Html.fromHtml(Constants.STRING_TERMS_PRIVACY));

        btnCloseTerms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        ((Activity) ctx).getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        dialog.setContentView(alert);
        final Window window = dialog.getWindow();
        assert window != null;
        dialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        window.setBackgroundDrawableResource(R.color.colorTransparent);
        window.setGravity(Gravity.CENTER);
        dialog.show();
    }

    public void getCountPerson() {
        pDialog = new ProgressDialog(ctx);
        pDialog.setMessage("Please wait...");
        pDialog.setCancelable(false);
        showpDialog();

        String WebServiceUrl = Common.GetWebServiceUrl() + "total_persons.php";
        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        RequestParams params = new RequestParams();
        params.put("gid", mgid);
        client.post(WebServiceUrl, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                Utils.log(TAG, res.toString());
                try {
                    JSONArray response = new JSONArray(res);
                    String error = response.getJSONObject(0).getString("error");
                    if (error.equals("no error") == false) {
                        hidePDialog();
                        Common.showDialog(ctx);
                    } else {
                        hidePDialog();
                        String male = response.getJSONObject(1).getString("m");
                        String female = response.getJSONObject(1).getString("f");
                        if (Integer.parseInt(male) > 0) {
                            lblcountm.setVisibility(View.VISIBLE);
                            lblcountm.setText(male);
                        } else {
                            lblcountm.setVisibility(View.GONE);
                        }
                        if (Integer.parseInt(female) > 0) {
                            lblcountf.setVisibility(View.VISIBLE);
                            lblcountf.setText(female);
                        } else {
                            lblcountf.setVisibility(View.GONE);
                        }
                    }
                    hidePDialog();
                } catch (JSONException e) {
                    hidePDialog();
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                hidePDialog();
            }
        });
    }

    private void showpDialog() {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }

    // hide process Dialog box
    private void hidePDialog() {
        if (this.pDialog != null) {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }

    public void init() {
        btngettogether2 = findViewById(R.id.btngettogether2);
        btnfeedback2 = findViewById(R.id.btnfeedback2);
        btnPremiumProfiles = findViewById(R.id.btnPremiumProfiles);
        btnAddMember = findViewById(R.id.btnAddMember);
        btnAddFreeData = findViewById(R.id.btnAddFreeData);
        lblcountm = findViewById(R.id.lblcountm);
        lblcountf = findViewById(R.id.lblcountf);
        lay_mkt = findViewById(R.id.lay_mkt);
        lay_man = findViewById(R.id.lay_man);
        lay_woman = findViewById(R.id.lay_woman);
        llInvReceived = findViewById(R.id.llInvReceived);
        llInvSent = findViewById(R.id.llInvSent);
        btnShareApp = findViewById(R.id.btnShareApp);
        btnShareYoutubeLink = findViewById(R.id.btnShareYoutubeLink);

        btnShareApp.setText(Util.getUnderlinedText(getResources().getString(R.string.share_app_link)));
        btnShareYoutubeLink.setText(Util.getUnderlinedText(getResources().getString(R.string.share_youtube_link)));

    }

    public void setupToolbar() {
        toolbar = getSupportActionBar();
        assert toolbar != null;
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);
    }


    public void launchContactPicker() {
        int permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS);
        if (permissionCheck == PackageManager.PERMISSION_GRANTED) {


            new MultiContactPicker.Builder(GenderActivity.this) //Activity/fragment context
                    .hideScrollbar(false) //Optional - default: false
                    .showTrack(true) //Optional - default: true
                    .searchIconColor(Color.WHITE) //Option - default: White
                    .setChoiceMode(MultiContactPicker.CHOICE_MODE_MULTIPLE) //Optional - default: CHOICE_MODE_MULTIPLE
                    .handleColor(ContextCompat.getColor(GenderActivity.this, R.color.colorPrimary)) //Optional - default: Azure Blue
                    .bubbleColor(ContextCompat.getColor(GenderActivity.this, R.color.colorPrimary)) //Optional - default: Azure Blue
                    .bubbleTextColor(Color.WHITE) //Optional - default: White
                    .setTitleText("Select Contacts") //Optional - default: Select Contacts

                    .setLoadingType(MultiContactPicker.LOAD_ASYNC) //Optional - default LOAD_ASYNC (wait till all loaded vs stream results)
                    .limitToColumn(LimitColumn.PHONE) //Optional - default NONE (Include phone + email, limiting to one can improve loading time)
                    .setActivityAnimations(android.R.anim.fade_in, android.R.anim.fade_out,
                            android.R.anim.fade_in,
                            android.R.anim.fade_out) //Optional - default: No animation overrides
                    .showPickerForResult(CONTACT_PICKER_REQUEST);


            /* Intent contactPicker = new Intent(this, ContactPickerActivity.class);
            contactPicker.putExtra(ContactPickerActivity.DISPLAY_SERVICE,false);
            startActivityForResult(contactPicker, CONTACT_PICKER_REQUEST);*/

        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_CONTACTS},
                    READ_CONTACT_REQUEST);
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case CONTACT_PICKER_REQUEST:
                //contacts were selected

                if (resultCode == RESULT_OK) {

                    if (data != null) {

                        List<ContactResult> results = MultiContactPicker.obtainResult(data);
                        Log.d("MyTag", results.get(0).getDisplayName());

                        if (results != null) {
                            for (ContactResult selectedContact : results) {
                                List<String> list = new ArrayList<>();
                                list.add(selectedContact.getPhoneNumbers() + "|" + selectedContact.getDisplayName());
                                mContacts.add(selectedContact);

                            }
                        }


                        setRecyclerView();
                    }

                } else if (resultCode == RESULT_CANCELED) {
                    System.out.println("User closed the picker without selecting items.");
                }


                break;

            default:
                super.onActivityResult(requestCode, resultCode, data);
        }

    }


    private String convertStringArrayToString(ArrayList<String> strArr) {
        StringBuilder sb = new StringBuilder();
        if (sb.toString() != null) {
            for (String str : strArr)
                sb.append(str).append("-");
            return sb.substring(0, sb.length() - 1);
        } else {
            return "";
        }
    }

    private void setRecyclerView() {
        ArrayList<String> name = new ArrayList<>();
        ArrayList<String> no = new ArrayList<>();
        for (int i = 0; i < mContacts.size(); i++) {
            name.add(mContacts.get(i).getDisplayName());
            String temp_name = mContacts.get(i).getDisplayName();
            String temp_no = mContacts.get(i).getPhoneNumbers().get(0).getNumber().replace("-", "");
            String nameNo = temp_no + "|" + temp_name;

            no.add(nameNo);
        }

        Utils.log(TAG, convertStringArrayToString(name));
        Utils.log(TAG, convertStringArrayToString(no));
        pDialog = new ProgressDialog(ctx);
        pDialog.setMessage("Contact(s) Adding...");
        showpDialog();
        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        RequestParams params = new RequestParams();
        params.put("gid", mgid);
        params.put("id", Utils.getString(ctx, Constants.USER_ID));
        params.put("mobile", convertStringArrayToString(no));
        Utils.log(TAG, "ADD_CONTACT_LIST_URL : " + Constants.APP_ADD_MEMBER + "?" + params);
        client.post(Constants.APP_ADD_MEMBER, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                Utils.log(TAG, "ADD_CONTACT_LIST_RESPONSE : " + response);
                MemberData data = new Gson().fromJson(response, MemberData.class);
                if (data.members.size() > 0) {
                    Toast.makeText(ctx, "Member Invited Successfully.", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(ctx, "Member Added Successfully.", Toast.LENGTH_LONG).show();
                }
                hidePDialog();
                startActivity(new Intent(GenderActivity.this, MyGroupMembers.class)
                        .putExtra("mgid", mgid)
                        .putExtra("mgname", mgname)
                        .putExtra("image", image)
                        .putExtra("URL", URL)
                        .putExtra("gendar", "2")
                        .putExtra("GROUP_MEMBER", group_member));

            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "ADD_CONTACT_LIST_ERROR : " + error.getMessage());
                hidePDialog();
            }
        });
    }


    private void shareMessage(String message) {
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, message);
        startActivity(intent);
    }
}
