package com.suguretaventure.mymarriagegroup.getsets;

/**
 * Created by ankitpatel on 29/03/19.
 */

public class GTRegListGetSet
{
    private String gtrname,gtrno;

    public String getGtrname() {
        return gtrname;
    }

    public void setGtrname(String gtrname) {
        this.gtrname = gtrname;
    }

    public String getGtrno() {
        return gtrno;
    }

    public void setGtrno(String gtrno) {
        this.gtrno = gtrno;
    }
}
