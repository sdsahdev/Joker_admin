package com.suguretaventure.mymarriagegroup;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.suguretaventure.mymarriagegroup.common.AppController;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.common.NetworkConnetionState;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import cz.msebera.android.httpclient.Header;

public class Dashboardbackup extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    private String TAG = "DASHBOARD_BACKUP";
    private Context ctx = this;
    private RelativeLayout lay_man, lay_woman, lay_mkt;
    private TextView btnfeedback2, lblcountm, lblcountf, lblregpersonname, lblprofile;
    private ProgressDialog pDialog;
    boolean exit = false;
    private ImageView imgregperson;
    View headerView;
    private androidx.appcompat.app.AlertDialog alertDialogBuilder;
    private FirebaseAnalytics mFirebaseAnalytics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getResources().getColor(R.color.navend));
        }

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        headerView = navigationView.getHeaderView(0);
        setSupportActionBar(toolbar);

        allocateMemory();
        if (new NetworkConnetionState().isNetworkAvailable(ctx)) {
            getCountPerson();
            setProfile();
        } else {
            networkAlert();
        }
        setListeners();

      /*  FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ctx,AddBiodata.class));
            }
        });*/

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(this);
    }

    public void setProfile() {
        /*pDialog = new ProgressDialog(ctx);
        pDialog.setMessage("Please wait...");
        pDialog.setCancelable(false);
        showpDialog();*/

        String WebServiceUrl = Common.GetWebServiceUrl() + "myprofile.php?rid=" + Utils.getString(ctx, Constants.USER_ID);
        JsonArrayRequest request = new JsonArrayRequest(WebServiceUrl, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                Utils.log(TAG, response.toString());
                try {
                    String error = response.getJSONObject(0).getString("error");
                    if (!error.equals("no error")) {
                        hidePDialog();
                        Common.showDialog(ctx);
                    } else {
                        JSONObject object = response.getJSONObject(1);
                        Glide.with(ctx)
                                .load(Common.GetRegUserIDImageUrl() + object.getString("photo"))
                                .apply(RequestOptions.circleCropTransform())
                                .into(imgregperson);
                        lblregpersonname.setText(object.getString("name").toUpperCase()
                                + " " + object.getString("sname").toUpperCase());
                        lblprofile.setText("Your total posts : " + object.getString("rp"));
                        hidePDialog();
                    }
                    hidePDialog();
                } catch (JSONException e) {
                    hidePDialog();
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                hidePDialog();
                Common.showDialog(ctx);
            }
        });
        request.setRetryPolicy(new DefaultRetryPolicy(2000, 3, 1));
        AppController.getInstance().addToRequestQueue(request);
    }

    private void networkAlert() {
        AlertDialog.Builder b1 = new AlertDialog.Builder(ctx);
        b1.setTitle("Network Error");
        b1.setMessage("No internet connection found. Please check your phone settings to turn on the internet.");
        b1.setPositiveButton("Retry", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (new NetworkConnetionState().isNetworkAvailable(ctx)) {
                    getCountPerson();
                } else {
                    networkAlert();
                }
            }
        });
        b1.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        b1.create().show();
    }

    public void allocateMemory() {
       /* storage = new DataStorage(ctx,getResources().getString(R.string.filename));
        imgregperson = headerView.findViewById(R.id.imgregperson);
        lblregpersonname = headerView.findViewById(R.id.lblregpersonname);
        lblprofile = headerView.findViewById(R.id.lblprofile);
        btnfeedback2 = findViewById(R.id.btnfeedback2);
        lblcountm = findViewById(R.id.lblcountm);
        lblcountf = findViewById(R.id.lblcountf);
        lay_mkt = findViewById(R.id.lay_mkt);
        lay_man = findViewById(R.id.lay_man);
        lay_woman = findViewById(R.id.lay_woman);*/
    }

    public void getCountPerson() {
        pDialog = new ProgressDialog(ctx);
        pDialog.setMessage("Please wait...");
        pDialog.setCancelable(false);
        showpDialog();

        String WebServiceUrl = Common.GetWebServiceUrl() + "total_persons.php";

        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        client.post(WebServiceUrl, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                Utils.log(TAG, res.toString());
                try {
                    JSONArray response = new JSONArray(res);
                    String error = response.getJSONObject(0).getString("error");
                    if (error.equals("no error") == false) {
                        hidePDialog();
                        Common.showDialog(ctx);
                    } else {
                        hidePDialog();
                        String male = response.getJSONObject(1).getString("m");
                        String female = response.getJSONObject(1).getString("f");
                        lblcountm.setText(male);
                        lblcountf.setText(female);
                    }
                    hidePDialog();
                } catch (JSONException e) {
                    hidePDialog();
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                hidePDialog();
                Common.showDialog(ctx);
            }
        });
    }

    public void setListeners() {
        btnfeedback2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ctx, Feedback.class));
            }
        });

        lay_mkt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(ctx, MarketActivity.class));

            }
        });

        lay_man.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ctx, Occupations.class)
                        .putExtra("gender", "1"));
            }
        });

        lay_woman.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ctx, Occupations.class)
                        .putExtra("gender", "0"));
            }
        });
    }

    // show process Dialog box
    private void showpDialog() {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }

    // hide process Dialog box
    private void hidePDialog() {
        if (this.pDialog != null) {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            exitByBackKey();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    protected void exitByBackKey() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        }
        alertDialogBuilder = new androidx.appcompat.app.AlertDialog.Builder(ctx)
                .setMessage("Do you want to exit this application ?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface arg0, int arg1) {
                        Intent homeIntent = new Intent(Intent.ACTION_MAIN);
                        homeIntent.addCategory( Intent.CATEGORY_HOME );
                        homeIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(homeIntent);
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface arg0, int arg1) {
                    }
                })
                .show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.dashboard, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.logout) {
            final AlertDialog alertDialog = new AlertDialog.Builder(ctx).create();
            alertDialog.setMessage("Do you want to Logout");
            alertDialog.setButton(DialogInterface.BUTTON_POSITIVE, "Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    String FCM_KEY = "" + Utils.getString(ctx, Constants.TOKEN);
                    Utils.clearPreference(ctx);
                    Utils.setString(ctx, Constants.TOKEN, FCM_KEY);
                    startActivity(new Intent(ctx, Login.class));
                    finish();
                }
            });
            alertDialog.setButton(DialogInterface.BUTTON_NEGATIVE, "Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    alertDialog.dismiss();
                }
            });
            alertDialog.show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        if (id == R.id.myprofile) {
            startActivity(new Intent(ctx, MyProfile.class).putExtra("flagDetail",false));
        } else if (id == R.id.nextgt) {
            startActivity(new Intent(ctx, GetTogether.class));
        }
        else if (id == R.id.myposts) {
            startActivity(new Intent(ctx, MyPosts.class)
                    .putExtra("from", "dashboard")
                    .putExtra("gender", "-1"));
        }
        else if (id == R.id.myfav) {
            startActivity(new Intent(ctx, MyFav_Arc.class)
                    .putExtra("from", "dashboard_fav"));
        } else if (id == R.id.myarchieved) {
            startActivity(new Intent(ctx, MyFav_Arc.class)
                    .putExtra("from", "dashboard_arc"));
        } else if (id == R.id.mygroups) {
            startActivity(new Intent(ctx, MyGroup.class));
        }  else if (id == R.id.TnC) {
            startActivity(new Intent(ctx, TermsActivity.class));
        }else if (id == R.id.share) {
            shareMessage("Share");
        } else if (id == R.id.rate) {
            Uri uri = Uri.parse("market://details?id=" + ctx.getPackageName());
            Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
            goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
                    Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
                    Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
            try {
                startActivity(goToMarket);
            } catch (ActivityNotFoundException e) {
                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("http://play.google.com/store/apps/details?id=" + ctx.getPackageName())));
            }
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        setProfile();
    }

    private void shareMessage(String message) {
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, message);
        startActivity(intent);
    }
}
