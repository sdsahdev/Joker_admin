package com.suguretaventure.mymarriagegroup.adapters;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.suguretaventure.mymarriagegroup.R;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.getsets.OccupationGetSet;

import java.util.ArrayList;

/**
 * Created by ankitpatel on 20/02/19.
 */

public class OccupationAdapter extends BaseAdapter {
    private Context context;
    private LayoutInflater inflater = null;
    String gender = "";
    private ArrayList<OccupationGetSet> arr_adapter;

    public OccupationAdapter(Context ctx, ArrayList<OccupationGetSet> arr_adapter, String gender) {
        this.context = ctx;
        this.arr_adapter = arr_adapter;
        this.gender = gender;
        inflater = (LayoutInflater) context.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        return arr_adapter.size();
    }

    @Override
    public Object getItem(int position) {
        return arr_adapter.get(position).getId();
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    class Holder {
        ImageView imggroup;
        TextView grouptitle, groupcount;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Holder holder = null;
        View itemView = convertView;
        if (itemView == null) {
            inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            itemView = inflater.inflate(R.layout.row_occu, parent, false);
            holder = new Holder();
            holder.imggroup = itemView.findViewById(R.id.imggroup);
            holder.grouptitle = itemView.findViewById(R.id.lblgroup);
            holder.groupcount = itemView.findViewById(R.id.txtgcount);
            itemView.setTag(holder);
        } else {
            holder = (Holder) itemView.getTag();
        }

        int defaultResouceId = R.drawable.app_icon;
        if (gender.equalsIgnoreCase("1")){
            defaultResouceId = R.drawable.male_image_new;
        }else if (gender.equalsIgnoreCase("0")){
            defaultResouceId = R.drawable.female_image_new;
        }

        Glide.with(context)
                .load(Common.GetOccIcon() + arr_adapter.get(position).getGicon())
                .apply(RequestOptions.circleCropTransform())
//                .placeholder(new ColorDrawable(ContextCompat.getColor(context, R.color.placeholder_color)))
//                .error(new ColorDrawable(ContextCompat.getColor(context, R.color.placeholder_color)))
                .placeholder(defaultResouceId)
                .error(defaultResouceId)
                .into(holder.imggroup);

        holder.grouptitle.setText(arr_adapter.get(position).getTitle());
        holder.groupcount.setText(arr_adapter.get(position).getTotalcount());
        if (arr_adapter.get(position).getTotalcount().equals(String.valueOf(0))) {
            holder.groupcount.setVisibility(View.GONE);
        } else {
            holder.groupcount.setVisibility(View.VISIBLE);
        }
        return itemView;
    }
}
