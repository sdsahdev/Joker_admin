package com.suguretaventure.mymarriagegroup.Model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

public class Members implements Serializable {

    @SerializedName("data")
    public ArrayList<Member> members;

    public class Member implements Serializable {

        @SerializedName("id")
        public String id;

        @SerializedName("mobile")
        public String mobile;

        @SerializedName("firstname")
        public String firstname;

        @SerializedName("surname")
        public String surname;

        @SerializedName("photo")
        public String photo;

        @SerializedName("image")
        public String image;

        @SerializedName("name")
        public String name;


        @SerializedName("is_subadmin")
        public String is_subadmin;

        @SerializedName("is_vip_member")
        public String is_vip_member;

        @SerializedName("is_premium_profile_added")
        public String is_premium_profile_added;

        public boolean selected = false;

        public boolean isSelected() {
            return selected;
        }

        public void setSelected(boolean selected) {
            this.selected = selected;
        }
    }

    @SerializedName("aid")
    public String aid;
}
