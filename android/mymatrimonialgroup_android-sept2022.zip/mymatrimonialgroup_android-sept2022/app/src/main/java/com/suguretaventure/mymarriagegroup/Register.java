package com.suguretaventure.mymarriagegroup;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.auth.FirebaseAuth;
import com.google.gson.Gson;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.poovam.pinedittextfield.SquarePinField;
import com.suguretaventure.mymarriagegroup.Model.AddGroupModel;
import com.suguretaventure.mymarriagegroup.Model.CheckId;
import com.suguretaventure.mymarriagegroup.Model.RegisterModel;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.common.NetworkConnetionState;
import com.suguretaventure.mymarriagegroup.imageresize.core.ImageCompressTask;
import com.suguretaventure.mymarriagegroup.imageresize.listeners.IImageCompressTaskListener;
import com.suguretaventure.mymarriagegroup.imageresize.util.Util;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Prefs;
import com.suguretaventure.mymarriagegroup.utils.Utility;
import com.suguretaventure.mymarriagegroup.utils.Utils;
import com.suguretaventure.mymarriagegroup.utils.WebServiceCaller;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import cz.msebera.android.httpclient.Header;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Register extends AppCompatActivity {
    private static final int GALLARY = 1;
    private static final int CAMERA = 2;
    private static final int REQUEST_MULTIPLE_PERMISSION = 100;
    EditText txtfname, txtsname, txtmobileno, txtpwd, txtpwd2, txtemail2, txtque, txtans, txtaddressid, txtphotoid/*, etOTP*/;
    String email, password, confirmpassword, mobile, firstname, surname, addressid, photoid;
    ProgressDialog pDialog;
    NetworkConnetionState connection;
    LinearLayout layupdate, layregister;
    ActionBar toolbar;
    int flagimg = 0;
    RegisterModel registerModel;
    CheckId CheckIdsModel;
    private SquarePinField etOTP;
    private String TAG = "REGISTER_ACTIVITY";
    private Context ctx = this;
    private Button btnregister;
    //    private TextView lblregisterwithus;
    private RelativeLayout relMobileDetail, relDetailFill;
    private Button btnAddDetail;
    private LinearLayout imageLl;
    private TextInputLayout tinputpwd1, tinputpwd;
    private ImageView imgphotoid, imgphotoid1, imgphotoid_select, imgaddrid, imgaddrid1, imgaddrid_select;
    private ExecutorService mExecutorService = Executors.newFixedThreadPool(1);
    private ImageCompressTask imageCompressTask;
    private Bitmap image = null;
    private String CameraFileAbsolutePath="";
    private boolean isMobile = true, isMail = false;
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

    //Firebase SMS Authentication Variable
    private FirebaseAuth auth;
    private String CountryCode = "";
    private String MobileNo = "";
    private String Mobilenumber = "";
    private String MailMSG = "";
    private FirebaseAnalytics mFirebaseAnalytics;
    //private String CodeSend;
    //private CountryCodePicker txtmobileCode;

    private IImageCompressTaskListener iImageCompressTaskListener = new IImageCompressTaskListener() {
        @Override
        public void onComplete(List<File> compressed) {
            File file = compressed.get(0);
            String utype = Utils.getString(ctx, Constants.TYPE);
            if (getIntent().getExtras().getString("from").equals("update")) {
                if (utype.equals("1")) {
                    txtphotoid.setText(file.getName());
                    imgphotoid1.setImageBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()));
                    flagimg = 1;
                } else {
                    txtaddressid.setText(file.getName());
                    imgaddrid1.setImageBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()));
                }
            } else {
                if (utype.equals("1")) {
                    /*txtphotoid.setText(file.getName());*/
                    imgphotoid.setImageBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()));
                    flagimg = 1;
                } else {
                    txtaddressid.setText(file.getName());
                    imgaddrid.setImageBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()));
                }
            }
        }

        @Override
        public void onError(Throwable error) {
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        /*getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);*/
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        getSupportActionBar().setTitle("Profile");

        allocateMemory();
        /*CountryCode = "+" + txtmobileCode.getSelectedCountryCode();*/
//        setupToolbar();
        setListeners();
    }

    private void allocateMemory() {
        MobileNo = getIntent().getStringExtra("MY_MOBILE");
        CountryCode = getIntent().getStringExtra("MY_CODE");
        connection = new NetworkConnetionState();
        auth = FirebaseAuth.getInstance();
        layupdate = findViewById(R.id.layupdate);

        layregister = findViewById(R.id.layregister);
        tinputpwd1 = findViewById(R.id.tinputpwd1);
        tinputpwd = findViewById(R.id.tinputpwd);
        imgphotoid = findViewById(R.id.imgphotoid);
        imgphotoid_select = findViewById(R.id.imgphotoid_select);
        imgaddrid1 = findViewById(R.id.imgaddrid1);
        imgphotoid1 = findViewById(R.id.imgphotoid1);
//        lblregisterwithus = findViewById(R.id.lblregisterwithus);
        txtphotoid = findViewById(R.id.txtphotoid);
        txtfname = findViewById(R.id.txtfname);
        txtsname = findViewById(R.id.txtsname);
        txtmobileno = findViewById(R.id.mobileNo);
        txtmobileno.setText(MobileNo);
        txtmobileno.setEnabled(false);
        txtmobileno.setFocusable(false);
        txtpwd = findViewById(R.id.txtpwd);
        txtpwd2 = findViewById(R.id.txtpwd2);
        txtemail2 = findViewById(R.id.txtemail2);
        txtque = findViewById(R.id.txtque);
        txtans = findViewById(R.id.txtans);
        btnregister = findViewById(R.id.btnregistration);
        etOTP = findViewById(R.id.etOTP);
        //txtmobileCode = findViewById(R.id.txtmobileCode);
        btnAddDetail = findViewById(R.id.btnAddDetail);
        relMobileDetail = findViewById(R.id.relMobileDetail);
        relDetailFill = findViewById(R.id.relDetailFill);
        imageLl = findViewById(R.id.image_ll);

        if (getIntent().getStringExtra("from").equals("login")){
            firstname=getIntent().getStringExtra("name");
            surname=getIntent().getStringExtra("surname");
            email=getIntent().getStringExtra("email");
            txtfname.setText(firstname);
            txtsname.setText(surname);
            txtemail2.setText(email);
            imageLl.setVisibility(View.GONE);
        }else {
            imageLl.setVisibility(View.VISIBLE);
        }
    }

    public boolean ValidateInput() {
        boolean isvalid = true;
        firstname = txtfname.getText().toString().trim();
        surname = txtsname.getText().toString().trim();
        /*question = txtque.getText().toString().trim();
        answer = txtans.getText().toString().trim();*/
        email = txtemail2.getText().toString().trim();
        password = txtpwd2.getText().toString().trim();
        confirmpassword = txtpwd2.getText().toString().trim();
        mobile = txtmobileno.getText().toString();
        if (firstname.length() == 0) {
            isvalid = false;
            txtfname.setError("First name required");
        }
        if (surname.length() == 0) {
            isvalid = false;
            txtsname.setError("Surname required");
        }

        if (email.length() > 0) {
            if (!email.contains("@") && !email.matches(emailPattern)) {
                isvalid = false;
                txtemail2.setError("Email invalid");
            } else {
                isMail = true;
            }
        } else {
            isvalid = false;
            txtemail2.setError("Email required");
        }

        /*if(question.length()==0)
        {
            isvalid=false;
            txtque.setError("hint question required");
        }
        if(answer.length()==0)
        {
            isvalid=false;
            txtans.setError("hint answer required");
        }*/

        if (email.length() == 0) {
            isvalid = false;
            txtemail2.setError("email required");
        }else if (!email.matches(Common.emailPattern)) {
            isvalid = false;
            txtemail2.setError("email is not proper");
        }
        /*   if (!getIntent().getExtras().getString("from").equals("update")) {*/
        if (password.length() == 0) {
            isvalid = false;
            tinputpwd.setPasswordVisibilityToggleEnabled(false);
            txtpwd.setError("Password required");
        } else {
            tinputpwd.setPasswordVisibilityToggleEnabled(true);
        }
        if (confirmpassword.length() == 0) {
            isvalid = false;
            tinputpwd1.setPasswordVisibilityToggleEnabled(false);
            txtpwd2.setError("Confirm Password required");
        } else {
            tinputpwd1.setPasswordVisibilityToggleEnabled(true);
        }
        if (!password.equals(confirmpassword)) {
            isvalid=false;
            Toast.makeText(ctx, "Password and Confirm password do not match", Toast.LENGTH_LONG).show();
        }
        //}
//        if (MobileNo.length() == 0) {
//            isvalid = false;
//            txtmobileno.setError("Mobile number required");
//            txtmobileno.requestFocus();
//        }
        return isvalid;
    }

    private void setListeners() {
        txtpwd.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if (s.length() > 0) {
                    tinputpwd.setPasswordVisibilityToggleEnabled(true);
                } else {
                    tinputpwd.setPasswordVisibilityToggleEnabled(false);
                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 0) {
                    tinputpwd.setPasswordVisibilityToggleEnabled(true);
                } else {
                    tinputpwd.setPasswordVisibilityToggleEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() > 0) {
                    tinputpwd.setPasswordVisibilityToggleEnabled(true);
                } else {
                    tinputpwd.setPasswordVisibilityToggleEnabled(false);
                }
            }
        });

        txtpwd2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if (s.length() > 0) {
                    tinputpwd1.setPasswordVisibilityToggleEnabled(true);
                } else {
                    tinputpwd1.setPasswordVisibilityToggleEnabled(false);
                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 0) {
                    tinputpwd1.setPasswordVisibilityToggleEnabled(true);
                } else {
                    tinputpwd1.setPasswordVisibilityToggleEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() > 0) {
                    tinputpwd1.setPasswordVisibilityToggleEnabled(true);
                } else {
                    tinputpwd1.setPasswordVisibilityToggleEnabled(false);
                }
            }
        });
        imgphotoid_select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Utils.setString(ctx, Constants.TYPE, "1");
                requestPermission();
            }
        });

        /*txtemail2.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    if (txtemail2.getText().toString().length() != 0) {
//                        checkMail();
                    } else {
                        txtemail2.setError("Email required");
                    }
                }
            }
        });*/
        btnregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                firstname = txtfname.getText().toString().trim();
                surname = txtsname.getText().toString().trim();
                email = txtemail2.getText().toString().trim();
                password = txtpwd2.getText().toString().trim();
                confirmpassword = txtpwd2.getText().toString().trim();
                if (txtfname.getText().toString().equals("") && txtsname.getText().toString().equals("") && txtpwd.getText().toString().equals("") && txtpwd2.getText().toString().equals("")) {
                    Toast.makeText(ctx, "All fields are required.", Toast.LENGTH_LONG).show();
                    txtfname.setError("First name required");
                    txtsname.setError("Surname required");
                    txtemail2.setError("Email required");
                    txtpwd.setError("Password required");
                    txtpwd2.setError("password required");
                } else if (txtfname.getText().toString().equals("")) {
                    txtfname.setError("First name required");
                } else if (txtsname.getText().toString().equals("")) {
                    txtsname.setError("Surname required");
                } else if (txtemail2.getText().toString().equals("")) {
                    txtemail2.setError("Email required");
                } else if (!email.matches(emailPattern)) {
                    txtemail2.setError("Valid Email required");
                } else if (txtpwd.getText().toString().equals("")) {
                    txtpwd.setError("Password required");
                } else if (!txtpwd2.getText().toString().equals(txtpwd.getText().toString())) {
                    txtpwd2.setError("password not match");
                } /*else if (!isMail) {
                    txtemail2.setError(MailMSG);
                }*/ else {
                    sendDataToServer();
                }
            }
        });

        /*txtmobileno.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    if (txtmobileno.getText().length() < 9) {
                        txtmobileno.setError("Mobile required");
                    } else if (CountryCode.equals("")) {
                        txtmobileno.setError("Country code required");
                    } else {
//                        Toast.makeText(ctx, "CC : " + CountryCode +"   ,    " + "MO : " + txtmobileno.getText().toString(), Toast.LENGTH_LONG).show();
                        checkMobile();
                    }
                }
            }
        });*/

      /*  imgaddrid_select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Utils.setString(ctx, Constants.TYPE, "2");
                requestPermission();
            }
        });

        imgphotoid1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Utils.setString(ctx, Constants.TYPE, "1");
                requestPermission();
            }
        });

        imgaddrid1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Utils.setString(ctx, Constants.TYPE, "2");
                requestPermission();
            }
        });*/

        /*btnAddDetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ProgressDialog dialog = new ProgressDialog(ctx);
                dialog.setTitle("OTP Verification");
                dialog.setMessage("OTP Verifying");
                dialog.setCancelable(false);
                dialog.show();
                if (txtmobileno.getText().length() < 9) {
                    txtmobileno.setError("Mobile number required");
                    dialog.dismiss();
                } else {
                    if (!etOTP.getText().toString().equalsIgnoreCase("")) {
                        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(CodeSend, etOTP.getText().toString());
                        signInWithPhoneAuthCredential(credential, dialog);
                    } else {
                        Toast.makeText(ctx, "OTP required", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });*/
        /*txtmobileCode.setOnCountryChangeListener(new CountryCodePicker.OnCountryChangeListener() {
            @Override
            public void onCountrySelected(Country selectedCountry) {
                CountryCode = "+" + selectedCountry.getPhoneCode();
            }
        });*/
    }

    /*private void sendVerificationCode(String countryCode, String mobile) {

        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                countryCode + "" + mobile,        // Phone number to verify
                60,                 // Timeout duration
                TimeUnit.SECONDS,   // Unit of timeout
                this,               // Activity (for callback binding)
                mCallbacks);        // OnVerificationStateChangedCallbacks
    }

    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential, final ProgressDialog dialog) {
        auth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d(TAG, "signInWithCredential:success");
                            *//*sendDataToServer();*//*
                            dialog.dismiss();
                            relMobileDetail.setVisibility(View.GONE);
                            relDetailFill.setVisibility(View.VISIBLE);
                        } else {
                            // Sign in failed, display a message and update the UI
                            Log.w(TAG, "signInWithCredential:failure", task.getException());
                            dialog.dismiss();

                            if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {
                                // The verification code entered was invalid
                                Toast.makeText(ctx, "The verification code entered was invalid", Toast.LENGTH_LONG).show();
                            }

                        }
                    }
                });
    }*/

    private void sendDataToServer() {
//        if (ValidateInput()) {
        if (connection.isNetworkAvailable(ctx)) {
            if (getIntent().getStringExtra("from").equals("login")) {
                sendLoginUpdateToServer();
            }else {
                if (CameraFileAbsolutePath.equals("")) {
                    Toast.makeText(ctx, "Profile photo required", Toast.LENGTH_SHORT).show();
                }else {
                    submitRegistrationDetails();
                }
            }
        } else {
            Toast.makeText(ctx, "No internet connection found. Please check your phone settings to turn on the internet.", Toast.LENGTH_LONG).show();
        }
//        }
    }

    private void submitRegistrationDetails() {

        if (!Utility.isNetworkAvailable(Register.this)) {
            /*Snackbar.make(txtpwd, "Internet connection is not available", Snackbar.LENGTH_INDEFINITE).setAction("RETRY", new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    submitRegistrationDetails();
                }
            }).setActionTextColor(getResources().getColor(R.color.colorPrimary)).show();*/
        } else {
            final ProgressDialog progressDialog = new ProgressDialog(ctx);
            progressDialog.setTitle("Please wait...");
            progressDialog.show();
            progressDialog.setCancelable(false);
            MultipartBody.Part part;
            RequestBody fileReqBody;
            File  PhotoId = new File(CameraFileAbsolutePath);
            if (CameraFileAbsolutePath != null) {
                try {
                    Bitmap bitmap1 = BitmapFactory.decodeFile(PhotoId.getPath());
                    bitmap1.compress(Bitmap.CompressFormat.JPEG, 70, new FileOutputStream(PhotoId));
                } catch (Throwable t) {
                    Log.e("ERROR", "Error compressing file." + t.toString());
                    t.printStackTrace();
                }
                // Create a request body with file and image media type
                fileReqBody = RequestBody.create(MediaType.parse("image/*"), PhotoId);
                // Create MultipartBody.Part using file request-body,file name and part name
                part = MultipartBody.Part.createFormData("image", PhotoId.getName(), fileReqBody);
            } else {
                // Create a request body with file and image media type
                fileReqBody = RequestBody.create(MediaType.parse("image/*"), "");
                // Create MultipartBody.Part using file request-body,file name and part name
                part = MultipartBody.Part.createFormData("image", "" + "");
            }


            RequestBody description1 = RequestBody.create(MediaType.parse("text/plain"), firstname);
            RequestBody description2 = RequestBody.create(MediaType.parse("text/plain"), surname);
            RequestBody description3 = RequestBody.create(MediaType.parse("text/plain"), email);//email);
            RequestBody description4 = RequestBody.create(MediaType.parse("text/plain"), MobileNo);
//            RequestBody description5 = RequestBody.create(MediaType.parse("text/plain"), "");
            RequestBody description6 = RequestBody.create(MediaType.parse("text/plain"), password);
            RequestBody description7 = RequestBody.create(MediaType.parse("text/plain"), CountryCode);
            Utils.log(TAG, "REGISTER_API " + "http://mymarriagegroup.com/APPDIR/ws/" + firstname + "," + surname + "," + "" + "," + MobileNo + "," + password + "," + CountryCode);
//            Utility.log("TEST_API", "1. " + description1 + " 2. " + description2 + " 3. " + description3);
//            Utility.log("TEST_API", "4. " + description4 + " 5. " + /*description5*/ + " 6. " + description6);
            WebServiceCaller.getClient().getRegisterModelCall(part,description1, description2, description3, description4, /*description5,*/ description6, description7).enqueue(new Callback<RegisterModel>() {
                @Override
                public void onResponse(Call<RegisterModel> call, retrofit2.Response<RegisterModel> response) {
                    Utility.log("TESTING_API", new Gson().toJson(response.body()));
                    if (response.body().getSuccess()) {
                        String msg = response.body().getMsg();
                        Toast.makeText(ctx, "You are successfully registered.", Toast.LENGTH_LONG).show();
                        registerModel = response.body();
                        Prefs.setObject(Register.this, Constants.LOGINDATA, registerModel);
                        Prefs.setValue(Register.this, Constants.LOGIN, "1");

                        String id = registerModel.getRegid() + "";
                        Utils.setString(ctx, Constants.USER_ID, id);
                        Utils.setString(ctx, Constants.USER_NAME, registerModel.getFirstname());
                        Utils.setString(ctx, Constants.USER_EMAIL, registerModel.getEmail());
                        Utils.setString(ctx, Constants.USER_MOBILE, registerModel.getMobile());
                        WebServices.registerFcm(TAG, ctx, registerModel.getMobile());
                        startActivity(new Intent(ctx, Dashboard.class));
                        finish();

                    } else {
                        Toast.makeText(ctx, response.body().getMsg(), Toast.LENGTH_LONG).show();

                    }
                    progressDialog.dismiss();
                }

                @Override
                public void onFailure(Call<RegisterModel> call, Throwable t) {
                    //swipeContainer.setRefreshing(false)
                    //
                    progressDialog.dismiss();
                    Toast.makeText(ctx, "Error1", Toast.LENGTH_LONG).show();
                    Utility.log("TESTING_API", t.getMessage());
                }
            });
        }


    }

    private void checkMobile() {
        if (!Utility.isNetworkAvailable(Register.this)) {
            Snackbar.make(txtpwd, "Internet connection is not available", Snackbar.LENGTH_INDEFINITE).setAction("RETRY", new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    submitRegistrationDetails();
                }
            }).setActionTextColor(getResources().getColor(R.color.colorPrimary)).show();
        } else {
            final ProgressDialog progressDialog = new ProgressDialog(ctx);
            progressDialog.setTitle("Please wait...");
            progressDialog.show();
            progressDialog.setCancelable(false);

            AsyncHttpClient client = new AsyncHttpClient(true,80,443);
            RequestParams params = new RequestParams();
            params.put("mobile", txtmobileno.getText().toString());
            client.post(Constants.APP_CHECK_MOBILE, params, new AsyncHttpResponseHandler() {
                @Override
                public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                    String response = new String(responseBody);
                    String SUCCESS = "", MESSAGE = "";
                    try {
                        JSONObject res = new JSONObject(response);
                        SUCCESS = res.getString("success");
                        MESSAGE = res.getString("message");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    if (SUCCESS.equals("yes")) {
                        isMobile = true;
                        /*Toast.makeText(ctx, "Send", Toast.LENGTH_LONG).show();*/
                        //sendVerificationCode(CountryCode, txtmobileno.getText().toString());
                    } else {
                        isMobile = false;
                        txtmobileno.setError("" + MESSAGE);
                    }
                    progressDialog.dismiss();
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                    Utils.log(TAG, error.getMessage());
                }
            });
        }
    }

    private void checkMail() {

        if (!Utility.isNetworkAvailable(Register.this)) {
            Snackbar.make(txtpwd, "Internet connection is not available", Snackbar.LENGTH_INDEFINITE).setAction("RETRY", new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    submitRegistrationDetails();
                }
            }).setActionTextColor(getResources().getColor(R.color.colorPrimary)).show();
        } else {
            final ProgressDialog progressDialog = new ProgressDialog(ctx);
            progressDialog.setTitle("Please wait...");
            progressDialog.show();
            progressDialog.setCancelable(false);
//            email = "";//txtemail2.getText().toString();

            AsyncHttpClient client = new AsyncHttpClient(true,80,443);
            RequestParams params = new RequestParams();
            params.put("email", "");
            client.post(Constants.APP_CHECK_EMAIL, params, new AsyncHttpResponseHandler() {
                @Override
                public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                    String response = new String(responseBody);
                    String SUCCESS = "", MESSAGE = "";
                    try {
                        JSONObject res = new JSONObject(response);
                        SUCCESS = res.getString("success");
                        MESSAGE = res.getString("message");
                        MailMSG = MESSAGE;
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    if (SUCCESS.equals("yes")) {
                        isMail = true;
                    } else {
                        isMail = false;
                        txtemail2.setError("" + MESSAGE);
                    }
                    progressDialog.dismiss();
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                    Utils.log(TAG, error.getMessage());
                }
            });
        }


    }

    // show process Dialog box
    private void showpDialog() {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }

    // hide process Dialog box
    private void hidePDialog() {
        if (this.pDialog != null) {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }

    void requestPermission() {
        if (PackageManager.PERMISSION_GRANTED !=
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ||
                PackageManager.PERMISSION_GRANTED != ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)) {
            String[] PermissionList = {Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.CAMERA};
            if (ActivityCompat.shouldShowRequestPermissionRationale
                    (this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ||
                    ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA)) {

                ActivityCompat.requestPermissions(this, PermissionList,
                        REQUEST_MULTIPLE_PERMISSION);
            } else {
                ActivityCompat.requestPermissions(this, PermissionList,
                        REQUEST_MULTIPLE_PERMISSION);
            }
        } else {
            showDialogBox();
        }
    }

    private void showDialogBox() {
        AlertDialog.Builder b1 = new AlertDialog.Builder(ctx);
        b1.setTitle("Select Photo");
        b1.setIcon(R.mipmap.logo1);
        b1.setMessage("I want to select photo");
        b1.setPositiveButton("Using CAMERA", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                File image = null;
                try {
                    image = Util.CreteFileWithUniqueName(ctx);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                CameraFileAbsolutePath = image.getAbsolutePath();
                Uri photoURI = FileProvider.getUriForFile(ctx,
                        BuildConfig.APPLICATION_ID + ".provider", image);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(intent, CAMERA);
            }
        });
        b1.setNegativeButton("using Gallery", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent = new Intent(Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, GALLARY);
            }
        });

        b1.create().show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GALLARY && resultCode == RESULT_OK &&
                data != null) {
            Uri uri = data.getData();
            Cursor cursor = MediaStore.Images.Media.query(getContentResolver(),
                    uri, new String[]{MediaStore.Images.Media.DATA});
            if (cursor != null && cursor.moveToFirst()) {
                CameraFileAbsolutePath = cursor.getString(cursor.getColumnIndexOrThrow
                        (MediaStore.Images.Media.DATA));
                imageCompressTask = new ImageCompressTask(this, CameraFileAbsolutePath,
                        iImageCompressTaskListener);
                mExecutorService.execute(imageCompressTask);
            }

        } else if (requestCode == CAMERA) {
            String utype = Utils.getString(ctx, Constants.TYPE);
            if (getIntent().getExtras().getString("from").equals("update")) {
                if (utype.equals("1"))
                    imgphotoid1.setImageBitmap(image);
                else
                    imgaddrid1.setImageBitmap(image);
            } else {
                if (utype.equals("1"))
                    imgphotoid.setImageBitmap(image);
                else
                    imgaddrid.setImageBitmap(image);
            }
            File imgFile = new File(CameraFileAbsolutePath);
            if (imgFile.exists()) {
                imageCompressTask = new ImageCompressTask(this, CameraFileAbsolutePath,
                        iImageCompressTaskListener);
                mExecutorService.execute(imageCompressTask);
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mExecutorService.shutdown();
        mExecutorService = null;
        imageCompressTask = null;
    }

    public void setupToolbar() {
        toolbar = getSupportActionBar();
        assert toolbar != null;
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (android.R.id.home == item.getItemId()) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    public void openTermsPolicy(View view) {
        final Dialog dialog = new Dialog(ctx);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LayoutInflater inflater = getLayoutInflater();
        @SuppressLint("InflateParams") View alert = inflater.inflate(R.layout.layout_terms, null, false);
        alert.findViewById(R.id.tvTerms);
        alert.findViewById(R.id.btnCloseTerms);
        dialog.setContentView(alert);
        final TextView tvTerms = dialog.findViewById(R.id.tvTerms);
        final Button btnCloseTerms = dialog.findViewById(R.id.btnCloseTerms);

        //Change Contain from Constants Class
        tvTerms.setText(Html.fromHtml(Constants.STRING_TERMS_PRIVACY));

        btnCloseTerms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.setContentView(alert);
        final Window window = dialog.getWindow();
        assert window != null;
        dialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        window.setBackgroundDrawableResource(R.color.colorTransparent);
        window.setGravity(Gravity.CENTER);
        dialog.show();
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(ctx, Login.class));
        finish();
    }

    private void sendLoginUpdateToServer() {
        if (!Utility.isNetworkAvailable(this)) {
            Toast.makeText(Register.this, "Check internet connection...", Toast.LENGTH_LONG).show();
        } else {
            final ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Please wait...");
            progressDialog.show();
            progressDialog.setCancelable(false);

            //Create request body with text description and text media type
            RequestBody description1 = RequestBody.create(MediaType.parse("text/plain"), Utils.getString(this, Constants.USER_ID));
            RequestBody description2 = RequestBody.create(MediaType.parse("text/plain"), firstname);
            RequestBody description3 = RequestBody.create(MediaType.parse("text/plain"), surname);
            RequestBody description4 = RequestBody.create(MediaType.parse("text/plain"), email);//etEmail.getText().toString().trim());
            RequestBody description5 = RequestBody.create(MediaType.parse("text/plain"), password);

            WebServiceCaller.getClient().updateLoginCall(description1, description2, description3, description4, description5).enqueue(new Callback<AddGroupModel>(){
                @Override
                public void onResponse(Call<AddGroupModel> call, Response<AddGroupModel> response) {
                    Log.d(TAG, "onResponse: "+response);
                    Utils.log(TAG, response.body().toString());
                    /* if (response.body().get(0).getSuccess()) {*/

                    Prefs.setValue(Register.this, Constants.LOGIN, "1");
                    Utils.setString(ctx, Constants.USER_NAME, firstname);
                    Utils.setString(ctx, Constants.USER_EMAIL, email);
                    Utils.setString(ctx, Constants.USER_MOBILE, MobileNo);
                    WebServices.registerFcm(TAG, ctx, MobileNo);
                    startActivity(new Intent(ctx, Dashboard.class));
                    finish();
                   /* } else {
                        Toast.makeText(Register.this, "Error api", Toast.LENGTH_LONG).show();
                    }*/
                    progressDialog.dismiss();
                }


                @Override
                public void onFailure(Call<AddGroupModel> call, Throwable t) {
                    //swipeContainer.setRefreshing(false)
                    //
                    progressDialog.dismiss();
                    Toast.makeText(Register.this, "Server Error " + t.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }
    }

}