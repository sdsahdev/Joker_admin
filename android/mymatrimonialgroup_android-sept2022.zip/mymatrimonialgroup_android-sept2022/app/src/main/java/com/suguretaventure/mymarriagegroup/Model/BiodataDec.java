package com.suguretaventure.mymarriagegroup.Model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

public class BiodataDec implements Serializable {

    @SerializedName("bid")
    public String bid;

    @SerializedName("register_userid")
    public String register_userid;

    @SerializedName("name")
    public String name;

    @SerializedName("middle_name")
    public String middleName;

    @SerializedName("surname")
    public String surname;

    @SerializedName("gender")
    public String gender;

    @SerializedName("age")
    public String age;

    @SerializedName("education")
    public String education;

    @SerializedName("specialization")
    public String specialization;

    @SerializedName("occupation")
    public String occupation;

    @SerializedName("occupation_detail")
    public String occupation_detail;

    @SerializedName("currency")
    public String currency;

    @SerializedName("annual_income")
    public String annual_income;

    @SerializedName("city")
    public String city;

    @SerializedName("date_of_birth")
    public String date_of_birth;

    @SerializedName("time_of_birth")
    public String time_of_birth;

    @SerializedName("place_of_birth")
    public String place_of_birth;

    @SerializedName("height")
    public String height;

    @SerializedName("weight")
    public String weight;

    @SerializedName("blood_group")
    public String blood_group;

    @SerializedName("complexion")
    public String complexion;

    @SerializedName("zodiac")
    public String zodiac;

    @SerializedName("fathers_name")
    public String fathers_name;

    @SerializedName("fathers_occupation")
    public String fathers_occupation;

    @SerializedName("mother_name")
    public String mother_name;

    @SerializedName("pHandicap")
    public String pHandicap;

    @SerializedName("sCitizen")
    public String sCitizen;

    @SerializedName("mother_occupation")
    public String mother_occupation;

    @SerializedName("brothers_name_occupation")
    public String brothers_name_occupation;

    @SerializedName("sisters_name_occupation")
    public String sisters_name_occupation;

    @SerializedName("religion")
    public String religion;

    @SerializedName("maritial_status")
    public String maritial_status;

    @SerializedName("mother_tongue")
    public String mother_tongue;

    @SerializedName("kul_daivat")
    public String kul_daivat;

    @SerializedName("close_relatives")
    public String close_relatives;

    @SerializedName("address")
    public String address;

    @SerializedName("native_place")
    public String native_place;

    @SerializedName("hobbies")
    public String hobbies;

    @SerializedName("expectation")
    public String expectation;

    @SerializedName("surname_community")
    public String surname_community;

    @SerializedName("drinking_habits")
    public String drinking_habits;

    @SerializedName("latitude")
    public String latitude;

    @SerializedName("smoking_habits")
    public String smoking_habits;

    @SerializedName("dietary_habits")
    public String dietary_habits;

    @SerializedName("name_to_contact")
    public String name_to_contact;

    @SerializedName("its_relation")
    public String its_relation;

    @SerializedName("contact_no")
    public String contact_no;

    @SerializedName("email_id")
    public String email_id;

    @SerializedName("mg_id")
    public String mg_id;

    @SerializedName("mg_name")
    public String mg_name;

    @SerializedName("image")
    public String image;

    @SerializedName("url")
    public String url;

    public String getMg_id() {
        return mg_id;
    }

    public void setMg_id(String mg_id) {
        this.mg_id = mg_id;
    }

    public String getMg_name() {
        return mg_name;
    }

    public void setMg_name(String mg_name) {
        this.mg_name = mg_name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public String getBid() {
        return bid;
    }

    public void setBid(String bid) {
        this.bid = bid;
    }

    public String getRegister_userid() {
        return register_userid;
    }

    public void setRegister_userid(String register_userid) {
        this.register_userid = register_userid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getEducation() {
        return education;
    }

    public void setEducation(String education) {
        this.education = education;
    }

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    public String getOccupation_detail() {
        return occupation_detail;
    }

    public void setOccupation_detail(String occupation_detail) {
        this.occupation_detail = occupation_detail;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getAnnual_income() {
        return annual_income;
    }

    public void setAnnual_income(String annual_income) {
        this.annual_income = annual_income;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getDate_of_birth() {
        return date_of_birth;
    }

    public void setDate_of_birth(String date_of_birth) {
        this.date_of_birth = date_of_birth;
    }

    public String getTime_of_birth() {
        return time_of_birth;
    }

    public void setTime_of_birth(String time_of_birth) {
        this.time_of_birth = time_of_birth;
    }

    public String getPlace_of_birth() {
        return place_of_birth;
    }

    public void setPlace_of_birth(String place_of_birth) {
        this.place_of_birth = place_of_birth;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getBlood_group() {
        return blood_group;
    }

    public void setBlood_group(String blood_group) {
        this.blood_group = blood_group;
    }

    public String getComplexion() {
        return complexion;
    }

    public void setComplexion(String complexion) {
        this.complexion = complexion;
    }

    public String getZodiac() {
        return zodiac;
    }

    public void setZodiac(String zodiac) {
        this.zodiac = zodiac;
    }

    public String getFathers_name() {
        return fathers_name;
    }

    public void setFathers_name(String fathers_name) {
        this.fathers_name = fathers_name;
    }

    public String getFathers_occupation() {
        return fathers_occupation;
    }

    public void setFathers_occupation(String fathers_occupation) {
        this.fathers_occupation = fathers_occupation;
    }

    public String getMother_name() {
        return mother_name;
    }

    public void setMother_name(String mother_name) {
        this.mother_name = mother_name;
    }

    public String getMother_occupation() {
        return mother_occupation;
    }

    public void setMother_occupation(String mother_occupation) {
        this.mother_occupation = mother_occupation;
    }

    public String getBrothers_name_occupation() {
        return brothers_name_occupation;
    }

    public void setBrothers_name_occupation(String brothers_name_occupation) {
        this.brothers_name_occupation = brothers_name_occupation;
    }

    public String getSisters_name_occupation() {
        return sisters_name_occupation;
    }

    public void setSisters_name_occupation(String sisters_name_occupation) {
        this.sisters_name_occupation = sisters_name_occupation;
    }

    public String getReligion() {
        return religion;
    }

    public void setReligion(String religion) {
        this.religion = religion;
    }

    public String getMaritial_status() {
        return maritial_status;
    }

    public void setMaritial_status(String maritial_status) {
        this.maritial_status = maritial_status;
    }

    public String getMother_tongue() {
        return mother_tongue;
    }

    public void setMother_tongue(String mother_tongue) {
        this.mother_tongue = mother_tongue;
    }

    public String getKul_daivat() {
        return kul_daivat;
    }

    public void setKul_daivat(String kul_daivat) {
        this.kul_daivat = kul_daivat;
    }

    public String getClose_relatives() {
        return close_relatives;
    }

    public void setClose_relatives(String close_relatives) {
        this.close_relatives = close_relatives;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getNative_place() {
        return native_place;
    }

    public void setNative_place(String native_place) {
        this.native_place = native_place;
    }

    public String getHobbies() {
        return hobbies;
    }

    public void setHobbies(String hobbies) {
        this.hobbies = hobbies;
    }

    public String getExpectation() {
        return expectation;
    }

    public void setExpectation(String expectation) {
        this.expectation = expectation;
    }

    public String getSurname_community() {
        return surname_community;
    }

    public void setSurname_community(String surname_community) {
        this.surname_community = surname_community;
    }

    public String getDrinking_habits() {
        return drinking_habits;
    }

    public void setDrinking_habits(String drinking_habits) {
        this.drinking_habits = drinking_habits;
    }

        public String getpHandicap() {
                return pHandicap;
        }

        public void setpHandicap(String pHandicap) {
                this.pHandicap = pHandicap;
        }

        public String getsCitizen() {
                return sCitizen;
        }

        public void setsCitizen(String sCitizen) {
                this.sCitizen = sCitizen;
        }

        public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getSmoking_habits() {
        return smoking_habits;
    }

    public void setSmoking_habits(String smoking_habits) {
        this.smoking_habits = smoking_habits;
    }

    public String getDietary_habits() {
        return dietary_habits;
    }

    public void setDietary_habits(String dietary_habits) {
        this.dietary_habits = dietary_habits;
    }

    public String getName_to_contact() {
        return name_to_contact;
    }

    public void setName_to_contact(String name_to_contact) {
        this.name_to_contact = name_to_contact;
    }

    public String getIts_relation() {
        return its_relation;
    }

    public void setIts_relation(String its_relation) {
        this.its_relation = its_relation;
    }

    public String getContact_no() {
        return contact_no;
    }

    public void setContact_no(String contact_no) {
        this.contact_no = contact_no;
    }

    public String getEmail_id() {
        return email_id;
    }

    public void setEmail_id(String email_id) {
        this.email_id = email_id;
    }
}