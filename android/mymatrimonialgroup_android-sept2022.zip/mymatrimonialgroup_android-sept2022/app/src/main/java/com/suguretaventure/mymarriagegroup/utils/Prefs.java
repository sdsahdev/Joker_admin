package com.suguretaventure.mymarriagegroup.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;

public class Prefs {

    private static SharedPreferences sharedPreferences = null;

    private static void openPrefs(Context context) {
        sharedPreferences = context.getSharedPreferences("StandUp", context.MODE_PRIVATE);
    }

    public static void setValue(Context context, String key, String value) {
        Prefs.openPrefs(context);
        SharedPreferences.Editor prefsEdit = Prefs.sharedPreferences.edit();
        prefsEdit.putString(key, value);
        prefsEdit.commit();

        prefsEdit = null;
        Prefs.sharedPreferences = null;
    }


    public static void setValue(Context context, String key, int value) {
        Prefs.openPrefs(context);
        SharedPreferences.Editor prefsEdit = Prefs.sharedPreferences.edit();
        prefsEdit.putInt(key, value);
        prefsEdit.commit();

        prefsEdit = null;
        Prefs.sharedPreferences = null;
    }


    public static void setObject(Context context, String key, Object value) {
        Prefs.openPrefs(context);
        SharedPreferences.Editor prefsEdit = Prefs.sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(value);
        prefsEdit.putString(key, json);
        prefsEdit.commit();

    }

    public static String getValue(Context context, String key, String value) {
        Prefs.openPrefs(context);
        String result = Prefs.sharedPreferences.getString(key, value);
        Prefs.sharedPreferences = null;
        return result;
    }

    public static int getValue(Context context, String key, int value) {
        Prefs.openPrefs(context);
        int result = Prefs.sharedPreferences.getInt(key, value);
        Prefs.sharedPreferences = null;
        return result;
    }

    public static Object getObject(Context context, String key, String value, Class va) {
        Gson gson = new Gson();
        Prefs.openPrefs(context);
        String result = Prefs.sharedPreferences.getString(key, value);
        return gson.fromJson(result, va);
    }

    public static void removeValue(Context context, String key) {
        Prefs.openPrefs(context);
        SharedPreferences.Editor editor = Prefs.sharedPreferences.edit();
        editor.remove(key);
        editor.apply();
    }

    public static void clearAllData(Context context) {
        Prefs.openPrefs(context);
        SharedPreferences.Editor editor = Prefs.sharedPreferences.edit();
        editor.clear();
        editor.commit();
    }
}

