package com.suguretaventure.mymarriagegroup.adapters;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.suguretaventure.mymarriagegroup.Model.GroupListModel;
import com.suguretaventure.mymarriagegroup.Model.Members;
import com.suguretaventure.mymarriagegroup.MyGroupMembers;
import com.suguretaventure.mymarriagegroup.R;
import com.suguretaventure.mymarriagegroup.UpdateGroupActivity;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import cz.msebera.android.httpclient.Header;
import de.hdodenhof.circleimageview.CircleImageView;

public class MemberAdapter extends RecyclerView.Adapter<MemberAdapter.MemberHolder> {
    public Context ctx;
    public String admin;
    public ArrayList<Members.Member> data;
    private String mgid;
    private String TAG = "MEMBER_LIST_ADAPTER";
    AlertDialog dialog;
    private LayoutInflater inflater;

    public MemberAdapter(Context ctx, ArrayList<Members.Member> data, String admin, String mgid) {
        this.ctx = ctx;
        this.admin = admin;
        this.data = data;
        this.mgid = mgid;

        Log.d("Memeber data ==>", new Gson().toJson(data));

        Collections.sort(this.data, new Comparator<Members.Member>() {
            @Override
            public int compare(Members.Member s1, Members.Member s2) {
                return s1.firstname.compareToIgnoreCase(s2.firstname);
            }
        });

        Collections.sort(this.data, new Comparator<Members.Member>() {
            @Override
            public int compare(Members.Member s1, Members.Member s2) {
                return s2.is_subadmin.compareToIgnoreCase(s1.is_subadmin);
            }
        });

        for (int i=0;i<this.data.size();i++){
            if (this.data.get(i).id.equals( this.admin)){
                Members.Member removedItem = this.data.remove(i);
                this.data.add(0,removedItem);
                notifyDataSetChanged();
            }
        }

    }

    public void updateList(ArrayList<Members.Member> arr_adapter1){
        data = arr_adapter1;
        notifyDataSetChanged();
    }


    @NonNull
    @Override
    public MemberHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_my_grp_reg, parent, false);
        return new MemberHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull final MemberHolder vH, final int i) {
        Utils.setString(ctx, Constants.MEMBER, data.size() + "");
        if (admin.equals(data.get(i).id)) {
            vH.tvAdmin.setVisibility(View.VISIBLE);
        } else {
            vH.tvAdmin.setVisibility(View.GONE);
        }


        if (!admin.equals(Utils.getString(ctx, Constants.USER_ID))) {
            vH.buttonViewOption.setVisibility(View.GONE);
        } else {
            if (Utils.getString(ctx, Constants.USER_ID).equals(data.get(i).id)){
                vH.buttonViewOption.setVisibility(View.GONE);
            }else{
                vH.buttonViewOption.setVisibility(View.VISIBLE);
            }
        }


        if (!data.get(i).id.equals(Utils.getString(ctx, Constants.USER_ID))) {
            vH.imgLeave.setVisibility(View.GONE);
        } else {
            vH.imgLeave.setVisibility(View.VISIBLE);
        }


        if (data.get(i).is_subadmin.equals("1")) {
            vH.lblIsSubAdmin.setVisibility(View.VISIBLE);
        } else {
            vH.lblIsSubAdmin.setVisibility(View.GONE);
        }

        if (!data.get(i).photo.equals("img1.png")) {
            Glide.with(ctx).load(Common.GetRegUserIDImageUrl() + data.get(i).photo).into(vH.imgreguser);
        } else {
            vH.imgreguser.setImageResource(R.drawable.place_holder);
        }


        vH.imgreguser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(ctx);
                inflater = (LayoutInflater) ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                View dialogLayout = inflater.inflate(R.layout.personimage_dialog, null);
                ImageView imgtabledesc = (ImageView) dialogLayout.findViewById(R.id.imgtabledesc);
                builder.setView(dialogLayout);

//                if (width > height) {
//                    rotatedBitmap = rotate(image, 90);
//                    Glide.with(context)
//                            .load(rotatedBitmap)
//                            .into(imgtabledesc);
//                } else {
                Glide.with(ctx)
                        .load(Common.GetRegUserIDImageUrl() + data.get(i).photo)
                        .into(imgtabledesc);
//                }

               /* Glide.with(context)
                        .load(Common.GetProfileImageUrl() + arr_adapter.get(i).getImage())
                        .into(imgtabledesc);*/
                Dialog dialog = builder.create();
                dialog.setCancelable(true);
                dialog.show();
            }
        });


        vH.imgLeave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
                builder.setIcon(R.drawable.ic_exit_to_app_black_24dp);
                builder.setTitle("Leave Member");
                builder.setMessage("Do you want to Leave from this group?");
                builder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        memberRemove(i);
                        Toast.makeText(ctx, "Leaved", Toast.LENGTH_LONG).show();
                        notifyDataSetChanged();
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        dialog.dismiss();
                    }
                });
                builder.show();
            }
        });

        vH.lblgrpregname.setText("" + data.get(i).firstname + " " + data.get(i).surname);
        vH.lblgrpregmobno.setText("" + data.get(i).mobile);
        /*if (data.get(i).id.equals(admin)){

        }*/
        StringBuffer buf = new StringBuffer(data.get(i).mobile);
        buf.replace(0, 6, "XXXXXX");
        vH.lblgrpregmobno.setText("" + buf.toString());
        vH.buttonViewOption.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                //creating a popup menu
                PopupMenu popup = new PopupMenu(ctx, vH.buttonViewOption);
                //inflating menu from xml resource
                popup.inflate(R.menu.options_menu);
                popup.getMenu().findItem(R.id.menu2).setTitle("Remove");
                if (data.get(i).is_subadmin.equals("1")) {
                    popup.getMenu().findItem(R.id.menu1).setTitle("Member");
                } else {
                    popup.getMenu().findItem(R.id.menu1).setTitle("Sub-Admin");
                }
                popup.getMenu().findItem(R.id.menu1).setVisible(true);
                /*if (groupListModel.getGrouplist().get(i).getGrptotal().equals("1")){
                    popup.getMenu().findItem(R.id.menu2).setTitle("Delete Group");
                    group_status = "Delete Group";
                }else {
                    popup.getMenu().findItem(R.id.menu2).setTitle("Leave Group");
                    group_status = "Leave Group";
                }*/

                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.menu1:
                                if (data.get(i).is_subadmin.equals("1")) {
                                    addSubAdmin(i, "0");
                                } else {
                                    addSubAdmin(i, "1");
                                }
                                break;
                            case R.id.menu2:
                                final AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
                                builder.setIcon(R.drawable.ic_remove_blue);
                                builder.setTitle("Remove Member");
                                builder.setMessage("Do you want to remove " + data.get(i).firstname + " " + data.get(i).surname + " from your group?");
                                builder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        memberRemove(i);
                                        Toast.makeText(ctx, "Removed", Toast.LENGTH_LONG).show();
                                        notifyDataSetChanged();
                                    }
                                });
                                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.cancel();
                                        dialog.dismiss();
                                    }
                                });
                                builder.show();
                                break;
                        }
                        return false;
                    }
                });
                //displaying the popup
                popup.show();

            }
        });
    }

    private void memberRemove(final int i) {
        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        final RequestParams params = new RequestParams();
        params.put("rid", data.get(i).id);
        params.put("gid", mgid);
        Utils.log(TAG, "REMOVE_MEMBER_URL : " + Constants.APP_MEMBER_REMOVE + "?" + params);
        client.post(Constants.APP_MEMBER_REMOVE, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                Utils.log(TAG, "REMOVE_MEMBER_RESPONSE : " + response);
                String success = "", message = "";
                try {
                    JSONObject res = new JSONObject(response);
                    success = res.getString("success");
                    message = res.getString("message");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                Utils.log(TAG, " SUCCESS " + success);
                if (success.equals("yes")) {
                    data.remove(i);
                    notifyItemRemoved(i);
                } else {
                    Toast.makeText(ctx, message, Toast.LENGTH_LONG).show();
                }
                Utils.setString(ctx, Constants.MEMBER, data.size() + "");
                if (dialog != null) {
                    dialog.dismiss();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "REMOVE_MEMBER_ERROR : " + error.getMessage());
                dialog.dismiss();
            }
        });
    }


    private void addSubAdmin(final int i, String add_remove_status) {
        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        final RequestParams params = new RequestParams();
        params.put("rid", data.get(i).id);
        params.put("gid", mgid);
        params.put("is_subadmin", add_remove_status);
        Utils.log(TAG, "ADD_SUBADMIN_URL : " + Constants.APP_ADD_REMOVE_SUBADMIN + "?" + params);
        client.post(Constants.APP_ADD_REMOVE_SUBADMIN, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                Utils.log(TAG, "ADD_SUBADMIN_RESPONSE : " + response);
                String success = "", message = "";
                try {
                    JSONObject res = new JSONObject(response);
                    success = res.getString("success");
                    message = res.getString("message");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                Utils.log(TAG, " SUCCESS " + success);

                if (success.equals("yes")) {
                    Toast.makeText(ctx, "Status updated successfully.", Toast.LENGTH_LONG).show();
                    ((MyGroupMembers) ctx).getMembers();
                    notifyDataSetChanged();
                } else {
                    Toast.makeText(ctx, message, Toast.LENGTH_LONG).show();
                }
                Utils.setString(ctx, Constants.MEMBER, data.size() + "");
                if (dialog != null) {
                    dialog.dismiss();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "REMOVE_MEMBER_ERROR : " + error.getMessage());
                dialog.dismiss();
            }
        });
    }

    private void memberLeave(final int i) {
        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        final RequestParams params = new RequestParams();
        params.put("rid", data.get(i).id);
        params.put("gid", mgid);
        Utils.log(TAG, "REMOVE_MEMBER_URL : " + Constants.APP_MEMBER_REMOVE + "?" + params);
        client.post(Constants.Leave_Group, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                Utils.log(TAG, "REMOVE_MEMBER_RESPONSE : " + response);
                String success = "", message = "";
                try {
                    JSONObject res = new JSONObject(response);
                    success = res.getString("success");
                    message = res.getString("message");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                Utils.log(TAG, " SUCCESS " + success);
                if (success.equals("true")) {
                    Toast.makeText(ctx, "Leaved", Toast.LENGTH_LONG).show();
                    data.remove(i);
                    notifyItemRemoved(i);
                } else {
                    Toast.makeText(ctx, message, Toast.LENGTH_LONG).show();
                }
                Utils.setString(ctx, Constants.MEMBER, data.size() + "");
                if (dialog != null) {
                    dialog.dismiss();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "REMOVE_MEMBER_ERROR : " + error.getMessage());
                dialog.dismiss();
            }
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class MemberHolder extends RecyclerView.ViewHolder {
        private TextView lblgrpregname, lblgrpregmobno, tvAdmin, lblIsSubAdmin;
        public ImageView imgRemove, imgLeave, buttonViewOption;
        CircleImageView imgreguser;

        public MemberHolder(@NonNull View itemView) {
            super(itemView);
            lblgrpregname = itemView.findViewById(R.id.lblgrpregname);
            lblIsSubAdmin = itemView.findViewById(R.id.lblIsSubAdmin);
            lblgrpregmobno = itemView.findViewById(R.id.lblgrpregmobno);
            imgRemove = itemView.findViewById(R.id.imgRemove);
            imgLeave = itemView.findViewById(R.id.imgLeave);
            tvAdmin = itemView.findViewById(R.id.tvAdmin);
            imgreguser = itemView.findViewById(R.id.imgreguser);
            buttonViewOption = itemView.findViewById(R.id.buttonViewOption);

        }
    }
}
