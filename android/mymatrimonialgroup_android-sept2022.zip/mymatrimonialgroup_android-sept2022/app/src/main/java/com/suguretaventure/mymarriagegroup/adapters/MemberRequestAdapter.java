package com.suguretaventure.mymarriagegroup.adapters;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.gson.Gson;
import com.suguretaventure.mymarriagegroup.Model.Members;
import com.suguretaventure.mymarriagegroup.R;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class MemberRequestAdapter extends RecyclerView.Adapter<MemberRequestAdapter.ViewHolder> {
    public ArrayList<Members.Member> data;
    private String admin_id;
    private Context ctx;
    LinearLayout linSendRequest;
    private String TAG = "MEMBER_ADAPTER_REQUEST";
    private int count = 0;

    public MemberRequestAdapter(Context ctx, ArrayList<Members.Member> data, LinearLayout linSendRequest, String admin_id) {
        this.ctx = ctx;
        this.data = data;
        this.linSendRequest = linSendRequest;
        this.admin_id = admin_id;

        Log.d("Data Members ==>", new Gson().toJson(data));

        Collections.sort(data, new Comparator<Members.Member>() {
            @Override
            public int compare(Members.Member s1, Members.Member s2) {
                return s1.firstname.compareToIgnoreCase(s2.firstname);
            }
        });

        Collections.sort(data, new Comparator<Members.Member>() {
            @Override
            public int compare(Members.Member s1, Members.Member s2) {
                return s2.is_subadmin.compareToIgnoreCase(s1.is_subadmin);
            }
        });

        for (int i = 0; i < this.data.size(); i++) {
            if (this.data.get(i).id.equals(this.admin_id)) {
                Members.Member removedItem = this.data.remove(i);
                this.data.add(0, removedItem);
                notifyDataSetChanged();
            }
        }

    }

    /*public MemberRequestAdapter(Context ctx, Members data) {
        this.ctx = ctx;
        this.data = data;


        Collections.sort(data.members, new Comparator<Members.Member>() {
            @Override
            public int compare(Members.Member s1, Members.Member s2) {
                return s1.firstname.compareToIgnoreCase(s2.firstname);
            }
        });

        Collections.sort(data.members, new Comparator<Members.Member>() {
            @Override
            public int compare(Members.Member s1, Members.Member s2) {
                return s2.is_subadmin.compareToIgnoreCase(s1.is_subadmin);
            }
        });
    }*/

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater layoutInflater = LayoutInflater.from(viewGroup.getContext());
        View view = layoutInflater.inflate(R.layout.row_request, viewGroup, false);
        return new ViewHolder(view);
    }


    public void updateList(ArrayList<Members.Member> arr_adapter1) {
        data = arr_adapter1;
        notifyDataSetChanged();
    }


    @Override
    public void onBindViewHolder(@NonNull final ViewHolder v, final int i) {
//        if (!Utils.getString(ctx, Constants.USER_ID).equalsIgnoreCase(data.get(i).id)) {
        v.lblname_list.setText(data.get(i).firstname + " " + data.get(i).surname);

        String maskedMobile = data.get(i).mobile.substring(6, 10);
        v.lblno_list.setText("XXXXXX" + maskedMobile);

        v.cardMember.setVisibility(View.VISIBLE);
//        } else {
//            v.cardMember.setVisibility(View.GONE);
//        }

        if (!data.get(i).photo.equals("img1.png")) {
            Glide.with(ctx).load(Common.GetRegUserIDImageUrl() + data.get(i).photo).apply(RequestOptions.circleCropTransform()).into(v.img_new_member);
        } else {
            v.img_new_member.setImageResource(R.drawable.logo_text_1);
        }


        if (data.get(i).isSelected()) {
            v.cbkCheckList.setChecked(true);
        } else {
            v.cbkCheckList.setChecked(false);
        }

        v.cbkCheckList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CheckBox cb = (CheckBox) view;
                if (cb.isChecked()) {
                    data.get(v.getAdapterPosition()).setSelected(cb.isChecked());
                    count++;
                } else {
                    cb.setChecked(false);
                    data.get(v.getAdapterPosition()).setSelected(cb.isChecked());
                    count--;
                }
                /*if (count > 0) {
                    linSendRequest.setVisibility(View.VISIBLE);
                } else {
                    linSendRequest.setVisibility(View.GONE);
                }*/
            }
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView img_new_member;
        TextView lblname_list, lblno_list;
        CheckBox cbkCheckList;
        CardView cardMember;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            img_new_member = itemView.findViewById(R.id.img_new_member_row_req);
            lblname_list = itemView.findViewById(R.id.lblname_list);
            lblno_list = itemView.findViewById(R.id.lblno_list);
            cbkCheckList = itemView.findViewById(R.id.cbkCheckList);
            cardMember = itemView.findViewById(R.id.cardMember);

        }
    }
}
