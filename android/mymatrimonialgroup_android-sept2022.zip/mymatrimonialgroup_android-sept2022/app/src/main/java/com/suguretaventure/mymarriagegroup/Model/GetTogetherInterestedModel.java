package com.suguretaventure.mymarriagegroup.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GetTogetherInterestedModel {


    public GetTogetherInterestedModel(String title) {
        this.title = title;
    }

    @SerializedName("error")
    @Expose
    private String error;
    @SerializedName("total")
    @Expose
    private Integer total;
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("register_userid")
    @Expose
    private String registerUserid;
    @SerializedName("gid")
    @Expose
    private String gid;
    @SerializedName("title")
    @Expose
    private String title;
    @SerializedName("detail")
    @Expose
    private Object detail;
    @SerializedName("gdatetime")
    @Expose
    private String gdatetime;
    @SerializedName("venue")
    @Expose
    private String venue;
    @SerializedName("data")
    @Expose
    private List<Datum> data = null;

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRegisterUserid() {
        return registerUserid;
    }

    public void setRegisterUserid(String registerUserid) {
        this.registerUserid = registerUserid;
    }

    public String getGid() {
        return gid;
    }

    public void setGid(String gid) {
        this.gid = gid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Object getDetail() {
        return detail;
    }

    public void setDetail(Object detail) {
        this.detail = detail;
    }

    public String getGdatetime() {
        return gdatetime;
    }

    public void setGdatetime(String gdatetime) {
        this.gdatetime = gdatetime;
    }

    public String getVenue() {
        return venue;
    }

    public void setVenue(String venue) {
        this.venue = venue;
    }

    public List<Datum> getData() {
        return data;
    }

    public void setData(List<Datum> data) {
        this.data = data;
    }





}
