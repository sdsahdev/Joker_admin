package com.suguretaventure.mymarriagegroup;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Html;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.maps.model.Dash;
import com.google.android.material.navigation.NavigationView;
/*import com.google.firebase.analytics.FirebaseAnalytics;*/
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.gson.Gson;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.suguretaventure.mymarriagegroup.Model.AddGroupModel;
import com.suguretaventure.mymarriagegroup.Model.GroupListModel;
import com.suguretaventure.mymarriagegroup.Model.MemberData;
import com.suguretaventure.mymarriagegroup.Model.RegisterModel;
import com.suguretaventure.mymarriagegroup.adapters.MyGroupAdapter;
import com.suguretaventure.mymarriagegroup.common.AppController;
import com.suguretaventure.mymarriagegroup.common.NetworkConnetionState;
import com.suguretaventure.mymarriagegroup.fcm.NotificationUtils;
import com.suguretaventure.mymarriagegroup.getsets.MyGroupGetSet;
import com.suguretaventure.mymarriagegroup.imageresize.core.ImageCompressTask;
import com.suguretaventure.mymarriagegroup.imageresize.listeners.IImageCompressTaskListener;
import com.suguretaventure.mymarriagegroup.imageresize.util.Util;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.ExifUtil;
import com.suguretaventure.mymarriagegroup.utils.GooglePlayStoreAppVersionNameLoader;
import com.suguretaventure.mymarriagegroup.utils.Utility;
import com.suguretaventure.mymarriagegroup.utils.Utils;
import com.suguretaventure.mymarriagegroup.utils.WebServiceCaller;
import com.wafflecopter.multicontactpicker.ContactResult;
import com.wafflecopter.multicontactpicker.LimitColumn;
import com.wafflecopter.multicontactpicker.MultiContactPicker;
import com.yalantis.ucrop.UCrop;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import cz.msebera.android.httpclient.Header;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;

/*import mx.com.quiin.contactpicker.Contact;
import mx.com.quiin.contactpicker.SimpleContact;
import mx.com.quiin.contactpicker.interfaces.ContactSelectionListener;
import mx.com.quiin.contactpicker.ui.ContactPickerActivity;*/

public class Dashboard extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, MyGroupAdapter.GroupListener { //, ContactSelectionListener
    private static final int READ_CONTACT_REQUEST = 1;
    private static final int CONTACT_PICKER_REQUEST = 3;
    private static final int GALLARY = 1;
    private static final int CAMERA = 2;
    private static final int REQUEST_MULTIPLE_PERMISSION = 100;
    AlertDialog aldialog;
    ActionBar toolbar;
    GroupListModel groupListModel;
    ImageView imgback;
    View headerView;
    private boolean isMobileVerified = false;
    String gid = "";
    private RelativeLayout lay_mkt, relDash;
    private TextView btnfeedback2, lblNoGroupDash, tvNoGroupTagLine;
    private String TAG = "DASHBOARD_ACTIVITY";
    private Context ctx = this;
    private RecyclerView rcvgrp;
    private MyGroupAdapter grpAdapter;
    private MyGroupGetSet grpGetSet;
    private ProgressDialog pDialog;
    private TextView lblemptygrp;
    private LinearLayout flt_newgroup;
    private List<ContactResult> mContacts = new ArrayList<>();
    private ExecutorService mExecutorService = Executors.newFixedThreadPool(1);
    private ImageCompressTask imageCompressTask;
    private Bitmap image = null;
    private String CameraFileAbsolutePath;
    private ImageView imgphotoid, imgphotoid_select;
    private androidx.appcompat.app.AlertDialog alertDialogBuilder;
    ImageView imgregperson;
    TextView lblregpersonname, tvCountInvReceived, tvCountInvSent;
    TextView lblprofile;
    TextView lblMobile;
    LinearLayout llInvReceived, llInvSent;
    private Uri photoUri;
    private FirebaseAnalytics mFirebaseAnalytics;
    Dashboard dashboard;
    public TextView txt;
    public AdView adViewHome;

    private IImageCompressTaskListener iImageCompressTaskListener = new IImageCompressTaskListener() {
        @Override
        public void onComplete(List<File> compressed) {
            File file = compressed.get(0);
            Bitmap bmp = BitmapFactory.decodeFile(file.getAbsolutePath());
            imgphotoid.setImageBitmap(bmp);
        }

        @Override
        public void onError(Throwable error) {
        }
    };

   /* @Override
    protected void onResume() {
        super.onResume();
        getMyGroupList();
    }*/

    public static void dialogShow(Context ctx, String msg) {
        AlertDialog.Builder b1 = new AlertDialog.Builder(ctx);
        b1.setTitle("Error");
        b1.setMessage(msg);
        b1.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        b1.create().show();
    }

    private static String convertStringArrayToString(ArrayList<String> strArr) {
        StringBuilder sb = new StringBuilder();
        for (String str : strArr)
            sb.append(str).append("-");
        return sb.substring(0, sb.length() - 1);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        dashboard = Dashboard.this;

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
//            window.setStatusBarColor(getResources().getColor(R.color.navend));
        }


        String token = FirebaseInstanceId.getInstance().getToken();
        Log.d(TAG, "onCreate: " + token);
        saveDeviceToken(token);

        NavigationView navigationView = findViewById(R.id.nav_view);
        headerView = navigationView.getHeaderView(0);
        imgregperson = headerView.findViewById(R.id.imgregperson);
        lblregpersonname = headerView.findViewById(R.id.lblregpersonname);
        lblprofile = headerView.findViewById(R.id.lblprofile);
        lblMobile = headerView.findViewById(R.id.lblMobile);
        txt = findViewById(R.id.txt);
        lblregpersonname.setText(Utils.getString(ctx, Constants.USER_NAME) + " " + Utils.getString(ctx, Constants.USER_SURNAME));
        lblprofile.setText("" + Utils.getString(ctx, Constants.USER_EMAIL));
        lblMobile.setText("" + Utils.getString(ctx, Constants.USER_MOBILE));
        Utils.log(TAG, "         1111111111111111     " + Utils.getString(ctx, Constants.TOKEN));
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        allocateMemory();


        if (new NetworkConnetionState().isNetworkAvailable(ctx)) {
            getMyGroupList();
            forceUpdate();
            flt_newgroup.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    addGroup();
                }
            });
        } else {
            networkAlert();
        }
        if (Utils.getString(ctx, Constants.USER_PHOTO) != null) {
            Glide.with(ctx).load(Utils.getString(ctx, Constants.USER_PHOTO)).apply(RequestOptions.circleCropTransform()).into(imgregperson);
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(this);
        setListener();
    }



    private void setListener() {
        lay_mkt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ctx, MarketActivity.class));
            }
        });
        btnfeedback2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ctx, HowWorks.class));
            }
        });

        llInvSent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ctx, InvitationSent.class)
                        .putExtra("from", "dashboard_invitation_sent"));
            }
        });

        llInvReceived.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ctx, InvitationReceived.class)
                        .putExtra("from", "dashboard_invitation_receive"));
            }
        });
    }

    private void addGroup() {
        AlertDialog.Builder builder = new AlertDialog.Builder(ctx);

        LayoutInflater layoutInflater = LayoutInflater.from(ctx);
        final View myview = layoutInflater.inflate(R.layout.dialog_new_group, null);
        builder.setView(myview);

        final TextView txtgtitle = myview.findViewById(R.id.txtgtitle);
        TextView btn_create_grp = myview.findViewById(R.id.btn_create_grp);

        imgphotoid_select = myview.findViewById(R.id.imgphotoid_select);
        imgphotoid = myview.findViewById(R.id.imgphotoid);

        imgphotoid_select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //storage.write("type","1"); //user image
                requestPermission();
            }
        });

        btn_create_grp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (txtgtitle.getText().toString().length() == 0) {
                    txtgtitle.setError("Group Title required");
                } else {
                    createNewGroup(txtgtitle.getText().toString(), aldialog);
                }
            }
        });
        aldialog = builder.create();
        final Window window = aldialog.getWindow();
        assert window != null;
        aldialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        window.setBackgroundDrawableResource(R.color.colorTransparent);
        window.setGravity(Gravity.CENTER);
        aldialog.show();
    }

    private void networkAlert() {
        AlertDialog.Builder b1 = new AlertDialog.Builder(ctx);
        b1.setTitle("Network Error");
        b1.setMessage("No internet connection found. Please check your phone settings to turn on the internet.");
        b1.setPositiveButton("Retry", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (new NetworkConnetionState().isNetworkAvailable(ctx)) {
                    getMyGroupList();
                } else {
                    networkAlert();
                }
            }
        });
        b1.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        b1.create().show();
    }

    /*public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            exitByBackKey();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }*/

    protected void exitByBackKey() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        }
        alertDialogBuilder = new androidx.appcompat.app.AlertDialog.Builder(ctx)
                .setMessage("Do you want to exit this application ?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface arg0, int arg1) {
                        /*Intent intent = new Intent(Intent.ACTION_MAIN);
                        intent.addCategory(Intent.CATEGORY_HOME);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);*/
                        /*System.exit(0);*/
                        finish();
                        alertDialogBuilder.dismiss();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface arg0, int arg1) {
                        alertDialogBuilder.dismiss();
                    }
                })
                .show();
    }

    @Override
    public void onBackPressed() {
        exitByBackKey();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.dashboard, menu);
        MenuItem menuInvSent, menuInvRecieved;
        menuInvSent = menu.findItem(R.id.invsent);
        menuInvRecieved = menu.findItem(R.id.invreceive);

        getSentRequest(menuInvSent);
        getRecievedRequest(menuInvRecieved);
        return true;
    }


    public void saveDeviceToken(final String deviceToken) {
        WebServiceCaller.getClient().saveDeviceToken(Utils.getString(ctx, Constants.USER_ID), deviceToken).enqueue(new Callback<RegisterModel>() {
            @Override
            public void onResponse(Call<RegisterModel> call, retrofit2.Response<RegisterModel> response) {

                Log.d("OnResponse", response.toString());
            }

            @Override
            public void onFailure(Call<RegisterModel> call, Throwable t) {
                //swipeContainer.setRefreshing(false)

                Log.d("Error_Message", t.getMessage());

                Toast.makeText(Dashboard.this, "Server Error  :   " + t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });


    }


    public void getSentRequest(final MenuItem invtationSent) {
        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        RequestParams params = new RequestParams();
        params.put("rid", Utils.getString(ctx, Constants.USER_ID));
        params.put("sent", "1");
        params.put("iGroupID", "");
        Utils.log(TAG, "REQ_SEND_BIO-DATA_URL : " + Constants.BIO_REQ_VIEW + "?" + params);
        client.post(Constants.BIO_REQ_VIEW, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                try {
                    JSONArray object = new JSONArray(response);
                    int total = object.getJSONObject(1).getInt("total");
                    invtationSent.setTitle("Invitation Sent (" + String.valueOf(total) + ")");
                    tvCountInvSent.setText(String.valueOf(total));
                    AppController.INV_SENT_COUNT = total;
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Toast.makeText(ctx, "Something Went Wrong", Toast.LENGTH_SHORT).show();
            }
        });
    }


    public void getRecievedRequest(final MenuItem invtationRecieved) {
        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        RequestParams params = new RequestParams();
        params.put("rid", Utils.getString(ctx, Constants.USER_ID));
        params.put("receive", "1");
        params.put("iGroupID", "");
        Utils.log(TAG, "REQ_SEND_BIO-DATA_URL : " + Constants.BIO_REQ_VIEW + "?" + params);
        client.post(Constants.BIO_REQ_VIEW, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                try {
                    JSONArray object = new JSONArray(response);
                    int total = object.getJSONObject(1).getInt("total");
                    invtationRecieved.setTitle("Invitation Received (" + String.valueOf(total) + ")");
                    tvCountInvReceived.setText(String.valueOf(total));
                    AppController.INV_RECEIVED_COUNT = total;
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Toast.makeText(ctx, "Something Went Wrong", Toast.LENGTH_SHORT).show();

            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.addGroup) {
            addGroup();
        } else if (id == R.id.dashboard) {
            startActivity(new Intent(ctx, Dashboard.class));
        } else if (id == R.id.myGroup) {
            startActivity(new Intent(ctx, MyGroup.class));
        }/* else if (id == R.id.myDrafts) {
            startActivity(new Intent(ctx, MyDrafts.class));
        }*/
//        else if (id == R.id.myPost) {
//            startActivity(new Intent(ctx, MyPosts.class)
//                    .putExtra("from", "dashboard")
//                    .putExtra("gender", "-1"));
//        }
        else if (id == R.id.myFev) {
            startActivity(new Intent(ctx, MyFav_Arc.class)
                    .putExtra("from", "dashboard_fav"));
        } else if (id == R.id.myArchive) {
            startActivity(new Intent(ctx, MyFav_Arc.class)
                    .putExtra("from", "dashboard_arc"));
        } else if (id == R.id.myRequest) {
            startActivity(new Intent(ctx, MyRequestActivity.class).putExtra("from", "dashboard_req"));
        } else if (id == R.id.gettogather) {
            startActivity(new Intent(ctx, GetTogether.class));
        } else if (id == R.id.myMarketing) {
            startActivity(new Intent(ctx, MyMarketActivity.class));
        } else if (id == R.id.invsent) {
            startActivity(new Intent(ctx, InvitationSent.class)
                    .putExtra("from", "dashboard_invitation_sent"));
        } else if (id == R.id.invreceive) {
            startActivity(new Intent(ctx, InvitationReceived.class)
                    .putExtra("from", "dashboard_invitation_receive"));
        } else if (id == R.id.myIncite) {
            shareMessage("https://play.google.com/store/apps/details?id=com.suguretaventure.mymarriagegroup");
        } else if (id == R.id.logout) {
            final AlertDialog alertDialog = new AlertDialog.Builder(ctx).create();
            alertDialog.setMessage("Are you sure you want to logout ?");
            alertDialog.setButton(DialogInterface.BUTTON_POSITIVE, "Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    String FCM_KEY = "" + Utils.getString(ctx, Constants.TOKEN);
                    Utils.clearPreference(ctx);
//                    Utils.setString(ctx, Constants.TOKEN, FCM_KEY);
                    startActivity(new Intent(ctx, Login.class));
                    finish();
                }
            });
            alertDialog.setButton(DialogInterface.BUTTON_NEGATIVE, "No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    alertDialog.dismiss();
                }
            });
            alertDialog.show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        if (id == R.id.myprofile) {
            startActivity(new Intent(ctx, MyProfile.class).putExtra("flagDetail", false));
        }
        else if (id == R.id.myposts) {
            startActivity(new Intent(ctx, MyPosts.class)
                    .putExtra("from", "dashboard")
                    .putExtra("gender", "-1"));
        }
        else if (id == R.id.myfav) {
            startActivity(new Intent(ctx, MyFav_Arc.class)
                    .putExtra("from", "dashboard_fav"));
        } else if (id == R.id.myRequest) {
            startActivity(new Intent(ctx, MyRequestActivity.class)
                    .putExtra("from", "dashboard_req"));
        } else if (id == R.id.myarchieved) {
            startActivity(new Intent(ctx, MyFav_Arc.class)
                    .putExtra("from", "dashboard_arc"));
        } else if (id == R.id.addbridegroom) {
            startActivity(new Intent(ctx, AddBiodata.class));
        } else if (id == R.id.mygroups) {
            startActivity(new Intent(ctx, MyGroup.class));
        } else if (id == R.id.share) {
            shareMessage("https://play.google.com/store/apps/details?id=com.suguretaventure.mymarriagegroup");
        } else if (id == R.id.feedback) {
            startActivity(new Intent(ctx, Feedback.class));
        } else if (id == R.id.HowWork) {
            startActivity(new Intent(ctx, HowWorks.class));
        } else if (id == R.id.faq) {
            startActivity(new Intent(ctx, FAQActivity.class).putExtra("PAGE", "FAQ"));
        } else if(id == R.id.youtubelink){
            openYoutubeLink();
        } else if(id == R.id.websitelink){
            websiteLink();
        }
        else if (id == R.id.TnC) {
            startActivity(new Intent(ctx, TermsActivity.class));
        } else if (id == R.id.about) {
            startActivity(new Intent(ctx, AboutActivity.class));
        } else if (id == R.id.logout) {
            String FCM_KEY = "" + Utils.getString(ctx, Constants.TOKEN);
            Utils.clearPreference(ctx);
//            Utils.setString(ctx, Constants.TOKEN, FCM_KEY);
            startActivity(new Intent(ctx, Login.class));
            finish();
        } else if (id == R.id.rate) {
            Uri uri = Uri.parse("market://details?id=" + ctx.getPackageName());
            Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
            goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
                    Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
                    Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
            try {
                startActivity(goToMarket);
            } catch (ActivityNotFoundException e) {
                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("http://play.google.com/store/apps/details?id=" + ctx.getPackageName())));
            }
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }


    private void openYoutubeLink(){
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/channel/UCD51w3xpsCC1SM0F5aEYNjw"));
        try {
            this.startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void websiteLink(){
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.mymarriagegroup.com"));
        try {
            this.startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void createNewGroup(final String gtitle, final AlertDialog aldialog) {

        if (!Utility.isNetworkAvailable(Dashboard.this)) {
            /*Snackbar.make(rcvgrp, "Internet connection is not available", Snackbar.LENGTH_INDEFINITE).setAction("RETRY", new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int permissionCheck = ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS);
                    if (permissionCheck == PackageManager.PERMISSION_GRANTED) {
                        Intent contactPicker = new Intent(ctx, ContactPickerActivity.class);
                        startActivityForResult(contactPicker, CONTACT_PICKER_REQUEST);
                    } else {
                        createNewGroup(gtitle, aldialog);
                    }
                }
            }).setActionTextColor(getResources().getColor(R.color.colorPrimary)).show();*/
        } else {
            final ProgressDialog progressDialog = new ProgressDialog(ctx);
            progressDialog.setTitle("Please wait...");
            progressDialog.show();
            progressDialog.setCancelable(false);
            int compressionRatio = 2; //1 == originalImage, 2 = 50% compression, 4=25% compress
            MultipartBody.Part part;
            if (CameraFileAbsolutePath != null) {
                File file = new File(CameraFileAbsolutePath);
                try {
                    Bitmap bitmap = BitmapFactory.decodeFile(file.getPath());
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 70, new FileOutputStream(file));
                } catch (Throwable t) {
                    Log.e("ERROR", "Error compressing file." + t.toString());
                    t.printStackTrace();
                }
                // Create a request body with file and image media type
                RequestBody fileReqBody = RequestBody.create(MediaType.parse("image/*"), file);
                part = MultipartBody.Part.createFormData("image", file.getName(), fileReqBody);
            } else {
                part = MultipartBody.Part.createFormData("image", "img1.png");
            }
            // Create MultipartBody.Part using file request-body,file name and part name
            //Create request body with text description and text media type
            RequestBody description1 = RequestBody.create(MediaType.parse("text/plain"), Utils.getString(ctx, Constants.USER_ID));
            RequestBody description2 = RequestBody.create(MediaType.parse("text/plain"), gtitle);
            WebServiceCaller.getClient().addGroupModelCall(part, description1, description2).enqueue(new Callback<AddGroupModel>() {
                @Override
                public void onResponse(Call<AddGroupModel> call, retrofit2.Response<AddGroupModel> response) {
                    Utils.log(TAG, response.toString());
                    if (response.isSuccessful()) {
                        Toast.makeText(ctx, response.body().getMsg(), Toast.LENGTH_LONG).show();
                        CameraFileAbsolutePath = null;
                        hidePDialog();
                        aldialog.dismiss();
                        gid = response.body().getGid();
                        /*int permissionCheck = ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS);
                        if (permissionCheck == PackageManager.PERMISSION_GRANTED) {


                            new MultiContactPicker.Builder(Dashboard.this) //Activity/fragment context
                                    .hideScrollbar(false) //Optional - default: false
                                    .showTrack(true) //Optional - default: true
                                    .searchIconColor(Color.WHITE) //Option - default: White
                                    .setChoiceMode(MultiContactPicker.CHOICE_MODE_MULTIPLE) //Optional - default: CHOICE_MODE_MULTIPLE
                                    .handleColor(ContextCompat.getColor(Dashboard.this, R.color.colorPrimary)) //Optional - default: Azure Blue
                                    .bubbleColor(ContextCompat.getColor(Dashboard.this, R.color.colorPrimary)) //Optional - default: Azure Blue
                                    .bubbleTextColor(Color.WHITE) //Optional - default: White
                                    .setTitleText("Select Contacts") //Optional - default: Select Contacts

                                    .setLoadingType(MultiContactPicker.LOAD_SYNC) //Optional - default LOAD_ASYNC (wait till all loaded vs stream results)
                                    .limitToColumn(LimitColumn.NONE) //Optional - default NONE (Include phone + email, limiting to one can improve loading time)
                                    .setActivityAnimations(android.R.anim.fade_in, android.R.anim.fade_out,
                                            android.R.anim.fade_in,
                                            android.R.anim.fade_out) //Optional - default: No animation overrides
                                    .showPickerForResult(CONTACT_PICKER_REQUEST);



                           *//* Intent contactPicker = new Intent(ctx, ContactPickerActivity.class);
                            startActivityForResult(contactPicker, CONTACT_PICKER_REQUEST);*//*
                        } else {
                            launchContactPicker();
                        }*/
                    } else {
                        Toast.makeText(ctx, "Error api", Toast.LENGTH_LONG).show();
                    }
                    progressDialog.dismiss();
                }

                @Override
                public void onFailure(Call<AddGroupModel> call, Throwable t) {
                    //swipeContainer.setRefreshing(false)
                    //
                    progressDialog.dismiss();
                    Toast.makeText(ctx, "Server Error", Toast.LENGTH_LONG).show();
                    Utils.log(TAG, t.getMessage());
                }
            });
        }


    }

    public void allocateMemory() {
        rcvgrp = findViewById(R.id.rcvgrp);
        lblemptygrp = findViewById(R.id.lblemptygrp1);
        flt_newgroup = findViewById(R.id.flt_newgroup);
        lay_mkt = findViewById(R.id.lay_mkt);
        btnfeedback2 = findViewById(R.id.btnfeedback2);
        relDash = findViewById(R.id.relDash);
        lblNoGroupDash = findViewById(R.id.lblNoGroupDash);
        tvNoGroupTagLine = findViewById(R.id.tvNoGroupTagLine);
        tvCountInvReceived = findViewById(R.id.tvCountInvReceived);
        tvCountInvSent = findViewById(R.id.tvCountInvSent);
        llInvReceived = findViewById(R.id.llInvReceived);
        llInvSent = findViewById(R.id.llInvSent);
        lblemptygrp.setText(Html.fromHtml(Constants.WELCOME_MESSAGE));
        lblNoGroupDash.setText("You have no group at present");
        tvNoGroupTagLine.setText("Please request your friend to add you in a particular group (where he is already member) or Group Admin create a new for your community!");


        adViewHome = findViewById(R.id.adViewHome);
        AdRequest adRequest = new AdRequest.Builder().build();

        adViewHome.loadAd(adRequest);
        adViewHome.setVisibility(View.VISIBLE);


    }

    public void getMyGroupList() {

        if (!Utility.isNetworkAvailable(Dashboard.this)) {
            /*Snackbar.make(rcvgrp, "Internet connection is not available", Snackbar.LENGTH_INDEFINITE).setAction("RETRY", new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    getMyGroupList();
                }
            }).setActionTextColor(getResources().getColor(R.color.colorPrimary)).show();*/
        } else {
            final ProgressDialog progressDialog = new ProgressDialog(ctx);
            progressDialog.setTitle("Fetching Data...");
            progressDialog.show();
            progressDialog.setCancelable(false);
            Utils.log(TAG, "REQUEST_URL : " + "my_groups.php" + "?rid=" + Utils.getString(ctx, Constants.USER_ID));
            WebServiceCaller.getClient().getGroupListModelCall("" + Utils.getString(ctx, Constants.USER_ID)).enqueue(new Callback<GroupListModel>() {
                @Override
                public void onResponse(Call<GroupListModel> call, retrofit2.Response<GroupListModel> response) {
                    if (response.isSuccessful()) {

                        groupListModel = response.body();
                        Utils.log(TAG, "REQUEST_URL : " + "my_groups.php" + "?rid=" + new Gson().toJson(groupListModel));

//                        Utils.setString(ctx, Constants.USER_IS_VIP, "0");
                        Utils.setString(ctx, Constants.USER_IS_VIP, groupListModel.members.is_vip_member);
                        Utils.setString(ctx, Constants.USER_IS_FIRST_PROFILE_UPLOADED, groupListModel.members.is_premium_profile_added);
                        int total = groupListModel.getGrouplist().size();
                        Log.d(TAG, "grouplist: "+groupListModel.getGrouplist());
                        if (total == 0) {
                            rcvgrp.setVisibility(View.GONE);
                            relDash.setVisibility(View.VISIBLE);
                            setAdapter();

                        } else {
                            relDash.setVisibility(View.GONE);
                            rcvgrp.setVisibility(View.VISIBLE);
                         setAdapter();
                        }
                    } else {
                        Toast.makeText(ctx, "No result found", Toast.LENGTH_LONG).show();
                    }
                    progressDialog.dismiss();

                }

                @Override
                public void onFailure(Call<GroupListModel> call, Throwable t) {
                    //swipeContainer.setRefreshing(false)
                    //
                    progressDialog.dismiss();
                    rcvgrp.setVisibility(View.GONE);
                    relDash.setVisibility(View.VISIBLE);
                 setAdapter();
//                    Log.e("Error", t.getMessage());
//                    Toast.makeText(ctx, "Error:" +t.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }

    }

    private void setAdapter() {
        grpAdapter = new MyGroupAdapter(ctx, groupListModel, "0",this);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        rcvgrp.setLayoutManager(mLayoutManager);
        rcvgrp.setAdapter(grpAdapter);
    }

    // show process Dialog box
    private void showpDialog() {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }

    // hide process Dialog box
    private void hidePDialog() {
        if (this.pDialog != null) {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }

    public void setupToolbar() {
        toolbar = getSupportActionBar();
        assert toolbar != null;
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setTitle(getResources().getString(R.string.app_name_title));
    }

    void requestPermission() {
        if (PackageManager.PERMISSION_GRANTED !=
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ||
                PackageManager.PERMISSION_GRANTED != ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)) {
            String[] PermissionList = {Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.CAMERA};
            if (ActivityCompat.shouldShowRequestPermissionRationale
                    (this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ||
                    ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA)) {

                ActivityCompat.requestPermissions(this, PermissionList,
                        REQUEST_MULTIPLE_PERMISSION);
            } else {
                ActivityCompat.requestPermissions(this, PermissionList,
                        REQUEST_MULTIPLE_PERMISSION);
            }
        } else {
            showDialogBox();
        }
    }

    private void showDialogBox() {
        androidx.appcompat.app.AlertDialog.Builder b1 = new androidx.appcompat.app.AlertDialog.Builder(ctx);
        b1.setTitle("Select Photo");
        b1.setIcon(R.mipmap.logo1);
        b1.setMessage("I want to select photo");
        b1.setPositiveButton("Using CAMERA", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);


                File image = null;
                try {
                    image = Util.CreteFileWithUniqueName(ctx);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                CameraFileAbsolutePath = image.getAbsolutePath();

                Uri photoURI = FileProvider.getUriForFile(ctx,
                        BuildConfig.APPLICATION_ID + ".provider", image);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(intent, CAMERA);
            }
        });
        b1.setNegativeButton("using Gallery", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent = new Intent(Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, GALLARY);
            }
        });

        b1.create().show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Toast.makeText(ctx, "" + requestCode, Toast.LENGTH_SHORT).show();
        if (requestCode == GALLARY && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            Cursor cursor = MediaStore.Images.Media.query(getContentResolver(), uri, new String[]{MediaStore.Images.Media.DATA});
            if (cursor != null && cursor.moveToFirst()) {
                CameraFileAbsolutePath = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA));
                photoUri = Uri.parse("file:" + CameraFileAbsolutePath);
                File destimage = null;
                try {
                    destimage = Util.CreteFileWithUniqueName(ctx);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (photoUri != null) {
                    File file = new File(uri.getPath());
                    UCrop.of(photoUri, Uri.fromFile(destimage))
                            .withAspectRatio(10f, 10f)
                            .withMaxResultSize(1024, 1024)
                            .start(Dashboard.this);
                }
//                imageCompressTask = new ImageCompressTask(this, CameraFileAbsolutePath, iImageCompressTaskListener);
//                mExecutorService.execute(imageCompressTask);
//                Bitmap bmp = BitmapFactory.decodeFile(CameraFileAbsolutePath);
//                imgphotoid.setRotation(ExifUtil.getCameraPhotoOrientation(CameraFileAbsolutePath));
//                imgphotoid.setImageBitmap(bmp);
            }

        } else if (requestCode == CAMERA) {

            photoUri = Uri.parse("file:" + CameraFileAbsolutePath);
            File destimage = null;
            try {
                destimage = Util.CreteFileWithUniqueName(ctx);
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (photoUri != null) {
                UCrop.of(photoUri, Uri.fromFile(destimage))
                        .withAspectRatio(10f, 10f)
                        .withMaxResultSize(1024, 1024)
                        .start(Dashboard.this);
            }
            /*if (CameraFileAbsolutePath != null) {
                File imgFile = new File(CameraFileAbsolutePath);
                if (imgFile.exists()) {
                    imageCompressTask = new ImageCompressTask(this, CameraFileAbsolutePath, iImageCompressTaskListener);
                    mExecutorService.execute(imageCompressTask);
                    Bitmap bmp = BitmapFactory.decodeFile(CameraFileAbsolutePath);
                    imgphotoid.setRotation(ExifUtil.getCameraPhotoOrientation(CameraFileAbsolutePath));
                    imgphotoid.setImageBitmap(bmp);
                    // imgphotoid.setImageBitmap(image);
                }
            }*/
        } else if (resultCode == RESULT_OK && requestCode == UCrop.REQUEST_CROP) {
            final Uri resultUri = UCrop.getOutput(data);

            Log.e("CROP IMAGE PATH", resultUri.toString());

            Bitmap cursor = null;
            try {
                cursor = MediaStore.Images.Media.getBitmap(getContentResolver(),
                        resultUri);
            } catch (IOException e) {
                e.printStackTrace();
            }
            imgphotoid.setImageBitmap(cursor);

        } else if (requestCode == CONTACT_PICKER_REQUEST) {


            //contacts were selected
            if (resultCode == RESULT_OK) {

                if (data != null) {


                    List<ContactResult> results = MultiContactPicker.obtainResult(data);
                    Log.d("MyTag", results.get(0).getDisplayName());

                    if (results != null) {
                        for (ContactResult selectedContact : results) {
                            List<String> list = new ArrayList<>();
                            list.add(selectedContact.getPhoneNumbers() + "|" + selectedContact.getDisplayName());
                            mContacts.add(selectedContact);

                        }
                    }

                    setRecyclerView(gid);
                }
            } else if (resultCode == RESULT_CANCELED) {
                System.out.println("User closed the picker without selecting items.");
            }

            /* if (data != null) {
                    TreeSet<SimpleContact> selectedContacts = (TreeSet<SimpleContact>) data.getSerializableExtra(ContactPickerActivity.CP_SELECTED_CONTACTS);
                    if (selectedContacts != null) {
                        for (SimpleContact selectedContact : selectedContacts) {
                            List<String> list = new ArrayList<>();
                            list.add(selectedContact.getCommunication() + "|" + selectedContact.getDisplayName());
                            mContacts.add(new Contact(selectedContact.getDisplayName(), list));
                        }
                    }
                }
            setRecyclerView(gid);
        }*/
        }
    }

    private void setRecyclerView(String gid) {

        ArrayList<String> name = new ArrayList<>();
        ArrayList<String> no = new ArrayList<>();
        for (int i = 0; i < mContacts.size(); i++) {
            name.add(mContacts.get(i).getDisplayName());
            String temp_name = mContacts.get(i).getDisplayName();
            String temp_no = mContacts.get(i).getPhoneNumbers().get(0).getNumber().replace("-", "");
            String nameNo = temp_no + "|" + temp_name;

            no.add(nameNo);
        }

        Utils.log(TAG, convertStringArrayToString(name));
        Utils.log(TAG, convertStringArrayToString(no));
        String Contactlist = convertStringArrayToString(no);
        pDialog = new ProgressDialog(ctx);
        pDialog.setMessage("Contact(s) Adding...");
        showpDialog();
        if (!Contactlist.equalsIgnoreCase("")) {
            AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
            RequestParams params = new RequestParams();
            params.put("gid", gid);
            params.put("id", Utils.getString(ctx, Constants.USER_ID));
            params.put("mobile", Contactlist);
            Utils.log(TAG, "ADD_CONTACT_LIST_URL : " + Constants.APP_ADD_MEMBER + "?" + params);
            client.post(Constants.APP_ADD_MEMBER, params, new AsyncHttpResponseHandler() {
                @Override
                public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                    String response = new String(responseBody);
                    Utils.log(TAG, "ADD_CONTACT_LIST_RESPONSE : " + response);
                    MemberData data = new Gson().fromJson(response, MemberData.class);
                    if (data.members.size() > 0) {
                        Toast.makeText(ctx, "Member Invited Successfully.", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(ctx, "Member Added Successfully.", Toast.LENGTH_LONG).show();
                    }
                    hidePDialog();
                    getMyGroupList();
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                    Utils.log(TAG, "ADD_CONTACT_LIST_ERROR : " + error.getMessage());
                    hidePDialog();
                }
            });
        } else {
            hidePDialog();
        }
    }

    private void shareMessage(String message) {
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, message);
        startActivity(intent);
    }

    @Override
    protected void onRestart() {
        super.onRestart();


        lblregpersonname.setText(Utils.getString(ctx, Constants.USER_NAME) + " " + Utils.getString(ctx, Constants.USER_SURNAME));
        lblprofile.setText("" + Utils.getString(ctx, Constants.USER_EMAIL));
        lblMobile.setText("" + Utils.getString(ctx, Constants.USER_MOBILE));
        if (Utils.getString(ctx, Constants.USER_PHOTO) != null) {
            Glide.with(ctx).load(Utils.getString(ctx, Constants.USER_PHOTO)).apply(RequestOptions.circleCropTransform()).into(imgregperson);
        }

    }


    public void launchContactPicker() {
        int permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS);
        if (permissionCheck == PackageManager.PERMISSION_GRANTED) {


            new MultiContactPicker.Builder(Dashboard.this) //Activity/fragment context
                    .hideScrollbar(false) //Optional - default: false
                    .showTrack(true) //Optional - default: true
                    .searchIconColor(Color.WHITE) //Option - default: White
                    .setChoiceMode(MultiContactPicker.CHOICE_MODE_MULTIPLE) //Optional - default: CHOICE_MODE_MULTIPLE
                    .handleColor(ContextCompat.getColor(Dashboard.this, R.color.colorPrimary)) //Optional - default: Azure Blue
                    .bubbleColor(ContextCompat.getColor(Dashboard.this, R.color.colorPrimary)) //Optional - default: Azure Blue
                    .bubbleTextColor(Color.WHITE) //Optional - default: White
                    .setTitleText("Select Contacts") //Optional - default: Select Contacts

                    .setLoadingType(MultiContactPicker.LOAD_ASYNC) //Optional - default LOAD_ASYNC (wait till all loaded vs stream results)
                    .limitToColumn(LimitColumn.PHONE) //Optional - default NONE (Include phone + email, limiting to one can improve loading time)
                    .setActivityAnimations(android.R.anim.fade_in, android.R.anim.fade_out,
                            android.R.anim.fade_in,
                            android.R.anim.fade_out) //Optional - default: No animation overrides
                    .showPickerForResult(CONTACT_PICKER_REQUEST);



         /*   Intent contactPicker = new Intent(this, ContactPickerActivity.class);
            contactPicker.putExtra(ContactPickerActivity.DISPLAY_SERVICE, false);
            startActivityForResult(contactPicker, CONTACT_PICKER_REQUEST);*/
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_CONTACTS},
                    READ_CONTACT_REQUEST);
        }
    }

    // check version on play store and force update
    public void forceUpdate() {
        PackageManager packageManager = this.getPackageManager();
        PackageInfo packageInfo = null;
        try {
            packageInfo = packageManager.getPackageInfo(getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        assert packageInfo != null;
        String currentVersion = packageInfo.versionName;
        new GooglePlayStoreAppVersionNameLoader(currentVersion, Dashboard.this).execute();
    }

    @Override
    public void showHideText(String isDefault) {
        if (isDefault.equals("0")){
            txt.setVisibility(View.GONE);
        }else {
            adViewHome.setVisibility(View.GONE);
            txt.setVisibility(View.VISIBLE);
            txt.setText("Now create a special Marriage Group for your own Community, Religion, Caste, City etc. all over the world ! You can see your Groups here.");

        }
    }
}
