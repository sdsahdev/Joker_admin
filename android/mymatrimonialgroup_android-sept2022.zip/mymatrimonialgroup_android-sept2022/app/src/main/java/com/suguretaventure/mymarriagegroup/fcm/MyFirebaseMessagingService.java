package com.suguretaventure.mymarriagegroup.fcm;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;

import androidx.core.app.NotificationCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.suguretaventure.mymarriagegroup.Dashboard;
import com.suguretaventure.mymarriagegroup.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;


public class MyFirebaseMessagingService extends FirebaseMessagingService {
	public static final String FCM_PARAM = "picture";
	private static final String CHANNEL_NAME = "FCM";
	private static final String CHANNEL_DESC = "Firebase Cloud Messaging";
	private int numMessages = 0;
	private static final String TAG = MyFirebaseMessagingService.class.getSimpleName();
	@Override
	public void onMessageReceived(RemoteMessage remoteMessage) {
		super.onMessageReceived(remoteMessage);
		RemoteMessage.Notification notification = remoteMessage.getNotification();
		Map<String, String> data = remoteMessage.getData();
		//Log.d("Response", Objects.requireNonNull(remoteMessage.getNotification()).getBody());
		sendNotification(notification, data);


		/*if (remoteMessage == null)
			return;

		// Check if message contains a notification payload.
		if (remoteMessage.getNotification() != null) {
			Log.e(TAG, "Notification Body: " + remoteMessage.getNotification().getBody());
			handleNotification(remoteMessage.getNotification().getBody());
		}

		// Check if message contains a data payload.
		if (remoteMessage.getData().size() > 0) {
			Log.e(TAG, "Data Payload: " + remoteMessage.getData().toString());

			try {
				JSONObject json = new JSONObject(remoteMessage.getData().toString());
				//handleDataMessage(json);
				String title = json.getString("title");
				String message = json.getString("message");

				sendNotification(title,message);
			} catch (Exception e) {
				Log.e(TAG, "Exception: " + e.getMessage());
			}
		}*/

	}

	private void handleDataMessage(JSONObject json) {

		Log.e(TAG, "push json: " + json.toString());

		try {

			String title = json.getString("title");
			String message = json.getString("message");

			//sendNotification(title,message);
		} catch (JSONException e) {
			Log.e(TAG, "Json Exception: " + e.getMessage());
		} catch (Exception e) {
			Log.e(TAG, "Exception: " + e.getMessage());
		}


		/*JSONObject data = json.getJSONObject("Data");


		String title = data.getString("title").toUpperCase();
		String message = data.getString("message");*/
	}

	private void handleNotification(String message) {
		if (!NotificationUtils.isAppIsInBackground(getApplicationContext())) {
			// app is in foreground, broadcast the push message
			Intent pushNotification = new Intent(ConfigNotification.PUSH_NOTIFICATION);
			pushNotification.putExtra("message", message);
			LocalBroadcastManager.getInstance(this).sendBroadcast(pushNotification);

			// play notification sound
			NotificationUtils notificationUtils = new NotificationUtils(getApplicationContext());
			notificationUtils.playNotificationSound();
		}else{
			// If the app is in background, firebase itself handles the notification

			Intent pushNotification = new Intent(ConfigNotification.PUSH_NOTIFICATION);
			pushNotification.putExtra("message", message);
			LocalBroadcastManager.getInstance(this).sendBroadcast(pushNotification);

			// play notification sound
			NotificationUtils notificationUtils = new NotificationUtils(getApplicationContext());
			notificationUtils.playNotificationSound();
		}

	}

	private void sendNotification(RemoteMessage.Notification notification, Map<String, String> data) {
		Bundle bundle = new Bundle();
		bundle.putString(FCM_PARAM, data.get(FCM_PARAM));
		/*android.util.Log.d("MainActivity",data.toString() );*/

		Log.d("MainActivity",notification.getTitle() + ","+notification.getBody() );

		Intent intent = new Intent(this, Dashboard.class);
		intent.putExtras(bundle);

		PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

		NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this, getString(R.string.notification_channel_id))
				.setContentTitle(notification.getTitle())
				.setContentText(notification.getBody())
                .setStyle(new NotificationCompat.BigTextStyle().bigText(notification.getBody()))
				.setAutoCancel(true)
				.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
				//.setSound(Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.win))
				.setContentIntent(pendingIntent)
				.setContentInfo("Hello")
				.setLargeIcon(BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher))
				.setColor(getResources().getColor(R.color.colorPrimary))
				.setLights(Color.RED, 1000, 300)
				.setDefaults(Notification.DEFAULT_VIBRATE)
				.setNumber(++numMessages)
				.setSmallIcon(R.mipmap.ic_launcher)
				.setPriority(Notification.PRIORITY_MAX);


		/*try {
			String picture = data.get(FCM_PARAM);
			if (picture != null && !"".equals(picture)) {
				URL url = new URL(picture);
				Bitmap bigPicture = BitmapFactory.decodeStream(url.openConnection().getInputStream());
				notificationBuilder.setStyle(
						new NotificationCompat.BigPictureStyle().bigPicture(bigPicture).setSummaryText(notification.getBody())
				);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}*/

		NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
			NotificationChannel channel = new NotificationChannel(
					getString(R.string.notification_channel_id), CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT
			);
			channel.setDescription(CHANNEL_DESC);
			channel.setShowBadge(true);
			channel.canShowBadge();
			channel.enableLights(true);
			channel.setLightColor(Color.RED);
			channel.enableVibration(true);
			channel.setVibrationPattern(new long[]{100, 200, 300, 400, 500});

			assert notificationManager != null;
			notificationManager.createNotificationChannel(channel);
		}

		assert notificationManager != null;
		notificationManager.notify(0, notificationBuilder.build());
	}
}