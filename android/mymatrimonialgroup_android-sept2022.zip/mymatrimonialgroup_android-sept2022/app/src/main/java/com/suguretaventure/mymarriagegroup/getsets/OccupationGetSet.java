package com.suguretaventure.mymarriagegroup.getsets;

import android.content.Context;

/**
 * Created by ankitpatel on 11/03/19.
 */

public class OccupationGetSet
{
    Context ctx;
    String title,id,gicon;
    String totalcount;

    public OccupationGetSet(Context ctx, String occupationTitle,
                            String occupationId, String gcount, String gicon)
    {
        this.title = occupationTitle;
        this.id = occupationId;
        this.totalcount = gcount;
        this.gicon = gicon;
    }

    public OccupationGetSet() {}

    public String getGicon() {
        return gicon;
    }

    public void setGicon(String gicon) {
        this.gicon = gicon;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTotalcount() {
        return totalcount;
    }

    public void setTotalcount(String totalcount) {
        this.totalcount = totalcount;
    }
}
