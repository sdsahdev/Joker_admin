package com.suguretaventure.mymarriagegroup;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.razorpay.Checkout;
import com.suguretaventure.mymarriagegroup.Model.AddGroupModel;
import com.suguretaventure.mymarriagegroup.Model.MemberData;
import com.suguretaventure.mymarriagegroup.adapters.OccupationAdapter;
import com.suguretaventure.mymarriagegroup.adapters.PersonAdapter;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.common.NetworkConnetionState;
import com.suguretaventure.mymarriagegroup.getsets.OccupationGetSet;
import com.suguretaventure.mymarriagegroup.imageresize.core.ImageCompressTask;
import com.suguretaventure.mymarriagegroup.imageresize.listeners.IImageCompressTaskListener;
import com.suguretaventure.mymarriagegroup.imageresize.util.Util;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utility;
import com.suguretaventure.mymarriagegroup.utils.Utils;
import com.suguretaventure.mymarriagegroup.utils.WebServiceCaller;
import com.wafflecopter.multicontactpicker.ContactResult;
import com.wafflecopter.multicontactpicker.LimitColumn;
import com.wafflecopter.multicontactpicker.MultiContactPicker;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import cz.msebera.android.httpclient.Header;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;

public class Occupations extends AppCompatActivity {
    private String TAG = "OCCUPATIONS";
    GridView gr_occupation;
    RelativeLayout lay_gall;
    Context ctx = this;
    private TextView txtallcount, lblempty_occ, btnAddFreeData;
    private ArrayList<OccupationGetSet> arr_adapter = new ArrayList<>();
    private OccupationAdapter adapter;
    private OccupationGetSet occupationGetSet;
    private String TotalRecords, gender;
    private ProgressDialog pDialog;
    ActionBar toolbar;
    private TextView txtGenderTitle, tvTemp;
    private LinearLayout addProfile;
    private ImageView imgGenderBack, imgGenderIcon, imgGenderMore;
    String mgid, mgname, count, image_1, URL;
    boolean is_premium_flag;
    private ImageView lblgroup;
    String gid = "";
    AlertDialog aldialog;
    private ImageCompressTask imageCompressTask;
    private Bitmap image = null;
    private String CameraFileAbsolutePath;
    private ImageView imgphotoid, imgphotoid_select;
    private Toolbar toolbar_top;
    private static final int READ_CONTACT_REQUEST = 1;
    private static final int CONTACT_PICKER_REQUEST = 2;
    private static final int GALLARY = 1;
    private static final int CAMERA = 2;
    private static final int REQUEST_MULTIPLE_PERMISSION = 100;
    private List<ContactResult> mContacts = new ArrayList<>();
    private ExecutorService mExecutorService = Executors.newFixedThreadPool(1);
    private FirebaseAnalytics mFirebaseAnalytics;

    int clickType = 0;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        mgid = getIntent().getExtras().getString("mgid");
        mgname = getIntent().getExtras().getString("mgname");
        URL = getIntent().getExtras().getString("URL");
        image_1 = getIntent().getExtras().getString("image");
        is_premium_flag = getIntent().getExtras().getBoolean("is_premium_flag");
// clear FLAG_TRANSLUCENT_STATUS flag:
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

// add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);

// finally change the color
        window.setStatusBarColor(getResources().getColor(R.color.colorPrimaryDark));
        setContentView(R.layout.activity_occupations);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        /*getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(getResources().getString(R.string.app_name_title));*/
        allocateMemory();

//        setupToolbar();
        if (new NetworkConnetionState().isNetworkAvailable(ctx)) {
            setOccupation();
        } else {
            networkAlert();
        }

        // imgback=findViewById(R.id.imgback);
        txtGenderTitle.setText("" + mgname);
        if (!image_1.equalsIgnoreCase("")) {
            Glide.with(ctx)
                    .load(URL + image_1)
                    .apply(RequestOptions.circleCropTransform())
                    .into(imgGenderIcon);
        }

        AdView adViewOccupation = findViewById(R.id.adViewOccupation);
        AdRequest adRequest = new AdRequest.Builder().build();
        adViewOccupation.loadAd(adRequest);

        setListener();
    }

    private void networkAlert() {
        AlertDialog.Builder b1 = new AlertDialog.Builder(ctx);
        b1.setTitle("Network Error");
        b1.setMessage("No internet connection found. Please check your phone settings to turn on the internet.");
        b1.setPositiveButton("Retry", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (new NetworkConnetionState().isNetworkAvailable(ctx)) {
                    setOccupation();
                } else {
                    networkAlert();
                }
            }
        });
        b1.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        b1.create().show();
    }

    public void setOccupation() {
        pDialog = new ProgressDialog(ctx);
        pDialog.setMessage("Please wait...");
        pDialog.setCancelable(false);
        showpDialog();
        txtallcount.setText("0");
        String WebServiceUrl = Common.GetWebServiceUrl() + "occupation_list.php";
        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        RequestParams params = new RequestParams();


        params.put("gender", gender);
        params.put("gid", mgid);
        if (is_premium_flag) {
            params.put("is_premium", "1");
        }

        Log.d("OCCUPATION_URL", WebServiceUrl + "?" + params);
        client.post(WebServiceUrl, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                Utils.log(TAG, res);
                try {
                    JSONArray response = new JSONArray(res);
                    String error = response.getJSONObject(0).getString("error");
                    if (error.equals("no error") == false) {
                        hidePDialog();
                        Common.showDialog(ctx);
                    } else {
                        int total = response.getJSONObject(1).getInt("total");
                        txtallcount.setText(response.getJSONObject(1).getString("tr"));
                        Log.d(TAG, "count: "+total);
                        if (response.getJSONObject(1).getString("tr").equals("0")) {
                            txtallcount.setVisibility(View.GONE);
                        } else {
                            txtallcount.setVisibility(View.VISIBLE);
                        }

                        if (total == 0) {
                            gr_occupation.setVisibility(View.GONE);
                            lblempty_occ.setVisibility(View.VISIBLE);
                        } else {
                            int size = response.length();
                            for (int i = 2; i < size; i++) //3
                            {
                                JSONObject object = response.getJSONObject(i);
                                occupationGetSet = new OccupationGetSet();
                                occupationGetSet.setId(object.getString("id"));
                                occupationGetSet.setTitle(object.getString("ot"));
                                occupationGetSet.setTotalcount(object.getString("tc"));
                                occupationGetSet.setGicon(object.getString("img"));
                                arr_adapter.add(occupationGetSet);
                            }
                            hidePDialog();
                            adapter = new OccupationAdapter(ctx, arr_adapter, gender);
                            gr_occupation.setAdapter(adapter);
                        }
                        hidePDialog();
                    }
                } catch (JSONException e) {
                    hidePDialog();
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

            }
        });
    }

    @SuppressLint("RestrictedApi")
    private void allocateMemory() {
        lblempty_occ = findViewById(R.id.lblempty_occ);
        txtallcount = findViewById(R.id.txtallcount);
        gr_occupation = findViewById(R.id.gr_occupation);
        lay_gall = findViewById(R.id.lay_gall);
        txtGenderTitle = findViewById(R.id.txtGenderTitle);
        imgGenderIcon = findViewById(R.id.imgGenderIcon);
        imgGenderBack = findViewById(R.id.imgGenderBack);
        addProfile = findViewById(R.id.addProfile);
        lblgroup = findViewById(R.id.lblgroup);
        tvTemp = findViewById(R.id.tvTemp);
        btnAddFreeData = findViewById(R.id.btnAddFreeData);

        gender = getIntent().getExtras().getString("gender");
        lblempty_occ.setVisibility(View.GONE);
        toolbar_top = findViewById(R.id.toolbar_top);
        setSupportActionBar(toolbar_top);

        if (gender.equals("0")) {
            lblgroup.setBackgroundResource(R.drawable.female_image_new);
            tvTemp.setText("All Free Bride Profiles");
            if (is_premium_flag) {
                tvTemp.setText("All Premium Bride Profiles");
                btnAddFreeData.setText(getResources().getString(R.string.addpremium_bride_biodata));
            } else
                btnAddFreeData.setText(getResources().getString(R.string.addfree_bride_biodata));
        } else if (gender.equals("1")) {
            lblgroup.setBackgroundResource(R.drawable.male_image_new);
            tvTemp.setText("All Free Groom Profiles");
            if (is_premium_flag) {
                tvTemp.setText("All Premium Groom Profiles");
                btnAddFreeData.setText(getResources().getString(R.string.addpremium_groom_biodata));
            } else
                btnAddFreeData.setText(getResources().getString(R.string.addfree_groom_biodata));
        }
    }

    private void setListener() {
        addProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });

        btnAddFreeData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(is_premium_flag && Utils.getString(Occupations.this, Constants.USER_IS_VIP).equals("0") )
                {
                    clickType = 3;
                    final BottomSheetDialog bottomSheerDialog = new BottomSheetDialog(ctx);
                    View parentView = LayoutInflater.from(ctx).inflate(R.layout.layout_primium_dialog, null);
                    bottomSheerDialog.setContentView(parentView);
                    ImageView imageView = parentView.findViewById(R.id.imgLogo);
                    Button btnSubscription = parentView.findViewById(R.id.btnSubscription);
                    imageView.startAnimation(AnimationUtils.loadAnimation(parentView.getContext(), R.anim.zoom_in_zoom_out));
                    btnSubscription.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startPayment("15");
                            bottomSheerDialog.dismiss();
                        }
                    });
                    bottomSheerDialog.show();
                }else{
                    if (Integer.parseInt(Utils.getString(ctx, Constants.MEMBER)) > 1 && Utils.getString(ctx, Constants.USER_DOCUMENT).equalsIgnoreCase("1")) {
                        startActivity(new Intent(ctx, AddBiodata.class)
                                .putExtra("mgid", mgid)
                                .putExtra("mgname", mgname)
                                .putExtra("image", image_1)
                                .putExtra("gender", gender)
                                .putExtra("is_premium_flag", is_premium_flag)
                                .putExtra("URL", URL));
                    } else if (!Utils.getString(ctx, Constants.USER_DOCUMENT).equalsIgnoreCase("1")) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
                        builder.setTitle("Update Your Profile");
                        builder.setMessage("Please update your profile first by adding your photo.");
                        builder.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                        builder.setPositiveButton("Go to My Profile", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                startActivity(new Intent(Occupations.this, ProfileUpdateActivity.class));
                            }
                        });
                        builder.show();
                    } else if (Integer.parseInt(Utils.getString(ctx, Constants.MEMBER)) < 2) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
                        builder.setTitle("Alert!!");
                        builder.setMessage("Minimum 2 members are required in a group to upload any bio-data. ");
                        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                        builder.show();
                    }
                }

            }
        });



        imgGenderBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Occupations.super.onBackPressed();
            }
        });
        lay_gall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ctx, PersonList.class)
                        .putExtra("gender", gender)
                        .putExtra("mgid", mgid)
                        .putExtra("mgname", mgname)
                        .putExtra("image", image_1)
                        .putExtra("URL", URL)
                        .putExtra("is_premium_flag", is_premium_flag)
                        .putExtra("goccuid", "-1")
                        .putExtra("from", "group")
                        .putExtra("goccu", "All"));
            }
        });

        gr_occupation.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                Log.d(TAG, "onItemClick: "+ arr_adapter.get(position).getId()+arr_adapter.get(position).getTitle());
                startActivity(new Intent(ctx, PersonList.class)
                        .putExtra("gender", gender)
                        .putExtra("mgid", mgid)
                        .putExtra("mgname", mgname)
                        .putExtra("image", image_1)
                        .putExtra("URL", URL)
                        .putExtra("is_premium_flag", is_premium_flag)
                        .putExtra("from", "group")
                        .putExtra("goccu", arr_adapter.get(position).getTitle())
                        .putExtra("goccuid", arr_adapter.get(position).getId())
                );
            }
        });
    }

    private void addGroup() {
        AlertDialog.Builder builder = new AlertDialog.Builder(ctx);

        LayoutInflater layoutInflater = LayoutInflater.from(ctx);
        final View myview = layoutInflater.inflate(R.layout.dialog_new_group, null);
        builder.setView(myview);

        final TextView txtgtitle = myview.findViewById(R.id.txtgtitle);
        TextView btn_create_grp = myview.findViewById(R.id.btn_create_grp);

        imgphotoid_select = myview.findViewById(R.id.imgphotoid_select);
        imgphotoid = myview.findViewById(R.id.imgphotoid);

        imgphotoid_select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //storage.write("type","1"); //user image
                requestPermission();
            }
        });

        btn_create_grp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (txtgtitle.getText().toString().length() == 0) {
                    txtgtitle.setError("Group Title required");
                } else {

                    createNewGroup(txtgtitle.getText().toString(), aldialog);

                }
            }
        });
        aldialog = builder.create();
        ((Activity) ctx).getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        final Window window = aldialog.getWindow();
        assert window != null;
        aldialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        window.setBackgroundDrawableResource(R.color.colorTransparent);
        window.setGravity(Gravity.CENTER);
        aldialog.show();
    }

    void requestPermission() {
        if (PackageManager.PERMISSION_GRANTED !=
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ||
                PackageManager.PERMISSION_GRANTED != ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)) {
            String[] PermissionList = {Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.CAMERA};
            if (ActivityCompat.shouldShowRequestPermissionRationale
                    (this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ||
                    ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA)) {

                ActivityCompat.requestPermissions(this, PermissionList,
                        REQUEST_MULTIPLE_PERMISSION);
            } else {
                ActivityCompat.requestPermissions(this, PermissionList,
                        REQUEST_MULTIPLE_PERMISSION);
            }
        } else {
            showDialogBox();
        }
    }

    private void showDialogBox() {
        androidx.appcompat.app.AlertDialog.Builder b1 = new androidx.appcompat.app.AlertDialog.Builder(ctx);
        b1.setTitle("Select Photo");
        b1.setIcon(R.mipmap.logo1);
        b1.setMessage("I want to select photo");
        b1.setPositiveButton("Using CAMERA", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);


                File image = null;
                try {
                    image = Util.CreteFileWithUniqueName(ctx);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                CameraFileAbsolutePath = image.getAbsolutePath();

                Uri photoURI = FileProvider.getUriForFile(ctx,
                        BuildConfig.APPLICATION_ID + ".provider", image);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(intent, CAMERA);
            }
        });
        b1.setNegativeButton("using Gallery", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent = new Intent(Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, GALLARY);
            }
        });

        b1.create().show();
    }

    private void createNewGroup(final String gtitle, final AlertDialog aldialog) {

        if (!Utility.isNetworkAvailable(Occupations.this)) {
            /*Snackbar.make(rcvgrp, "Internet connection is not available", Snackbar.LENGTH_INDEFINITE).setAction("RETRY", new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int permissionCheck = ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS);
                    if (permissionCheck == PackageManager.PERMISSION_GRANTED) {
                        Intent contactPicker = new Intent(ctx, ContactPickerActivity.class);
                        startActivityForResult(contactPicker, CONTACT_PICKER_REQUEST);
                    } else {
                        createNewGroup(gtitle, aldialog);
                    }
                }
            }).setActionTextColor(getResources().getColor(R.color.colorPrimary)).show();*/
        } else {
            final ProgressDialog progressDialog = new ProgressDialog(ctx);
            progressDialog.setTitle("Please wait...");
            progressDialog.show();
            progressDialog.setCancelable(false);
            int compressionRatio = 2; //1 == originalImage, 2 = 50% compression, 4=25% compress
            MultipartBody.Part part;
            if (CameraFileAbsolutePath != null) {
                File file = new File(CameraFileAbsolutePath);
                try {
                    Bitmap bitmap = BitmapFactory.decodeFile(file.getPath());
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 9, new FileOutputStream(file));
                } catch (Throwable t) {
                    Log.e("ERROR", "Error compressing file." + t.toString());
                    t.printStackTrace();
                }
                // Create a request body with file and image media type
                RequestBody fileReqBody = RequestBody.create(MediaType.parse("image/*"), file);
                part = MultipartBody.Part.createFormData("image", file.getName(), fileReqBody);
            } else {
                part = MultipartBody.Part.createFormData("image", "img1.png");
            }
            // Create MultipartBody.Part using file request-body,file name and part name
            //Create request body with text description and text media type
            RequestBody description1 = RequestBody.create(MediaType.parse("text/plain"), Utils.getString(ctx, Constants.USER_ID));
            RequestBody description2 = RequestBody.create(MediaType.parse("text/plain"), gtitle);
            WebServiceCaller.getClient().addGroupModelCall(part, description1, description2).enqueue(new Callback<AddGroupModel>() {
                @Override
                public void onResponse(Call<AddGroupModel> call, retrofit2.Response<AddGroupModel> response) {
                    Utils.log(TAG, response.toString());
                    if (response.isSuccessful()) {
                        Toast.makeText(ctx, response.body().getMsg(), Toast.LENGTH_LONG).show();
                        CameraFileAbsolutePath = null;
                        hidePDialog();
                        aldialog.dismiss();
                        gid = response.body().getGid();
                        int permissionCheck = ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS);
                        if (permissionCheck == PackageManager.PERMISSION_GRANTED) {


                            new MultiContactPicker.Builder(Occupations.this) //Activity/fragment context
                                    .hideScrollbar(false) //Optional - default: false
                                    .showTrack(true) //Optional - default: true
                                    .searchIconColor(Color.WHITE) //Option - default: White
                                    .setChoiceMode(MultiContactPicker.CHOICE_MODE_MULTIPLE) //Optional - default: CHOICE_MODE_MULTIPLE
                                    .handleColor(ContextCompat.getColor(Occupations.this, R.color.colorPrimary)) //Optional - default: Azure Blue
                                    .bubbleColor(ContextCompat.getColor(Occupations.this, R.color.colorPrimary)) //Optional - default: Azure Blue
                                    .bubbleTextColor(Color.WHITE) //Optional - default: White
                                    .setTitleText("Select Contacts") //Optional - default: Select Contacts

                                    .setLoadingType(MultiContactPicker.LOAD_ASYNC) //Optional - default LOAD_ASYNC (wait till all loaded vs stream results)
                                    .limitToColumn(LimitColumn.PHONE) //Optional - default NONE (Include phone + email, limiting to one can improve loading time)
                                    .setActivityAnimations(android.R.anim.fade_in, android.R.anim.fade_out,
                                            android.R.anim.fade_in,
                                            android.R.anim.fade_out) //Optional - default: No animation overrides
                                    .showPickerForResult(CONTACT_PICKER_REQUEST);


                            //  Intent contactPicker = new Intent(ctx, ContactPickerActivity.class);
                            //  startActivityForResult(contactPicker, CONTACT_PICKER_REQUEST);
                        } else {
                            launchContactPicker();
                        }
                    } else {
                        Toast.makeText(ctx, "Error api", Toast.LENGTH_LONG).show();
                    }
                    progressDialog.dismiss();
                }

                @Override
                public void onFailure(Call<AddGroupModel> call, Throwable t) {
                    //swipeContainer.setRefreshing(false)
                    //
                    progressDialog.dismiss();
                    Toast.makeText(ctx, "Server Error", Toast.LENGTH_LONG).show();
                    Utils.log(TAG, t.getMessage());
                }
            });
        }


    }

    // show process Dialog box
    private void showpDialog() {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }

    // hide process Dialog box
    private void hidePDialog() {
        if (this.pDialog != null) {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }

    public void setupToolbar() {
        toolbar = getSupportActionBar();
        assert toolbar != null;
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.home3:
                startActivity(new Intent(this, Dashboard.class));
                break;

            case R.id.menu_group:
                addGroup();
                break;

            case R.id.menu_CNP:

                if(is_premium_flag && Utils.getString(Occupations.this, Constants.USER_IS_VIP).equals("0") )
                {
                        clickType = 3;
                        final BottomSheetDialog bottomSheerDialog = new BottomSheetDialog(ctx);
                        View parentView = LayoutInflater.from(ctx).inflate(R.layout.layout_primium_dialog, null);
                        bottomSheerDialog.setContentView(parentView);
                        ImageView imageView = parentView.findViewById(R.id.imgLogo);
                        Button btnSubscription = parentView.findViewById(R.id.btnSubscription);
                        imageView.startAnimation(AnimationUtils.loadAnimation(parentView.getContext(), R.anim.zoom_in_zoom_out));
                        btnSubscription.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                startPayment("15");
                                bottomSheerDialog.dismiss();
                            }
                        });
                        bottomSheerDialog.show();
                }else {
                    if (Integer.parseInt(Utils.getString(ctx, Constants.MEMBER)) > 1 && Utils.getString(ctx, Constants.USER_DOCUMENT).equalsIgnoreCase("1")) {
                        startActivity(new Intent(ctx, AddBiodata.class)
                                .putExtra("mgid", mgid)
                                .putExtra("mgname", mgname)
                                .putExtra("image", image_1)
                                .putExtra("gender", gender)
                                .putExtra("is_premium_flag", is_premium_flag)
                                .putExtra("URL", URL));
                    } else if (!Utils.getString(ctx, Constants.USER_DOCUMENT).equalsIgnoreCase("1")) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
                        builder.setTitle("Update Your Profile");
                        builder.setMessage("Please update your profile first by adding your photo.");
                        builder.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                        builder.setPositiveButton("Go to My Profile", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                startActivity(new Intent(Occupations.this, ProfileUpdateActivity.class));
                            }
                        });
                        builder.show();
                    } else if (Integer.parseInt(Utils.getString(ctx, Constants.MEMBER)) < 2) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
                        builder.setTitle("Alert!!");
                        builder.setMessage("Minimum 2 members are required in a group to upload any bio-data. ");
                        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                    /*builder.setPositiveButton("Go to My Profile", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            startActivity(new Intent(GenderActivity.this, ProfileUpdateActivity.class));
                        }
                    });*/
                        builder.show();
                    }
                }



                /*else {
                    AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
                    builder.setTitle("Update Your Profile");
                    builder.setMessage("Please update your profile first by adding your photo. Also minimum 2 members are required in a group to upload any bio-data.");
                    builder.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    builder.setPositiveButton("Go to My Profile", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            startActivity(new Intent(Occupations.this, ProfileUpdateActivity.class));
                        }
                    });
                    builder.show();
                }*/
                break;

            case R.id.myFavourite:
                startActivity(new Intent(ctx, MyFav_Arc.class)
                        .putExtra("from", "dashboard_fav_group")
                        .putExtra("groupId", mgid));
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.gender_menu, menu);
       /* menu_get_to = menu.findItem(R.id.addGetTo);
        if (Utils.getString(ctx, "isAdmin").equalsIgnoreCase("1")) {
            menu_get_to.setVisible(true);
        } else {
            menu_get_to.setVisible(false);
        }*/
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GALLARY && resultCode == RESULT_OK &&
                data != null) {
            Uri uri = data.getData();
            Cursor cursor = MediaStore.Images.Media.query(getContentResolver(),
                    uri, new String[]{MediaStore.Images.Media.DATA});
            if (cursor != null && cursor.moveToFirst()) {
                CameraFileAbsolutePath = cursor.getString(cursor.getColumnIndexOrThrow
                        (MediaStore.Images.Media.DATA));
                imageCompressTask = new ImageCompressTask(this, CameraFileAbsolutePath,
                        iImageCompressTaskListener);
                mExecutorService.execute(imageCompressTask);
                Bitmap bmp = BitmapFactory.decodeFile(CameraFileAbsolutePath);
                imgphotoid.setImageBitmap(bmp);
            }

        } else if (requestCode == CAMERA) {
            if (CameraFileAbsolutePath != null) {
                File imgFile = new File(CameraFileAbsolutePath);
                if (imgFile.exists()) {
                    imageCompressTask = new ImageCompressTask(this, CameraFileAbsolutePath,
                            iImageCompressTaskListener);
                    mExecutorService.execute(imageCompressTask);
                    Bitmap bmp = BitmapFactory.decodeFile(CameraFileAbsolutePath);
                    imgphotoid.setImageBitmap(bmp);
                    // imgphotoid.setImageBitmap(image);
                }
            }
        } else if (resultCode == CONTACT_PICKER_REQUEST) {

            //contacts were selected
            if (resultCode == RESULT_OK) {

                if (data != null) {

                    List<ContactResult> results = MultiContactPicker.obtainResult(data);
                    Log.d("MyTag", results.get(0).getDisplayName());

                    if (results != null) {
                        for (ContactResult selectedContact : results) {
                            List<String> list = new ArrayList<>();
                            list.add(selectedContact.getPhoneNumbers() + "|" + selectedContact.getDisplayName());
                            mContacts.add(selectedContact);
                        }
                    }
                    setRecyclerView(gid);
                }

            } else if (resultCode == RESULT_CANCELED) {
                System.out.println("User closed the picker without selecting items.");
            }
        }
    }

    public void launchContactPicker() {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.READ_CONTACTS},
                READ_CONTACT_REQUEST);
    }

    private IImageCompressTaskListener iImageCompressTaskListener = new IImageCompressTaskListener() {
        @Override
        public void onComplete(List<File> compressed) {
            File file = compressed.get(0);
            imgphotoid.setImageBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()));

        }

        @Override
        public void onError(Throwable error) {
        }
    };

    private void setRecyclerView(String gid) {
        ArrayList<String> name = new ArrayList<>();
        ArrayList<String> no = new ArrayList<>();
        for (int i = 0; i < mContacts.size(); i++) {
            name.add(mContacts.get(i).getDisplayName());
            String temp_name = mContacts.get(i).getDisplayName();
            String temp_no = mContacts.get(i).getPhoneNumbers().get(0).getNumber().replace("-", "");
            String nameNo = temp_no + "|" + temp_name;

            no.add(nameNo);
        }

        Utils.log(TAG, convertStringArrayToString(name));
        Utils.log(TAG, convertStringArrayToString(no));

        pDialog = new ProgressDialog(ctx);
        pDialog.setMessage("Contact(s) Adding...");
        showpDialog();
        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        RequestParams params = new RequestParams();
        params.put("gid", gid);
        params.put("id", Utils.getString(ctx, Constants.USER_ID));
        params.put("mobile", convertStringArrayToString(no));
        Utils.log(TAG, "ADD_CONTACT_LIST_URL : " + Constants.APP_ADD_MEMBER + "?" + params);
        client.post(Constants.APP_ADD_MEMBER, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                Utils.log(TAG, "ADD_CONTACT_LIST_RESPONSE : " + response);
                MemberData data = new Gson().fromJson(response, MemberData.class);
                if (data.members.size() > 0) {
                    Toast.makeText(ctx, "Member Invited Successfully.", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(ctx, "Member Added Successfully.", Toast.LENGTH_LONG).show();
                }
                hidePDialog();
                setOccupation();
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "ADD_CONTACT_LIST_ERROR : " + error.getMessage());
                hidePDialog();
            }
        });
    }

    private static String convertStringArrayToString(ArrayList<String> strArr) {
        StringBuilder sb = new StringBuilder();
        for (String str : strArr)
            sb.append(str).append("-");
        return sb.substring(0, sb.length() - 1);
    }

    public void startPayment(String amount) {
//                Checkout.preload(context);
        final Activity activity = this;
        String amount_ = String.valueOf(Integer.parseInt(amount) * 100*75);
        final Checkout co = new Checkout();
//        co.setKeyID("rzp_live_rqh0DabOcTj5iZ");

        try {
            JSONObject options = new JSONObject();
            options.put("name", "" + Utils.getString(ctx, Constants.USER_NAME));
            options.put("description", "Add Bio Data Charge");
            options.put("image", "");
            options.put("currency", "INR");
            options.put("amount", amount_);

            JSONObject preFill = new JSONObject();
            preFill.put("email", "" + Utils.getString(ctx, Constants.USER_EMAIL));
            preFill.put("contact", "" + Utils.getString(ctx, Constants.USER_MOBILE));

            options.put("prefill", preFill);

            co.open(activity, options);
        } catch (Exception e) {
            Toast.makeText(activity, "Error in payment: " + e.getMessage(), Toast.LENGTH_SHORT)
                    .show();
            e.printStackTrace();
        }
    }

    private void subscribeUser(final String razorPayId) {

        pDialog = new ProgressDialog(ctx);
        pDialog.setMessage("Please wait...");
        pDialog.setCancelable(false);
        showpDialog();

        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        RequestParams params = new RequestParams();
        params.put("rid", Utils.getString(ctx, Constants.USER_ID));
        Utils.log(TAG, "REQUEST_URL : " + Constants.SUBSCRIBE_USER + "?" + params);
        client.post(Constants.SUBSCRIBE_USER, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                Utils.log(TAG, "REQUEST_RESPONSE : " + response);
                Toast.makeText(Occupations.this, "Congratulation!. You are VIP member now of My Marriage Group", Toast.LENGTH_SHORT).show();
                Utils.setString(Occupations.this, Constants.USER_FIRST_PROFILE_PAYMENT_ID, razorPayId);
                Utils.setString(Occupations.this, Constants.USER_IS_VIP, "1");
                if (clickType == 1) {
                    startActivity(new Intent(ctx, Occupations.class)
                            .putExtra("gender", "1")
                            .putExtra("mgid", mgid)
                            .putExtra("mgname", mgname)
                            .putExtra("image", image)
                            .putExtra("is_premium_flag", true)
                            .putExtra("URL", URL));
                } else if (clickType == 2) {
                    startActivity(new Intent(ctx, Occupations.class)
                            .putExtra("gender", "0")
                            .putExtra("mgid", mgid)
                            .putExtra("mgname", mgname)
                            .putExtra("image", image)
                            .putExtra("is_premium_flag", true)
                            .putExtra("URL", URL));
                } else if (clickType == 3) {
                    if (Integer.parseInt(Utils.getString(ctx, Constants.MEMBER)) > 1 && Utils.getString(ctx, Constants.USER_DOCUMENT).equalsIgnoreCase("1")) {
                        startActivity(new Intent(ctx, AddBiodata.class)
                                .putExtra("mgid", mgid)
                                .putExtra("mgname", mgname)
                                .putExtra("image", image)
                                .putExtra("gender", "")
                                .putExtra("is_premium_flag", true)
                                .putExtra("URL", URL));
                    } else if (!Utils.getString(ctx, Constants.USER_DOCUMENT).equalsIgnoreCase("1")) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
                        builder.setTitle("Update Your Profile");
                        builder.setMessage("Please update your profile first by adding your photo.");
                        builder.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                        builder.setPositiveButton("Go to My Profile", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                startActivity(new Intent(Occupations.this, ProfileUpdateActivity.class));
                            }
                        });
                        builder.show();
                    } else if (Integer.parseInt(Utils.getString(ctx, Constants.MEMBER)) < 2) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
                        builder.setTitle("Alert!!");
                        builder.setMessage("Minimum 2 members are required in a group to upload any bio-data. ");
                        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                    /*builder.setPositiveButton("Go to My Profile", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            startActivity(new Intent(PrimiumBiodataActivity.this, ProfileUpdateActivity.class));
                        }
                    });*/
                        builder.show();
                    }
                }
               /* BioData data = new Gson().fromJson(response, BioData.class);
                Utils.log("REQ_RESPONSE", data.totalRequest);*/
                hidePDialog();
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "REQUEST_ERROR : " + error.getMessage());
                hidePDialog();
            }
        });
    }
}
