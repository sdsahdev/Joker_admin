package com.suguretaventure.mymarriagegroup.adapters;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.suguretaventure.mymarriagegroup.PersonalDetails;
import com.suguretaventure.mymarriagegroup.R;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.getsets.MyGrpRegListGetSet;

import java.util.ArrayList;

/**
 * Created by ankitpatel on 23/02/19.
 */

public class MyGrpRegListAdapter extends RecyclerView.Adapter<MyGrpRegListAdapter.MyViewHolder>
{
    private Context context;
    private LayoutInflater inflater;
    private ArrayList<MyGrpRegListGetSet> arr_adapter;
    private ProgressDialog pDialog;

    public MyGrpRegListAdapter(Context context, ArrayList<MyGrpRegListGetSet> arr_adapter)
    {
        this.context = context;
        this.arr_adapter = arr_adapter;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_my_grp_reg, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, @SuppressLint("RecyclerView") final int i) {
        holder.lblgrpregname.setText(arr_adapter.get(i).getFullname());
        holder.lblgrpregmobno.setText(arr_adapter.get(i).getMobile());
        holder.lblgrp_regu_posts.setText("Posts: " + arr_adapter.get(i).getPosts());

        Glide.with(context)
                .load(Common.GetRegUserIDImageUrl()+arr_adapter.get(i).getPhoto())
                .apply(RequestOptions.circleCropTransform())
                .into(holder.imgreguser);

        holder.lay_show_posts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                context.startActivity(new Intent(context, PersonalDetails.class)
                        .putExtra("from","group")
                        .putExtra("Rid",arr_adapter.get(i).getRid()));
            }
        });
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        TextView lblgrpregname,lblgrpregmobno,lblgrp_regu_posts;
        ImageView imgreguser;
        LinearLayout lay_show_posts;

        MyViewHolder(View view) {
            super(view);
            lblgrp_regu_posts = view.findViewById(R.id.lblgrp_regu_posts);
            lblgrpregname = view.findViewById(R.id.lblgrpregname);
            lblgrpregmobno = view.findViewById(R.id.lblgrpregmobno);
            imgreguser = view.findViewById(R.id.imgreguser);
            lay_show_posts = view.findViewById(R.id.lay_show_posts);
        }
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return arr_adapter.size();
    }
}
