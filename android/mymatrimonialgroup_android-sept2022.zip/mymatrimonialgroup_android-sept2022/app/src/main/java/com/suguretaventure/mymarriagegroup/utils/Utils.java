package com.suguretaventure.mymarriagegroup.utils;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.suguretaventure.mymarriagegroup.BuildConfig;
import com.suguretaventure.mymarriagegroup.R;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import cz.msebera.android.httpclient.Header;

/**
 * Created by VINING3 on 10/10/2018.
 */

public class Utils {

    private static SharedPreferences getSP(Context context) {
        return context.getSharedPreferences(Constants.TAG, Context.MODE_PRIVATE);
    }

    public static void log(String TAG, String msg) {
        if (Constants.isDebug) {
            Log.d(TAG, msg);
        }
    }

    public static void setString(Context context, String key, String value) {
        SharedPreferences.Editor editor = getSP(context).edit();
        editor.putString(key, value);
        editor.apply();
    }

    public static String getString(Context context, String key) {
        if (key.equals(Constants.USER_ID) && BuildConfig.DEBUG)
            return "7";
        return getSP(context).getString(key, "");
    }

    public static void removePref(Context context, String key) {
        SharedPreferences.Editor editor = getSP(context).edit();
        editor.remove(key);
        editor.apply();
    }

    public static void setBoolean(Context context, String key, boolean value) {
        SharedPreferences.Editor editor = getSP(context).edit();
        editor.putBoolean(key, value);
        editor.apply();
    }

    public static void setInteger(Context context, String key, int value) {
        SharedPreferences.Editor editor = getSP(context).edit();
        editor.putInt(key, value);
        editor.apply();
    }

    public static int getInteger(Context context, String key) {
        return getSP(context).getInt(key, 0);
    }

    public static boolean getBoolean(Context context, String key) {
        return getSP(context).getBoolean(key, false);
    }

    public static void hideKeyboard(Activity activity) {
        InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
        View focusedView = activity.getCurrentFocus();
        if (focusedView != null) {
            if (inputMethodManager != null) {
                inputMethodManager.hideSoftInputFromWindow(focusedView.getWindowToken(), 0);
            }
        }
    }

    public static void setLogin(Context context) {
        SharedPreferences.Editor editor = getSP(context).edit();
        editor.putBoolean("LOGIN", true);
        editor.apply();
    }

    public static boolean isLogin(Context context) {
        return getSP(context).getBoolean("LOGIN", false);
    }

    public static void setCoupon(Context context) {
        SharedPreferences.Editor editor = getSP(context).edit();
        editor.putBoolean("COUPON", true);
        editor.apply();
    }

    public static boolean isCoupon(Context context) {
        return getSP(context).getBoolean("COUPON", false);
    }

    public static void clearPreference(Context context) {
        getSP(context).edit().clear().apply();
    }

    public static String md5(String password) {
        MessageDigest digest;
        try {
            digest = MessageDigest.getInstance("MD5");
            digest.reset();
            digest.update(password.getBytes());
            byte[] a = digest.digest();
            int len = a.length;
            StringBuilder sb = new StringBuilder(len << 1);
            for (byte anA : a) {
                sb.append(Character.forDigit((anA & 0xf0) >> 4, 16));
                sb.append(Character.forDigit(anA & 0x0f, 16));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static boolean isValidEmail(CharSequence target) {
        return !TextUtils.isEmpty(target) && Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }

    public static boolean isInternet(Context mContext) {
        ConnectivityManager cm = (ConnectivityManager) mContext.getSystemService(Context.CONNECTIVITY_SERVICE);
        return (cm != null ? cm.getActiveNetworkInfo() : null) != null;
    }


    public static <T> T gson(String response, Class<T> typeClass) {
        return new Gson().fromJson(response, typeClass);
    }

    public static Animation downFromTop() {
        TranslateAnimation downFromTop = new TranslateAnimation(0f, 0f, -100f, 0f);
        downFromTop.setDuration(1000);
        return downFromTop;
    }

    public static Animation upFromBottom() {
        TranslateAnimation upFromBottom = new TranslateAnimation(0f, 0f, 100f, 0f);
        upFromBottom.setDuration(1000);
        return upFromBottom;
    }
}
