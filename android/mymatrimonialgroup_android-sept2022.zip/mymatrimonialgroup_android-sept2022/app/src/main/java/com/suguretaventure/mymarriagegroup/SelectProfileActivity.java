package com.suguretaventure.mymarriagegroup;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;

import retrofit2.http.Header;

public class SelectProfileActivity extends AppCompatActivity {

    private AdView adViewGender;
    TextView btnPremiumProfiles, btnAddFreeData, txtGenderTitle;
    private ImageView imgGenderBack;
    private Toolbar toolbar_top;
    private ImageView imgGenderIcon;
    Bundle bundle;
    private ProgressDialog pDialog;
    private Context ctx = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_profile);
        bundle = getIntent().getExtras();
        bundle.getString("Brides");
        bundle.getString("Grooms");

        setListener();


        AdRequest adRequest = new AdRequest.Builder().build();
        adViewGender.loadAd(adRequest);


    }

    private void setListener() {
        toolbar_top = findViewById(R.id.toolbar_top);
        setSupportActionBar(toolbar_top);
        adViewGender = findViewById(R.id.adViewGender);
        btnPremiumProfiles = findViewById(R.id.btnPremiumProfiles);
        btnAddFreeData = findViewById(R.id.btnAddFreeData);
        imgGenderBack = toolbar_top.findViewById(R.id.imgGenderBack);
        txtGenderTitle = toolbar_top.findViewById(R.id.txtGenderTitle);
        imgGenderIcon = toolbar_top.findViewById(R.id.imgGenderIcon);

        getCountPerson();
        getPremiumCountPerson();

        imgGenderBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SelectProfileActivity.super.onBackPressed();
            }
        });

        if (!getIntent().getStringExtra("image").equalsIgnoreCase("")) {
            Glide.with(SelectProfileActivity.this)
                    .load(getIntent().getStringExtra("URL") + getIntent().getStringExtra("image"))
                    .apply(RequestOptions.circleCropTransform())
                    .into(imgGenderIcon);
        }

        btnPremiumProfiles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SelectProfileActivity.this,
                        PrimiumBiodataActivity.class).putExtra("mgid", getIntent().getStringExtra("mgid"))
                        .putExtra("mgname", getIntent().getStringExtra("mgname"))
                        .putExtra("image", getIntent().getStringExtra("image"))
                        .putExtra("URL", getIntent().getStringExtra("URL"))
                        .putExtra("GROUP_MEMBER", getIntent().getStringExtra("GROUP_MEMBER")));
            }
        });

        btnAddFreeData.setText("FREE PROFILES" + "\n " + "Brides " + getIntent().getStringExtra("Brides") + "  " + "Grooms " + getIntent().getStringExtra("Grooms"));
        btnPremiumProfiles.setText("PREMIUM PROFILES" + "\n " + "Brides " + getIntent().getStringExtra("Brides") + "  " + "Grooms " + getIntent().getStringExtra("Grooms"));

        btnAddFreeData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addBiodata();
            }
        });
        txtGenderTitle.setText(getIntent().getStringExtra("mgname"));
    }


    private void addBiodata() {

        startActivity(new Intent(SelectProfileActivity.this, GenderActivity.class)
                .putExtra("mgid", getIntent().getStringExtra("mgid"))
                .putExtra("mgname", getIntent().getStringExtra("mgname"))
                .putExtra("image", getIntent().getStringExtra("image"))
                .putExtra("gender", "")
                .putExtra("URL", getIntent().getStringExtra("URL"))
                .putExtra("GROUP_MEMBER", getIntent().getStringExtra("GROUP_MEMBER")));

        /*if (Integer.parseInt(Utils.getString(SelectProfileActivity.this, Constants.MEMBER)) > 1 &&
                Utils.getString(SelectProfileActivity.this, Constants.USER_DOCUMENT).equalsIgnoreCase("1")) {
            startActivity(new Intent(SelectProfileActivity.this, GenderActivity.class)
                    .putExtra("mgid", getIntent().getStringExtra("mgid"))
                    .putExtra("mgname", getIntent().getStringExtra("mgname"))
                    .putExtra("image", getIntent().getStringExtra("image"))
                    .putExtra("gender", "")
                    .putExtra("URL", getIntent().getStringExtra("URL"))
                    .putExtra("GROUP_MEMBER", getIntent().getStringExtra("GROUP_MEMBER")));
        } else if (!Utils.getString(SelectProfileActivity.this, Constants.USER_DOCUMENT).equalsIgnoreCase("1")) {
            AlertDialog.Builder builder = new AlertDialog.Builder(SelectProfileActivity.this);
            builder.setTitle("Update Your Profile");
            builder.setMessage("Please update your profile first by adding your photo.");
            builder.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            builder.setPositiveButton("Go to My Profile", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    startActivity(new Intent(SelectProfileActivity.this, ProfileUpdateActivity.class));
                }
            });
            builder.show();
        } else if (Integer.parseInt(Utils.getString(SelectProfileActivity.this, Constants.MEMBER)) < 2) {
            AlertDialog.Builder builder = new AlertDialog.Builder(SelectProfileActivity.this);
            builder.setTitle("Alert!!");
            builder.setMessage("Minimum 2 members are required in a group to upload any bio-data. ");
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            builder.show();
        }*/
    }

    public void getCountPerson() {
        pDialog = new ProgressDialog(this);
        pDialog.setMessage("Please wait...");
        pDialog.setCancelable(false);
        showpDialog();

        String WebServiceUrl = Common.GetWebServiceUrl() + "total_persons.php";
        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        RequestParams params = new RequestParams();
        params.put("gid", getIntent().getStringExtra("mgid"));
        client.post(WebServiceUrl, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                Utils.log("TAG", res.toString());
                try {
                    JSONArray response = new JSONArray(res);
                    String error = response.getJSONObject(0).getString("error");
                    if (error.equals("no error") == false) {
                        hidePDialog();
                        Common.showDialog(ctx);
                    } else {
                        hidePDialog();
                        String male = response.getJSONObject(1).getString("m");
                        String female = response.getJSONObject(1).getString("f");


                        btnAddFreeData.setText(Html.fromHtml("<font color=#ffffff>" + "<b>"
                                + "FREE PROFILES" + "</b>" + "</font>" + "<br />" + "<font color=#ffffff>" + "<small>" + "Brides:" + female
                                + "</small>" + "<small>" + "  Grooms:" + male + "</small>"));
                    }
                    hidePDialog();
                } catch (JSONException e) {
                    hidePDialog();
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody, Throwable error) {
                hidePDialog();

            }


        });

    }

    private void showpDialog() {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }


    // hide process Dialog box
    private void hidePDialog() {
        if (this.pDialog != null) {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }

    public void getPremiumCountPerson() {
        /*pDialog = new ProgressDialog(ctx);
        pDialog.setMessage("Please wait...");
        pDialog.setCancelable(false);
        showpDialog();*/

        String WebServiceUrl = Common.GetWebServiceUrl() + "total_persons.php";
        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        RequestParams params = new RequestParams();
        params.put("gid", getIntent().getStringExtra("mgid"));
        params.put("is_premium", "1");
        Utils.log("TAG", "REQUEST_RESPONSE : " + WebServiceUrl);
        client.post(WebServiceUrl, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                Utils.log("TAG", res.toString());
                try {
                    JSONArray response = new JSONArray(res);
                    String error = response.getJSONObject(0).getString("error");
                    if (error.equals("no error") == false) {
                        hidePDialog();
                        Common.showDialog(ctx);
                    } else {
                        hidePDialog();
                        String male = response.getJSONObject(1).getString("m");
                        String female = response.getJSONObject(1).getString("f");

                        btnPremiumProfiles.setText(Html.fromHtml("<font color=#ffffff>" + "<b>"
                                + "PREMIUM PROFILES" + "</b>" + "</font>" + "<br />" + "<font color=#ffffff>" + "<small>" + "Brides:" + female
                                + "</small>" + "<small>" + "  Grooms:" + male + "</small>"));
                    }
                    hidePDialog();
                } catch (JSONException e) {
                    hidePDialog();
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody, Throwable error) {
                hidePDialog();

            }

           /* @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
            }*/
        });
    }
}