package com.suguretaventure.mymarriagegroup;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.app.SearchManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.provider.MediaStore;
import android.text.Html;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;
import com.google.firebase.FirebaseException;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.gson.Gson;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;
import com.rilixtech.widget.countrycodepicker.Country;
import com.rilixtech.widget.countrycodepicker.CountryCodePicker;
import com.suguretaventure.mymarriagegroup.Model.MarketAddPersonModel;
import com.suguretaventure.mymarriagegroup.Model.MarketCity;
import com.suguretaventure.mymarriagegroup.Model.MarketingListModel;
import com.suguretaventure.mymarriagegroup.Model.MarketingModel;
import com.suguretaventure.mymarriagegroup.adapters.AdapterMarket;
import com.suguretaventure.mymarriagegroup.adapters.MarketingPersonadapter;
import com.suguretaventure.mymarriagegroup.common.NetworkConnetionState;
import com.suguretaventure.mymarriagegroup.imageresize.core.ImageCompressTask;
import com.suguretaventure.mymarriagegroup.imageresize.listeners.IImageCompressTaskListener;
import com.suguretaventure.mymarriagegroup.imageresize.util.Util;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.ExifUtil;
import com.suguretaventure.mymarriagegroup.utils.Utility;
import com.suguretaventure.mymarriagegroup.utils.Utils;
import com.suguretaventure.mymarriagegroup.utils.WebServiceCaller;
import com.yalantis.ucrop.UCrop;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import cz.msebera.android.httpclient.Header;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;

public class MarketActivity extends AppCompatActivity implements PaymentResultListener {
    private String TAG = "MARKET_ACTIVITY";
    private Context context = this;
    private SearchView searchView;
    private int counter = 60;
    private boolean isMobileVerified = false;
    private FirebaseAuth auth;
    List<MarketingModel> marketModels = new ArrayList<>();
    AdapterMarket adapterMarket;
    ActionBar toolbar;
    private RecyclerView recyvCategoryList;
    String mgid, mgname, count, Iconimage, URL;
    private TextView txtGenderTitle, tvNoData;
    private ImageView imgGenderIcon, imgGenderBack;
    private Toolbar toolbar_top;
    private String CodeSend;
    String strcid, strcname, strname, straddress, stremail, strmobile, strdesc, strWeb, strCity;
    private Bitmap image = null;
    ProgressDialog dialogsending, dialog;
    private String CameraFileAbsolutePath, CameraFileAbsolutePath1, CameraFileAbsolutePath2;
    private int imageUploadType;
    private ImageView imgphotoid, imgphotoid11, imgphotoid2, imgphotoid_select, imgphotoid_select1, imgphotoid_select2;
    private LinearLayout flt_newgroup;
    private static final int GALLARY = 1;
    private static final int CAMERA = 2;
    private static final int REQUEST_MULTIPLE_PERMISSION = 100;
    private ExecutorService mExecutorService = Executors.newFixedThreadPool(1);
    private ImageCompressTask imageCompressTask;
    private ArrayList<String> ListCategory, ListCategoryId, ListCity;
    private String cid = "";
    private Spinner spnCategorySearch, spnCitySearch;
    private TextView tvSubmit, tvClear, txtdefault;
    private String cat_id = "0", city = "", payment_id = "";
    private LinearLayout LinSPN, LinCategory;
    Dialog alertDialog;
    private String CountryCode = "";
    private boolean isGroup = false;

    private EditText etAddOTP, txtmobileno;


    String latitude = "", longitude = "";
    String source_lat = "", source_lng = "";
    String source_name = "", leave_city = "";
    private AdView mAdView;
    private TextView linResend;

    Button btnSendotp;
    LinearLayout linAddOTP;
    TextView btn_create_grp;
    TextView tvPayment;

    private Uri photoUri;
    private FirebaseAnalytics mFirebaseAnalytics;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        Places.initialize(MarketActivity.this, getResources().getString(R.string.google_maps_key));
        Window window = getWindow();
// clear FLAG_TRANSLUCENT_STATUS flag:
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

// add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);

// finally change the color
        window.setStatusBarColor(getResources().getColor(R.color.colorPrimaryDark));

        setContentView(R.layout.activity_market);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);

        isGroup = getIntent().getBooleanExtra("isGroup", false);

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);


        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                // Code to be executed when an ad finishes loading.
            }

            @Override
            public void onAdFailedToLoad(int errorCode) {
                // Code to be executed when an ad request fails.
            }

            @Override
            public void onAdOpened() {
                // Code to be executed when an ad opens an overlay that
                // covers the screen.
            }

            @Override
            public void onAdClicked() {
                // Code to be executed when the user clicks on an ad.
            }

            @Override
            public void onAdLeftApplication() {
                // Code to be executed when the user has left the app.
            }

            @Override
            public void onAdClosed() {
                // Code to be executed when the user is about to return
                // to the app after tapping on an ad.
            }
        });


        recyvCategoryList = findViewById(R.id.recyvCategoryList);

        imgGenderIcon = findViewById(R.id.imgGenderIcon);
        imgGenderBack = findViewById(R.id.imgGenderBack);

        flt_newgroup = findViewById(R.id.flt_newgroup);
        spnCategorySearch = findViewById(R.id.spnCategorySearch);
        spnCitySearch = findViewById(R.id.spnCitySearch);
        tvSubmit = findViewById(R.id.tvSubmit);
        tvClear = findViewById(R.id.tvClear);
        txtdefault = findViewById(R.id.txtdefault);
        tvNoData = findViewById(R.id.tvNoData);
        auth = FirebaseAuth.getInstance();

        txtGenderTitle = findViewById(R.id.txtGenderTitle);
        toolbar_top = findViewById(R.id.toolbar_top);
        setSupportActionBar(toolbar_top);
        imgGenderBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MarketActivity.super.onBackPressed();
            }
        });


        Intent intent = this.getIntent();
        txtdefault.setText(Html.fromHtml(Constants.Market_MESSAGE));
        if (intent != null) {
            mgid = intent.getStringExtra("mgid");
            mgname = intent.getStringExtra("mgname");
            URL = intent.getStringExtra("URL");
            Iconimage = intent.getStringExtra("image");
            if (mgid != null) {
                txtGenderTitle.setText("" + mgname);
                if (!Iconimage.equalsIgnoreCase("")) {
                    Glide.with(context)
                            .load(URL + Iconimage)
                            .apply(RequestOptions.circleCropTransform())
                            .into(imgGenderIcon);
                }
            } else {
                txtGenderTitle.setText("Market");

            }
        }
        //setData();
        //Set List Adapter

        if (new NetworkConnetionState().isNetworkAvailable(context)) {
            setData();
            getCity();
            updateData(cat_id, city);
            setonclicklistner();
            imgGenderBack.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    MarketActivity.super.onBackPressed();
                }
            });

        } else {
            networkAlert();
        }


    }

    private void getCity() {
        ListCity = new ArrayList<>();
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        Utils.log(TAG, "FILTER_CITY_DATA_URL : " + Constants.APP_MARKETING_CITY + "?" + null);
        client.post(Constants.APP_MARKETING_CITY, null, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                Utils.log(TAG, "FILTER_CITY_DATA_RESPONSE : " + res);
                if (!res.equalsIgnoreCase("")) {
                    MarketCity data = new Gson().fromJson(res, MarketCity.class);
                    ListCity.add("Select City");
                    for (int i = 0; i < data.marketing.size(); i++) {
                        ListCity.add("" + data.marketing.get(i).city);
                    }

                    ArrayAdapter AgenttypeAdapter = new ArrayAdapter(context, R.layout.my_spinner, R.id.tvSpinner, ListCity);
                    spnCitySearch.setAdapter(AgenttypeAdapter);

                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "FILTER_CITY_DATA_ERROR : " + error.getMessage());
            }
        });
    }

    private void updateData(String cat, String c_id) {
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("cid", "" + cat);
        params.put("city", "" + c_id);
        Utils.log(TAG, "FILTER_DATA_URL : " + Constants.APP_MARKETING_SEARCH + "?" + params);
        client.post(Constants.APP_MARKETING_SEARCH, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                Utils.log(TAG, "FILTER_DATA_RESPONSE : " + res);
                if (!res.equalsIgnoreCase("")) {
                    MarketingListModel data = new Gson().fromJson(res, MarketingListModel.class);
                    if (data.data.size() > 0) {
                        recyvCategoryList.setLayoutManager(new LinearLayoutManager(context));
                        recyvCategoryList.setAdapter(new MarketingPersonadapter(context, data, "-"));
                        recyvCategoryList.setVisibility(View.VISIBLE);
                        tvNoData.setVisibility(View.GONE);
                        txtdefault.setVisibility(View.GONE);
                    } else {
                        recyvCategoryList.setVisibility(View.GONE);
                        tvNoData.setVisibility(View.VISIBLE);
                        txtdefault.setVisibility(View.VISIBLE);
                        Toast.makeText(MarketActivity.this, "No data found", Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "FILTER_DATA_ERROR : " + error.getMessage());
            }
        });
    }

    void requestPermission() {
        if (PackageManager.PERMISSION_GRANTED !=
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ||
                PackageManager.PERMISSION_GRANTED != ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)) {
            String[] PermissionList = {Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.CAMERA};
            if (ActivityCompat.shouldShowRequestPermissionRationale
                    (this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ||
                    ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA)) {

                ActivityCompat.requestPermissions(this, PermissionList,
                        REQUEST_MULTIPLE_PERMISSION);
            } else {
                ActivityCompat.requestPermissions(this, PermissionList,
                        REQUEST_MULTIPLE_PERMISSION);
            }
        } else {
            showDialogBox();
        }
    }

    private void showDialogBox() {
        androidx.appcompat.app.AlertDialog.Builder b1 = new androidx.appcompat.app.AlertDialog.Builder(context);
        b1.setTitle("Select Photo");
        b1.setIcon(R.mipmap.logo1);
        b1.setMessage("I want to select photo");
        b1.setPositiveButton("Using CAMERA", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                File image = null;
                try {
                    image = Util.CreteFileWithUniqueName(MarketActivity.this);
                } catch (IOException e) {
                    e.printStackTrace();
                }

                if (imageUploadType == 1) {
                    CameraFileAbsolutePath = image.getAbsolutePath();
                }
                if (imageUploadType == 2) {
                    CameraFileAbsolutePath1 = image.getAbsolutePath();
                }
                if (imageUploadType == 3) {
                    CameraFileAbsolutePath2 = image.getAbsolutePath();
                }

                Uri photoURI = FileProvider.getUriForFile(MarketActivity.this,
                        BuildConfig.APPLICATION_ID + ".provider", image);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(intent, CAMERA);
            }
        });
        b1.setNegativeButton("using Gallery", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent = new Intent(Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, GALLARY);
            }
        });

        b1.create().show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GALLARY && resultCode == RESULT_OK &&
                data != null) {

            Uri uri = data.getData();
            Cursor cursor = MediaStore.Images.Media.query(getContentResolver(),
                    uri, new String[]{MediaStore.Images.Media.DATA});
            if (cursor != null && cursor.moveToFirst()) {
                switch (imageUploadType) {
                    case 1:
                        CameraFileAbsolutePath = cursor.getString(cursor.getColumnIndexOrThrow
                                (MediaStore.Images.Media.DATA));
                        photoUri = Uri.parse("file:"+CameraFileAbsolutePath);
                        break;
                    case 2:
                        CameraFileAbsolutePath1 = cursor.getString(cursor.getColumnIndexOrThrow
                                (MediaStore.Images.Media.DATA));

                        photoUri = Uri.parse("file:"+CameraFileAbsolutePath1);

                        break;
                    case 3:
                        CameraFileAbsolutePath2 = cursor.getString(cursor.getColumnIndexOrThrow
                                (MediaStore.Images.Media.DATA));
                        photoUri = Uri.parse("file:"+CameraFileAbsolutePath2);
                        break;
                }

            }
            if (photoUri!=null){

                File destimage = null;
                try {
                    destimage = Util.CreteFileWithUniqueName(this);
                } catch (IOException e) {
                    e.printStackTrace();
                }


                UCrop.of(photoUri, Uri.fromFile(destimage))
                        .withAspectRatio(8f, 5f)
                        .withMaxResultSize(1024, 650)
                        .start(MarketActivity.this);
            }





            /*Uri uri = data.getData();
            Cursor cursor = MediaStore.Images.Media.query(getContentResolver(),
                    uri, new String[]{MediaStore.Images.Media.DATA});
            if (cursor != null && cursor.moveToFirst()) {
                String imgPath = cursor.getString(cursor.getColumnIndexOrThrow
                        (MediaStore.Images.Media.DATA));
                imageCompressTask = new ImageCompressTask(this, imgPath,
                        iImageCompressTaskListener);
                mExecutorService.execute(imageCompressTask);
                if (imageUploadType == 1) {
                    CameraFileAbsolutePath = imgPath;
                    Bitmap bmp = BitmapFactory.decodeFile(imgPath);
                    imgphotoid.setRotation(ExifUtil.getCameraPhotoOrientation(CameraFileAbsolutePath));
                    imgphotoid.setImageBitmap(bmp);
                }

                if (imageUploadType == 2) {
                    CameraFileAbsolutePath1 = imgPath;
                    Bitmap bmp = BitmapFactory.decodeFile(imgPath);
                    imgphotoid11.setRotation(ExifUtil.getCameraPhotoOrientation(CameraFileAbsolutePath1));
                    imgphotoid11.setImageBitmap(bmp);
                }

                if (imageUploadType == 3) {
                    CameraFileAbsolutePath2 = imgPath;
                    Bitmap bmp = BitmapFactory.decodeFile(imgPath);
                    imgphotoid2.setRotation(ExifUtil.getCameraPhotoOrientation(CameraFileAbsolutePath2));
                    imgphotoid2.setImageBitmap(bmp);
                }


            }*/

        } else if (requestCode == CAMERA) {
            //imgphotoid.setImageBitmap(image);


            switch (imageUploadType){
                case 1:
                    photoUri = Uri.parse("file:"+CameraFileAbsolutePath);
                    break;
                case 2:
                    photoUri = Uri.parse("file:"+CameraFileAbsolutePath1);
                    break;
                case 3:
                    photoUri = Uri.parse("file:"+CameraFileAbsolutePath2);
                    break;
            }
            if (photoUri!=null){

                File destimage = null;
                try {
                    destimage = Util.CreteFileWithUniqueName(this);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                UCrop.of(photoUri, Uri.fromFile(destimage))
                        .withAspectRatio(8f, 5f)
                        .withMaxResultSize(1024, 650)
                        .start(MarketActivity.this);
            }

            /*if (imageUploadType == 1) {
                File imgFile = new File(CameraFileAbsolutePath);
                if (imgFile.exists()) {
                    imageCompressTask = new ImageCompressTask(this, CameraFileAbsolutePath,
                            iImageCompressTaskListener);
                    mExecutorService.execute(imageCompressTask);
                    Bitmap bmp = BitmapFactory.decodeFile(CameraFileAbsolutePath);
                    imgphotoid.setRotation(ExifUtil.getCameraPhotoOrientation(CameraFileAbsolutePath));
                    imgphotoid.setImageBitmap(bmp);
                }
            }

            if (imageUploadType == 2) {
                File imgFile = new File(CameraFileAbsolutePath1);
                if (imgFile.exists()) {
                    imageCompressTask = new ImageCompressTask(this, CameraFileAbsolutePath1,
                            iImageCompressTaskListener);
                    mExecutorService.execute(imageCompressTask);
                    Bitmap bmp = BitmapFactory.decodeFile(CameraFileAbsolutePath1);
                    imgphotoid11.setRotation(ExifUtil.getCameraPhotoOrientation(CameraFileAbsolutePath1));
                    imgphotoid11.setImageBitmap(bmp);
                }
            }

            if (imageUploadType == 3) {
                File imgFile = new File(CameraFileAbsolutePath2);
                if (imgFile.exists()) {
                    imageCompressTask = new ImageCompressTask(this, CameraFileAbsolutePath2,
                            iImageCompressTaskListener);
                    mExecutorService.execute(imageCompressTask);
                    Bitmap bmp = BitmapFactory.decodeFile(CameraFileAbsolutePath2);
                    imgphotoid2.setRotation(ExifUtil.getCameraPhotoOrientation(CameraFileAbsolutePath2));
                    imgphotoid2.setImageBitmap(bmp);
                }
            }
*/

        }else if (resultCode == RESULT_OK && requestCode == UCrop.REQUEST_CROP) {
            final Uri resultUri = UCrop.getOutput(data);

            Log.e("CROP IMAGE PATH", resultUri.toString());

            Bitmap cursor = null;
            try {
                cursor = MediaStore.Images.Media.getBitmap(getContentResolver(),
                        resultUri);
            } catch (IOException e) {
                e.printStackTrace();
            }
            if ( imageUploadType== 1) {
                imgphotoid.setImageBitmap(cursor);
            } else if (imageUploadType == 2) {
                imgphotoid11.setImageBitmap(cursor);
            } else if (imageUploadType == 3) {
                imgphotoid2.setImageBitmap(cursor);
            }

        }
    }


    private void addMrketingperson(String razorpayPaymentID) {
        if (!Utility.isNetworkAvailable(context)) {
            /*Snackbar.make(rcvgrp, "Internet connection is not available", Snackbar.LENGTH_INDEFINITE).setAction("RETRY", new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    getMArketingperson(my_rid);
                }
            }).setActionTextColor(getResources().getColor(R.color.colorPrimary)).show();*/
        } else {
            final ProgressDialog progressDialog = new ProgressDialog(context);
            progressDialog.setTitle("Please wait...");
            progressDialog.show();
            progressDialog.setCancelable(false);

                File file = new File(CameraFileAbsolutePath);
                try {
                    Bitmap bitmap = BitmapFactory.decodeFile(file.getPath());
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 70, new FileOutputStream(file));
                } catch (Throwable t) {
                    Log.e("ERROR", "Error compressing file." + t.toString());
                    t.printStackTrace();
                }
                // Create a request body with file and image media type
                RequestBody fileReqBody = RequestBody.create(MediaType.parse("image/*"), file);
                // Create MultipartBody.Part using file request-body,file name and part name
                MultipartBody.Part part = MultipartBody.Part.createFormData("image", file.getName(), fileReqBody);

            MultipartBody.Part part1 = MultipartBody.Part.createFormData("image1", "");
            if (CameraFileAbsolutePath1!= null) {
                File file1 = new File(CameraFileAbsolutePath1);
                try {
                    Bitmap bitmap = BitmapFactory.decodeFile(file1.getPath());
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 70, new FileOutputStream(file1));
                } catch (Throwable t) {
                    Log.e("ERROR", "Error compressing file." + t.toString());
                    t.printStackTrace();
                }

                // Create a request body with file and image media type
                RequestBody fileReqBody1 = RequestBody.create(MediaType.parse("image/*"), file1);
                // Create MultipartBody.Part using file request-body,file name and part name
                part1 = MultipartBody.Part.createFormData("image1", file1.getName(), fileReqBody1);
            }
            MultipartBody.Part part2 = MultipartBody.Part.createFormData("image2","");

            if(CameraFileAbsolutePath2 != null) {
                File file2 = new File(CameraFileAbsolutePath2);
                try {
                    Bitmap bitmap = BitmapFactory.decodeFile(file2.getPath());
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 70, new FileOutputStream(file2));
                } catch (Throwable t) {
                    Log.e("ERROR", "Error compressing file." + t.toString());
                    t.printStackTrace();
                }

                // Create a request body with file and image media type
                RequestBody fileReqBody2 = RequestBody.create(MediaType.parse("image/*"), file2);
                // Create MultipartBody.Part using file request-body,file name and part name
                part2 = MultipartBody.Part.createFormData("image2", file2.getName(), fileReqBody2);
            }



            //Create request body with text description and text media type
            RequestBody description1 = RequestBody.create(MediaType.parse("text/plain"), cid);
            RequestBody description2 = RequestBody.create(MediaType.parse("text/plain"), Utils.getString(context, Constants.USER_ID));
            RequestBody description3 = RequestBody.create(MediaType.parse("text/plain"), strname);
            RequestBody description4 = RequestBody.create(MediaType.parse("text/plain"), straddress);
            RequestBody description5 = RequestBody.create(MediaType.parse("text/plain"), strmobile);
            RequestBody description6 = RequestBody.create(MediaType.parse("text/plain"), stremail);
            RequestBody description7 = RequestBody.create(MediaType.parse("text/plain"), strdesc);
            RequestBody description10 = RequestBody.create(MediaType.parse("text/plain"), strCity);
            RequestBody description12 = RequestBody.create(MediaType.parse("text/plain"), strWeb);
            RequestBody description11 = RequestBody.create(MediaType.parse("text/plain"), razorpayPaymentID);
            RequestBody description8 = RequestBody.create(MediaType.parse("text/plain"), "lat");
            RequestBody description9 = RequestBody.create(MediaType.parse("text/plain"), "lon");

            WebServiceCaller.getClient().marketAddPersonModelCall(part,part1,part2, description1, description2, description3, description4, description5, description6, description7, description8, description9, description10, description11, description12).enqueue(new Callback<MarketAddPersonModel>() {
                @Override
                public void onResponse(Call<MarketAddPersonModel> call, retrofit2.Response<MarketAddPersonModel> response) {
                    Log.d("API_RESPONSE", "DATA" + response.body().getMsg());
                    if (response.isSuccessful()) {
                        Toast.makeText(context, response.body().getMsg(), Toast.LENGTH_LONG).show();
                        CameraFileAbsolutePath = null;
                        CameraFileAbsolutePath1 = null;
                        CameraFileAbsolutePath2 = null;
                    } else {
                        Toast.makeText(context, "Error", Toast.LENGTH_LONG).show();

                    }
                    progressDialog.dismiss();
                }

                @Override
                public void onFailure(Call<MarketAddPersonModel> call, Throwable t) {
                    //swipeContainer.setRefreshing(false)
                    //
                    Log.d("ERRPR_API", t.toString());
                    progressDialog.dismiss();
                    Toast.makeText(context, "Error", Toast.LENGTH_LONG).show();
                }
            });
        }


    }

    private void networkAlert() {
        AlertDialog.Builder b1 = new AlertDialog.Builder(context);
        b1.setTitle("Network Error");
        b1.setMessage("No internet connection found. Please check your phone settings to turn on the internet.");
        b1.setPositiveButton("Retry", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                setData();
            }
        });
        b1.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        b1.create().show();
    }

    private IImageCompressTaskListener iImageCompressTaskListener = new IImageCompressTaskListener() {
        @Override
        public void onComplete(List<File> compressed) {
            File file = compressed.get(0);
            if (imageUploadType == 1) {
                imgphotoid.setImageBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()));
            }
            if (imageUploadType == 2) {
                imgphotoid11.setImageBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()));
            }

            if (imageUploadType == 3) {
                imgphotoid2.setImageBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()));
            }


        }

        @Override
        public void onError(Throwable error) {
        }
    };

    private void setData() {
        ListCategory = new ArrayList<>();
        ListCategoryId = new ArrayList<>();
        final ProgressDialog dialog = new ProgressDialog(context);
        dialog.setTitle("Please wait...");
        dialog.show();
        dialog.setCancelable(false);
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        Utils.log(TAG, Constants.APP_GET_MARKETING_LIST);
        client.post(Constants.APP_GET_MARKETING_LIST, null, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                Utils.log(TAG, "APP_GET_MARKETING_LIST_RESPONSE : " + new String(responseBody));
                MarketingModel model = new Gson().fromJson(new String(responseBody), MarketingModel.class);
                ListCategory.add("Select Category");
                ListCategoryId.add("0");
                for (int i = 0; i < model.data.size(); i++) {
                    ListCategory.add("" + model.data.get(i).cname);
                    ListCategoryId.add("" + model.data.get(i).cid);
                }

                ArrayAdapter AgenttypeAdapter = new ArrayAdapter(context, R.layout.my_spinner, R.id.tvSpinner, ListCategory);
                spnCategorySearch.setAdapter(AgenttypeAdapter);

                /*recyclerView.setLayoutManager(new LinearLayoutManager(context));
                adapterMarket = new AdapterMarket(context, model);
                recyclerView.setAdapter(adapterMarket);*/
                dialog.dismiss();
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "APP_GET_MARKETING_LIST_ERROR : " + error.getMessage());
                dialog.dismiss();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_marketing, menu);
        // Associate searchable configuration with the SearchView
        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        searchView = (SearchView) menu.findItem(R.id.action_search).getActionView();
        searchView.setVisibility(View.GONE);
        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
        searchView.setMaxWidth(Integer.MAX_VALUE);

        // listening to search query text change
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                // filter recycler view when query submitted
                //adapterFoWorkbook.getFilter().filter(query);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String query) {
                // filter recycler view when text is changed
                if (marketModels == null) {

                } else if (marketModels.size() == 0) {

                } else {
                    adapterMarket.getFilter().filter(query);
                }

                return true;
            }
        });
        return true;
    }

    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem home = menu.findItem(R.id.dashboard);
        MenuItem Addnew = menu.findItem(R.id.addAdvertise);
        MenuItem MyMarket = menu.findItem(R.id.MyMarketing);

        Log.d("Mobile_USER", "Mobile :- " + Utils.getString(context, Constants.USER_MOBILE));

        if (Utils.getString(context, Constants.USER_MOBILE).equals("")) {
            home.setVisible(false);
            Addnew.setVisible(false);
            MyMarket.setVisible(false);
        } else {
            home.setVisible(true);
            Addnew.setVisible(true);
            MyMarket.setVisible(true);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        int id = item.getItemId();
        if (id == R.id.dashboard) {
            startActivity(new Intent(context, Dashboard.class));
        } else if (id == R.id.MyMarketing) {
            startActivity(new Intent(context, MyMarketActivity.class)
                    .putExtra("isGroup", isGroup));
        } else if (id == R.id.addAdvertise) {
            addMarkrt();
        } else if (id == R.id.action_search) {
            return true;
        } else if (id == android.R.id.home) {
            finish();
        }

        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onBackPressed() {
        // close search view on back button pressed
        if (searchView != null) {
            if (!searchView.isIconified()) {
                searchView.setIconified(true);
                return;
            }
        }
        super.onBackPressed();
    }

    public void addMarkrt() {

        Utils.log(TAG, "USER ID : " + Utils.getString(context, Constants.USER_ID));
        if (!Utils.getString(context, Constants.USER_ID).equalsIgnoreCase("")) {
            alertDialog = new Dialog(context);
            alertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            alertDialog.setContentView(R.layout.dialog_new_marketing_person);
            alertDialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
            alertDialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            final EditText txtname, txtaddress, txtemail, txtdesc, txtCity, txtwebsite;
            final Spinner spnCategory;

            final RadioButton rbtnYes, rbtnNo;
            RadioGroup rgPaymentOption;

            final Button btnsubmitotp;
            final CountryCodePicker txtAddmobileCode;



            btn_create_grp = alertDialog.findViewById(R.id.btn_create_grp);
            tvPayment = alertDialog.findViewById(R.id.tvPayment);
            btnSendotp = alertDialog.findViewById(R.id.btnsendotp);
            linAddOTP = alertDialog.findViewById(R.id.LinAddOTP);
            btnsubmitotp = alertDialog.findViewById(R.id.btnsubmitotp);
            ImageView imgclose = alertDialog.findViewById(R.id.imgclose);
            TextView tvPhoto = alertDialog.findViewById(R.id.tvPhoto);
            TextView tvPhoto1 = alertDialog.findViewById(R.id.tvPhoto1);
            TextView tvPhoto2 = alertDialog.findViewById(R.id.tvPhoto2);
            isMobileVerified = false;


            imgclose.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    alertDialog.dismiss();
                }
            });
            txtAddmobileCode = alertDialog.findViewById(R.id.txtmobileCode);
            txtname = alertDialog.findViewById(R.id.txtname);
            etAddOTP = alertDialog.findViewById(R.id.etAddOTP);
            txtaddress = alertDialog.findViewById(R.id.txtaddress);
            txtemail = alertDialog.findViewById(R.id.txtemail);
            txtmobileno = alertDialog.findViewById(R.id.txtmobileno);
            txtwebsite = alertDialog.findViewById(R.id.txtwebsite);
            txtdesc = alertDialog.findViewById(R.id.txtdesc);
            imgphotoid_select = alertDialog.findViewById(R.id.imgphotoid_select);
            imgphotoid_select1 = alertDialog.findViewById(R.id.imgphotoid_select1);
            imgphotoid_select2 = alertDialog.findViewById(R.id.imgphotoid_select2);
            imgphotoid = alertDialog.findViewById(R.id.imgphotoid);
            imgphotoid11 = alertDialog.findViewById(R.id.imgphotoid11);
            imgphotoid2 = alertDialog.findViewById(R.id.imgphotoid2);
            txtCity = alertDialog.findViewById(R.id.txtCity);
            spnCategory = alertDialog.findViewById(R.id.spnCategory);
            LinSPN = alertDialog.findViewById(R.id.LinSPN);
            LinCategory = alertDialog.findViewById(R.id.LinCategory);
            linResend = alertDialog.findViewById(R.id.linResend);


            LinSPN.setVisibility(View.VISIBLE);
            CountryCode = "+" + txtAddmobileCode.getSelectedCountryCode();
            LinCategory.setVisibility(View.GONE);
            ListCategory.remove(0);
            ListCategory.add(0, "Select Category*");
            ArrayAdapter AgenttypeAdapter = new ArrayAdapter(context, R.layout.my_spinner, R.id.tvSpinner, ListCategory);
            spnCategory.setAdapter(AgenttypeAdapter);
            /*tvPhoto.setText("Upload Photo");
            tvPhoto1.setText("Upload Photo");
            tvPhoto2.setText("Upload Photo");*/
                    /*ArrayAdapter<String> customAdapter = new ArrayAdapter<String>(context, R.layout.custom_spinner_items1, ListCategory);
                    customAdapter.setDropDownViewResource(R.layout.custom_spinner_items_dropdown);
                    spnCategory.setAdapter(customAdapter);*/

            AdView adViewDialog = alertDialog.findViewById(R.id.adViewDialog);
            AdRequest adRequest = new AdRequest.Builder().build();
            adViewDialog.loadAd(adRequest);
            imgphotoid_select.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //storage.write("type","1"); //user image
                    imageUploadType = 1;
                    requestPermission();
                }
            });


            imgphotoid_select1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //storage.write("type","1"); //user image
                    imageUploadType = 2;
                    requestPermission();
                }
            });


            imgphotoid_select2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //storage.write("type","1"); //user image
                    requestPermission();
                    imageUploadType = 3;
                }
            });

            /*etAddOTP.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if (!hasFocus) {
                        if (etAddOTP.getText().length() == 6 && CodeSend != null) {
                            ProgressDialog dialog = new ProgressDialog(context);
                            dialog.setTitlde("OTP Verification");
                            dialog.setMessage("OTP Verifying");
                            dialog.setCancelable(false);
                            dialog.show();
                            PhoneAuthCredential credential = PhoneAuthProvider.getCredential(CodeSend, etAddOTP.getText().toString());
                            signInWithPhoneAuthCredential(credential, dialog, linResend , etAddOTP, txtmobileno);
                        } else {
                            Toast.makeText(context, "Please enter valid OTP", Toast.LENGTH_LONG).show();
                        }
                    }
                }
            });*/






            linResend.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    linResend.setVisibility(View.GONE);
                    if (CountryCode.equalsIgnoreCase("")) {
                        Toast.makeText(context, "enter country code", Toast.LENGTH_LONG).show();
                    } else if (txtmobileno.getText().length() < 9) {
                        txtmobileno.setError("Contact number required");
                        linAddOTP.setVisibility(View.GONE);
                    } else {
                        linAddOTP.setVisibility(View.VISIBLE);
                        sendSMS(CountryCode, txtmobileno.getText().toString(), linResend, btnSendotp, linAddOTP);
                    }
                }
            });
            /*txtmobileno.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if (!hasFocus) {

                        if (CountryCode.equalsIgnoreCase("")) {
                            Toast.makeText(context, "enter country code", Toast.LENGTH_LONG).show();
                        } else if (txtmobileno.getText().length() < 9) {
                            txtmobileno.setError("Contact number required");
                            LinAddOTP.setVisibility(View.GONE);
                        } else {
                            LinAddOTP.setVisibility(View.VISIBLE);
                            sendSMS(CountryCode, txtmobileno.getText().toString(), linResend);
                        }
                    }
                }
            });*/

            txtAddmobileCode.setOnCountryChangeListener(new CountryCodePicker.OnCountryChangeListener() {
                @Override
                public void onCountrySelected(Country selectedCountry) {
                    CountryCode = "+" + selectedCountry.getPhoneCode();
                }
            });

            spnCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if (position != 0) {
                        cid = ListCategoryId.get(position);
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            btnSendotp.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (CountryCode.equalsIgnoreCase("")) {
                        Toast.makeText(context, "enter country code", Toast.LENGTH_LONG).show();
                    } else if (txtmobileno.getText().length() < 9) {
                        txtmobileno.setError("Contact number required");
                        linAddOTP.setVisibility(View.GONE);
                    } else {
                        dialogsending = new ProgressDialog(context);
                        dialogsending.setMessage("Sending...");
                        dialogsending.setCancelable(true);
                        dialogsending.show();
                        sendSMS(CountryCode, txtmobileno.getText().toString(), linResend, btnSendotp, linAddOTP);
                    }
                }
            });

            btnsubmitotp.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (etAddOTP.getText().length() == 6 && CodeSend != null) {
                        ProgressDialog dialog = new ProgressDialog(context);
                        dialog.setTitle("OTP Verification");
                        dialog.setMessage("OTP Verifying");
                        dialog.setCancelable(false);
                        dialog.show();
                        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(CodeSend, etAddOTP.getText().toString());
                        signInWithPhoneAuthCredential(credential, dialog, linResend, etAddOTP, txtmobileno);
                    } else {
                        Toast.makeText(context, "Please enter valid OTP", Toast.LENGTH_LONG).show();
                    }
                }
            });



            rgPaymentOption = findViewById(R.id.rgPaymentOption);
            rbtnYes = findViewById(R.id.rbtnYes);
            rbtnNo = findViewById(R.id.rbtnNo);

            rbtnNo.setChecked(true);
            rgPaymentOption.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup radioGroup, int i) {
                    if (radioGroup.getCheckedRadioButtonId() == R.id.rbtnYes) {
                        btn_create_grp.setText("Proceed to Pay");

                    }
                    if (radioGroup.getCheckedRadioButtonId() == R.id.rbtnNo)  {
                        btn_create_grp.setText("Create Market");
                    }
                }
            });



            btn_create_grp.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (txtname.getText().toString().length() == 0) {
                        txtname.setError("Enter Market title");
                    } else if (txtaddress.getText().toString().length() == 0) {
                        txtaddress.setError("Enter Market Address");
                    } else if (txtmobileno.getText().toString().length() < 9) {
                        txtmobileno.setError("Enter Mobile Number");
                    } else if (txtdesc.getText().toString().length() == 0) {
                        txtdesc.setError("Enter Description");
                    } else if (txtCity.getText().toString().length() == 0) {
                        txtCity.setError("Enter City");
                    } else if (CameraFileAbsolutePath == null) {
                        Toast.makeText(context, "Photo required...", Toast.LENGTH_SHORT).show();
                    }else {
                        strname = txtname.getText().toString();
                        straddress = txtaddress.getText().toString();
                        stremail = txtemail.getText().toString();
                        if (txtemail.getText().toString().length() == 0) {
                            stremail = "-";
                        }
                        strmobile = txtmobileno.getText().toString();
                        strdesc = txtdesc.getText().toString();
                        strCity = txtCity.getText().toString();
                        strWeb = txtwebsite.getText().toString();
                        // createNewGroup(txtgtitle.getText().toString(),aldialog);
                        if (isMobileVerified) {

                            if (rbtnYes.isChecked()){
                                startPayment();
                            }else{
                                addMrketingperson("0");
                            }

                            alertDialog.dismiss();
                            //addBiodata();
                        } else {
                            Toast.makeText(context, "Verify mobile number to create market", Toast.LENGTH_LONG).show();
                        }
                    }
                }
            });
            alertDialog.show();
        } else {
            Toast.makeText(context, "You are required to Login.", Toast.LENGTH_SHORT).show();
        }
    }

    public void startPayment() {
        final Activity activity = this;

        final Checkout co = new Checkout();

        try {
            JSONObject options = new JSONObject();
            options.put("name", "" + Utils.getString(context, Constants.USER_NAME));
            options.put("description", "Add Market Charge");
            //You can omit the image option to fetch the image from dashboard
            options.put("image", "");
            options.put("currency", "USD");
            options.put("amount", "100");

            JSONObject preFill = new JSONObject();
            preFill.put("email", "" + Utils.getString(context, Constants.USER_EMAIL));
            preFill.put("contact", "" + Utils.getString(context, Constants.USER_MOBILE));

            options.put("prefill", preFill);

            co.open(activity, options);
        } catch (Exception e) {
            Toast.makeText(activity, "Error in payment: " + e.getMessage(), Toast.LENGTH_SHORT)
                    .show();
            e.printStackTrace();
        }
    }

    /**
     * The name of the function has to be
     * onPaymentSuccess
     * Wrap your code in try catch, as shown, to ensure that this method runs correctly
     */
    @SuppressWarnings("unused")
    @Override
    public void onPaymentSuccess(String razorpayPaymentID) {
        try {
            addMrketingperson(razorpayPaymentID);
            alertDialog.dismiss();
        } catch (Exception e) {
            Utils.log(TAG, "Exception in onPaymentSuccess : " + e.getMessage());
        }
    }

    /**
     * The name of the function has to be
     * onPaymentError
     * Wrap your code in try catch, as shown, to ensure that this method runs correctly
     */
    @SuppressWarnings("unused")
    @Override
    public void onPaymentError(int code, String response) {
        try {
            Toast.makeText(this, "Payment failed: " + code + " " + response, Toast.LENGTH_SHORT).show();
            Log.d("PAYMENT_CODE", String.valueOf(code));
            Log.d("PAYMENT_RESPONSE", response);
            alertDialog.dismiss();
        } catch (Exception e) {
            Utils.log(TAG, "Exception in onPaymentError : " + e.getMessage());
        }
    }

    private void sendSMS(String countryCode, String mobile, final TextView linResend, Button btnsendotp, LinearLayout linAddOTP) {
        counter = 60;
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                countryCode + "" + mobile,        // Phone number to verify
                60,                 // Timeout duration
                TimeUnit.SECONDS,   // Unit of timeout
                this,               // Activity (for callback binding)
                mCallbacks);        // OnVerificationStateChangedCallbacks
        linResend.setVisibility(View.VISIBLE);
        btnsendotp.setVisibility(View.GONE);
        linAddOTP.setVisibility(View.VISIBLE);
        new CountDownTimer(60000, 1000) {
            public void onTick(long millisUntilFinished) {
                linResend.setText("Resend OTP within " + counter + " seconds.");
                linResend.setClickable(false);
                if (counter > 0) {
                    counter--;
                } else {
                    linResend.setClickable(true);
                    linResend.setText("Resend OTP?");
                }
            }

            public void onFinish() {
                counter = 0;
                linResend.setClickable(true);
                linResend.setText("Resend OTP?");
            }
        }.start();
    }

    PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
        @Override
        public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {
            Log.d(TAG, "onVerificationCompleted");

            dialogsending.dismiss();
            isMobileVerified = true;
            Toast.makeText(context, "OTP verification Successful", Toast.LENGTH_LONG).show();


            linResend.setVisibility(View.GONE);
            btnSendotp.setVisibility(View.GONE);
            linAddOTP.setVisibility(View.GONE);

            tvPayment.setVisibility(View.VISIBLE);
            btn_create_grp.setVisibility(View.VISIBLE);

        }

        @Override
        public void onVerificationFailed(FirebaseException e) {
            Log.d(TAG, "onVerificationFailed  : " + e.getMessage());
            dialogsending.dismiss();
            Toast.makeText(context, "OTP invalid", Toast.LENGTH_LONG).show();
        }

        @Override
        public void onCodeSent(String code, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
            super.onCodeSent(code, forceResendingToken);
            CodeSend = code;
            dialogsending.dismiss();
            Toast.makeText(context, "OTP will be sent on this number", Toast.LENGTH_LONG).show();
            Log.d(TAG, "onCodeSent  : " + code);
        }
    };

    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential, final ProgressDialog dialog, final TextView linResend, final EditText etAddOTP, final EditText txtmobileno) {
        auth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {

                            Log.d(TAG, "signInWithCredential:success");

                            dialog.dismiss();
                            isMobileVerified = true;
                            Toast.makeText(MarketActivity.this, "OTP verification Successful", Toast.LENGTH_LONG).show();


                            linResend.setVisibility(View.GONE);
                            btnSendotp.setVisibility(View.GONE);
                            linAddOTP.setVisibility(View.GONE);

                            tvPayment.setVisibility(View.VISIBLE);
                            btn_create_grp.setVisibility(View.VISIBLE);

                        } else {
                            // Sign in failed, display a message and update the UI
                            Log.w(TAG, "signInWithCredential:failure", task.getException());
                            dialog.dismiss();

                            if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {
                                // The verification code entered was invalid
                                Toast.makeText(context, "The verification code entered was invalid", Toast.LENGTH_LONG).show();
                            }

                        }
                    }
                });
    }

    public void setonclicklistner() {
        flt_newgroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Utils.log(TAG, "USER ID : " + Utils.getString(context, Constants.USER_ID));
                if (!Utils.getString(context, Constants.USER_ID).equalsIgnoreCase("")) {
                    alertDialog = new Dialog(context);
                    alertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                    alertDialog.setContentView(R.layout.dialog_new_marketing_person);
                    alertDialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                    final EditText txtname, etAddOTP, txtaddress, txtemail, txtmobileno, txtdesc, txtCity, txtwebsite;
                    final Spinner spnCategory;
                    final Button btnsendotp, btnsubmitotp;
                    final CountryCodePicker txtAddmobileCode;
                    btnsendotp = alertDialog.findViewById(R.id.btnsendotp);
                    btnsubmitotp = alertDialog.findViewById(R.id.btnsubmitotp);
                    ImageView imgclose = alertDialog.findViewById(R.id.imgclose);
                    TextView tvPhoto = alertDialog.findViewById(R.id.tvPhoto);
                    isMobileVerified = false;

                    imgclose.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            alertDialog.dismiss();
                        }
                    });
                    txtAddmobileCode = alertDialog.findViewById(R.id.txtmobileCode);
                    txtname = alertDialog.findViewById(R.id.txtname);
                    etAddOTP = alertDialog.findViewById(R.id.etAddOTP);
                    txtaddress = alertDialog.findViewById(R.id.txtaddress);
                    txtemail = alertDialog.findViewById(R.id.txtemail);
                    txtmobileno = alertDialog.findViewById(R.id.txtmobileno);
                    txtdesc = alertDialog.findViewById(R.id.txtdesc);
                    imgphotoid_select = alertDialog.findViewById(R.id.imgphotoid_select);
                    imgphotoid_select1 = alertDialog.findViewById(R.id.imgphotoid_select1);
                    imgphotoid_select2 = alertDialog.findViewById(R.id.imgphotoid_select2);
                    imgphotoid = alertDialog.findViewById(R.id.imgphotoid);
                    imgphotoid11 = alertDialog.findViewById(R.id.imgphotoid11);
                    imgphotoid2 = alertDialog.findViewById(R.id.imgphotoid2);
                    txtwebsite = alertDialog.findViewById(R.id.txtwebsite);
                    txtCity = alertDialog.findViewById(R.id.txtCity);
                    spnCategory = alertDialog.findViewById(R.id.spnCategory);
                    LinSPN = alertDialog.findViewById(R.id.LinSPN);
                    LinCategory = alertDialog.findViewById(R.id.LinCategory);
                    linResend = alertDialog.findViewById(R.id.linResend);
                    tvPhoto = alertDialog.findViewById(R.id.tvPhoto);
                    btn_create_grp = alertDialog.findViewById(R.id.btn_create_grp);
                    tvPayment = alertDialog.findViewById(R.id.tvPayment);
                    btnSendotp = alertDialog.findViewById(R.id.btnsendotp);
                    linAddOTP = alertDialog.findViewById(R.id.LinAddOTP);
                    LinSPN.setVisibility(View.VISIBLE);
                    CountryCode = "+" + txtAddmobileCode.getSelectedCountryCode();
                    LinCategory.setVisibility(View.GONE);
                    ListCategory.remove(0);
                    ListCategory.add(0, "Select Category*");
                    ArrayAdapter AgenttypeAdapter = new ArrayAdapter(context, R.layout.my_spinner, R.id.tvSpinner, ListCategory);
                    spnCategory.setAdapter(AgenttypeAdapter);
//                    tvPhoto.setText("Upload Photo");
                    /*ArrayAdapter<String> customAdapter = new ArrayAdapter<String>(context, R.layout.custom_spinner_items1, ListCategory);
                    customAdapter.setDropDownViewResource(R.layout.custom_spinner_items_dropdown);
                    spnCategory.setAdapter(customAdapter);*/

                    imgphotoid_select.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            //storage.write("type","1"); //user image
                            imageUploadType =1;
                            requestPermission();
                        }
                    });

                    imgphotoid_select1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            //storage.write("type","1"); //user image
                            imageUploadType =2;
                            requestPermission();
                        }
                    });

                    imgphotoid_select2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            //storage.write("type","1"); //user image
                            imageUploadType =3;
                            requestPermission();
                        }
                    });

                    /*etAddOTP.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                        @Override
                        public void onFocusChange(View v, boolean hasFocus) {
                            if (!hasFocus) {
                                if (etAddOTP.getText().length() == 6 && CodeSend != null) {
                                    ProgressDialog dialog = new ProgressDialog(context);
                                    dialog.setTitle("OTP Verification");
                                    dialog.setMessage("OTP Verifying");
                                    dialog.setCancelable(false);
                                    dialog.show();
                                    PhoneAuthCredential credential = PhoneAuthProvider.getCredential(CodeSend, etAddOTP.getText().toString());
                                    signInWithPhoneAuthCredential(credential, dialog, linResend , etAddOTP, txtmobileno);
                                } else {
                                    Toast.makeText(context, "Please enter valid OTP", Toast.LENGTH_LONG).show();
                                }
                            }
                        }
                    });*/

                    btnsendotp.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            if (spnCategory.getSelectedItemPosition() == 0) {
                                Toast.makeText(context, "Select Category to proceed", Toast.LENGTH_LONG).show();
                            } else if (txtname.getText().toString().length() == 0) {
                                txtname.setError("Enter Market title");
                            } else if (txtaddress.getText().toString().length() == 0) {
                                txtaddress.setError("Enter Market Address");
                            } else if (txtCity.getText().toString().length() == 0) {
                                txtCity.setError("Enter City");
                            } else if (txtdesc.getText().toString().length() == 0) {
                                txtdesc.setError("Enter Description");
                            } else if (CameraFileAbsolutePath == null ) {
                                Toast.makeText(context, "Photo required...", Toast.LENGTH_SHORT).show();
                            } else if (CountryCode.equalsIgnoreCase("")) {
                                Toast.makeText(context, "enter country code", Toast.LENGTH_LONG).show();
                            } else if (txtmobileno.getText().length() < 9) {
                                txtmobileno.setError("Contact number required");
                                linAddOTP.setVisibility(View.GONE);
                            } else {
                                dialogsending = new ProgressDialog(context);
                                dialogsending.setMessage("Sending...");
                                dialogsending.setCancelable(true);
                                dialogsending.show();
                                sendSMS(CountryCode, txtmobileno.getText().toString(), linResend, btnsendotp, linAddOTP);
                            }
                        }
                    });

                    btnsubmitotp.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (etAddOTP.getText().length() == 6 && CodeSend != null) {
                                ProgressDialog dialog = new ProgressDialog(context);
                                dialog.setTitle("OTP Verification");
                                dialog.setMessage("OTP Verifying");
                                dialog.setCancelable(false);
                                dialog.show();
                                PhoneAuthCredential credential = PhoneAuthProvider.getCredential(CodeSend, etAddOTP.getText().toString());
                                signInWithPhoneAuthCredential(credential, dialog, linResend, etAddOTP, txtmobileno);
                            } else {
                                Toast.makeText(context, "Please enter valid OTP", Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                    linResend.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            linResend.setVisibility(View.GONE);
                            if (CountryCode.equalsIgnoreCase("")) {
                                Toast.makeText(context, "enter country code", Toast.LENGTH_LONG).show();
                            } else if (txtmobileno.getText().length() < 9) {
                                txtmobileno.setError("Contact number required");
                                linAddOTP.setVisibility(View.GONE);
                            } else {
                                linAddOTP.setVisibility(View.VISIBLE);
                                sendSMS(CountryCode, txtmobileno.getText().toString(), linResend, btnsendotp, linAddOTP);
                            }
                        }
                    });
                   /* txtmobileno.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                        @Override
                        public void onFocusChange(View v, boolean hasFocus) {
                            if (!hasFocus) {

                                if (CountryCode.equalsIgnoreCase("")) {
                                    Toast.makeText(context, "enter country code", Toast.LENGTH_LONG).show();
                                } else if (txtmobileno.getText().length() < 9) {
                                    txtmobileno.setError("Contact number required");
                                    LinAddOTP.setVisibility(View.GONE);
                                } else {
                                    LinAddOTP.setVisibility(View.VISIBLE);
                                    sendSMS(CountryCode, txtmobileno.getText().toString(), linResend, btnsendotp);
                                }
                            }
                        }
                    });*/

                    txtAddmobileCode.setOnCountryChangeListener(new CountryCodePicker.OnCountryChangeListener() {
                        @Override
                        public void onCountrySelected(Country selectedCountry) {
                            CountryCode = "+" + selectedCountry.getPhoneCode();
                        }
                    });

                    spnCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                            if (position != 0) {
                                cid = ListCategoryId.get(position);
                            }
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> parent) {

                        }
                    });



                    RadioGroup rgPaymentOption = alertDialog.findViewById(R.id.rgPaymentOption);
                    final RadioButton rbtnYes = alertDialog.findViewById(R.id.rbtnYes);
                    RadioButton rbtnNo = alertDialog.findViewById(R.id.rbtnNo);


                    rgPaymentOption.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                        @Override
                        public void onCheckedChanged(RadioGroup radioGroup, int i) {
                            if (radioGroup.getCheckedRadioButtonId() == R.id.rbtnYes) {
                                btn_create_grp.setText("Proceed to Pay");

                            }
                            if (radioGroup.getCheckedRadioButtonId() == R.id.rbtnNo)  {
                                btn_create_grp.setText("Create Market");
                            }
                        }
                    });

                    btn_create_grp.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (txtname.getText().toString().length() == 0) {
                                txtname.setError("Enter Market title");
                            } else if (txtaddress.getText().toString().length() == 0) {
                                txtaddress.setError("Enter Market Address");
                            } else if (txtmobileno.getText().toString().length() < 9) {
                                txtmobileno.setError("Enter Mobile Number");
                            } else if (txtdesc.getText().toString().length() == 0) {
                                txtdesc.setError("Enter Description");
                            } else if (txtCity.getText().toString().length() == 0) {
                                txtCity.setError("Enter City");
                            } else if (CameraFileAbsolutePath == null ) {
                                Toast.makeText(context, "Photo required...", Toast.LENGTH_SHORT).show();
                            } else {
                                strname = txtname.getText().toString();
                                straddress = txtaddress.getText().toString();
                                stremail = txtemail.getText().toString();
                                if (txtemail.getText().toString().length() == 0) {
                                    stremail = "-";
                                }
                                strmobile = txtmobileno.getText().toString();
                                strdesc = txtdesc.getText().toString();
                                strCity = txtCity.getText().toString();
                                strWeb = txtwebsite.getText().toString();
                                // createNewGroup(txtgtitle.getText().toString(),aldialog);
                                if (isMobileVerified) {
                                    if (rbtnYes.isChecked()) {
                                        startPayment();
                                    }else{
                                        addMrketingperson("0");
                                    }
                                    //addBiodata();
                                } else {
                                    Toast.makeText(context, "Verify mobile number to add bio-data", Toast.LENGTH_LONG).show();
                                }
                            }
                        }
                    });
                    alertDialog.show();
                } else {
                    Toast.makeText(context, "You are required to Login.", Toast.LENGTH_SHORT).show();
                }
            }
        });
        spnCategorySearch.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) {
                    cat_id = ListCategoryId.get(position);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spnCitySearch.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) {
                    city = ListCity.get(position);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        tvSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateData(cat_id, city);
            }
        });
        tvClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spnCitySearch.setSelection(0);
                spnCategorySearch.setSelection(0);
                cat_id = "";
                city = "";
                updateData(cat_id, city);
            }
        });
    }


}
