package com.suguretaventure.mymarriagegroup.utils;

public class Constants {
    public static final int ANDROID_API_LEVEL_28 = 28;
    public static String TAG = "MY_MARRIAGE_GROUP";
    final public static String LOGIN = "login";
    final public static String SHAPE = "shape";
    final public static String LOGINDATA = "logindata";
    final public static String FCMTOKEN = "fcmtoken";

    //For Data Storage
    final public static String USER_ID = "U_ID";
    final public static String USER_NAME = "F_NAME";
    final public static String USER_SURNAME = "S_NAME";
    final public static String USER_EMAIL = "EMAIL_ID";
    final public static String USER_MOBILE = "MOBILE_NUMBER";
    final public static String USER_PROFILE_UPDATED = "PROFILE_UPDATED";
    final public static String USER_DOCUMENT = "IS_DOCUMENT";
    final public static String USER_PHOTO = "PROFILE_PHOTO";
    final public static String USER_IS_VIP = "USER_IS_VIP";
    final public static String USER_IS_FIRST_PROFILE_UPLOADED = "USER_IS_FIRST_PROFILE_UPLOADED";
    final public static String USER_FIRST_PROFILE_PAYMENT_ID = "USER_FIRST_PROFILE_PAYMENT_ID";
    final public static String TOKEN = "FCM_TOKEN";
    final public static String TOKEN_REGISTER = "FCM_TOKEN_REGISTERED";
    final public static String TYPE = "TYPE";
    final public static String MEMBER = "TEMP_MEMBER_COUNT";
    final public static String IMEI = "IMEI";


    //    public static String HOST = "http://13.232.185.67/ws/";
    public static String HOST = "https://mymarriagegroup.com/ws2/demo/";  //Live App Base
//    public static String HOST = "https://mymarriagegroup.com/ws2-test/demo/";  //Test App Base

    public static String APP_LOGIN = HOST + "loginm.php";
    public static String APP_REGISTER = HOST + "registerm.php";
    public static String APP_CHECK_MOBILE = HOST + "check_mobile.php";
    public static String PRE_FORGOT_API = HOST + "preforgotpassword.php";
    public static String APP_LOGIN_NEW = HOST + "login_new.php";
    public static String APP_CHECK_EMAIL = HOST + "check_email.php";
    public static String APP_PERSON_LIST = HOST + "check_email.php";
    public static String APP_MEMBER_LIST = HOST + "group_member_list.php";
    public static String APP_ADD_MEMBER = HOST + "group_member_invite.php";
    public static String APP_MEMBER_REMOVE = HOST + "group_member_remove.php";
    public static String APP_ADD_REMOVE_SUBADMIN = HOST + "add_sub_admin.php";
    /*public static String APP_MY_GROUP_DELETE = HOST + "delete_group.php";*/
    public static String APP_MY_GROUP_DELETE = HOST + "admin_leave_group.php";
    public static String DELETE_BIODATA = HOST + "biodata_delete.php";
    public static String UPDATE_BIODATA = HOST + "biodata_update.php";
    public static String REGISTER_FCM = HOST + "AppStatistics.php";
    public static String APP_SEND_REQUEST = HOST + "biodata_request.php";
    public static String APP_LIST_GET_TOGETHER = HOST + "gettogether-list.php";
    public static String APP_DELETE_GET_TOGETHER = HOST + "gettogether-delete.php";
    public static String APP_UPDATE_GET_TOGETHER = HOST + "gettogether-update.php";
    public static String APP_GET_PROFILE = HOST + "myprofile.php";
    public static String BIO_REQ_SEND = HOST + "bio_req_send.php";
    public static String BIO_REQ_VIEW = HOST + "bio_view_req_new_1.php";
    public static String DELETE_ALL_INVITATION = HOST + "delete_all_bio_req.php";
    public static String BIO_REQ_ACCEPT = HOST + "bio_req_receive.php";
    public static String APP_UPDATE_PROFILE = HOST + "register_update.php";
    public static String APP_BIODATA_REQUEST = HOST + "biodata_request_list.php";
    public static String SUBSCRIBE_USER = HOST + "subscribe_user.php";
    public static String SET_PREMIUM_BIODATA = HOST + "set_premium_biodata.php";
    public static String APP_BIODATA_ALL_REQUEST = HOST + "biodata_request_list_all.php";
    public static String GROUP_ALL_REQUEST = HOST + "group_request_list.php";
    public static String APP_BIODATA_REQUEST_SENT = HOST + "biodata_sent_list.php";
    public static String APP_GROUP_INVITE_LIST = HOST + "group_invite_list.php";
    public static String APP_BIODATA_VERIFIED = HOST + "biodata_verified_by.php";//bid,rid,status(1=accept,0=reject)

    public static String APP_GET_MARKETING_LIST = HOST + "get_marketing_cat.php";
    public static String Leave_Group = HOST + "leave_group.php";
    public static String Delete_Group = HOST + "admin_leave_group.php";
    public static String Delete_Group_Final = HOST + "delete_group.php";
    public static String SEND_GROUP_REQUEST = HOST + "send_group_request.php";
    public static String SEND_GROUP_RESPONSE = HOST + "send_group_response.php";
    public static String APP_MARKETING_LIST_BY_CAT = HOST + "get_marketing_full.php";
    public static String APP_DELETE_MARKETING = HOST + "delete_marketing.php";
    public static String APP_UPDATE_MARKETING = HOST + "update_marketing.php";
    public static String APP_MARKETING_CITY = HOST + "marketing_city.php"; //
    public static String APP_MY_MARKETING_LIST = HOST + "get_marketing.php"; // rid or cid
    public static String APP_MARKETING_SEARCH = HOST + "marketing_search.php"; // cid,city
    public static String Admin_Leave_Group = HOST + "admin_leave_group.php"; // cid,city
    public static String Bio_Approval_Sent = HOST + "bio_req_approval_send.php"; // rid,bid
    public static String API_SAVE_TOKEN = HOST + "save_device_token.php"; // rid,device_token

    public static String APP_LIST_GET_TOGETHER_INTERESTED = HOST + "gt_regu_list.php";


    public static String MV_ID = "ID";
    public static String MV_CID = "CID";
    public static String MV_CNAME = "CNAME";
    public static String MV_NAME = "NAME";
    public static String MV_ADDRESS = "ADDRESS";
    public static String MV_MOBILE = "MOBILE";
    public static String MV_EMAIL = "EMAIL";
    public static String MV_IMAGE = "IMAGE";
    public static String MV_IMAGE1 = "IMAGE1";
    public static String MV_IMAGE2 = "IMAGE2";
    public static String MV_PHOTO = "PHOTO";
    public static String MV_PHOTO1 = "PHOTO1";
    public static String MV_PHOTO2 = "PHOTO2";
    public static String MV_CITY = "CITY";
    public static String MV_DESCRIPTION = "DESCRIPTION";
    public static String MV_LAT = "LAT";
    public static String MV_LON = "LON";
    public static String WEBSITE = "website";
    public static boolean isDebug = true;

    public static String STRING_TERMS_PRIVACY =
            "<p><font size='24'>By downloading or using the app, these terms will automatically apply to you – you should make sure therefore that you read them carefully before using the app. You’re not allowed to copy, or modify the app, any part of the app, or our trademarks in any way. You’re not allowed to attempt to extract the source code of the app, and you also shouldn’t try to translate the app into other languages, or make derivative versions. The app itself, and all the trade marks, copyright, database rights and other intellectual property rights related to it, still belong to My Marriage Group.</font></p>" +
                    "<p><font size='24'>My Marriage Group is committed to ensuring that the app is as useful and efficient as possible. For that reason, we reserve the right to make changes to the app or to charge for its services, at any time and for any reason. We will never charge you for the app or its services without making it very clear to you exactly what you’re paying for.</font></p>" +
                    "<p><font size='24'>The My Marriage Group app stores and processes personal data that you have provided to us, in order to provide our Service. It’s your responsibility to keep your phone and access to the app secure. We therefore recommend that you do not jailbreak or root your phone, which is the process of removing software restrictions and limitations imposed by the official operating system of your device. It could make your phone vulnerable to malware/viruses/malicious programs, compromise your phone’s security features and it could mean that the My Marriage Group app won’t work properly or at all.</font></p>" +
                    "<p><font size='24'>You should be aware that there are certain things that My Marriage Group will not take responsibility for. Certain functions of the app will require the app to have an active internet connection. The connection can be Wi-Fi, or provided by your mobile network provider, but My Marriage Group cannot take responsibility for the app not working at full functionality if you don’t have access to Wi-Fi, and you don’t have any of your data allowance left.</font></p>" +
                    "<p><font size='24'>If you’re using the app outside of an area with Wi-Fi, you should remember that your terms of the agreement with your mobile network provider will still apply. As a result, you may be charged by your mobile provider for the cost of data for the duration of the connection while accessing the app, or other third party charges. In using the app, you’re accepting responsibility for any such charges, including roaming data charges if you use the app outside of your home territory (i.e. region or country) without turning off data roaming. If you are not the bill payer for the device on which you’re using the app, please be aware that we assume that you have received permission from the bill payer for using the app.</font></p>" +
                    "<p><font size='24'>Along the same lines, My Marriage Group cannot always take responsibility for the way you use the app i.e. You need to make sure that your device stays charged – if it runs out of battery and you can’t turn it on to avail the Service, My Marriage Group cannot accept responsibility.</font></p>" +
                    "<p><font size='24'>With respect to My Marriage Group’s responsibility for your use of the app, when you’re using the app, it’s important to bear in mind that although we endeavour to ensure that it is updated and correct at all times, we do rely on third parties to provide information to us so that we can make it available to you. My Marriage Group accepts no liability for any loss, direct or indirect, you experience as a result of relying wholly on this functionality of the app.</font></p>" +
                    "<p><font size='24'>At some point, we may wish to update the app. The app is currently available on Android – the requirements for system (and for any additional systems we decide to extend the availability of the app to) may change, and you’ll need to download the updates if you want to keep using the app. My Marriage Group does not promise that it will always update the app so that it is relevant to you and/or works with the Android version that you have installed on your device. However, you promise to always accept updates to the application when offered to you, We may also wish to stop providing the app, and may terminate use of it at any time without giving notice of termination to you. Unless we tell you otherwise, upon any termination, (a) the rights and licenses granted to you in these terms will end; (b) you must stop using the app, and (if needed) delete it from your device.</font></p>" +
                    "<h1><font color='#DA4313'>Changes to This Terms and Conditions</font></h1>" +
                    "<p><font size='24'>We may update our Terms and Conditions from time to time. Thus, you are advised to review this page periodically for any changes. We will notify you of any changes by posting the new Terms and Conditions on this page. These changes are effective immediately after they are posted on this page.</font></p>" +
                    "<h1><font color='#DA4313'>Privacy Policy</font></h1>" +
                    "<p><font size='24'>My Marriage Group built the My Marriage Group app as a Commercial app. This SERVICE is provided by My Marriage Group and is intended for use as is.</font></p>" +
                    "<p><font size='24'>This page is used to inform visitors regarding our policies with the collection, use, and disclosure of Personal Information if anyone decided to use our Service.</font></p>" +
                    "<p><font size='24'>If you choose to use our Service, then you agree to the collection and use of information in relation to this policy. The Personal Information that we collect is used for providing and improving the Service. We will not use or share your information with anyone except as described in this Privacy Policy.</font></p>" +
                    "<p><font size='24'>The terms used in this Privacy Policy have the same meanings as in our Terms and Conditions, which is accessible at My Marriage Group unless otherwise defined in this Privacy Policy.</font></p>" +
                    "<h3><font color='#DA4313'>Data collection and security Practices of the data collected or shared</font></h3>" +
                    "<p><font size='24'>\t•\t Data is not encrypted in transit</font></p>" +
                    "<p><font size='24'>\t•\tYou cannot request that data be deleted. </font></p>" +
                    "<p><font size='24'>\t•\t Approximate location collected & used for app functionality.</font></p>" +
                    "<p><font size='24'>\t•\t Personal info: Name, Email address, Address, Phone Number, Photos. These are collected & used for app functionality. </font></p>" +
                    "<p><font size='24'>\t•\t Contact list: Contact list collected is processed ephemerally & used for app functionality. Contact list is never stored nor shared to any third party. (Processing data 'ephemerally' means accessing and using data while it is only stored in memory, and is retained for no longer than necessary to service the specific request in real time.)</font></p>" +
                    "<p><font size='24'>For a better experience, while using our Service, we may require you to provide us with certain personally identifiable information. The information that we request will be retained by us and used as described in this privacy policy.</font></p>" +
                    "<p><font size='24'>The app does use third party services that may collect information used to identify you.</font></p>" +
                    "<p><font size='24'>Link to privacy policy of third party service providers used by the app</font></p>" +
                    "<p><font size='24'>\t•\t<a href = 'https://www.google.com/policies/privacy/'>Google Play Services</a></font></p>" +
                    "<h3><font color='#DA4313'>Log Data</font></h3>" +
                    "<p><font size='24'>We want to inform you that whenever you use our Service, in a case of an error in the app we collect data and information (through third party products) on your phone called Log Data. This Log Data may include information such as your device Internet Protocol (“IP”) address, device name, operating system version, the configuration of the app when utilizing our Service, the time and date of your use of the Service, and other statistics.</font></p>" +
                    "<h3><font color='#DA4313'>Cookies</font></h3>" +
                    "<p><font size='24'>Cookies are files with a small amount of data that are commonly used as anonymous unique identifiers. These are sent to your browser from the websites that you visit and are stored on your device's internal memory.</font></p>" +
                    "<p><font size='24'>This Service does not use these “cookies” explicitly. However, the app may use third party code and libraries that use “cookies” to collect information and improve their services. You have the option to either accept or refuse these cookies and know when a cookie is being sent to your device. If you choose to refuse our cookies, you may not be able to use some portions of this Service.</font></p>" +
                    "<h3><font color='#DA4313'>Service Providers</font></h3>" +
                    "<p><font size='24'>We may employ third-party companies and individuals due to the following reasons:</font></p>" +
                    "<p><font size='24'>\t•\tTo facilitate our Service;</font></p>" +
                    "<p><font size='24'>\t•\tTo provide the Service on our behalf;</font></p>" +
                    "<p><font size='24'>\t•\tTo perform Service-related services; or</font></p>" +
                    "<p><font size='24'>\t•\tTo assist us in analyzing how our Service is used.</font></p>" +
                    "<p><font size='24'>We want to inform users of this Service that these third parties have access to your Personal Information. The reason is to perform the tasks assigned to them on our behalf. However, they are obligated not to disclose or use the information for any other purpose.</font></p>" +
                    "<h3><font color='#DA4313'>Security</font></h3>" +
                    "<p><font size='24'>We value your trust in providing us your Personal Information, thus we are striving to use commercially acceptable means of protecting it. But remember that no method of transmission over the internet, or method of electronic storage is 100% secure and reliable, and we cannot guarantee its absolute security.</font></p>" +
                    "<h3><font color='#DA4313'>Links to Other Sites</font></h3>" +
                    "<p><font size='24'>This Service may contain links to other sites. If you click on a third-party link, you will be directed to that site. Note that these external sites are not operated by us. Therefore, we strongly advise you to review the Privacy Policy of these websites. We have no control over and assume no responsibility for the content, privacy policies, or practices of any third-party sites or services.</font></p>" +
                    "<h3><font color='#DA4313'>Children’s Privacy</font></h3>" +
                    "<p><font size='24'>These Services do not address anyone under the age of 13. We do not knowingly collect personally identifiable information from children under 13. In the case we discover that a child under 13 has provided us with personal information, we immediately delete this from our servers. If you are a parent or guardian and you are aware that your child has provided us with personal information, please contact us so that we will be able to do necessary actions.</font></p>" +
                    "<h3><font color='#DA4313'>Changes to This Privacy Policy</font></h3>" +
                    "<p><font size='24'>We may update our Privacy Policy from time to time. Thus, you are advised to review this page periodically for any changes. We will notify you of any changes by posting the new Privacy Policy on this page. These changes are effective immediately after they are posted on this page.</font></p>" +
                    "<h3><font color='#DA4313'>Contact Us:</font></h3>" +
                    "<p><font size='24'>If you have any questions or suggestions about our Terms and Conditions, do not hesitate to contact us at suguretaventure@gmail.com or<br><br> WhatsApp on +91 7506094881.</font></p>" +
                    "<p><font size='24'>\nFor Business Partnership/Venture Capital Funding, please contact on<br>mobile number : +91 7506094881 </font></p>" +
                    "<p><font size='24'>\nVisit our website: <br>www.mymarriagegroup.com</font></p>" +
                    "<p><font size='24'>\nContact address: <br>02, Ground floor, Plot no 331-5 B,<br>Adipur, Gandhidham,<br>Gujarat 370205, India (Landmark- Near Kutch Lawn Table Tennis Court/ TAP Orthopedic Hospital/ Police Quarters)</font></p>";

    public static String STRING_HOW_THIS_APP_WORK = "<center><h1><font color='#DA4313'>Concept, Mission, Vision, Values; and FAQ</font></h1></center>" +
            "<h2><font color='#DA4313'>Concept:</font></h2>" +
            "<p>Anyone in the world can download this app &amp; can form a marriage/ matrimonial group for its own community society, religion, caste etc. This group will be a special group only for its community society, religion, caste etc. All profiles in your group are verified by admin first and then added. Therefore you have a group of genuine profiles amongst your community society, religion, caste etc. It’s also a place for all marriage related commercials such as Marriage hall, catering, photographers etc available city wise, all over the world. As on today there is no such app in the world &amp; we are proud to launch the same.</p>" +
            "<h2><font color='#DA4313'>Vision:</font></h2>" +
            "<p>(i) Our vision is that in all parts of the world such marriage groups shall become functional. (ii) All marriage related commercials shall also be made available to these groups. (iii) To provide a perfect app for this purpose and make it number 1 in its category. </p>" +
            "<h2><font color='#DA4313'>Mission:</font></h2>" +
            "<p>(i) To connect you to such genuine &amp; eminent families in your community (ii) The genuineness can be verifiable through your known relatives, friends and admin. (iii) We shall provide this in a simplest form, user friendly manner, easy to use and at the same time provide security to members.</p>" +
            "<h2><font color='#DA4313'>Values:</font></h2>" +
            "<p>(i) Genuineness (ii) Verifiability and (iii) Security are the values of this app. We shall take all possible measures to implement the same.</p>" +
            "<h2><font color='#DA4313'>Contact us:</font></h2>" +
            "<p>If you have any questions or suggestions, please contact us at suguretaventure@gmail.com  or<br><br> WhatsApp on +91 7506094881.</p>" +
            "<p><font size='24'>\nFor Business Partnership/Venture Capital Funding, please contact on<br>mobile number : +91 7506094881 </font></p>" +
            "<p><font size='24'>\nVisit our website: <br>www.mymarriagegroup.com</font></p>" +
            "<p><font size='24'>\nContact address: <br>02, Ground floor, Plot no 331-5 B,<br>Adipur, Gandhidham,<br>Gujarat 370205, India (Landmark- Near Kutch Lawn Table Tennis Court/ TAP Orthopedic Hospital/ Police Quarters)</font></p>";

    public static String STRING_FAQ = "<h2><font color='#DA4313'>1. What is ‘My Marriage Group’ app?</font></h2>" +
            "<p>It is a special mobile app. It is created for the special purpose so that anyone can form a matrimonial group for its own a community. Therefore, anyone can form a ‘Marriage/ Matrimonial Group’ for its own community. It will be a special group only for their own Community, Society, Samaj, Religion, Caste etc.</p>" +

            "<h2><font color='#DA4313'>2. Can anyone form a matrimonial group?</font></h2>" +
            "<p>Yes. Anyone in world can form a matrimonial group for its own community, Community, Society, Samaj, Religion, Caste etc.</p>" +

            "<h2><font color='#DA4313'>3. How to form a group?</font></h2>" +
            "<p>It’s very easy. Just download the ‘My Marriage Group’ app from the play store and register yourself. Thereafter a group page will open where an icon is present to create a new group. Just click the icon, name the group and your group is formed. Then go to your contact list. Select contacts and add them in the group. You can also add group image.</p>" +

            "<h2><font color='#DA4313'>4. Can multiple groups be formed?</font></h2>" +
            "<p>Yes. You can form as many groups depending upon your requirements.</p>" +

            "<h2><font color='#DA4313'>5. How to add new members?</font></h2>" +
            "<p>Just go to group setting of that particular group, click add new member, select from your contact list. Your contact will be added into the group.</p>" +

            "<h2><font color='#DA4313'>6. How many members one can add in a group?</font></h2>" +
            "<p>There is no restriction. One can add as many members. It may be few hundreds to thousands. So, your group really represents your entire community.</p>" +

            "<h2><font color='#DA4313'>7. Who can add members?</font></h2>" +
            "<p>Admin can add members.</p>" +

            "<h2><font color='#DA4313'>8. Who are admin?</font></h2>" +
            "<p>All members by default admin for the purpose of addition/ deletion of members.</p>" +

            "<h2><font color='#DA4313'>9. Is there is any app providing similar service?</font></h2>" +
            "<p>No. there is no similar app in the world wherein one can be able to create a special matrimonial group for its own Community, Society, Samaj, Religion, Caste etc.</p>" +

            "<h2><font color='#DA4313'>10. Why there is need of this app?</font></h2>" +
            "<p>Yes, thousands of matrimonial groups are formed worldwide, but all are on chatting platforms.</p>" +
            "<p>(i)	There are many restrictions on these platforms such as only limited number of members can be added, so that they need to create multiple groups.</p>" +
            "<p>(ii) They need to upload every bio-data in all groups manually.</p>" +
            "<p>(iii) All bio-data cannot be seen by entire community. </p>" +
            "<p>(iv) No prescribed formats for bio-data.</p>" +
            "<p>(v)	Also, in a chatting app, anyone posts anything in a group, as there is no restrictions.</p>" +
            "<p>(vi) In this special community group, only matrimonial profiles are allowed, nothing else.</p>" +
            "<p>(vii) Commercial information, advertisements are available in this app city wise, like marriage hall, catering services, photographers etc in your city; their contact numbers etc are available at one place. It may be Mumbai or New York City, all word wide information available in this app.</p>" +
            "<p>(viii) Your entire community is covered.</p>" +
            "<p>(ix) Similarly only on confirm request from invitee, your mobile number is shown to the opposite party. So, calls from anyone are automatically barred. You get connected to only those profiles in which you are interested.</p>" +

            "<h2><font color='#DA4313'>11. How to upload bio-data?</font></h2>" +
            "<p>Go to group and click on plus icon. A profile page will open. Fill up details, upload required photos, documents. Thereafter you send the bio-data to admin. Admin will approve the data. On approval, the bio-data will be displayed on the group.</p>" +

            "<h2><font color='#DA4313'>12. How to edit bio-data?</font></h2>" +
            "<p>Go to setting of group. Select ‘My Biodatas’. Go to ‘Edit’ option. Edit the post. Save it and again send it to admin for approval. On approval from admin, the bio-data will be displayed in the group.</p>" +

            "<h2><font color='#DA4313'>13. How to invite friends?</font></h2>" +
            "<p>Go to setting. Select invite/ share option. A link will be send to the invitee. On clicking the link, the app will be downloaded.</p>" +

            "<h2><font color='#DA4313'>14. How to delete account/ bio-data?</font></h2>" +
            "<p>These can be done from settings.</p>" +

            "<h2><font color='#DA4313'>15. How to change password?</font></h2>" +
            "<p>This can be from setting. Fill up old password, create new password, re-type new password and save it.</p>" +

            "<h2><font color='#DA4313'>16. How to retrieve forgot password?</font></h2>" +
            "<p>Go to setting. Click on forgot password. A pop window will appear. Provide your registered email. Your new password will be sent on email.</p>" +

            "<h2><font color='#DA4313'>17. Are bio-data are genuine?</font></h2>" +
            "<p>Yes. All bio-data are approved by admin first, then only it is added. Secondly, mobile numbers are verified at the time of registration. Thirdly photo and id proof are taken at the time of uploading the bio-datas. Fourthly, a small amount of bank transaction done at the time of uploading the bio-data for verification purpose, so that only genuine members could only upload the bio-data. Also, these can be verifiable as and when required. All members are added by members only, therefore all are known members. No outsider can join he group directly, as happens in many matrimonial websites etc.</p>" +

            "<h2><font color='#DA4313'>18. Is it free group?</font></h2>" +
            "<p>Yes. It is free group. Only a small bank transaction is done at the time of uploading the bio-data for verification of genuineness of the person who upload the bio-data. For all others its free to view the profiles.</p>" +

            "<h2><font color='#DA4313'>19. Does this app provides commercials?</font></h2>" +
            "<p>Yes. All marriage related commercials are available city wise, all over the world such as marriage halls, Catering services, Photographers etc available in your city.</p>" +

            "<h2><font color='#DA4313'>20. Can anyone see the commercial without forming a group or registering?</font></h2>" +
            "<p>Yes. Any one see the commercials without forming a group or becoming a member. Just download the app and you will find the Market icon, just click it, fill up name of city and see the available commercials in that city.</p>" +

            "<h2><font color='#DA4313'>21. How to add commercials?</font></h2>" +
            "<p>Go to ‘Market’, then setting. Click add new registrations, fill the required information, follow the steps and submit it. It will be displayed in the app.</p>" +

            "<h2><font color='#DA4313'>22. Can one edit the commercials? </font></h2>" +
            "<p>Yes. The person who have uploaded the details can do so if desired, by going to setting, edit it and save.</p>" +

            "<h2><font color='#DA4313'>23. Do you check the genuineness of commercials?</font></h2>" +
            "<p>No. The details are to be verified by the customers by way of visiting the halls, interactions etc. However, we verify mobile number, email and do a small bank transaction for verification of genuineness of the person who uploads the details.</p>" +

            "<h2><font color='#DA4313'>24. Refund Policy:</font></h2>" +
            "<p>1.\tThe payment for service once subscribed by the user is not refundable and any amount paid shall stand appropriated. Refund if any will be at the sole discretion of the Company and it offers no guarantees whatsoever for the accuracy or timeliness of the refunds reaching the user's card/bank accounts.\n" +
            "<br>2.\tThe payment for service once subscribed is non-transferable. Any subscription which is paid is being subscribed for that individual and cannot be used for any other profile in his/her family/friends/acquaintances etc. \n" +
            "<br>3.\tIf a profile is deleted for whatsoever reason then that person’s subscription lapses.\n" +
            "<br>4.\tSubscription is co-extensive with the profile and expires as soon as the profile is deleted and cannot be reactivated.\n" +
            "<br>5.\t If we do issue a refund or credit, we are under no obligation to issue the same or similar refund in the future. It shall depend case to case basis. \n" +
            "<br>6.\tThe payment is done towards using the services and verification purposed and shall not be refunded, unless company decides to do so or in the case of error on company’s part. \n" +
            "<br>7.\tIf you need further assistance, please contact customer support. \n" +
            "<br>8.\tPlease pay attention to the following rules which if broken, will result in a permanent ban without refund:\n" +
            "<br><br>(i)\tAnyone found to be using the services under the age of 18 will be banned immediately without refund and your IP address will also be banned.\n" +
            "<br>(ii)\tYou have registered as a member solely for the purpose of finding a spouse or you are a parent/ caretaker who has registered on behalf of their child with their permission. You may not assign or otherwise transfer your account to any other person or entity.\n" +
            "<br>(iii)\tYou commit to keep all information provided to you/ by other members as private and confidential & you will obtain the permission of the member who provided it to you prior to sharing it with a third party.\n" +
            "<br>(iv)\tYou will not request money, or any other form of financial assistance, from any member that you meet on this site – any attempt to do so may result in your details being shared with legal teams, lawyers, the Police or any other Government or legal bodies for the purpose of an investigation.\n" +
            "<br>(v)\tYou will not send money or any form of financial asset to any other member that you meet on this site– any attempt to do so may result in your details being shared with legal teams, lawyers, the Police or any other Government or legal bodies for the purpose of an investigation.\n" +
            "<br>(vi)\tYou will not organize and will not participate in any funds  transfer or any asset transfer arrangement organized by any member you meet on this site– any attempt to do so may result in your details being shared with legal teams, lawyers, the Police or any other Government or legal bodies for the purpose of an investigation.\n" +
            "<br>(vii)\tYou will not load or distribute any virus or softwarFe which may harm the site or any of its users.\n" +
            "<br>(viii)\tYou will not create multiple user accounts for yourself.\n" +
            "<br>(ix)\tYou will not post in your profile or communicate through any vulgar language, pictures or content of hurting nature.\n" +
            "<br>(x)\tYou will not post in your profile or communicate through any conversations any material promoting harmful or criminal thoughts, intent or action.\n" +
            "<br>(xi)\tYou will not post in your profile or communicate through any  conversations any form of harassment, sexual or otherwise, racism, bigotry, violence, invasion of privacy, suggesting, engaging in or enticing other to commit any illegal or immoral acts. Such actions can be followed up and prosecuted as necessary.\n" +
            "<br>(xii)\tYou will not send to any member unsolicited mass mails,  junk mail, spam mail and chain letters, nor will you send any business information with the intent to engage or sell to other members including asking members to sign up to other websites or any other medium for products and services.\n" +
            "<br>(xiii)\tYou will not engage in gathering personal information such as email addresses, telephone numbers, addresses, financial information or any other kind of information of our members.\n" +
            "<br>(xiv)\tAny profile deemed suspicious or fraudulent will be rejected immediately with a permanent ban and no refund.\n" +
            "<br>(xv)\tAbuse to staff will not be tolerated in any way, shape of form, and will result in a permanent ban without refund.\n" +
            "<br>(xvi)\tYou agree to include factual information about yourself which is a true and accurate representation of yourself. You may not use fake pictures (actors, actresses, models or any person who is not the actual member.) and any other misleading or untruthful personal Information, such as incorrect full names, misrepresented real age, location, country of residence, country of origin, religion, height, weight, and any other item of personal description can result in a permanent ban without refund.\n" +
            "<br>(xvii)\tAny member found to be trying to find ways to evade using our site conversation area and trying to post their personal details to take conversations off the site will be banned without refund.\n" +
            "<br>(xviii)\tAny member requesting to take conversations off the website/ app when compatibility has not been established can be subject to a permanent ban without refund.\n" +
            "<br>(xix)\t Please note that all members whether free or subscribed must adhere to the rules mentioned herein these terms and conditions. Failure to do so can result in a ban without refund.\n" +
            "<br>(xx)\tIt is your responsibility to communicate with members in a polite, respectful manner. Rude, offensive, filthy, disgusting or vulgar messages or any other inappropriate messages will result in a permanent ban without refund.\n</p>" +


            "<h2><font color='#DA4313'>Contact Us:</font></h2>" +
            "<p>If you have any questions or suggestions, please contact us at suguretaventure@gmail.com  or<br><br> WhatsApp on +91 7506094881.</p>" +
            "<p><font size='24'>\nFor Business Partnership/Venture Capital Funding, please contact on<br>mobile number : +91 7506094881 </font></p>" +
            "<p><font size='24'>\nVisit our website: <br>www.mymarriagegroup.com</font></p>" +
            "<p><font size='24'>\nContact address: <br>02, Ground floor, Plot no 331-5 B,<br>Adipur, Gandhidham,<br>Gujarat 370205, India (Landmark- Near Kutch Lawn Table Tennis Court/ TAP Orthopedic Hospital/ Police Quarters)</font></p>";

    public static String WELCOME_MESSAGE = "<h1>Congratulations!</h1>" +
            "<p>\nNow create a special <br>Matrimonial Group for your own Community, Society, Religion, Caste, etc. Just click the icon below to start with.</p>";

    public static String DEFAULT_DOWNLOAD_PAGE =
            "<p>\nYou have no groups at present. Please request your relatives or Admin to add you in your community marriage group. Or create a new Marriage Group for your community. Just click the icon below to start with.</p>";

    public static String MY_GROUP_MESSAGE = "<h1>Congratulations!</h1>" +
            "<p>\nNow create a special Marriage Group for your own Community, Religion, Caste, City etc. all over the world ! You can see your Groups here.</p>";

    public static String LIST_MSG = "<h1>Congratulations!</h1>" +
            "<p>\nNow create a profile <br>for matrimonial Group for your own Community, Society, Religion, Caste, etc.</p>";

    public static String Market_MESSAGE = "<h1>Congratulations!</h1>" +
            "<p>\nNow you can advertise Marriage Halls, Catering Services, Photographers, Banquet Halls or other Marriage related Services. Just click the icon below";

    public static String Favorite_MESSAGE = "<h1>Congratulations!</h1>" +
            "<p>Now create a special Marriage Group for your own Community, Religion, Caste, City etc. all over the world ! You can see your Favourites profiles here.";

    public static String Post_MESSAGE = "<h1>Congratulations!</h1>" +
            "<p>Now create a special Marriage Group for your own Community, Religion, Caste, City etc. all over the world ! You can see your posts here.";

    public static String Archive_MESSAGE = "<h1>Congratulations!</h1>" +
            "<p>Now create a special Marriage Group for your own Community, Religion, Caste, City etc. all over the world ! You can see your Archived profiles here.";

    public static String INVITATION_SENT = "<h1>Congratulations!</h1>" +
            "<p>Now create a special Marriage Group for your own Community, Religion, Caste, City etc. all over the world ! You can see your invitations sent here.";

    public static String INVITATION_SENT_BIO = "<h1>Congratulations!</h1>" +
            "<p>Now create a special Marriage Group for your own Community, Religion, Caste, City etc. all over the world ! You can see bio-datas sent for approval here.";

    public static String INVITATION_RECEIVED_BIO = "<h1>Congratulations!</h1>" +
            "<p>Now create a special Marriage Group for your own Community, Religion, Caste, City etc. all over the world ! You can see bio-datas received for approval here.";

    public static String INVITATION_RECEIVE = "<h1>Congratulations!</h1>" +
            "<p>Now create a special Marriage Group for your own Community, Religion, Caste, City etc. all over the world ! You can see your invitations received here.";

    public static String INVITATION_GET_TO_GATHER = "<h1>Congratulations!</h1>" +
            "<p>Now create a special Marriage Group for your own Community, Religion, Caste, City etc. all over the world ! You can see Next Get-together events here.";

    public static String INVITATION_GET_TO_GATHER_INTERESTED = "<h1>Congratulations!</h1>" +
            "<p>Now create a special Marriage Group for your own Community, Religion, Caste, City etc. all over the world ! You can see interested members in this Get-together here.";


    public static String INVITATION_LOGIN = "Now create a Special Matrimony Group for your own Community, Caste, Religion etc. ";

    public static String MY_MARKET_MESSAGE = "<h1>Congratulations!</h1>" +
            "<p>\nNow create a special Marriage Group for your own Community, Religion, Caste, City etc. all over the world ! You can see your market posts here.";

    public static String WELCOME_MESSAGE_MAIN = "<h4><font color='#ED8A19'>You have no group at present</font></h4>";

    public static String ABOUT = "'My marriage group’ app is developed and maintained by ‘Sugureta Venture’ Company. The motive of this app is to provide a facility of a particular community for matrimonial search. This is for entire community and as it is online based, it covers the entire world. So any one based anywhere in the world can get connected for search of bride/ grooms in their community. They can also upload profiles of their children or relatives children. This program is helped by following entrepreneurs.";

    public static String CONTACT_US = "<h2><font color='#DA4313'>Contact Us:</font></h2>" +
            "<p>If you have any questions or suggestions, please contact us at suguretaventure@gmail.com or<br><br>WhatsApp on +91 7506094881.</p>" +
            "<p><font size='24'>\nVisit our website: <br>www.mymarriagegroup.com</font></p>" +
            "<p><font size='24'>\nFor Business Partnership/Venture Capital Funding, please contact on<br>mobile number : +91 7506094881 </font></p>" +
            "<p><font size='24'>\nContact address: <br>02, Ground floor, Plot no 331-5 B,<br>Adipur, Gandhidham,<br>Gujarat 370205, India (Landmark- Near Kutch Lawn Table Tennis Court/ TAP Orthopedic Hospital/ Police Quarters)</font></p>";
}
