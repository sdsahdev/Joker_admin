package com.suguretaventure.mymarriagegroup.adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Build;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.suguretaventure.mymarriagegroup.Model.BioData;
import com.suguretaventure.mymarriagegroup.MyProfile;
import com.suguretaventure.mymarriagegroup.PersonDesc;
import com.suguretaventure.mymarriagegroup.ProfileUpdateActivity;
import com.suguretaventure.mymarriagegroup.R;
import com.suguretaventure.mymarriagegroup.utils.ExifUtil;

import static com.suguretaventure.mymarriagegroup.utils.ExifUtil.rotate;

public class RequestAdapter extends RecyclerView.Adapter<RequestAdapter.ViewHolder> {
    private Context context;
    private BioData data;
    private int type;

    public RequestAdapter(Context context, BioData data,int type) {
        this.context = context;
        this.data = data;
        this.type = type;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
        View view = inflater.inflate(R.layout.layout_request, viewGroup, false);
        return new ViewHolder(view);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onBindViewHolder(@NonNull ViewHolder v, final int i) {
        // v.imgReqBio.setRotation(ExifUtil.getCameraPhotoOrientation(data.detail.get(i).photo));

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        Bitmap image = null, rotatedBitmap = null;

        Glide.with(context)
                .load(data.detail.get(i).photo)
                .apply(RequestOptions.circleCropTransform()).into(v.imgReqBio);

        /*image = ExifUtil.getBitmapFromURL(data.detail.get(i).photo);
        int width = image.getWidth();
        int height = image.getHeight();

        if (width > height) {
            rotatedBitmap = rotate(image, 90);
            Glide.with(context)
                    .load(rotatedBitmap)
                    .apply(RequestOptions.circleCropTransform()).into(v.imgReqBio);
        } else {
            Glide.with(context)
                    .load(data.detail.get(i).photo)
                    .apply(RequestOptions.circleCropTransform()).into(v.imgReqBio);
        }*/


        // v.imgReqBio.setRotation(uploadImage.getmRotation());

        v.lblReqNameSur.setText(data.detail.get(i).name + " " + data.detail.get(i).surname);
        v.lblReqAge.setText("Age: "+data.detail.get(i).age);
        v.lblReqEdu.setText(data.detail.get(i).education);
        v.lblReqOccupa.setText(data.detail.get(i).occupation);
        if (type==0) {
            v.lblReqUploadedBy.setText("Uploaded: " + data.detail.get(i).rid_full_name);
            v.lblReqUploadedBy.setVisibility(View.VISIBLE);
        }else{
            v.lblReqUploadedBy.setVisibility(View.GONE);
        }
        v.lblReqUploadedBy.setTextColor(Color.parseColor("#4169E1"));
        v.lblReqUploadedBy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, MyProfile.class).putExtra("rId",data.detail.get(i).register_userid).putExtra("flagDetail",true);
                context.startActivity(intent);
            }
        });

        v.layRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                context.startActivity(new Intent(context, PersonDesc.class).putExtra("pid", data.detail.get(i).bid).putExtra("type", type).putExtra("request", "1"));
            }
        });
    }

    @Override
    public int getItemCount() {
        return data.detail.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView imgReqBio;
        private TextView lblReqNameSur, lblReqAge, lblReqEdu, lblReqOccupa,lblReqUploadedBy;
        private LinearLayout layRequest;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            lblReqNameSur = itemView.findViewById(R.id.lblReqNameSur);
            lblReqAge = itemView.findViewById(R.id.lblReqAge);
            lblReqEdu = itemView.findViewById(R.id.lblReqEdu);
            lblReqOccupa = itemView.findViewById(R.id.lblReqOccupa);
            imgReqBio = itemView.findViewById(R.id.imgReqBio);
            layRequest = itemView.findViewById(R.id.layRequest);
            lblReqUploadedBy = itemView.findViewById(R.id.lblReqUploadedBy);
        }
    }
}
