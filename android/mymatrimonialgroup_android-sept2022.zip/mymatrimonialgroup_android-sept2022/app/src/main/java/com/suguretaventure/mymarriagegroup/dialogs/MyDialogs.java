package com.suguretaventure.mymarriagegroup.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.suguretaventure.mymarriagegroup.R;

import java.util.ArrayList;

public class MyDialogs {
    public static ArrayList<String> getTogether(final Context context, Dialog alertDialog, EditText Title, EditText Detail) {
        ArrayList<String> result = new ArrayList<>();
        alertDialog = new Dialog(context);
        alertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        alertDialog.setContentView(R.layout.dailog_get_together);
        alertDialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        //Allocating Memory
        Title = alertDialog.findViewById(R.id.txtGetTogetherTitle);
        Detail = alertDialog.findViewById(R.id.txtGetTogethermsg);
        Button btnGetTogetherCancel = alertDialog.findViewById(R.id.btnGetTogetherCancel);
        Button btnGetTogetherRegister = alertDialog.findViewById(R.id.btnGetTogetherRegister);
        //set-Listener
        
        // Setting Dialog Title
        /*
        btnsendpwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pwdValidateInput()) {
                    if (NetworkConnetionState.isNetworkAvailable(context)) {
                        sendEmail(alertDialog);
                    } else {
                        Toast.makeText(context, "No internet connection found. Please check your phone settings to turn on the internet.", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });

        btncancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                alertDialog.cancel();
            }
        });*/
        // Showing Alert Message
        alertDialog.show();
        return result;
    }
}
