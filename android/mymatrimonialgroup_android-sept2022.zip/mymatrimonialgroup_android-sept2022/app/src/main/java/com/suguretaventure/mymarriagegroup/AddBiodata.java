package com.suguretaventure.mymarriagegroup;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.gson.Gson;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.poovam.pinedittextfield.SquarePinField;
import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;
import com.rilixtech.widget.countrycodepicker.Country;
import com.rilixtech.widget.countrycodepicker.CountryCodePicker;
import com.scrounger.countrycurrencypicker.library.CountryCurrencyPicker;
import com.scrounger.countrycurrencypicker.library.Currency;
import com.scrounger.countrycurrencypicker.library.Listener.CountryCurrencyPickerListener;
import com.scrounger.countrycurrencypicker.library.PickerType;
import com.suguretaventure.mymarriagegroup.Model.BiodataDec;
import com.suguretaventure.mymarriagegroup.Model.Members;
import com.suguretaventure.mymarriagegroup.Model.RegisterModel;
import com.suguretaventure.mymarriagegroup.adapters.MemberRequestAdapter;
import com.suguretaventure.mymarriagegroup.common.AppController;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.common.LocationTrack;
import com.suguretaventure.mymarriagegroup.common.NetworkConnetionState;
import com.suguretaventure.mymarriagegroup.database.DBHelper;
import com.suguretaventure.mymarriagegroup.imageresize.core.ImageCompressTask;
import com.suguretaventure.mymarriagegroup.imageresize.listeners.IImageCompressTaskListener;
import com.suguretaventure.mymarriagegroup.imageresize.util.Util;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utils;
import com.suguretaventure.mymarriagegroup.utils.WebServiceCaller;
import com.yalantis.ucrop.UCrop;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import cz.msebera.android.httpclient.Header;
import retrofit2.Call;
import retrofit2.Callback;

import static android.Manifest.permission.ACCESS_COARSE_LOCATION;
import static android.Manifest.permission.ACCESS_FINE_LOCATION;

public class AddBiodata extends AppCompatActivity implements PaymentResultListener {
    public static final String EXTRA_DATA = "EXTRA_DATA";
    public static Object ExtraData = "EXTRA_DATA";
    ArrayList<BiodataDec> arr_adapter_list;
    private DBHelper dbHelper;
    private int saveflag = 1;
    private final static int ALL_PERMISSIONS_RESULT = 101;
    private static final int GALLARY = 1;
    private static final int CAMERA = 2;
    private static final int REQUEST_MULTIPLE_PERMISSION = 100;
    ProgressDialog pDialog;
    NetworkConnetionState connection;
    Integer id;
    ArrayList<String> OccupationId = new ArrayList<String>();
    ArrayList<String> OccupationTitle = new ArrayList<String>();
    ArrayAdapter<String> dataAdapter, bgroupAdapter, heightAdapter, weightAdapter;
    int selected;

    LocationTrack locationTrack;
    double latitude, longitude;
    ActionBar toolbar;
    ProgressDialog dialogsending;
    private SquarePinField etAddOTP;
    private FirebaseAuth auth;
    private String CodeSend;
    private String TAG = "ADD_BIO_DATA";
    private Context ctx = this;
    /*private boolean isMobileVerified = false;*/
    private boolean isMobileVerified = true;
    private EditText txtfullname, txtcontactNo, txtRelation, txtcontactSurname, txtcontact2, txtOtherRelatives, txtcity, txtNative, txtMiddleName,
            txtSpecialization, txtmotherOccupation, txtfatherOccupation, txtsurname, txtincome, txtblood, txtdobplace, txthobbies, txtincomeCurrency,
            txtexpectation, txtfathername, txtmothername, txtbroname, txtsisname,
            txtaddress, txtcontact1, txtmailid, txtbgphotoid, txtReligion, txtMotherTongue, txtKulDevta, txtOccDetails;

    private TextView lblskip, linResend;
    private RadioGroup rdogrpgender, rgSalPer;
    private RadioButton rdomale, rdofemale, rbtnPerAnum, rbtnPerMonth;
    //private Spinner spnoccupation;
    private Spinner spnoccupation1, spnblood, spnHeight, spnWeight, spinnerComplexion, spinnerRashi, spinnerAge, spinnerMarital, spinnerCitizen,spinnerHandicap, spinnerEducation, spnCurrency, spnSalary;
    private String fullname="", mgid, rel_surname, surname, relative, fatherOccup, motherOccup,seniorcitizen = "no",pchallenge = "no",
            nativePlace, relation, contactNo, city, education, occupation, income, height, weight, blood, dobdate, dobtime, dobplace,
            hobbies, expectation, fathername, mothername, brothers, sisters, address, contact, person_name, contact2, age, email, Specialization, middle,
            gender = "", complexion, ras_tithi, religion, marital, motherTongue, kulDevta = "", bgphoto, smokingHabits = "", drinkingHabits = "", diataryHabits = "", occDetails = "",sCitizen="NO",pHandicap="NO";
    private  String mgname = "",image_str = "",URL = "";
    private Button btngroupnext1, btnsendotp, btnsubmitotp;
    private int mYear, mMonth, mDay, mHour, mMinute, mAmPm;
    private ArrayList permissionsToRequest;
    private ArrayList permissionsRejected = new ArrayList();
    private ArrayList permissions = new ArrayList();
    private ImageView imgbridegroom, imgselect_br_gr, imgbridegroomfull1, imgselect_br_grfull1, imgbridegroomfull2, imgselect_br_grfull2;
    private ExecutorService mExecutorService = Executors.newFixedThreadPool(1);
    private ImageCompressTask imageCompressTask;
    private Bitmap image = null, image1 = null, image2 = null;
    private String CameraFileAbsolutePath = "", CameraFileAbsolutePath1 = "", CameraFileAbsolutePath2 = "";
    private Uri photoUri;
    private Members myData;
    private String G_ID = "";
    private ArrayList<String> MemberList;
    private CountryCodePicker txtAddmobileCode;
    private TextView txtGenderTitle;
    private ImageView imgGenderBack, imgGenderIcon, imgGenderMore;
    private Toolbar toolbar_top;
    private LinearLayout LinAddOTP;
    private int temp = 0;
    private int counter = 60;
    private TextView tvDate, tvTime, lblText;
    private LinearLayout linDate, linTime;
    private RadioButton rbtnYes, rbtnNo;
    private FirebaseAnalytics mFirebaseAnalytics;
    int userid;
    private BiodataDec biodataDec=new BiodataDec();


    String[] complexionList = {"Select Complexion", "Very fair", "Fair", "Wheatish", "Wheatish-Brown", "Semi- Dark (Savala)", "Dark"};
    String[] currency_list = {"Select Currency", "INR", "EUR", "USD"};
    String[] citizenList = {"Select", "Yes", "No"};
    String[] salary_list = {"Yearly Income", "1Lac -2.5Lac", "2.5Lac-5Lac", "5Lac-7.5Lac", "7.5Lac-10Lac", "10Lac+"};
    String[] maritialStatusList = {"Select Maritial Status", "Never married (un-married)", "Divorced", "Widowed", "Awaiting Divorce", "Annulled"};
    String[] rashiList = {"Select Zodiac", "Aries (Mesh)", "Taurus (Vrushabh) ", "Gemini (Mithun)", "Cancer (Kark)", "Leo (Sinh)", "Virgo (Kanya)", "Libra (Tula)", "Scorpius (Vrushchik)", "Sagittarius (Dhanu)", " Capricornus (Makar)", "Aquarius (Kumbha)", "Pisces (Meen)"};
    String[] educationList = {"Select Education", "SSC", "HSC", "Diploma", "Under Graduate", "Graduate", "Post Graduate", "Masters"};
    ScrollView scrollView;


    RadioGroup rgShowContactNumber;
    RadioButton rbtnContactYes, rbtnContactNo;

    RadioGroup rgDrinkingHabbits, rgSmokingHabits, rgDietaryHabits;
    RadioButton rbtnDrinkYes, rbtnDrinkNo, rbtnDrinkOccasional, rbtnSmokeYes, rbtnSmokeNo, rbtnSmokeOccasional, rbtnDietaryVeg, rbtnDietaryNonVeg, rbtnDietaryNonVegOccasional, rbtnDietaryEggetarian;


    EditText txt_search_mname;
    ArrayList<Members.Member> memberArrayList;
    MemberRequestAdapter memberRequestAdapter;

    boolean is_premium_flag = false;

    private IImageCompressTaskListener iImageCompressTaskListener = new IImageCompressTaskListener() {
        @Override
        public void onComplete(List<File> compressed) {
            switch (temp) {
                case 0:
                    File file = compressed.get(0);
                    txtbgphotoid.setText(file.getName());
                    imgbridegroom.setImageBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()));
                    break;
                case 1:
                    File file1 = compressed.get(0);
                    txtbgphotoid.setText(file1.getName());
                    imgbridegroomfull1.setImageBitmap(BitmapFactory.decodeFile(file1.getAbsolutePath()));
                    break;
                case 2:
                    File file2 = compressed.get(0);
                    txtbgphotoid.setText(file2.getName());
                    imgbridegroomfull2.setImageBitmap(BitmapFactory.decodeFile(file2.getAbsolutePath()));
                    break;

            }            //UPloadImageToServer();
        }

        @Override
        public void onError(Throwable error) {
            Log.e("trace error", "Error occurred: " + error);
        }
    };
    private String CountryCode = "";

    private RadioGroup rgPaymentOption;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_biodata);

        dbHelper = new DBHelper(AddBiodata.this);
        userid = Integer.parseInt(Utils.getString(ctx, Constants.USER_ID));
        //   ArrayList arrayList = dbHelper.getAllBiodata();
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Window window = getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(getResources().getColor(R.color.colorPrimaryDark));
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        allocateMemory();
        Checkout.preload(ctx);
        setSupportActionBar(toolbar_top);
        G_ID = getIntent().getStringExtra("mgid");
        is_premium_flag = getIntent().getExtras().getBoolean("is_premium_flag");
        Log.d(TAG, "onCreate: Premium"+is_premium_flag);
        if (is_premium_flag) {
            rgPaymentOption.setVisibility(View.GONE);
            lblText.setText("You are requested to pay ₹1125 ($15) to confirm the premium member who is updating the bio-data.");
            if (Utils.getString(ctx, Constants.USER_IS_FIRST_PROFILE_UPLOADED).equals("1")) {
                btngroupnext1.setText("Proceed to Pay");
                lblText.setVisibility(View.VISIBLE);
            } else {
                btngroupnext1.setText("Publish Biodata");
                lblText.setVisibility(View.GONE);
            }

        }

        if (connection.isNetworkAvailable(ctx)) {
            setOccupation();
            getMemberList(G_ID);
            MemberList = new ArrayList<>();
            CountryCode = "+" + txtAddmobileCode.getSelectedCountryCode();
        } else {
            Toast.makeText(ctx, "No internet connection found. Please check your phone settings to turn on the internet.", Toast.LENGTH_LONG).show();
        }
        setListeners();

        permissions.add(ACCESS_FINE_LOCATION);
        permissions.add(ACCESS_COARSE_LOCATION);
        permissionsToRequest = findUnAskedPermissions(permissions);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (permissionsToRequest.size() > 0)
                requestPermissions((String[]) permissionsToRequest.toArray(new String[permissionsToRequest.size()]), ALL_PERMISSIONS_RESULT);
        }


        txtfullname.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (gender.equalsIgnoreCase("")) {
                    Toast.makeText(ctx, "Select Bride or Groom First", Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        locationTrack = new LocationTrack(ctx);
        if (locationTrack.canGetLocation()) {
            latitude = locationTrack.getLatitude();
            longitude = locationTrack.getLongitude();
            if (longitude == 0.0 && latitude == 0.0) {
            } else {
                Geocoder geocoder;
                List<Address> addresses;
                geocoder = new Geocoder(ctx, Locale.getDefault());

                try {
                    addresses = geocoder.getFromLocation(latitude, longitude, 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } else {
        }
    }

    private void getMemberList(String g_id) {
        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        RequestParams params = new RequestParams();
        params.put("gid", g_id);
        Utils.log(TAG, Constants.APP_MEMBER_LIST + "?" + params);
        client.post(Constants.APP_MEMBER_LIST, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {

                try {
                    String res = new String(responseBody);
                    Utils.log(TAG, "RESPONSE : " + res);
                    myData = new Gson().fromJson(res, Members.class);

                    Log.d("  :", new Gson().toJson(myData));
                    Utils.log(TAG, "SURNAME : " + myData.members.get(0).surname);
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "ERROR : " + error.getMessage());
            }
        });
    }

    public void allocateMemory() {

        auth = FirebaseAuth.getInstance();
        connection = new NetworkConnetionState();
        lblskip = findViewById(R.id.lblskip);
        imgbridegroom = findViewById(R.id.imgbridegroom);
        imgselect_br_gr = findViewById(R.id.imgselect_br_gr);
        txtbgphotoid = findViewById(R.id.txtbgphotoid);
        txtfullname = findViewById(R.id.txtfullname);
        txtMiddleName = findViewById(R.id.txtMiddleName);
        txtSpecialization = findViewById(R.id.txtSpecialization);
        txtsurname = findViewById(R.id.txtsurname);
        txtincome = findViewById(R.id.txtincome);
        txtincomeCurrency = findViewById(R.id.txtincomeCurrency);
        // txtheight = findViewById(R.id.txtheight);
        //  txtweight = findViewById(R.id.txtweight);
        txtblood = findViewById(R.id.txtblood);
        txtdobplace = findViewById(R.id.txtdobplace);
        txthobbies = findViewById(R.id.txthobbies);
        txtexpectation = findViewById(R.id.txtexpectation);
        txtfathername = findViewById(R.id.txtfathername);
        txtmothername = findViewById(R.id.txtmothername);
        txtbroname = findViewById(R.id.txtbroname);
        txtsisname = findViewById(R.id.txtsisname);
        txtaddress = findViewById(R.id.txtaddress);
        txtcontact1 = findViewById(R.id.txtcontact1);
        txtcontact2 = findViewById(R.id.txtcontact2);
        txtmailid = findViewById(R.id.txtmailid);
        spnoccupation1 = findViewById(R.id.spnoccupation1);
        spinnerComplexion = findViewById(R.id.spinnerComplexion);
        spnCurrency = findViewById(R.id.spnCurrency);
        spnSalary = findViewById(R.id.spnSalary);
        spinnerRashi = findViewById(R.id.spinnerRashi);
        spinnerAge = findViewById(R.id.spinnerAge);
        spinnerMarital = findViewById(R.id.spinnerMarital);

        spinnerCitizen = findViewById(R.id.spinnerSCitizen);
        spinnerHandicap = findViewById(R.id.spinnerHandicap);
        spinnerEducation = findViewById(R.id.spinnerEducation);
        spnblood = findViewById(R.id.spnblood);
        spnHeight = findViewById(R.id.spnHeight);
        spnWeight = findViewById(R.id.spnWeight);
        rdogrpgender = findViewById(R.id.rdogrpgender);
        rdomale = findViewById(R.id.rdomale);
        rdofemale = findViewById(R.id.rdofemale);
        btngroupnext1 = findViewById(R.id.btngroupnext1);
        lblText = findViewById(R.id.lblText);
        btnsendotp = findViewById(R.id.btnsendotp);
        btnsubmitotp = findViewById(R.id.btnsubmitotp);
        txtfatherOccupation = findViewById(R.id.txtfatherOccupation);
        txtmotherOccupation = findViewById(R.id.txtmotherOccupation);
        txtOtherRelatives = findViewById(R.id.txtOtherRelatives);
        txtNative = findViewById(R.id.txtNative);
        txtRelation = findViewById(R.id.txtRelation);
        txtcontact2 = findViewById(R.id.txtcontact2);
        txtcity = findViewById(R.id.txtcity);
        txtcontactSurname = findViewById(R.id.txtcontactSurname);
        txtcontactNo = findViewById(R.id.txtcontactNo);
        txtAddmobileCode = findViewById(R.id.txtAddmobileCode);
        LinAddOTP = findViewById(R.id.LinAddOTP);
        etAddOTP = findViewById(R.id.etAddOTP);
        imgbridegroomfull2 = findViewById(R.id.imgbridegroomfull2);
        imgselect_br_grfull2 = findViewById(R.id.imgselect_br_grfull2);
        imgbridegroomfull1 = findViewById(R.id.imgbridegroomfull1);
        imgselect_br_grfull1 = findViewById(R.id.imgselect_br_grfull1);
        linResend = findViewById(R.id.linResend);
        tvDate = findViewById(R.id.tvDate);
        tvTime = findViewById(R.id.tvTime);
        linDate = findViewById(R.id.linDate);
        linTime = findViewById(R.id.linTime);
        txtReligion = findViewById(R.id.txtReligion);
        txtMotherTongue = findViewById(R.id.txtMotherTongue);
        txtKulDevta = findViewById(R.id.txtKulDevta);
        txtOccDetails = findViewById(R.id.txtOccDetails);
        rbtnYes = findViewById(R.id.rbtnYes);
        rbtnNo = findViewById(R.id.rbtnNo);
        rgPaymentOption = findViewById(R.id.rgPaymentOption);
        rgSalPer = findViewById(R.id.rgSalPer);
        rbtnPerAnum = findViewById(R.id.rbtnPerAnum);
        rbtnPerMonth = findViewById(R.id.rbtnPerMonth);


        rgDrinkingHabbits = findViewById(R.id.rgDrinkingHabbits);
        rgSmokingHabits = findViewById(R.id.rgSmokingHabits);
        rgDietaryHabits = findViewById(R.id.rgDietaryHabits);
        rbtnDrinkYes = findViewById(R.id.rbtnDrinkYes);
        rbtnDrinkNo = findViewById(R.id.rbtnDrinkNo);
        rbtnDrinkOccasional = findViewById(R.id.rbtnDrinkOccasional);
        rbtnSmokeYes = findViewById(R.id.rbtnSmokeYes);
        rbtnSmokeNo = findViewById(R.id.rbtnSmokeNo);
        rbtnSmokeOccasional = findViewById(R.id.rbtnSmokeOccasional);
        rbtnDietaryVeg = findViewById(R.id.rbtnDietaryVeg);
        rbtnDietaryNonVeg = findViewById(R.id.rbtnDietaryNonVeg);
        rbtnDietaryNonVegOccasional = findViewById(R.id.rbtnDietaryNonVegOccasional);
        rbtnDietaryEggetarian = findViewById(R.id.rbtnDietaryEggetarian);
        scrollView = findViewById(R.id.scrollView);

        rgShowContactNumber = findViewById(R.id.rgShowContactNumber);
        rbtnContactYes = findViewById(R.id.rbtnContactYes);
        rbtnContactNo = findViewById(R.id.rbtnContactNo);

        if (getIntent().hasExtra("from")) {
            biodataDec= (BiodataDec) getIntent().getSerializableExtra(EXTRA_DATA);
            if (!biodataDec.name.isEmpty()) {
                txtfullname.setText(biodataDec.name);
            }

            if (!biodataDec.middleName.isEmpty()) {
                txtMiddleName.setText(biodataDec.middleName);
            } else {
                txtMiddleName.setText("");
            }

            if (!biodataDec.surname.isEmpty()) {
                txtsurname.setText(biodataDec.surname);
            } else {
                txtsurname.setText("");
            }

            if (!(biodataDec.getAge().isEmpty())) {
                age = biodataDec.getAge();
                int pos=-1;
                String[] age=ctx.getResources().getStringArray(R.array.age);
                for (int i =0;i<=age.length-1;i++){
                    if (age[i].equals(biodataDec.getAge())){
                        pos=i;
                    }
                }
                ArrayAdapter ageAdapter = new ArrayAdapter<String>(ctx,
                        android.R.layout.simple_spinner_item,
                        ctx.getResources().getStringArray(R.array.age));
                ageAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerAge.setAdapter(ageAdapter);
               final int finalPos = pos;
                spinnerAge.post(new Runnable() {
                    @Override
                    public void run() {
                        spinnerAge.setSelection(finalPos);
                    }
                });

            }

           /* selected = sp.getSelectedItem().toString();
            if (!selected.equals("Country"))
                spinner_item = selected;
            System.out.println(selected);*/

            if (!biodataDec.getEducation().isEmpty()) {
                education = biodataDec.getEducation();
                int pos=-1;
                for (int i =0;i<=educationList.length-1;i++){
                    if (educationList[i].equals(biodataDec.getEducation())){
                        pos=i;
                    }
                }
               setEducationSpinnerAdapter();
                final int finalPos = pos;
                spinnerEducation.post(new Runnable() {
                    @Override
                    public void run() {
                        spinnerEducation.setSelection(finalPos);
                    }
                });
            }

            if (!biodataDec.specialization.isEmpty()) {
                txtSpecialization.setText(biodataDec.specialization);
            } else {
                txtSpecialization.setText("");
            }


            if (!biodataDec.occupation_detail.isEmpty()) {
                txtOccDetails.setText(biodataDec.occupation_detail);
            } else {
                txtOccDetails.setText("");
            }

            if (biodataDec.getCurrency() !=null && !biodataDec.currency.isEmpty()) {
                txtincomeCurrency.setText(biodataDec.getCurrency());
            }

            if (!biodataDec.annual_income.isEmpty()) {
                txtincome.setText(biodataDec.getAnnual_income());
            }

            if (!biodataDec.city.isEmpty()) {
                txtcity.setText(biodataDec.city);
            }

            if (!biodataDec.date_of_birth.isEmpty()) {
                dobdate=biodataDec.getDate_of_birth();
                tvDate.setText(biodataDec.date_of_birth);
            }

            if (!biodataDec.time_of_birth.isEmpty()) {
                tvTime.setText(biodataDec.time_of_birth);
            }

            if (!biodataDec.place_of_birth.isEmpty()) {
                dobplace=biodataDec.place_of_birth;
                txtdobplace.setText(biodataDec.getPlace_of_birth());
            }

            if (!biodataDec.height.isEmpty()) {
                height = biodataDec.getHeight();
                int pos=-1;
                String[] heightList=ctx.getResources().getStringArray(R.array.height);
                for (int i =0;i<=heightList.length-1;i++){
                    if (heightList[i].equals(biodataDec.getHeight())){
                        pos=i;
                    }
                }
                heightAdapter = new ArrayAdapter<String>(ctx,
                        android.R.layout.simple_spinner_item,
                        ctx.getResources().getStringArray(R.array.height));
                heightAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spnHeight.setAdapter(heightAdapter);
                final int finalPos = pos;
                spnHeight.post(new Runnable() {
                    @Override
                    public void run() {
                        spnHeight.setSelection(finalPos);
                    }
                });
            }

            if (!biodataDec.weight.isEmpty()) {
                weight = biodataDec.getWeight();
                int pos=-1;
                String[] weightList=ctx.getResources().getStringArray(R.array.weight);
                for (int i =0;i<=weightList.length-1;i++){
                    if (weightList[i].equals(biodataDec.getWeight())){
                        pos=i;
                    }
                }
                weightAdapter = new ArrayAdapter<String>(ctx,
                        android.R.layout.simple_spinner_item,
                        ctx.getResources().getStringArray(R.array.weight));
                weightAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spnWeight.setAdapter(weightAdapter);
                final int finalPos = pos;
                spnWeight.post(new Runnable() {
                    @Override
                    public void run() {
                        spnWeight.setSelection(finalPos);
                    }
                });
            }



            if (!biodataDec.blood_group.isEmpty()) {
                blood = biodataDec.getBlood_group();
                int pos=-1;
                String[] bloodList=ctx.getResources().getStringArray(R.array.blood);
                for (int i =0;i<=bloodList.length-1;i++){
                    if (bloodList[i].equals(biodataDec.getBlood_group())){
                        pos=i;
                    }
                }

                bgroupAdapter = new ArrayAdapter<String>(ctx,
                        android.R.layout.simple_spinner_item,
                        ctx.getResources().getStringArray(R.array.blood));
                bgroupAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spnblood.setAdapter(bgroupAdapter);
                final int finalPos = pos;
                spnblood.post(new Runnable() {
                    @Override
                    public void run() {
                        spnblood.setSelection(finalPos);
                    }
                });
            }

            if (!biodataDec.complexion.isEmpty()) {
                complexion = biodataDec.getComplexion();
                int pos=-1;
                for (int i =0;i<=complexionList.length-1;i++){
                    if (complexionList[i].equals(biodataDec.getComplexion())){
                        pos=i;
                    }
                }

                setComplexionSpinnerAdapter();
                final int finalPos = pos;
                spinnerComplexion.post(new Runnable() {
                    @Override
                    public void run() {
                        spinnerComplexion.setSelection(finalPos);
                    }
                });
            }

            if (biodataDec.getsCitizen() != null && !biodataDec.getsCitizen().isEmpty()) {
                sCitizen = biodataDec.getsCitizen();
                int pos=-1;
                for (int i =0;i<=citizenList.length-1;i++){
                    if (citizenList[i].equals(biodataDec.getsCitizen())){
                        pos=i;
                    }
                }

                setCitizenSpinnerAdapter();
                final int finalPos = pos;
                spinnerCitizen.post(new Runnable() {
                    @Override
                    public void run() {
                        spinnerCitizen.setSelection(finalPos);
                    }
                });
            }

            if (biodataDec.getpHandicap() != null && !biodataDec.getpHandicap().isEmpty()) {
                pHandicap = biodataDec.getpHandicap();
                int pos=-1;
                for (int i =0;i<=citizenList.length-1;i++){
                    if (citizenList[i].equals(biodataDec.getpHandicap())){
                        pos=i;
                    }
                }

                setCitizenSpinnerAdapter();
                final int finalPos = pos;
                spinnerHandicap.post(new Runnable() {
                    @Override
                    public void run() {
                        spinnerHandicap.setSelection(finalPos);
                    }
                });
            }

            if (!biodataDec.zodiac.isEmpty()) {
                ras_tithi = biodataDec.getZodiac();
                int pos=-1;
                for (int i =0;i<=rashiList.length-1;i++){
                    if (rashiList[i].equals(biodataDec.getZodiac())){
                        pos=i;
                    }
                }

               setRashiSpinnerAdapter();
                final int finalPos = pos;
                spinnerRashi.post(new Runnable() {
                    @Override
                    public void run() {
                        spinnerRashi.setSelection(finalPos);
                    }
                });
            }

            if (!biodataDec.fathers_name.isEmpty()) {
                txtfathername.setText(biodataDec.fathers_name);
                txtfathername.setFocusableInTouchMode(false);
            }

            if (!biodataDec.fathers_occupation.isEmpty()) {
                txtfatherOccupation.setText(biodataDec.fathers_occupation);
                txtfatherOccupation.setFocusableInTouchMode(false);
            }

            if (biodataDec.getMother_name() != null && !biodataDec.getMother_name().isEmpty()) {
                txtmothername.setText(biodataDec.getMother_name());
                txtmothername.setFocusableInTouchMode(false);
            }

            if (biodataDec.getMother_occupation() != null && !biodataDec.getMother_occupation().isEmpty()) {
                txtmotherOccupation.setText(biodataDec.mother_occupation);
                txtmotherOccupation.setFocusableInTouchMode(false);
            } else {
                txtmotherOccupation.setText("");
            }

            if (!biodataDec.brothers_name_occupation.isEmpty()) {
                txtbroname.setText(biodataDec.brothers_name_occupation);
                txtbroname.setFocusableInTouchMode(false);
            } else {
                txtbroname.setText("");
            }

            if (!biodataDec.sisters_name_occupation.isEmpty()) {
                txtsisname.setText(biodataDec.sisters_name_occupation);
                txtsisname.setFocusableInTouchMode(false);
            } else {
                txtsisname.setText("");
            }

            if (!biodataDec.religion.isEmpty()) {
                txtReligion.setText(biodataDec.religion);
                txtReligion.setFocusableInTouchMode(false);
            } else {
                txtReligion.setText("");
            }

            if (!biodataDec.maritial_status.isEmpty()) {
                marital = biodataDec.getMaritial_status();
                int pos=-1;
                for (int i =0;i<=maritialStatusList.length-1;i++){
                    if (maritialStatusList[i].equals(biodataDec.getMaritial_status())){
                        pos=i;
                    }
                }
                setMaritialSpinnerAdapter();
                final int finalPos = pos;
                spinnerMarital.post(new Runnable() {
                    @Override
                    public void run() {
                        spinnerMarital.setSelection(finalPos);
                    }
                });
            }

            if (!biodataDec.mother_tongue.isEmpty()) {
                txtMotherTongue.setText(biodataDec.mother_tongue);
                txtMotherTongue.setFocusableInTouchMode(false);
            } else {
                txtMotherTongue.setText("");
            }

            if (!biodataDec.kul_daivat.isEmpty()) {
                txtKulDevta.setText(biodataDec.kul_daivat);
                txtKulDevta.setFocusableInTouchMode(false);
            } else {
                txtKulDevta.setText("");
            }

            if (!biodataDec.close_relatives.isEmpty()) {
                txtOtherRelatives.setText(biodataDec.close_relatives);
                txtOtherRelatives.setFocusableInTouchMode(false);
            } else {
                txtOtherRelatives.setText("");
            }

            if (!biodataDec.address.isEmpty()) {
                txtaddress.setText(biodataDec.address);
                txtaddress.setFocusableInTouchMode(false);
            } else {
                txtaddress.setText("");
            }

            if (!biodataDec.native_place.isEmpty()) {
                txtNative.setText(biodataDec.native_place);
                txtNative.setFocusableInTouchMode(false);
            } else {
                txtNative.setText("");
            }

            if (!biodataDec.hobbies.isEmpty()) {
                txthobbies.setText(biodataDec.hobbies);
                txthobbies.setFocusableInTouchMode(false);
            } else {
                txthobbies.setText("");
            }

            if (!biodataDec.expectation.isEmpty()) {
                txtexpectation.setText(biodataDec.expectation);
                txtexpectation.setFocusableInTouchMode(false);
            } else {
                txtexpectation.setText("");
            }

         /*   if (!biodataDec.surname_community.isEmpty()) {
                rel_surname.setText(biodataDec.surname_community);
            } else {
                rel_surname.setText("");
            }*/


            if(!(biodataDec.drinking_habits.isEmpty())) {
                Log.d(TAG, "allocateMemory:d "+biodataDec.drinking_habits);
                if (biodataDec.getDrinking_habits().equalsIgnoreCase("Yes")){
                    ((RadioButton)rgDrinkingHabbits.getChildAt(0)).setChecked(true);
                    ((RadioButton)rgDrinkingHabbits.getChildAt(1)).setClickable(false);
                    ((RadioButton)rgDrinkingHabbits.getChildAt(2)).setClickable(false);
                }else  if (biodataDec.getDrinking_habits().equalsIgnoreCase("No")){
                    ((RadioButton)rgDrinkingHabbits.getChildAt(1)).setChecked(true);
                    ((RadioButton)rgDrinkingHabbits.getChildAt(0)).setClickable(false);
                    ((RadioButton)rgDrinkingHabbits.getChildAt(2)).setClickable(false);
                }else if (biodataDec.getDrinking_habits().equalsIgnoreCase("Occasional")){
                    ((RadioButton)rgDrinkingHabbits.getChildAt(2)).setChecked(true);
                    ((RadioButton)rgDrinkingHabbits.getChildAt(1)).setClickable(false);
                    ((RadioButton)rgDrinkingHabbits.getChildAt(0)).setClickable(false);
                }
            }

            if (!biodataDec.smoking_habits.isEmpty()) {
                Log.d(TAG, "allocateMemory:s "+biodataDec.smoking_habits);
               if (biodataDec.getSmoking_habits().equalsIgnoreCase("Yes")){
                   ((RadioButton)rgSmokingHabits.getChildAt(0)).setChecked(true);
                   ((RadioButton)rgDrinkingHabbits.getChildAt(1)).setClickable(false);
                   ((RadioButton)rgDrinkingHabbits.getChildAt(2)).setClickable(false);
               }else  if (biodataDec.getSmoking_habits().equalsIgnoreCase("No")){
                   ((RadioButton)rgSmokingHabits.getChildAt(1)).setChecked(true);
                   ((RadioButton)rgDrinkingHabbits.getChildAt(0)).setClickable(false);
                   ((RadioButton)rgDrinkingHabbits.getChildAt(2)).setClickable(false);
               }else if (biodataDec.getSmoking_habits().equalsIgnoreCase("Occasional")){
                    ((RadioButton)rgSmokingHabits.getChildAt(2)).setChecked(true);
                   ((RadioButton)rgDrinkingHabbits.getChildAt(0)).setClickable(false);
                   ((RadioButton)rgDrinkingHabbits.getChildAt(1)).setClickable(false);
                }

            }

            if (!biodataDec.dietary_habits.isEmpty()) {
                Log.d(TAG, "allocateMemory:ch "+biodataDec.dietary_habits);

                if (biodataDec.getDietary_habits().equalsIgnoreCase("Vegetarian")){
                    ((RadioButton)rgDietaryHabits.getChildAt(0)).setChecked(true);
                    ((RadioButton)rgDrinkingHabbits.getChildAt(1)).setClickable(false);
                    ((RadioButton)rgDrinkingHabbits.getChildAt(2)).setClickable(false);
                    ((RadioButton)rgDrinkingHabbits.getChildAt(3)).setClickable(false);
                }else  if (biodataDec.getDietary_habits().equalsIgnoreCase("Non-vegetarian")){
                    ((RadioButton)rgDietaryHabits.getChildAt(1)).setChecked(true);
                    ((RadioButton)rgDrinkingHabbits.getChildAt(0)).setClickable(false);
                    ((RadioButton)rgDrinkingHabbits.getChildAt(2)).setClickable(false);
                    ((RadioButton)rgDrinkingHabbits.getChildAt(3)).setClickable(false);
                }else if (biodataDec.getDietary_habits().equalsIgnoreCase("Occasional non-vegetarian (Mixed)")){
                    ((RadioButton)rgDietaryHabits.getChildAt(2)).setChecked(true);
                    ((RadioButton)rgDrinkingHabbits.getChildAt(0)).setClickable(false);
                    ((RadioButton)rgDrinkingHabbits.getChildAt(1)).setClickable(false);
                    ((RadioButton)rgDrinkingHabbits.getChildAt(3)).setClickable(false);
                }else if (biodataDec.getDietary_habits().equalsIgnoreCase("Eggetarian")){
                    ((RadioButton)rgDietaryHabits.getChildAt(3)).setChecked(true);
                    ((RadioButton)rgDrinkingHabbits.getChildAt(0)).setClickable(false);
                    ((RadioButton)rgDrinkingHabbits.getChildAt(1)).setClickable(false);
                    ((RadioButton)rgDrinkingHabbits.getChildAt(2)).setClickable(false);
                }


            }

            if (!biodataDec.getName_to_contact().isEmpty()) {
                txtcontact1.setText(biodataDec.getName_to_contact());
                txtcontact1.setFocusableInTouchMode(false);
            } else {
                txtcontact1.setText("");
            }

            if (!biodataDec.its_relation.isEmpty()) {
                txtRelation.setText(biodataDec.its_relation);
                txtRelation.setFocusableInTouchMode(false);
            } else {
                txtRelation.setText("");
            }

           /* if (!biodataDec.contact_no.isEmpty()) {
                rgShowContactNumber.setText(biodataDec.contact_no);
            } else {
                rgShowContactNumber.setText("");
            }*/


            if (!biodataDec.getEmail_id().isEmpty()) {
                txtmailid.setText(biodataDec.email_id);
                txtmailid.setFocusableInTouchMode(false);
            } else {
                txtmailid.setText("");
            }


            if (!biodataDec.mg_id.isEmpty()) {
                mgid=biodataDec.getMg_id();
            }

            if (!biodataDec.gender.isEmpty()) {
                gender=biodataDec.getGender();
            }

            if (!biodataDec.mg_name.isEmpty()) {
                mgname=biodataDec.getMg_name();
            }

            if (!biodataDec.getUrl().isEmpty()){
                URL=biodataDec.getUrl();
            }

//            if (!biodataDec.image.isEmpty()) {
//                txtmailid.setText(biodataDec.image);
//            } else {
//                txtmailid.setText("");
//            }

         /*   if (!biodataDec.url.isEmpty()) {
                txtmailid.setText(biodataDec.url);
            } else {
                txtmailid.setText("");
            }
*/
        }




        setComplexionSpinnerAdapter();
        setRashiSpinnerAdapter();
        setAgeSpinnerAdapter();
        setMaritialSpinnerAdapter();
        setCitizenSpinnerAdapter();
        setHandicapSpinnerAdapter();
        setEducationSpinnerAdapter();
//        setCurrencySpinner();
//        setSalarySpinner();



        bgroupAdapter = new ArrayAdapter<String>(ctx,
                android.R.layout.simple_spinner_item,
                ctx.getResources().getStringArray(R.array.blood));
        bgroupAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnblood.setAdapter(bgroupAdapter);

        weightAdapter = new ArrayAdapter<String>(ctx,
                android.R.layout.simple_spinner_item,
                ctx.getResources().getStringArray(R.array.weight));
        weightAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnWeight.setAdapter(weightAdapter);

        heightAdapter = new ArrayAdapter<String>(ctx,
                android.R.layout.simple_spinner_item,
                ctx.getResources().getStringArray(R.array.height));
        heightAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnHeight.setAdapter(heightAdapter);


        toolbar_top = findViewById(R.id.toolbar_top);
        txtGenderTitle = toolbar_top.findViewById(R.id.txtGenderTitle);
        imgGenderBack = toolbar_top.findViewById(R.id.imgGenderBack);
        imgGenderIcon = toolbar_top.findViewById(R.id.imgGenderIcon);

        String action = getIntent().getExtras().getString("action");

        if (getIntent().hasExtra("from")){
            Log.d(TAG, "allocateMemory: "+"cc");
        }else {
            mgid = getIntent().getExtras().getString("mgid");
            gender = getIntent().getExtras().getString("gender");
            mgname = getIntent().getExtras().getString("mgname");
            image_str = getIntent().getExtras().getString("image");
            URL = getIntent().getExtras().getString("URL");
            txtGenderTitle.setText("" + mgname);
            if (!image_str.equalsIgnoreCase("")) {
                Glide.with(ctx)
                        .load(URL + image_str)
                        .apply(RequestOptions.circleCropTransform())
                        .into(imgGenderIcon);
            }
        }
        //  arr_adapter_list = getIntent().getSerializableExtra();



    }

    public void setListeners() {

        txtaddress.setHint(getResources().getString(R.string.residential_add));
        linResend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                linResend.setVisibility(View.GONE);
                if (CountryCode.equalsIgnoreCase("")) {
                    Toast.makeText(ctx, "enter country code", Toast.LENGTH_LONG).show();
                } else if (txtcontactNo.getText().length() < 9) {
                    txtcontactNo.setError("Contact number required");
                    LinAddOTP.setVisibility(View.GONE);
                } else {
                    LinAddOTP.setVisibility(View.VISIBLE);

                    sendSMS(CountryCode, txtcontactNo.getText().toString());
                }
            }
        });

        txtAddmobileCode.setOnCountryChangeListener(new CountryCodePicker.OnCountryChangeListener() {
            @Override
            public void onCountrySelected(Country selectedCountry) {
                CountryCode = "+" + selectedCountry.getPhoneCode();
            }
        });

        imgGenderBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AddBiodata.super.onBackPressed();
            }
        });
        imgselect_br_gr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                temp = 0;
                requestPermission(0);
            }
        });
        imgselect_br_grfull1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                temp = 1;
                requestPermission(1);
            }
        });
        imgselect_br_grfull2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                temp = 2;
                requestPermission(2);
            }
        });


        if (gender.equalsIgnoreCase("1")) {
            rdogrpgender.check(R.id.rdomale);
            rdomale.setTextColor(Color.parseColor("#FFFFFF"));
            rdofemale.setTextColor(Color.parseColor("#000000"));
            rdofemale.setClickable(false);
        } else if (gender.equalsIgnoreCase("0")) {
            rdogrpgender.check(R.id.rdofemale);
            rdofemale.setTextColor(Color.parseColor("#FFFFFF"));
            rdomale.setTextColor(Color.parseColor("#000000"));
            rdomale.setClickable(false);
        }

        rdogrpgender.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.rdomale:
                        gender = "1";
                        rdomale.setTextColor(Color.parseColor("#FFFFFF"));
                        rdofemale.setTextColor(Color.parseColor("#000000"));
                        break;
                    case R.id.rdofemale:
                        gender = "0";
                        rdofemale.setTextColor(Color.parseColor("#FFFFFF"));
                        rdomale.setTextColor(Color.parseColor("#000000"));
                        break;
                }
            }
        });


        rgDrinkingHabbits.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.rbtnDrinkYes:
                        drinkingHabits = rbtnDrinkYes.getText().toString();
                        break;
                    case R.id.rbtnDrinkNo:
                        drinkingHabits = rbtnDrinkNo.getText().toString();
                        break;
                    case R.id.rbtnDrinkOccasional:
                        drinkingHabits = rbtnDrinkOccasional.getText().toString();
                        break;
                }
            }

        });


        rgSmokingHabits.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.rbtnSmokeYes:
                        smokingHabits = rbtnSmokeYes.getText().toString();
                        break;
                    case R.id.rbtnSmokeNo:
                        smokingHabits = rbtnSmokeNo.getText().toString();
                        break;
                    case R.id.rbtnSmokeOccasional:
                        smokingHabits = rbtnSmokeOccasional.getText().toString();
                        break;
                }
            }
        });


        rgDietaryHabits.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.rbtnDietaryVeg:
                        diataryHabits = rbtnDietaryVeg.getText().toString();
                        break;
                    case R.id.rbtnDietaryNonVeg:
                        diataryHabits = rbtnDietaryNonVeg.getText().toString();
                        break;
                    case R.id.rbtnDietaryNonVegOccasional:
                        diataryHabits = rbtnDietaryNonVegOccasional.getText().toString();
                        break;
                    case R.id.rbtnDietaryEggetarian:
                        diataryHabits = rbtnDietaryEggetarian.getText().toString();
                        break;
                }
            }
        });


        spnoccupation1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) {
                    occupation = OccupationId.get(position);
                } else {
                    occupation = "";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spinnerCitizen.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) {
                    sCitizen = citizenList[position];
                } else {
                    sCitizen = "NO";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spinnerHandicap.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) {
                    pHandicap = citizenList[position];
                } else {
                    pHandicap = "NO";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spinnerComplexion.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) {
                    complexion = spinnerComplexion.getSelectedItem().toString();
                } else {
                    complexion = "";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        spinnerRashi.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) {
                    ras_tithi = spinnerRashi.getSelectedItem().toString();
                } else {
                    ras_tithi = "";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        spinnerAge.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) {
                    age = spinnerAge.getSelectedItem().toString();
                } else {
                    age = "";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        spinnerMarital.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) {
                    marital = spinnerMarital.getSelectedItem().toString();
                } else {
                    marital = "";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spnHeight.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                if (position != 0) {
                    height = spnHeight.getSelectedItem().toString();

                } else {
                    height = "";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        spnWeight.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                if (position != 0) {
                    weight = spnWeight.getSelectedItem().toString();
                } else {
                    weight = "";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        spinnerEducation.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) {
                    education = spinnerEducation.getSelectedItem().toString();
                } else {
                    education = "";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        spnblood.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) {
                    blood = bgroupAdapter.getItem(position).toString();
                } else {
                    blood = "-";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        linDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(ctx, android.app.AlertDialog.THEME_HOLO_LIGHT, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {
                        monthOfYear = monthOfYear + 1;
                        String mnth = (monthOfYear < 10) ? "0" + monthOfYear : "" + monthOfYear;
                        String day = (dayOfMonth < 10) ? "0" + dayOfMonth : "" + dayOfMonth;
                        tvDate.setText(day + "-" + mnth + "-" + year);
                    }
                }, mYear, mMonth, mDay);
                datePickerDialog.setCancelable(false);
                datePickerDialog.show();
            }
        });
        linTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                mHour = c.get(Calendar.HOUR);
                mMinute = c.get(Calendar.MINUTE);
                mAmPm = c.get(Calendar.AM_PM);
                TimePickerDialog timePickerDialog = new TimePickerDialog(ctx,
                        new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay,
                                                  int minute) {
                                String am_pm = (hourOfDay < 12) ? "AM" : "PM";
                                String hourOfDay1 = (hourOfDay < 10) ? "0" + hourOfDay : "" + hourOfDay;
                                String minute1 = (minute < 10) ? "0" + minute : "" + minute;


                                tvTime.setText(hourOfDay1 + ":" + minute1 + " " + am_pm);
                            }
                        }, mHour, mMinute, false);
                timePickerDialog.setCancelable(false);
                timePickerDialog.show();
            }
        });

        rbtnNo.setChecked(true);
        rgPaymentOption.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if (radioGroup.getId() == R.id.rbtnYes) {
                    btngroupnext1.setText("Proceed to Pay");

                }
                if (radioGroup.getId() == R.id.rbtnNo) {
                    btngroupnext1.setText("Send bio-data to publish");
                }
            }
        });

        /*rgShowContactNumber.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if (radioGroup.getCheckedRadioButtonId() == R.id.rbtnContactYes) {
                    String str_contact1 = txtcontact1.getText().toString();
                    txtcontact1.setText(str_contact1 +" - "+txtcontactNo.getText().toString() );

                }
                if (radioGroup.getCheckedRadioButtonId() == R.id.rbtnContactNo)  {
                    String str_contact1 = txtcontact1.getText().toString();
                    txtcontact1.setText(str_contact1 +" - "+txtcontactNo.getText().toString() );
                }
            }
        });*/


        btngroupnext1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (isMobileVerified) {
                    if (is_premium_flag) {
                        if (Utils.getString(ctx, Constants.USER_IS_FIRST_PROFILE_UPLOADED).equals("1")) {
                            startPayment("15");
                        } else {
                            addBiodata("1",false);
                        }
                    } else {
                        if (rbtnYes.isChecked()) {
                            startPayment("1");
                        } else {
                            addBiodata("0", false);
                        }
                    }

//                    addBiodata("1");
                } else {
                    Toast.makeText(ctx, "Verify mobile number to add bio-data", Toast.LENGTH_LONG).show();
                }


            }
        });

        btnsendotp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (ValidateInput() == true) {
                    if (imgbridegroom.getDrawable() != null) {
                        if (connection.isNetworkAvailable(ctx)) {
                            if (CountryCode.equalsIgnoreCase("")) {
                                Toast.makeText(ctx, "enter country code", Toast.LENGTH_LONG).show();
                            } else if (txtcontactNo.getText().length() < 9) {
                                txtcontactNo.setError("Contact number required");
                                LinAddOTP.setVisibility(View.GONE);
                            } else {
                                dialogsending = new ProgressDialog(ctx);
                                dialogsending.setMessage("Sending...");
                                dialogsending.setCancelable(true);
                                dialogsending.show();
                                sendSMS(CountryCode, txtcontactNo.getText().toString());
                                /*startPayment("1");*/

                            }

                        } else {
                            Toast.makeText(ctx, "No internet connection found. Please check your phone settings to turn on the internet.", Toast.LENGTH_LONG).show();
                        }
                    } else {
                        Toast.makeText(ctx, "Photos required", Toast.LENGTH_LONG).show();
                    }
                }

            }
        });

        btnsubmitotp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (etAddOTP.getText().length() == 6 && CodeSend != null) {
                    ProgressDialog dialog = new ProgressDialog(ctx);
                    dialog.setTitle("OTP Verification");
                    dialog.setMessage("OTP Verifying");
                    dialog.setCancelable(false);
                    dialog.show();
                    PhoneAuthCredential credential = PhoneAuthProvider.getCredential(CodeSend, etAddOTP.getText().toString());
                    signInWithPhoneAuthCredential(credential, dialog);
                } else {
                    Toast.makeText(ctx, "Please enter valid OTP", Toast.LENGTH_LONG).show();
                }
            }
        });

        txtincomeCurrency.setFocusableInTouchMode(false);
        txtincomeCurrency.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CountryCurrencyPicker pickerDialog = CountryCurrencyPicker.newInstance(PickerType.CURRENCY, new CountryCurrencyPickerListener() {

                    @Override
                    public void onSelectCountry(com.scrounger.countrycurrencypicker.library.Country country) {
                    }

                    @Override
                    public void onSelectCurrency(Currency currency) {
                        txtincomeCurrency.setText(currency.getCode());
                        txtincomeCurrency.requestFocus(currency.getCode().length());
//                        if (currency.getCountries() == null) {
//                            Toast.makeText(AddBiodata.this,
//                                    String.format("name: %s\nsymbol: %s", currency.getName(), currency.getSymbol())
//                                    , Toast.LENGTH_SHORT).show();
//                        } else {
//                            Toast.makeText(AddBiodata.this,
//                                    String.format("name: %s\ncurrencySymbol: %s\ncountries: %s", currency.getName(), currency.getSymbol(), TextUtils.join(", ", currency.getCountriesNames()))
//                                    , Toast.LENGTH_SHORT).show();
//                        }
                    }
                });

                pickerDialog.setDialogTitle(getString(R.string.country_currency_dialog_title));
                pickerDialog.show(getSupportFragmentManager(), CountryCurrencyPicker.DIALOG_NAME);
            }
        });
    }


    // set  spinner list
    public void setComplexionSpinnerAdapter() {
        ArrayAdapter aa = new ArrayAdapter(AddBiodata.this, android.R.layout.simple_spinner_item, complexionList);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerComplexion.setAdapter(aa);

    }


    // set  spinner list
    public void setCurrencySpinner() {
        ArrayAdapter aa = new ArrayAdapter(AddBiodata.this, android.R.layout.simple_spinner_item, currency_list);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnCurrency.setAdapter(aa);

    }

    public void setSalarySpinner() {
        ArrayAdapter aa = new ArrayAdapter(AddBiodata.this, android.R.layout.simple_spinner_item, salary_list);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnSalary.setAdapter(aa);

    }

    // set  spinner list
    public void setRashiSpinnerAdapter() {
        ArrayAdapter aa = new ArrayAdapter(AddBiodata.this, android.R.layout.simple_spinner_item, rashiList);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerRashi.setAdapter(aa);

    }


    // set  spinner list
    public void setMaritialSpinnerAdapter() {
        ArrayAdapter aa = new ArrayAdapter(AddBiodata.this, android.R.layout.simple_spinner_item, maritialStatusList);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerMarital.setAdapter(aa);

    }

    public void setCitizenSpinnerAdapter() {
        ArrayAdapter aa = new ArrayAdapter(AddBiodata.this, android.R.layout.simple_spinner_item, citizenList);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCitizen.setAdapter(aa);

    }


    // set  spinner list
    public void setHandicapSpinnerAdapter() {
        ArrayAdapter aa = new ArrayAdapter(AddBiodata.this, android.R.layout.simple_spinner_item, citizenList);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerHandicap.setAdapter(aa);

    }

    public void setEducationSpinnerAdapter() {
        ArrayAdapter aa = new ArrayAdapter(AddBiodata.this, android.R.layout.simple_spinner_item, educationList);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerEducation.setAdapter(aa);

    }


    // set  spinner list
    public void setAgeSpinnerAdapter() {
        ArrayAdapter ageAdapter = new ArrayAdapter<String>(ctx,
                android.R.layout.simple_spinner_item,
                ctx.getResources().getStringArray(R.array.age));
        ageAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerAge.setAdapter(ageAdapter);

    }


    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential, final ProgressDialog dialog) {
        auth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d(TAG, "signInWithCredential:success");
                            /*sendDataToServer();*/
                            dialog.dismiss();
                            linResend.setVisibility(View.GONE);
                            isMobileVerified = true;
                            txtcontactNo.setEnabled(false);
                            Toast.makeText(ctx, "OTP verification Successful", Toast.LENGTH_LONG).show();
                            txtcontactNo.setCompoundDrawables(null, null, getResources().getDrawable(R.drawable.ic_done_green), null);
                            etAddOTP.setEnabled(false);

                            LinAddOTP.setVisibility(View.GONE);
                            btngroupnext1.setVisibility(View.VISIBLE);
                            if (is_premium_flag) {
                                if (Utils.getString(ctx, Constants.USER_IS_FIRST_PROFILE_UPLOADED).equals("1")) {
                                    btngroupnext1.setText("Proceed to Pay");
                                    lblText.setVisibility(View.VISIBLE);
                                } else {
                                    btngroupnext1.setText("Publish Biodata");
                                    lblText.setVisibility(View.GONE);
                                }
                            }else {
                                lblText.setVisibility(View.VISIBLE);


                                if (rbtnYes.isChecked()) {
                                    btngroupnext1.setText("Proceed to Pay");
                                }
                                if (rbtnNo.isChecked()) {
                                    btngroupnext1.setText("Send bio-data to publish");
                                }
                            }

                        } else {
                            // Sign in failed, display a message and update the UI
                            Log.w(TAG, "signInWithCredential:failure", task.getException());
                            dialog.dismiss();

                            if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {
                                // The verification code entered was invalid
                                Toast.makeText(ctx, "The verification code entered was invalid", Toast.LENGTH_LONG).show();
                            }

                        }
                    }
                });
    }

    private void sendSMS(String countryCode, String mobile) {
        counter = 60;
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                countryCode + "" + mobile,        // Phone number to verify
                60,                 // Timeout duration
                TimeUnit.SECONDS,   // Unit of timeout
                this,               // Activity (for callback binding)
                mCallbacks);        // OnVerificationStateChangedCallbacks
        linResend.setVisibility(View.VISIBLE);

        new CountDownTimer(60000, 1000) {
            public void onTick(long millisUntilFinished) {
                linResend.setText("Resend OTP within " + counter + " seconds.");
                linResend.setClickable(false);
                if (counter > 0) {
                    counter--;
                } else {
                    linResend.setClickable(true);
                    linResend.setText("Resend OTP?");
                }
            }

            public void onFinish() {
                counter = 0;
                linResend.setClickable(true);
                linResend.setText("Resend OTP?");
            }
        }.start();
    }

    public void setOccupation() {
        String WebServiceUrl = Common.GetWebServiceUrl() + "occupation_list.php?gender=-1";
        JsonArrayRequest request = new JsonArrayRequest(WebServiceUrl, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                Utils.log(TAG, response.toString());
                try {
                    String error = response.getJSONObject(0).getString("error");
                    if (error.equals("no error") == false) {
                        Common.showDialog(ctx);
                    } else {
                        //no error
                        int total = response.getJSONObject(1).getInt("total");
                        if (total == 0)
                            Toast.makeText(ctx, "No Occupation Found", Toast.LENGTH_LONG).show();
                        else {
                            int size = response.length();
                            OccupationId.add("0");
                            OccupationTitle.add("Select Occupation");
                            for (int i = 2; i < (size-4); i++) //3
                            {
                                JSONObject object = response.getJSONObject(i);
                                OccupationId.add(object.getString("id"));
                                OccupationTitle.add(object.getString("ot"));
                            }
                            JSONObject object = response.getJSONObject(size-1);


                            OccupationId.add(object.getString("id"));
                            OccupationTitle.add(object.getString("ot"));
                            dataAdapter = new ArrayAdapter<String>(ctx, R.layout.spinner_item, OccupationTitle);
                            dataAdapter.setDropDownViewResource(R.layout.spinner_item);
                            //spnoccupation.setAdapter(dataAdapter);
                            spnoccupation1.setAdapter(dataAdapter);

                            //for save data
                            if (getIntent().hasExtra("from")) {
                                if (!biodataDec.getOccupation().isEmpty() && biodataDec.getOccupation() !=null) {
                                    Log.d(TAG, "onResponse: "+OccupationTitle.size());
                                    for (int i = 0; i <= OccupationTitle.size()-1; i++) {
                                        Log.d(TAG, "onResponse: "+i);
                                        if (Integer.parseInt(biodataDec.getOccupation())==i){
                                           final int finalI = i;
                                            spnoccupation1.post(new Runnable() {
                                                @Override
                                                public void run() {
                                                    spnoccupation1.setSelection(finalI);
                                                }
                                            });
                                        }
                                    }
                                }
                            }
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Common.showDialog(ctx);
            }
        });
        request.setRetryPolicy(new DefaultRetryPolicy(2000, 3, 1));
        AppController.getInstance().addToRequestQueue(request);
    }

    public void addBiodata(String razorpayPaymentID, boolean pay_status) {
        pDialog = new ProgressDialog(ctx);
        pDialog.setMessage("Uploading Please Wait....");
        pDialog.setCancelable(false);

        showpDialog();

        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        RequestParams params = new RequestParams();
        params.put("register_userid", "" + Utils.getString(ctx,Constants.USER_ID));
        params.put("name", fullname);
        params.put("middle", middle);
        params.put("surname", surname);
        params.put("gender", gender);
        params.put("age", "" + age);
        params.put("city", "" + city);
        params.put("education", education);
        params.put("occupationid", occupation);
        params.put("address", address);
        Log.d(TAG, sCitizen+ "addBiodata: "+pHandicap  );
        if (sCitizen.equalsIgnoreCase("YES")){
            params.put("is_senior_citizen", 1);
        }else {
            params.put("is_senior_citizen", 0);
        }

        if (pHandicap.equalsIgnoreCase("YES")){
            params.put("is_physically_challenged", 1);
        }else {
            params.put("is_physically_challenged", 0);
        }

        income = txtincomeCurrency.getText().toString() + " " + txtincome.getText().toString();

       /* if (txtincome.getText().toString().length()!=0) {

            if (rbtnPerMonth.isChecked()) {

            } else {
                income = spnCurrency.getSelectedItem().toString() + " " + txtincome.getText().toString().trim() + " /anum";
            }

        }else{
            income = txtincome.getText().toString().trim();
        }*/

        params.put("income", income);

        if (weight.length() == 0) {
            weight = "";
        }
        params.put("height", height);
        params.put("weight", weight);
        params.put("blood", blood);
        params.put("degree", Specialization);
        params.put("birthdate", dobdate);
        params.put("birthtime", dobtime);
        params.put("birthplace", dobplace);
        params.put("hobbies", hobbies);
        params.put("expectation", expectation);
        params.put("photo", "img1.png");
        params.put("fathername", fathername);
        params.put("fatheroccup", fatherOccup);
        params.put("mothername", mothername);
        params.put("motheroccup", motherOccup);
        params.put("brothers", brothers);
        params.put("sisters", sisters);
        params.put("relatives", relative);
        params.put("nativeplace", nativePlace);
        params.put("contact", contact);
        params.put("contact_person_number", contactNo);
        params.put("contact2", contact2);
        params.put("email", email);
        params.put("saved", "0");

        params.put("latitude", "" + latitude);
        params.put("longitude", "" + longitude);
        params.put("relation", relation);

       /* if (rbtnContactYes.isChecked()){
            relation = relation +" - "+ contactNo;
        }*/
        params.put("contact_person", person_name);
        params.put("relative_who_knows", contact2);
        params.put("rel_surname", rel_surname);
        params.put("complexion", complexion);
        params.put("rastithi", ras_tithi);
        params.put("religion", religion);
        params.put("marital", marital);
        params.put("mothertongue", motherTongue);
        params.put("kuldaivat", kulDevta);
        params.put("occDetails", occDetails);
        params.put("drinking_habits", drinkingHabits);
        params.put("smoking_habits", smokingHabits);
        params.put("diatary_habits", diataryHabits);
        params.put("pay_id", razorpayPaymentID);
        params.put("groupid", mgid);
        params.put("verified", "0");
        if (is_premium_flag) {
            params.put("is_premium", "1");
        }

        if (pay_status){
            params.put("pay_status", "1");
        }else {
            params.put("pay_status", "0");
        }

        Utils.log(TAG, "ADD_BIO_DATA_URL : " + Common.GetWebServiceUrl() + "biodatam.php" + "?" + params);
        client.post(Common.GetWebServiceUrl() + "biodatam.php", params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                String success = "", msg = "", id = "";
                Utils.log(TAG, "ADD_BIO_DATA_RESPONSE : " + response);


                try {
                    JSONObject res = new JSONObject(response);
                    success = res.getString("success");
                    msg = res.getString("msg");
                    id = res.getString("id");
                    Log.d("ID==>", id);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                if (success.equalsIgnoreCase("true")) {
                    sendVerified(id);
                    //  Toast.makeText(AddBiodata.this, "" + msg, Toast.LENGTH_LONG).show();
                    for (int i = 3; i <= 5; i++) {
                          UPloadImageToServer(id, msg, i);
                    }
                } else {
                    Toast.makeText(AddBiodata.this, "" + msg, Toast.LENGTH_LONG).show();
                }

               /* Intent intent = new Intent(AddBiodata.this,SendVerifiedActivity.class);
                intent.putExtra("bId",id);
                intent.putExtra("memberList",new Gson().toJson(myData));
                startActivity(intent);*/
                hidePDialog();



            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "ADD_BIO_DATA_ERROR : " + error.getMessage());
                hidePDialog();
                Common.showBioDataDialog(ctx, error.getMessage());
            }
        });
    }

    private void sendVerified(final String id) {

        final Dialog alertDialog = new Dialog(ctx);
        LayoutInflater inflater = getLayoutInflater();
        View convertView = (View) inflater.inflate(R.layout.layout_bio_request, null);
        alertDialog.setContentView(convertView);
        alertDialog.setCancelable(false);
        alertDialog.setTitle("Send request to publish");
        RecyclerView recyclerView = convertView.findViewById(R.id.rcvMemberList);
        LinearLayout LinSendRequest = convertView.findViewById(R.id.LinSendRequest);
        Button btnSend = convertView.findViewById(R.id.btnSend);
        Button cancel = convertView.findViewById(R.id.btn);

        txt_search_mname = convertView.findViewById(R.id.txt_search_mname);

        memberArrayList = myData.members;
      /*  final AlertDialog alertDialog__ = alertDialog.create();*/
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.dismiss();
            }
        });

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int count = 0;
                StringBuffer string = new StringBuffer();
                String admin_id = myData.aid;
                Log.d(TAG, "myData: "+myData.aid);
                string.append(admin_id + ",");
                for (int i = 0; i < myData.members.size(); i++) {

                    if (myData.members.get(i).isSelected()) {

//                        if (myData.members.get(i).is_subadmin.equals("0") && !myData.members.get(i).id.equals(admin_id)) {
//                            string.append(myData.members.get(i).id + ",");
//                            count++;
//                        }

                        if (myData.members.get(i).is_subadmin.equals("1") || myData.members.get(i).is_subadmin.equals("0")) {
                            string.append(myData.members.get(i).id + ",");
                            count++;
                        }
                    }
                }

                if (count > 0) {
                    Log.d(TAG, "onClick: "+string);
                    send_request_new(id, string);
                    alertDialog.dismiss();
                } else {
                    Toast.makeText(AddBiodata.this, "Please select atleast 1 members", Toast.LENGTH_SHORT).show();
                }
            }
        });


        /*alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });*/

        /*alertDialog.setPositiveButton("Send to Publish", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });*/


        recyclerView.setLayoutManager(new LinearLayoutManager(ctx));
        memberRequestAdapter = new MemberRequestAdapter(ctx, memberArrayList, LinSendRequest, myData.aid);
        recyclerView.setAdapter(memberRequestAdapter);
        memberRequestAdapter.notifyDataSetChanged();
        alertDialog.setCancelable(true);

        txt_search_mname.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Utils.log(TAG, "2. s " + s + " : start " + start + " : before " + before + " : count " + count);

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (txt_search_mname.getText().toString().equalsIgnoreCase("")) {
                    memberRequestAdapter.updateList(memberArrayList);

                } else {

                    ArrayList<Members.Member> temp = new ArrayList();
                    for (Members.Member d : memberArrayList) {
                        //or use .equal(text) with you want equal match
                        //use .toLowerCase() for better matches
                        if (d.firstname.toLowerCase().contains(txt_search_mname.getText().toString().toLowerCase())
                                || d.surname.toLowerCase().contains(txt_search_mname.getText().toString().toLowerCase())
                                || d.mobile.toLowerCase().contains(txt_search_mname.getText().toString().toLowerCase())) {
                            temp.add(d);
                        }
                    }
                    //update recyclerview
                    memberRequestAdapter.updateList(temp);
                }
            }
        });
        alertDialog.show();
    }


    public void send_request_new(String id, StringBuffer string) {
        WebServiceCaller.getClient().send_request(id,string).enqueue(new Callback<RegisterModel>() {
            @Override
            public void onResponse(Call<RegisterModel> call, retrofit2.Response<RegisterModel> response) {
                RegisterModel obj = response.body();
                assert obj != null;
                if (obj.getSuccess()){
                    Toast.makeText(AddBiodata.this, "Bio-data sent to admin to publish", Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(AddBiodata.this, "Record Already Added", Toast.LENGTH_LONG).show();
                }
                AddBiodata.super.onBackPressed();
                Log.d("OnResponse", response.toString());
            }

            @Override
            public void onFailure(Call<RegisterModel> call, Throwable t) {
                //swipeContainer.setRefreshing(false)

                Log.d("Error_Message", t.getMessage());

                Toast.makeText(AddBiodata.this, "Server Error  :   " + t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });


    }


    private void sendRequest(String id, StringBuffer string) {
        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        RequestParams params = new RequestParams();
        params.put("bid", id);
        params.put("ids", string);
        Utils.log(TAG, Constants.APP_SEND_REQUEST + "?" + params);
        client.post(Constants.APP_SEND_REQUEST, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                String success = "", message = "";
                Utils.log(TAG, "SEND_REQUEST_RESPONSE : " + res);
                try {
                    JSONObject object = new JSONObject(res);
                    success = object.getString("success");
                    message = object.getString("msg");
                } catch (JSONException e) {
                    e.printStackTrace();
                }

//                Toast.makeText(AddBiodata.this, res, Toast.LENGTH_LONG).show();
                if (success.equalsIgnoreCase("true")) {
                    Toast.makeText(AddBiodata.this, "Bio-data sent to admin to publish", Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(AddBiodata.this, "Record Already Added", Toast.LENGTH_LONG).show();
                }
                AddBiodata.super.onBackPressed();
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "SEND_REQUEST_ERROR : " + error.getMessage());
            }
        });
    }

    public boolean ValidateInput() {
        boolean isvalid = true;
        fullname = txtfullname.getText().toString().trim();
        surname = txtsurname.getText().toString().trim();

        //blood = txtblood.getText().toString();
        bgphoto = txtbgphotoid.getText().toString();
        dobdate = tvDate.getText().toString();
        dobtime = tvTime.getText().toString();
        dobplace = txtdobplace.getText().toString();
        hobbies = txthobbies.getText().toString();
        expectation = txtexpectation.getText().toString();
        fathername = txtfathername.getText().toString();
        mothername = txtmothername.getText().toString();
        brothers = txtbroname.getText().toString();
        sisters = txtsisname.getText().toString();
        address = txtaddress.getText().toString();
        contact = txtcontactNo.getText().toString();
        person_name = txtcontact1.getText().toString();
        contactNo = txtcontactNo.getText().toString();
        contact2 = txtcontact2.getText().toString();
        middle = txtMiddleName.getText().toString();
        Specialization = txtSpecialization.getText().toString();
        fatherOccup = txtfatherOccupation.getText().toString();
        motherOccup = txtmotherOccupation.getText().toString();
        relative = txtOtherRelatives.getText().toString();
        nativePlace = txtNative.getText().toString();
        city = txtcity.getText().toString();
        relation = txtRelation.getText().toString();
        rel_surname = txtcontactSurname.getText().toString();
        email = txtmailid.getText().toString().trim().toLowerCase();


        // complexion = spinnerComplexion.getSelectedItem().toString();
        // ras_tithi = spinnerRashi.getSelectedItem().toString();
        religion = txtReligion.getText().toString();
        //  marital = spinnerMarital.getSelectedItem().toString();
        motherTongue = txtMotherTongue.getText().toString();
        kulDevta = txtKulDevta.getText().toString();
        occDetails = txtOccDetails.getText().toString();

        //gender = rdogrpgender.getText().toString();

        /*String emailPattern = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+" +
                "(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        if (email.matches(emailPattern))
        {
            isvalid=false;
            txtmailid.setError("email is not proper");
        }*/
        if (email.length() > 0) {
            if (!email.contains(".com")) {
                 isvalid = false;
                Toast.makeText(ctx, "Enter Valid Email", Toast.LENGTH_SHORT).show();
                txtmailid.setError("Email required");
            } else if (!email.contains("@")) {
                isvalid = false;
                Toast.makeText(ctx, "Enter Valid Email", Toast.LENGTH_SHORT).show();
                txtmailid.setError("Email required");
            }
        } else {
            if (email.equalsIgnoreCase("")) {
                email = "-";
            }
        }if (gender.isEmpty()) {
            isvalid = false;
            Toast.makeText(ctx, "Select Bride or Groom First", Toast.LENGTH_SHORT).show();
        } else if (fullname.isEmpty()) {
            isvalid = false;
            Toast.makeText(ctx, "First name required", Toast.LENGTH_SHORT).show();
            txtfullname.setError("First name required");
        } else if (middle.isEmpty()) {
            isvalid = false;
            Toast.makeText(ctx, "Middle name required", Toast.LENGTH_SHORT).show();
            txtMiddleName.setError("Middle name required");
        }else if (surname.isEmpty()) {
            isvalid = false;
            Toast.makeText(ctx, "Surname required", Toast.LENGTH_SHORT).show();
            txtsurname.setError("Surname required");
        }else if (age.length() == 0) {
            isvalid = false;
            Toast.makeText(ctx, "Age required", Toast.LENGTH_SHORT).show();
        } else if (spinnerMarital.getSelectedItemPosition() == 0) {
            isvalid = false;
            Toast.makeText(ctx, "Marital status required", Toast.LENGTH_SHORT).show();
        }/*else if (spinnerHandicap.getSelectedItemPosition() == 0) {
            isvalid = false;
            Toast.makeText(ctx, "P.Handicap required", Toast.LENGTH_SHORT).show();
        }else if (spinnerCitizen.getSelectedItemPosition() == 0) {
            isvalid = false;
            Toast.makeText(ctx, "S.Citizen required", Toast.LENGTH_SHORT).show();
        }*/else if (education.length() == 0) {
            isvalid = false;
            Toast.makeText(ctx, "Education required", Toast.LENGTH_SHORT).show();

        }else if (txtincome.getText().toString().equals("")) {
            isvalid = false;
            txtincome.setError("Annual income required");
        }else if (!txtincome.getText().toString().equals("") && txtincomeCurrency.getText().toString().equals("")) {
            isvalid = false;
            Toast.makeText(ctx, "Currency required", Toast.LENGTH_SHORT).show();
            txtincomeCurrency.setError("Currency required");
        }else if (occupation.length() == 0) {
            isvalid = false;
            Toast.makeText(ctx, "Occupation required", Toast.LENGTH_SHORT).show();
        }else if (city.length() == 0) {
            isvalid = false;
            Toast.makeText(ctx, "Present residing city required", Toast.LENGTH_SHORT).show();
            txtcity.setError("Present residing city required");
        }else if (height.length() == 0) {
            isvalid = false;
            Toast.makeText(ctx, "Height required", Toast.LENGTH_SHORT).show();

        }else if (complexion.length() == 0) {
            isvalid = false;
            Toast.makeText(ctx, "Complexion required", Toast.LENGTH_SHORT).show();

        }else if (dobdate.length() == 0) {
            dobdate = "";
            //   isvalid = false;
            //   tvDate.setError("Birth Date required");
            //  Toast.makeText(ctx, "Birth Date required", Toast.LENGTH_SHORT).show();
        }else if (dobtime.length() == 0) {
            dobtime = "";
            // isvalid = false;
            //tvTime.setError("Birth time required");
            //Toast.makeText(ctx, "Birth time required", Toast.LENGTH_SHORT).show();

        }else if (dobplace.length() == 0) {
            dobplace = "-";
        }
        /*if (hobbies.length() == 0) {
            isvalid = false;
            txthobbies.setError("hobbies required");
        }*/
        /*if (expectation.length() == 0) {
            isvalid = false;
            txtexpectation.setError("expectation required");
        }*/
        else if (fathername.length() == 0) {
            isvalid = false;
            Toast.makeText(ctx, "Father's name required", Toast.LENGTH_SHORT).show();
            txtfathername.setError("Father's name required");
        }else if (mothername.length() == 0) {
            mothername = "-";
        }else if (address.length() == 0) {
            isvalid = false;
            Toast.makeText(ctx, "Address required", Toast.LENGTH_SHORT).show();
            txtaddress.setError("Address required");
        }else if (contact.length() == 0) {
            isvalid = false;
            Toast.makeText(ctx, "contact number required", Toast.LENGTH_SHORT).show();
            txtcontact1.setError("contact number required");
        }else if (contactNo.length() == 0) {
            isvalid = false;
            Toast.makeText(ctx, "Contact number required", Toast.LENGTH_SHORT).show();
            txtcontactNo.setError("Contact number required");
        }
        /*if (email.length() == 0) {
            isvalid = false;
            txtmailid.setError("email required");
        }*/
       else if (txtMiddleName.getText().length() == 0) {
            middle = "-";
        }else if (txtNative.getText().length() == 0) {
            nativePlace = "-";
        }else if (txtcontact1.getText().length() == 0) {
            isvalid = false;
            Toast.makeText(ctx, "Name of contact person required", Toast.LENGTH_SHORT).show();
            txtcontact1.setError("Name of contact person required");
        }else if (txtRelation.getText().length() == 0) {
            isvalid = false;
            Toast.makeText(ctx, "Relation and contact number required", Toast.LENGTH_SHORT).show();
            txtcontactNo.setError("Relation and contact number required");
        }else if (CameraFileAbsolutePath.equals("")) {
            isvalid = false;
            Toast.makeText(ctx, "Upload at least one photo", Toast.LENGTH_SHORT).show();
        }
        return isvalid;
    }



    // show process Dialog box
    private void showpDialog() {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }

    // hide process Dialog box
    private void hidePDialog() {
        if (this.pDialog != null) {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }

    public long getMaxDate() {
        long l = new Date().getTime();
        l = l + 172800000;
        return l;
    }

    public long getMinDate() {
        long l = new Date().getTime();
        return l;
    }

    private ArrayList findUnAskedPermissions(ArrayList wanted) {
        ArrayList result = new ArrayList();
        for (Object perm : wanted) {
            if (!hasPermission(perm)) {
                result.add(perm);
            }
        }
        return result;
    }

    private boolean hasPermission(Object permission) {
        if (canMakeSmores()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                return (checkSelfPermission((String) permission) == PackageManager.PERMISSION_GRANTED);
            }
        }
        return true;
    }

    private boolean canMakeSmores() {
        return (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP_MR1);
    }

    @TargetApi(Build.VERSION_CODES.M)
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case ALL_PERMISSIONS_RESULT:
                for (Object perms : permissionsToRequest) {
                    if (!hasPermission(perms)) {
                        permissionsRejected.add(perms);
                    }
                }
                if (permissionsRejected.size() > 0) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (shouldShowRequestPermissionRationale(String.valueOf(permissionsRejected.get(0)))) {
                            showMessageOKCancel("These permissions are mandatory for the application. Please allow access.",
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                                requestPermissions((String[]) permissionsRejected.toArray(new String[permissionsRejected.size()]), ALL_PERMISSIONS_RESULT);
                                            }
                                        }
                                    });
                            return;
                        }
                    }

                }
                break;
        }
    }

    private void showMessageOKCancel(String message, DialogInterface.OnClickListener okListener) {
        new AlertDialog.Builder(ctx)
                .setMessage(message)
                .setPositiveButton("OK", okListener)
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }

    void requestPermission(int i) {
        if (PackageManager.PERMISSION_GRANTED !=
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ||
                PackageManager.PERMISSION_GRANTED != ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)) {
            String[] PermissionList = {Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.CAMERA};
            if (ActivityCompat.shouldShowRequestPermissionRationale
                    (this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ||
                    ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA)) {

                ActivityCompat.requestPermissions(this, PermissionList,
                        REQUEST_MULTIPLE_PERMISSION);
            } else {
                ActivityCompat.requestPermissions(this, PermissionList,
                        REQUEST_MULTIPLE_PERMISSION);
            }
        } else {
            showDialogBox();
        }
    }

    private void showDialogBox() {
        AlertDialog.Builder b1 = new AlertDialog.Builder(ctx);
        b1.setTitle("Select Photo");
        b1.setIcon(R.mipmap.logo1);
        b1.setMessage("I want to select photo");
        b1.setPositiveButton("Using CAMERA", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                File image = null;
                try {
                    image = Util.CreteFileWithUniqueName(ctx);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                switch (temp) {
                    case 0:
                        CameraFileAbsolutePath = image.getAbsolutePath();
                        break;
                    case 1:
                        CameraFileAbsolutePath1 = image.getAbsolutePath();
                        break;
                    case 2:
                        CameraFileAbsolutePath2 = image.getAbsolutePath();
                }
                Uri photoUri = FileProvider.getUriForFile(ctx,

                        BuildConfig.APPLICATION_ID + ".provider", image);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
                startActivityForResult(intent, CAMERA);
            }
        });
        b1.setNegativeButton("using Gallery", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent = new Intent(Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, GALLARY);
            }
        });

        b1.create().show();
    }


    @Override
    public void onBackPressed() {


        new AlertDialog.Builder(AddBiodata.this)
                .setTitle("Alert!")
                .setMessage("Filled information will be saved and show in my bio data drafts.")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (getIntent().hasExtra("from")&&biodataDec.getBid()!=null && !biodataDec.getBid().isEmpty()){
                            updateBioData(biodataDec.getBid());
                        }else {
                            insertBiodata();
                        }
                        finish();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        return;
                    }
                }).show();

    }

    private void getAllData(){
        fullname = txtfullname.getText().toString().trim();
        surname = txtsurname.getText().toString().trim();
        bgphoto = txtbgphotoid.getText().toString();
        dobdate = tvDate.getText().toString();
        dobtime = tvTime.getText().toString();
        dobplace = txtdobplace.getText().toString();
        hobbies = txthobbies.getText().toString();
        expectation = txtexpectation.getText().toString();
        fathername = txtfathername.getText().toString();
        mothername = txtmothername.getText().toString();
        brothers = txtbroname.getText().toString();
        sisters = txtsisname.getText().toString();
        address = txtaddress.getText().toString();
        contact = txtcontactNo.getText().toString();
        person_name = txtcontact1.getText().toString();
        contactNo = txtcontactNo.getText().toString();
        contact2 = txtcontact2.getText().toString();
        middle = txtMiddleName.getText().toString();
        Specialization = txtSpecialization.getText().toString();
        fatherOccup = txtfatherOccupation.getText().toString();
        motherOccup = txtmotherOccupation.getText().toString();
        relative = txtOtherRelatives.getText().toString();
        nativePlace = txtNative.getText().toString();
        city = txtcity.getText().toString();
        relation = txtRelation.getText().toString();
        rel_surname = txtcontactSurname.getText().toString();
        email = txtmailid.getText().toString().trim();


        // complexion = spinnerComplexion.getSelectedItem().toString();
        // ras_tithi = spinnerRashi.getSelectedItem().toString();
        religion = txtReligion.getText().toString();
        //  marital = spinnerMarital.getSelectedItem().toString();
        motherTongue = txtMotherTongue.getText().toString();
        kulDevta = txtKulDevta.getText().toString();
        occDetails = txtOccDetails.getText().toString();
    }

    private void updateBioData(String bid){
        getAllData();
        dbHelper.updateBiodata(bid,fullname,middle,surname,age,education,Specialization,occupation,occDetails,
                txtincomeCurrency.getText().toString(),txtincome.getText().toString(),city,dobdate,dobtime,dobplace,height,weight,blood,complexion,ras_tithi,
                fathername,fatherOccup,mothername,motherOccup,brothers,sisters,religion,marital,motherTongue,
                kulDevta,relative,address,nativePlace,hobbies,expectation,rel_surname,drinkingHabits,smokingHabits,diataryHabits,
                person_name,relation,contact,email,mgid,gender,mgname,image_str,URL,pHandicap,sCitizen);
    }

    private void insertBiodata() {
        fullname = txtfullname.getText().toString().trim();
        surname = txtsurname.getText().toString().trim();
        bgphoto = txtbgphotoid.getText().toString();
        dobdate = tvDate.getText().toString();
        dobtime = tvTime.getText().toString();
        dobplace = txtdobplace.getText().toString();
        hobbies = txthobbies.getText().toString();
        expectation = txtexpectation.getText().toString();
        fathername = txtfathername.getText().toString();
        mothername = txtmothername.getText().toString();
        brothers = txtbroname.getText().toString();
        sisters = txtsisname.getText().toString();
        address = txtaddress.getText().toString();
        contact = txtcontactNo.getText().toString();
        person_name = txtcontact1.getText().toString();
        contactNo = txtcontactNo.getText().toString();
        contact2 = txtcontact2.getText().toString();
        middle = txtMiddleName.getText().toString();
        Specialization = txtSpecialization.getText().toString();
        fatherOccup = txtfatherOccupation.getText().toString();
        motherOccup = txtmotherOccupation.getText().toString();
        relative = txtOtherRelatives.getText().toString();
        nativePlace = txtNative.getText().toString();
        city = txtcity.getText().toString();
        relation = txtRelation.getText().toString();
        rel_surname = txtcontactSurname.getText().toString();
        email = txtmailid.getText().toString().trim();


        // complexion = spinnerComplexion.getSelectedItem().toString();
        // ras_tithi = spinnerRashi.getSelectedItem().toString();
        religion = txtReligion.getText().toString();
        //  marital = spinnerMarital.getSelectedItem().toString();
        motherTongue = txtMotherTongue.getText().toString();
        kulDevta = txtKulDevta.getText().toString();
        occDetails = txtOccDetails.getText().toString();


        dbHelper.insertBiodata(userid,fullname,middle,surname,age,education,Specialization,occupation,occDetails,
                txtincomeCurrency.getText().toString(),txtincome.getText().toString(),city,dobdate,dobtime,dobplace,height,weight,blood,complexion,ras_tithi,
                fathername,fatherOccup,mothername,motherOccup,brothers,sisters,religion,marital,motherTongue,
                kulDevta,relative,address,nativePlace,hobbies,expectation,rel_surname,drinkingHabits,smokingHabits,diataryHabits,
                person_name,relation,contact,email,mgid,gender,mgname,image_str,URL,pHandicap,sCitizen);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GALLARY && resultCode == RESULT_OK &&
                data != null) {
            Uri uri = data.getData();
            Cursor cursor = MediaStore.Images.Media.query(getContentResolver(),
                    uri, new String[]{MediaStore.Images.Media.DATA});
            if (cursor != null && cursor.moveToFirst()) {
                switch (temp) {
                    case 0:
                        CameraFileAbsolutePath = cursor.getString(cursor.getColumnIndexOrThrow
                                (MediaStore.Images.Media.DATA));
                        photoUri = Uri.parse("file:" + CameraFileAbsolutePath);
                        break;
                    case 1:
                        CameraFileAbsolutePath1 = cursor.getString(cursor.getColumnIndexOrThrow
                                (MediaStore.Images.Media.DATA));

                        photoUri = Uri.parse("file:" + CameraFileAbsolutePath1);

                        break;
                    case 2:
                        CameraFileAbsolutePath2 = cursor.getString(cursor.getColumnIndexOrThrow
                                (MediaStore.Images.Media.DATA));
                        photoUri = Uri.parse("file:" + CameraFileAbsolutePath2);
                        break;
                }

            }
            if (photoUri != null) {

                File destimage = null;
                try {
                    destimage = Util.CreteFileWithUniqueName(ctx);
                } catch (IOException e) {
                    e.printStackTrace();
                }

                UCrop.of(photoUri, Uri.fromFile(destimage))
                        .withAspectRatio(10f, 10f)
                        .withMaxResultSize(1024, 1024)
                        .start(AddBiodata.this);
            }


        } else if (requestCode == CAMERA) {
            switch (temp) {
                case 0:
                    photoUri = Uri.parse("file:" + CameraFileAbsolutePath);
                    break;
                case 1:
                    photoUri = Uri.parse("file:" + CameraFileAbsolutePath1);
                    break;
                case 2:
                    photoUri = Uri.parse("file:" + CameraFileAbsolutePath2);
                    break;
            }
            if (photoUri != null) {

                File destimage = null;
                try {
                    destimage = Util.CreteFileWithUniqueName(ctx);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                UCrop.of(photoUri, Uri.fromFile(destimage))
                        .withAspectRatio(10f, 10f)
                        .withMaxResultSize(1024, 1024)
                        .start(AddBiodata.this);
            }

        } else if (resultCode == RESULT_OK && requestCode == UCrop.REQUEST_CROP) {
            final Uri resultUri = UCrop.getOutput(data);

            Log.e("CROP IMAGE PATH", resultUri.toString());

            Bitmap cursor = null;
            try {
                cursor = MediaStore.Images.Media.getBitmap(getContentResolver(),
                        resultUri);
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (temp == 0) {
                imgbridegroom.setImageBitmap(cursor);
            } else if (temp == 1) {
                imgbridegroomfull1.setImageBitmap(cursor);
            } else if (temp == 2) {
                imgbridegroomfull2.setImageBitmap(cursor);
            }

        }
    }

    //3 == photo (Face Bio-data
    //4 == full photo photo1
    //5 == full photo photo2
    private void UPloadImageToServer(final String bgid, final String msg, Integer type) {
//        String Pageurl = Common.GetWebServiceUrl() + "upload_image.php?bgid=" + bgid + "&type=" + type;
        String Pageurl = "https://mymarriagegroup.com/ws/upload_image.php?bgid=" + bgid + "&type=" + type;
        Log.e("trace pageurl", Pageurl);
        JSONObject object = new JSONObject();
        String myimage = "";
        if (imgbridegroom.getDrawable() != null) {
            try {
                switch (type) {
                    case 3:
                        BitmapDrawable image = (BitmapDrawable) imgbridegroom.getDrawable();
                        Bitmap ImageCompresser = image.getBitmap();
                        ByteArrayOutputStream ba = new ByteArrayOutputStream();
                        ImageCompresser.compress(Bitmap.CompressFormat.JPEG, 100, ba);
                        myimage = Base64.encodeToString(ba.toByteArray(), Base64.DEFAULT);
                        break;
                    case 4:
                        if (imgbridegroomfull1.getDrawable() != null) {
                            BitmapDrawable image1 = (BitmapDrawable) imgbridegroomfull1.getDrawable();
                            Bitmap ImageCompresser1 = image1.getBitmap();
                            ByteArrayOutputStream ba1 = new ByteArrayOutputStream();
                            ImageCompresser1.compress(Bitmap.CompressFormat.JPEG, 100, ba1);
                            myimage = Base64.encodeToString(ba1.toByteArray(), Base64.DEFAULT);
                        }
                        break;

                    case 5:
                        if (imgbridegroomfull2.getDrawable() != null) {
                            BitmapDrawable image2 = (BitmapDrawable) imgbridegroomfull2.getDrawable();
                            Bitmap ImageCompresser2 = image2.getBitmap();
                            ByteArrayOutputStream ba2 = new ByteArrayOutputStream();
                            ImageCompresser2.compress(Bitmap.CompressFormat.JPEG, 100, ba2);
                            myimage = Base64.encodeToString(ba2.toByteArray(), Base64.DEFAULT);
                            break;
                        }

                }
                object.put("image", myimage);
            } catch (JSONException e) {
                Log.d("trace error", e.getMessage());
            }

            Log.e("trace object", object.toString());
            final JsonObjectRequest request = new JsonObjectRequest(Pageurl, object, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject result) {
                    Log.d("trace result", result.toString());
                    try {
                        if (result.getString("error").equals("no")) {
                            //   Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show();
                        } else {
                            // Toast.makeText(ctx, result.getString("message"), Toast.LENGTH_LONG).show();

                        }
                        hidePDialog();
                    } catch (JSONException e) {
                        Log.d("trace error", "upload error" + e.getMessage());
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError e) {
                    Log.d("trace error", "upload error" + e.getMessage());
                }
            });
            request.setRetryPolicy(new DefaultRetryPolicy(100000, 5, 5));
            AppController.getInstance().addToRequestQueue(request);
        } else {
            Toast.makeText(ctx, "Photos required", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mExecutorService.shutdown();
        mExecutorService = null;
        imageCompressTask = null;
    }

    public void setupToolbar() {
        toolbar = getSupportActionBar();
        assert toolbar != null;
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (android.R.id.home == item.getItemId()) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
        @Override
        public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {
            Log.d(TAG, "onVerificationCompleted");
            dialogsending.dismiss();

            linResend.setVisibility(View.GONE);
            isMobileVerified = true;
            txtcontactNo.setEnabled(false);
            Toast.makeText(ctx, "Mobile verification successful", Toast.LENGTH_LONG).show();
            txtcontactNo.setCompoundDrawables(null, null, getResources().getDrawable(R.drawable.ic_done_green), null);
            etAddOTP.setEnabled(false);

            LinAddOTP.setVisibility(View.GONE);
            btngroupnext1.setVisibility(View.VISIBLE);
            if (is_premium_flag) {
                if (Utils.getString(ctx, Constants.USER_IS_FIRST_PROFILE_UPLOADED).equals("1")) {
                    btngroupnext1.setText("Proceed to Pay");
                    lblText.setVisibility(View.VISIBLE);
                } else {
                    btngroupnext1.setText("Publish Biodata");
                    lblText.setVisibility(View.GONE);
                }
            }else {
                lblText.setVisibility(View.VISIBLE);


                if (rbtnYes.isChecked()) {
                    btngroupnext1.setText("Proceed to Pay");
                }
                if (rbtnNo.isChecked()) {
                    btngroupnext1.setText("Send bio-data to publish");
                }
            }
        }

        @Override
        public void onVerificationFailed(FirebaseException e) {
            Log.d(TAG, "onVerificationFailed  : " + e.getMessage());
            Toast.makeText(ctx, "OTP invalid", Toast.LENGTH_LONG).show();
            dialogsending.dismiss();
        }

        @Override
        public void onCodeSent(String code, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
            super.onCodeSent(code, forceResendingToken);
            CodeSend = code;
            LinAddOTP.setVisibility(View.VISIBLE);
            btnsendotp.setVisibility(View.GONE);
            dialogsending.dismiss();
            Toast.makeText(ctx, "OTP will be sent on this number", Toast.LENGTH_LONG).show();
            Log.d(TAG, "onCodeSent  : " + code);
        }
    };

    // App Demo : https://github.com/razorpay/razorpay-android-sample-app
    // Activity must be implements by PaymentResultListener
    // Add Jar Lib in Project -> App -> lib
    // Add Checkout.preload(ctx); in OnCreate Method
    // Payment Getway Methods (override)......
    //Live detail in AndroidManifest.xml Meta below
    // <meta-data
    //  android:name="com.razorpay.ApiKey"
    //  android:value="YOUR  :  KEY_ID" />
    //  Test Credit Card No : 4111 1111 1111 1111
    //  https://razorpay.com/docs/payment-gateway/test-card-details/
    // If you want RS 5 Payment Then You have to add 500 In short INR * 100

    public void startPayment(String amount) {
        Checkout.preload(getApplicationContext());
        final Activity activity = this;
        String amount_ = String.valueOf(Integer.parseInt(amount) * 100*75);
        final Checkout co = new Checkout();
        co.setKeyID("rzp_live_rqh0DabOcTj5iZ");
        try {
            JSONObject options = new JSONObject();
            options.put("name", "" + Utils.getString(ctx, Constants.USER_NAME));
            options.put("description", "Add Bio Data Charge");
            //You can omit the image option to fetch the image from dashboard
            options.put("image", "");
            options.put("currency", "INR");
            options.put("amount", amount_);

            JSONObject preFill = new JSONObject();
            preFill.put("email", "" + Utils.getString(ctx, Constants.USER_EMAIL));
            preFill.put("contact", "" + Utils.getString(ctx, Constants.USER_MOBILE));

            options.put("prefill", preFill);

            co.open(activity, options);
        } catch (Exception e) {
            Toast.makeText(activity, "Error in payment: " + e.getMessage(), Toast.LENGTH_SHORT)
                    .show();
            e.printStackTrace();
        }
    }

    /**
     * The name of the function has to be
     * onPaymentSuccess
     * Wrap your code in try catch, as shown, to ensure that this method runs correctly
     */
    @SuppressWarnings("unused")
    @Override
    public void onPaymentSuccess(String razorpayPaymentID) {
        try {
            Toast.makeText(this, "Payment Successful: " + razorpayPaymentID, Toast.LENGTH_SHORT).show();
            addBiodata(razorpayPaymentID, true);
        } catch (Exception e) {
            Utils.log(TAG, "Exception in onPaymentSuccess : " + e.getMessage());
        }
    }

    /**
     * The name of the function has to be
     * onPaymentError
     * Wrap your code in try catch, as shown, to ensure that this method runs correctly
     */
    @SuppressWarnings("unused")
    @Override
    public void onPaymentError(int code, String response) {
        try {
            Toast.makeText(this, "Payment failed: " + code + " " + response, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Utils.log(TAG, "Exception in onPaymentError : " + e.getMessage());
        }
    }
}