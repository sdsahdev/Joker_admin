package com.suguretaventure.mymarriagegroup;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.suguretaventure.mymarriagegroup.Model.AddGroupModel;
import com.suguretaventure.mymarriagegroup.imageresize.core.ImageCompressTask;
import com.suguretaventure.mymarriagegroup.imageresize.listeners.IImageCompressTaskListener;
import com.suguretaventure.mymarriagegroup.imageresize.util.Util;
import com.suguretaventure.mymarriagegroup.utils.Utility;
import com.suguretaventure.mymarriagegroup.utils.Utils;
import com.suguretaventure.mymarriagegroup.utils.WebServiceCaller;
import com.yalantis.ucrop.UCrop;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;

public class UpdateGroupActivity extends AppCompatActivity {
    private static final int GALLARY = 1;
    private static final int CAMERA = 2;
    private static final int REQUEST_MULTIPLE_PERMISSION = 100;
    AlertDialog aldialog;
    private Context context = this;
    private String TAG = "UPDATE_GROUP";
    private EditText etTitle;
    private TextView btn_update_grp;
    private ImageView imgGroup, imgGroup_select;
    private String title, gid, URL, photo;
    private String CameraFileAbsolutePath;
    private ExecutorService mExecutorService = Executors.newFixedThreadPool(1);
    private ImageCompressTask imageCompressTask;
    private Bitmap image = null;
    private FirebaseAnalytics mFirebaseAnalytics;

    private Uri photoUri;
    private IImageCompressTaskListener iImageCompressTaskListener = new IImageCompressTaskListener() {
        @Override
        public void onComplete(List<File> compressed) {
            File file = compressed.get(0);
            Glide.with(context).load(file.getAbsoluteFile()).into(imgGroup);
            //imgGroup.setImageBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()));
        }

        @Override
        public void onError(Throwable error) {
            Utils.log(TAG, error.getMessage());
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_group);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        getSupportActionBar().setTitle(getResources().getString(R.string.app_name_title));
        allocateMemory();
        getData();
        setData();
        setListener();
    }

    private void setListener() {
        imgGroup_select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestPermission();
            }
        });
        btn_update_grp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (etTitle.getText().toString().length() == 0) {
                    etTitle.setError("Group Title required");
                } else {
                    UpdateGroup(etTitle.getText().toString(),photo ,gid , aldialog);
                }
            }
        });
    }

    private void setData() {
        etTitle.setText(title);
        if (!photo.equalsIgnoreCase("")) {
            Glide.with(context).load(URL + photo).into(imgGroup);
        }
    }

    private void getData() {
        title = getIntent().getStringExtra("title");
        gid = getIntent().getStringExtra("gid");
        URL = getIntent().getStringExtra("URL");
        photo = getIntent().getStringExtra("photo");
    }

    private void allocateMemory() {
        etTitle = findViewById(R.id.etTitle);
        imgGroup = findViewById(R.id.imgGroup);
        imgGroup_select = findViewById(R.id.imgGroup_select);
        btn_update_grp = findViewById(R.id.btn_update_grp);

    }

    private void requestPermission() {
        if (PackageManager.PERMISSION_GRANTED !=
                ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) ||
                PackageManager.PERMISSION_GRANTED != ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA)) {
            String[] PermissionList = {Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.CAMERA};
            if (ActivityCompat.shouldShowRequestPermissionRationale
                    ((Activity) context, Manifest.permission.WRITE_EXTERNAL_STORAGE) ||
                    ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, Manifest.permission.CAMERA)) {

                ActivityCompat.requestPermissions((Activity) context, PermissionList,
                        REQUEST_MULTIPLE_PERMISSION);
            } else {
                ActivityCompat.requestPermissions((Activity) context, PermissionList,
                        REQUEST_MULTIPLE_PERMISSION);
            }
        } else {
            showDialogBox();
        }
    }

    private void showDialogBox() {
        androidx.appcompat.app.AlertDialog.Builder b1 = new androidx.appcompat.app.AlertDialog.Builder(context);
        b1.setTitle("Select Photo");
        b1.setIcon(R.mipmap.logo1);
        b1.setMessage("I want to select photo");
        b1.setPositiveButton("Using CAMERA", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);


                File image = null;
                try {
                    image = Util.CreteFileWithUniqueName(context);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                CameraFileAbsolutePath = image.getAbsolutePath();

                Uri photoURI = FileProvider.getUriForFile(context,
                        BuildConfig.APPLICATION_ID + ".provider", image);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(intent, CAMERA);
            }
        });
        b1.setNegativeButton("using Gallery", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent = new Intent(Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, GALLARY);
            }
        });

        b1.create().show();
    }

    private void UpdateGroup(final String title, String photo, String id, final AlertDialog aldialog) {

        if (!Utility.isNetworkAvailable(context)) {
            /*Snackbar.make(rcvgrp, "Internet connection is not available", Snackbar.LENGTH_INDEFINITE).setAction("RETRY", new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    createNewGroup(gtitle, aldialog);
                }
            }).setActionTextColor(getResources().getColor(R.color.colorPrimary)).show();*/
        } else {
            final ProgressDialog progressDialog = new ProgressDialog(context);
            progressDialog.setTitle("Please wait...");
            progressDialog.show();
            progressDialog.setCancelable(false);
            RequestBody fileReqBody, fileReqBody1;
            int compressionRatio = 2; //1 == originalImage, 2 = 50% compression, 4=25% compress
            MultipartBody.Part part;
            if (CameraFileAbsolutePath != null) {
                File file = new File(CameraFileAbsolutePath);
                try {
                    Bitmap bitmap = BitmapFactory.decodeFile(file.getPath());
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, new FileOutputStream(file));
                } catch (Throwable t) {
                    Log.e("ERROR", "Error compressing file." + t.toString());
                    t.printStackTrace();
                }
                // Create a request body with file and image media type
             fileReqBody = RequestBody.create(MediaType.parse("image/*"), file);
                part = MultipartBody.Part.createFormData("image", file.getName(), fileReqBody);
            } else {
                part = MultipartBody.Part.createFormData("image", "");
            }
            // Create MultipartBody.Part using file request-body,file name and part name
            //Create request body with text description and text media type
            RequestBody description1 = RequestBody.create(MediaType.parse("text/plain"), gid);
            RequestBody description2 = RequestBody.create(MediaType.parse("text/plain"), title);
            RequestBody description3 = RequestBody.create(MediaType.parse("text/plain"), photo);
            WebServiceCaller.getClient().updateGroupModelCall(part, description1, description2, description3).enqueue(new Callback<AddGroupModel>() {
                @Override
                public void onResponse(Call<AddGroupModel> call, retrofit2.Response<AddGroupModel> response) {
                    Utils.log(TAG, response.toString());
                    if (response.isSuccessful()) {
                        CameraFileAbsolutePath = null;
                        Toast.makeText(context, response.body().getMsg(), Toast.LENGTH_LONG).show();
                        UpdateGroupActivity.super.onBackPressed();
                    } else {
                        Toast.makeText(context, "Error api", Toast.LENGTH_LONG).show();
                    }
                    progressDialog.dismiss();
                }

                @Override
                public void onFailure(Call<AddGroupModel> call, Throwable t) {
                    //swipeContainer.setRefreshing(false)
                    //
                    progressDialog.dismiss();
                    Toast.makeText(context, "Server Error", Toast.LENGTH_LONG).show();
                    Utils.log(TAG, t.getMessage());
                }
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GALLARY && resultCode == RESULT_OK &&
                data != null) {
            Uri uri = data.getData();
            Cursor cursor = MediaStore.Images.Media.query(getContentResolver(),
                    uri, new String[]{MediaStore.Images.Media.DATA});
            if (cursor != null && cursor.moveToFirst()) {
                CameraFileAbsolutePath = cursor.getString(cursor.getColumnIndexOrThrow
                        (MediaStore.Images.Media.DATA));

                photoUri = Uri.parse("file:"+CameraFileAbsolutePath);

                if (photoUri!=null){
                    File destimage = null;
                    try {
                        destimage = Util.CreteFileWithUniqueName(this);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    UCrop.of(photoUri, Uri.fromFile(destimage))
                            .withAspectRatio(10f, 10f)
                            .withMaxResultSize(1024, 1024)
                            .start(UpdateGroupActivity.this);
                }
               /* imageCompressTask = new ImageCompressTask(this, CameraFileAbsolutePath,
                        iImageCompressTaskListener);
                mExecutorService.execute(imageCompressTask);
                Bitmap bmp = BitmapFactory.decodeFile(CameraFileAbsolutePath);
                imgGroup.setImageBitmap(bmp);*/
            }

        } else if (requestCode == CAMERA) {

            photoUri = Uri.parse("file:"+CameraFileAbsolutePath);
            File destimage = null;
            try {
                destimage = Util.CreteFileWithUniqueName(this);
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (photoUri!=null){
                UCrop.of(photoUri, Uri.fromFile(destimage))
                        .withAspectRatio(10f, 10f)
                        .withMaxResultSize(1024, 1024)
                        .start(UpdateGroupActivity.this);
            }
            /*File imgFile = new File(CameraFileAbsolutePath);
            if (imgFile.exists()) {
                imgGroup.setImageBitmap(image);
                imageCompressTask = new ImageCompressTask(this, CameraFileAbsolutePath,
                        iImageCompressTaskListener);
                mExecutorService.execute(imageCompressTask);
                Bitmap bmp = BitmapFactory.decodeFile(CameraFileAbsolutePath);
                imgGroup.setImageBitmap(bmp);
            }*/
        }else if (resultCode == RESULT_OK && requestCode == UCrop.REQUEST_CROP) {
            final Uri resultUri = UCrop.getOutput(data);

            Log.e("CROP IMAGE PATH", resultUri.toString());

            Bitmap cursor = null;
            try {
                cursor = MediaStore.Images.Media.getBitmap(getContentResolver(),
                        resultUri);
            } catch (IOException e) {
                e.printStackTrace();
            }
            imgGroup.setImageBitmap(cursor);

        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
