package com.suguretaventure.mymarriagegroup;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.crystal.crystalrangeseekbar.interfaces.OnRangeSeekbarChangeListener;
import com.crystal.crystalrangeseekbar.widgets.CrystalRangeSeekbar;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.razorpay.Checkout;
import com.suguretaventure.mymarriagegroup.adapters.PersonAdapter;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.common.NetworkConnetionState;
import com.suguretaventure.mymarriagegroup.getsets.PersonGetSet;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;


public class MyPosts extends AppCompatActivity {
    private Context ctx = this;
    private RecyclerView rcvpersonlist;
    private TextView lblgroupoccu, lblempty_biodata, lbl_nodata,txtGenderTitle,filterTv;
    private ArrayList<PersonGetSet> arr_adapter = new ArrayList<>();
    private LinearLayout lay_search;
    private PersonAdapter personAdapter;
    private PersonGetSet personGetSet;
    private ProgressDialog pDialog;
    private EditText txt_search_pname;
    private String RidFrom, Rid;
    //    ActionBar toolbar;
    Toolbar toolbar_top;
    String verified;
    private ImageView imgGenderBack;

    public static boolean onBackPressFlag = false;
    private FirebaseAnalytics mFirebaseAnalytics;


    @Override
    protected void onResume() {
        super.onResume();
        if (onBackPressFlag){
            getMyPosts();
            onBackPressFlag = false;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_person_list);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        getSupportActionBar().setTitle(getResources().getString(R.string.app_name_title));
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        allocateMemory();
        setListener();
        lbl_nodata.setText(Html.fromHtml(Constants.Post_MESSAGE));

        if (new NetworkConnetionState().isNetworkAvailable(ctx)) {
            getMyPosts();
        } else {
            networkAlert();
        }
    }

    private void setListener() {
        filterTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Toast.makeText(PersonList.this, "Toast", Toast.LENGTH_SHORT).show();
                final Dialog alertDialog = new Dialog(MyPosts.this);
                alertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                LayoutInflater inflater = getLayoutInflater();
                View alert = inflater.inflate(R.layout.dialog_filter_list, null, false);
                alertDialog.setContentView(alert);
                final TextView minAge =  alertDialog.findViewById(R.id.min_Age);
                final TextView maxAge = alertDialog.findViewById(R.id.max_age);
                final Button saveBtn = alertDialog.findViewById(R.id.save_btn);
                final CrystalRangeSeekbar seekbar_age = alertDialog.findViewById(R.id.seekBar_Age);

                seekbar_age.setOnRangeSeekbarChangeListener(new OnRangeSeekbarChangeListener() {
                    @SuppressLint("SetTextI18n")
                    @Override
                    public void valueChanged(Number minValue, Number maxValue) {
                        maxAge.setVisibility(View.VISIBLE);
                        maxAge.setText(String.valueOf(maxValue));
                        minAge.setText(String.valueOf(minValue));
                    }
                });


                saveBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        customFilter(seekbar_age.getSelectedMinValue().intValue(),seekbar_age.getSelectedMaxValue().intValue());
                        alertDialog.dismiss();
                    }
                });
                alertDialog.show();
            }
        });
    }

    private void customFilter(int minAge, int maxAge) {
        ArrayList<PersonGetSet> temp = new ArrayList();
        for (PersonGetSet d : arr_adapter) {
            //or use .equal(text) with you want equal match
            //use .toLowerCase() for better matches
            Log.d("TAG", "customFilter: "+d.getAge()+"\n");
            final int age=Integer.parseInt(d.getAge());
            if (age>=minAge && age<=maxAge){
                temp.add(d);
            }
        }

        //update recyclerview
        if (!temp.isEmpty())
            personAdapter.updateList(temp);
    }

    private void networkAlert() {
        AlertDialog.Builder b1 = new AlertDialog.Builder(ctx);
        b1.setTitle("Network Error");
        b1.setMessage("No internet connection found. Please check your phone settings to turn on the internet.");
        b1.setPositiveButton("Retry", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (new NetworkConnetionState().isNetworkAvailable(ctx)) {
                    getMyPosts();
                } else {
                    networkAlert();
                }
            }
        });
        b1.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        b1.create().show();
    }

    public void allocateMemory() {
        rcvpersonlist = findViewById(R.id.rcvpersonlist);
        lblgroupoccu = findViewById(R.id.lblgroupoccu);
        lblempty_biodata = findViewById(R.id.lblempty_biodata);
        lbl_nodata = findViewById(R.id.lbl_nodata);
        txt_search_pname = findViewById(R.id.txt_search_pname);
        lay_search = findViewById(R.id.lay_search);
        toolbar_top = findViewById(R.id.toolbar_top);
        imgGenderBack = findViewById(R.id.imgGenderBack);
        txtGenderTitle = findViewById(R.id.txtGenderTitle);
        txtGenderTitle.setText(getResources().getString(R.string.app_name_title));
        toolbar_top = findViewById(R.id.toolbar_top);
        imgGenderBack = findViewById(R.id.imgGenderBack);
        filterTv = findViewById(R.id.filter_tv);

        setSupportActionBar(toolbar_top);
        imgGenderBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

//        imgGenderBack.setVisibility(View.GONE);
        RidFrom = getIntent().getExtras().getString("from");
        if (RidFrom.equals("group")) {
            lay_search.setVisibility(View.GONE);
            lblgroupoccu.setText("Group Member Posts");
            Rid = getIntent().getExtras().getString("Rid");
        } else {
            lay_search.setVisibility(View.VISIBLE);
            lblgroupoccu.setText("My Biodatas");
            Rid = "" + Utils.getString(ctx, Constants.USER_ID);

            AdView adViewGender = findViewById(R.id.adViewPersonList);
            AdRequest adRequest = new AdRequest.Builder().build();
            adViewGender.loadAd(adRequest);

        }

        txt_search_pname.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (txt_search_pname.getText().toString().equalsIgnoreCase("")) {
                    if (!arr_adapter.isEmpty())
                        personAdapter.updateList(arr_adapter);
                } else {
                    filter(txt_search_pname.getText().toString());
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

    }

    public void getMyPosts() {
        pDialog = new ProgressDialog(ctx);
        pDialog.setMessage("Please wait...");
        pDialog.setCancelable(false);
        showpDialog();
        String WebServiceUrl = Common.GetWebServiceUrl() + "person_list.php";

        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("rid", Rid);
        params.put("gender", "-1");
        if (getIntent().getStringExtra("from").equals("dashboard")){
            params.put("gid",getIntent().getStringExtra("mgid"));
        }
        client.post(WebServiceUrl, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                Log.d("trace response", res);
                try {
                    JSONArray response = new JSONArray(res);
                    String error = response.getJSONObject(0).getString("error");
                    if (error.equals("no error") == false) {
                        Common.showDialog(ctx);
                    } else {
                        arr_adapter.clear();
                        int total = response.getJSONObject(1).getInt("total");
                        if (total == 0) {
                            rcvpersonlist.setVisibility(View.GONE);
                            lblempty_biodata.setVisibility(View.VISIBLE);
                            lbl_nodata.setVisibility(View.VISIBLE);
                        } else {
                            lblempty_biodata.setVisibility(View.GONE);
                            lbl_nodata.setVisibility(View.GONE);
                            int size = response.length();
                            for (int i = 2; i < size; i++) //3
                            {
                                JSONObject object = response.getJSONObject(i);
                                personGetSet = new PersonGetSet();
                                personGetSet.setId(object.getString("id"));
                                personGetSet.setName(object.getString("name"));
                                personGetSet.setAge(object.getString("age"));
                                personGetSet.setEducation(object.getString("edu"));
                                personGetSet.setOccupation(object.getString("occu"));
                                personGetSet.setImage(object.getString("photo"));
                                personGetSet.setVerified(object.getString("verified"));
                                personGetSet.setGender(object.getString("gen"));
                                personGetSet.setPay_date(object.getString("pay_date"));
                                personGetSet.setRid_name(object.getString("rid_name"));
                                personGetSet.setIs_premium(object.getString("is_premium"));
                                setAdapter();

                                arr_adapter.add(personGetSet);
                            }
                            hidePDialog();
                        }
                        hidePDialog();
                    }
                    hidePDialog();

                } catch (JSONException e) {
                    hidePDialog();
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

            }
        });
    }

    void setAdapter(){
        personAdapter = new PersonAdapter(ctx, arr_adapter, RidFrom,0,true);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        rcvpersonlist.setLayoutManager(mLayoutManager);
        rcvpersonlist.setAdapter(personAdapter);
    }

    void filter(String text) {
        ArrayList<PersonGetSet> temp = new ArrayList();
        for (PersonGetSet d : arr_adapter) {
            //or use .equal(text) with you want equal match
            //use .toLowerCase() for better matches
            if (d.getCity() !=null) {
                if (d.getName().toLowerCase().contains(text.toLowerCase()) || d.getCity().toLowerCase().contains(text.toLowerCase())) {
                    temp.add(d);
                }
            }else {
                if (d.getName().toLowerCase().contains(text.toLowerCase())) {
                    temp.add(d);
                }
            }
        }
        //update recyclerview
        if (!temp.isEmpty())
            personAdapter.updateList(temp);
    }

    // show process Dialog box
    private void showpDialog() {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }

    // hide process Dialog box
    private void hidePDialog() {
        if (this.pDialog != null) {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_posts, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        int id = item.getItemId();
        if(id == R.id.dashboard){
            startActivity(new Intent(ctx, Dashboard.class));
        }else if (id == R.id.myGroup) {
            startActivity(new Intent(ctx, MyGroup.class));
        }  else if (id == R.id.myDrafts) {
            startActivity(new Intent(ctx, MyDrafts.class));
        } else if (id == R.id.myPost) {
            startActivity(new Intent(ctx, MyPosts.class)
                    .putExtra("from", "dashboard")
                    .putExtra("gender", "-1"));
        } else if (id == R.id.myFev) {
            startActivity(new Intent(ctx, MyFav_Arc.class)
                    .putExtra("from", "dashboard_fav"));
        } else if (id == R.id.myArchive) {
            startActivity(new Intent(ctx, MyFav_Arc.class)
                    .putExtra("from", "dashboard_arc"));
        }else if (id == R.id.myMarketing) {
            startActivity(new Intent(ctx, MyMarketActivity.class));
        }
        return super.onOptionsItemSelected(item);
    }

}
