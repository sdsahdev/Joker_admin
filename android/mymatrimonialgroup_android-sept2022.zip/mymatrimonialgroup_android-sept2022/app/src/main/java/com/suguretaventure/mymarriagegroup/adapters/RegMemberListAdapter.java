package com.suguretaventure.mymarriagegroup.adapters;

import android.app.ProgressDialog;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.suguretaventure.mymarriagegroup.R;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.getsets.MyGrpRegListGetSet;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;

/**
 * Created by ankitpatel on 23/02/19.
 */

public class RegMemberListAdapter extends RecyclerView.Adapter<RegMemberListAdapter.MyViewHolder>
{
    private Context context;
    private LayoutInflater inflater;
    ArrayList<MyGrpRegListGetSet> arr_adapter;
    private ProgressDialog pDialog;
    private String gid;

    public RegMemberListAdapter(Context context, ArrayList<MyGrpRegListGetSet> arr_adapter,String gid)
    {
        this.context = context;
        this.arr_adapter = arr_adapter;
        this.gid = gid;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_member, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int i) {
        holder.lblmember_name.setText(arr_adapter.get(i).getFullname());
        holder.lblmember_mo.setText(arr_adapter.get(i).getMobile());

        Glide.with(context)
                .load(Common.GetRegUserIDImageUrl()+arr_adapter.get(i).getPhoto())
                .apply(RequestOptions.circleCropTransform())
                .into(holder.img_new_member);

        holder.add_this_member.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addMember(arr_adapter.get(i).getRid(),i);
            }
        });
    }

    private void addMember(final String rid,final int position)
    {
        pDialog = new ProgressDialog(context);
        pDialog.setMessage("Please wait...");
        pDialog.setCancelable(false);
        //showpDialog();

        String WebServiceUrl = Common.GetWebServiceUrl() + "add_new_member.php";
        Log.e("trace url",WebServiceUrl);
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("rid",""+rid);
        params.put("gid",""+gid);
        client.post(WebServiceUrl, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                try
                {
                    JSONArray response = new JSONArray(res);
                    String error = response.getJSONObject(0).getString("error");
                    if(error.equals("no error")==false)
                    {
                        Common.showDialog(context,error);
                    }
                    else
                    {
                        String success = response.getJSONObject(1).getString("success");
                        if(success.equals("yes")==true)
                        {
                            arr_adapter.remove(position);
                            notifyDataSetChanged();
                        }
                        String msg = response.getJSONObject(2).getString("message");
                        Toast.makeText(context, msg, Toast.LENGTH_LONG).show();
                    }
                } catch (JSONException e) {
                    Common.showDialog(context,e.toString());
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Common.showDialog(context,error.toString());
            }
        });
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView lblmember_name,lblmember_mo,add_this_member;
        public ImageView img_new_member;

        public MyViewHolder(View view) {
            super(view);
            add_this_member = view.findViewById(R.id.add_this_member);
            lblmember_name = view.findViewById(R.id.lblmember_name);
            lblmember_mo = view.findViewById(R.id.lblmember_mo);
            img_new_member = view.findViewById(R.id.img_new_member);
        }
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return arr_adapter.size();
    }
}
