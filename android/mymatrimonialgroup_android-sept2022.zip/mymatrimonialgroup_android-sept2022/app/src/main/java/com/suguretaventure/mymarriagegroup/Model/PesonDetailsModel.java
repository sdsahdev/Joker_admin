package com.suguretaventure.mymarriagegroup.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class PesonDetailsModel {
    @SerializedName("detail")
    @Expose
    private List<Detail> detail = null;
    @SerializedName("success")
    @Expose
    private Boolean success;
    @SerializedName("message")
    @Expose
    private String message;

    public List<Detail> getDetail() {
        return detail;
    }

    public void setDetail(List<Detail> detail) {
        this.detail = detail;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    public class Detail {

        @SerializedName("id")
        @Expose
        private String id;
        @SerializedName("register_userid")
        @Expose
        private String registerUserid;
        @SerializedName("name")
        @Expose
        private String name;
        @SerializedName("surname")
        @Expose
        private String surname;
        @SerializedName("gender")
        @Expose
        private String gender;
        @SerializedName("education")
        @Expose
        private String education;
        @SerializedName("occupationid")
        @Expose
        private String occupationid;
        @SerializedName("income")
        @Expose
        private String income;
        @SerializedName("height")
        @Expose
        private String height;
        @SerializedName("weight")
        @Expose
        private String weight;
        @SerializedName("blood")
        @Expose
        private String blood;
        @SerializedName("birthdate")
        @Expose
        private String birthdate;
        @SerializedName("birthtime")
        @Expose
        private String birthtime;
        @SerializedName("birthplace")
        @Expose
        private String birthplace;
        @SerializedName("hobbies")
        @Expose
        private String hobbies;
        @SerializedName("expectation")
        @Expose
        private String expectation;
        @SerializedName("photo")
        @Expose
        private String photo;
        @SerializedName("fathername")
        @Expose
        private String fathername;
        @SerializedName("mothername")
        @Expose
        private String mothername;
        @SerializedName("brothers")
        @Expose
        private String brothers;
        @SerializedName("sisters")
        @Expose
        private String sisters;
        @SerializedName("address")
        @Expose
        private String address;
        @SerializedName("contact")
        @Expose
        private String contact;
        @SerializedName("contact2")
        @Expose
        private String contact2;
        @SerializedName("email")
        @Expose
        private String email;
        @SerializedName("datatime")
        @Expose
        private String datatime;
        @SerializedName("saved")
        @Expose
        private String saved;
        @SerializedName("verified")
        @Expose
        private String verified;
        @SerializedName("latitude")
        @Expose
        private String latitude;
        @SerializedName("longitude")
        @Expose
        private String longitude;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getRegisterUserid() {
            return registerUserid;
        }

        public void setRegisterUserid(String registerUserid) {
            this.registerUserid = registerUserid;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getSurname() {
            return surname;
        }

        public void setSurname(String surname) {
            this.surname = surname;
        }

        public String getGender() {
            return gender;
        }

        public void setGender(String gender) {
            this.gender = gender;
        }

        public String getEducation() {
            return education;
        }

        public void setEducation(String education) {
            this.education = education;
        }

        public String getOccupationid() {
            return occupationid;
        }

        public void setOccupationid(String occupationid) {
            this.occupationid = occupationid;
        }

        public String getIncome() {
            return income;
        }

        public void setIncome(String income) {
            this.income = income;
        }

        public String getHeight() {
            return height;
        }

        public void setHeight(String height) {
            this.height = height;
        }

        public String getWeight() {
            return weight;
        }

        public void setWeight(String weight) {
            this.weight = weight;
        }

        public String getBlood() {
            return blood;
        }

        public void setBlood(String blood) {
            this.blood = blood;
        }

        public String getBirthdate() {
            return birthdate;
        }

        public void setBirthdate(String birthdate) {
            this.birthdate = birthdate;
        }

        public String getBirthtime() {
            return birthtime;
        }

        public void setBirthtime(String birthtime) {
            this.birthtime = birthtime;
        }

        public String getBirthplace() {
            return birthplace;
        }

        public void setBirthplace(String birthplace) {
            this.birthplace = birthplace;
        }

        public String getHobbies() {
            return hobbies;
        }

        public void setHobbies(String hobbies) {
            this.hobbies = hobbies;
        }

        public String getExpectation() {
            return expectation;
        }

        public void setExpectation(String expectation) {
            this.expectation = expectation;
        }

        public String getPhoto() {
            return photo;
        }

        public void setPhoto(String photo) {
            this.photo = photo;
        }

        public String getFathername() {
            return fathername;
        }

        public void setFathername(String fathername) {
            this.fathername = fathername;
        }

        public String getMothername() {
            return mothername;
        }

        public void setMothername(String mothername) {
            this.mothername = mothername;
        }

        public String getBrothers() {
            return brothers;
        }

        public void setBrothers(String brothers) {
            this.brothers = brothers;
        }

        public String getSisters() {
            return sisters;
        }

        public void setSisters(String sisters) {
            this.sisters = sisters;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getContact() {
            return contact;
        }

        public void setContact(String contact) {
            this.contact = contact;
        }

        public String getContact2() {
            return contact2;
        }

        public void setContact2(String contact2) {
            this.contact2 = contact2;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getDatatime() {
            return datatime;
        }

        public void setDatatime(String datatime) {
            this.datatime = datatime;
        }

        public String getSaved() {
            return saved;
        }

        public void setSaved(String saved) {
            this.saved = saved;
        }

        public String getVerified() {
            return verified;
        }

        public void setVerified(String verified) {
            this.verified = verified;
        }

        public String getLatitude() {
            return latitude;
        }

        public void setLatitude(String latitude) {
            this.latitude = latitude;
        }

        public String getLongitude() {
            return longitude;
        }

        public void setLongitude(String longitude) {
            this.longitude = longitude;
        }

    }
}
