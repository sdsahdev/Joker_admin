package com.suguretaventure.mymarriagegroup.Model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

public class MarketingListModel implements Serializable {

    @SerializedName("marketing")
    public ArrayList<DATA> data;

    public class DATA implements Serializable {
        @SerializedName("id")
        public String id;

        @SerializedName("cid")
        public String cid;

        @SerializedName("cname")
        public String cname;

        @SerializedName("website")
        public String website;

        @SerializedName("pay_status")
        public String pay_status;

        @SerializedName("name")
        public String name;

        @SerializedName("address")
        public String address;

        @SerializedName("mobile")
        public String mobile;

        @SerializedName("email")
        public String email;

        @SerializedName("image")
        public String image;
        @SerializedName("image1")
        public String image1;
        @SerializedName("image2")
        public String image2;

        @SerializedName("photo")
        public String photo;

        @SerializedName("photo1")
        public String photo1;


        @SerializedName("photo2")
        public String photo2;

        @SerializedName("city")
        public String city;

        @SerializedName("description")
        public String description;

        @SerializedName("lat")
        public String lat;

        @SerializedName("lon")
        public String lon;
    }
}
