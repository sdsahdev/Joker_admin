package com.suguretaventure.mymarriagegroup.Model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

public class MemberData implements Serializable {

    @SerializedName("data")
    public ArrayList<member> members;

    public class member implements Serializable {
        @SerializedName("mobile")
        public String mobile;
    }
}
