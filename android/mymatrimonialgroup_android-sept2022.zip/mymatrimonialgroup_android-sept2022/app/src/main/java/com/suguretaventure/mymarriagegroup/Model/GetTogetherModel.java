package com.suguretaventure.mymarriagegroup.Model;

public class GetTogetherModel {
    private String id, gid, title, gdatetime, venue, register_userid;

    public GetTogetherModel(String id, String gid, String title, String gdatetime, String venue, String register_userid) {
        this.id = id;
        this.gid = gid;
        this.title = title;
        this.gdatetime = gdatetime;
        this.venue = venue;
        this.register_userid = register_userid;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getGid() {
        return gid;
    }

    public void setGid(String gid) {
        this.gid = gid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getGdatetime() {
        return gdatetime;
    }

    public void setGdatetime(String gdatetime) {
        this.gdatetime = gdatetime;
    }

    public String getVenue() {
        return venue;
    }

    public void setVenue(String venue) {
        this.venue = venue;
    }

    public String getRegister_userid() {
        return register_userid;
    }

    public void setRegister_userid(String register_userid) {
        this.register_userid = register_userid;
    }
}
/*
"id":"1","gid":"32","title":"Testing","gdatetime":"11-06-2019 05:08 AM","venue":"Detail","register_userid":"31"}*/
