package com.suguretaventure.mymarriagegroup;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import android.text.Html;
import android.text.util.Linkify;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utils;

public class FAQActivity extends AppCompatActivity {
    private String TAG = "FAQ_ACTIVITY";
    private Context context = this;
    private String FAQ = "Frequently Asked Questions (FAQ)";
    private String TERMS = "Terms & Privacy Policy";
    private TextView txtFaqDetail, myTitle, txtTermsFAQ;
    private String PAGE = "";
    private FirebaseAnalytics mFirebaseAnalytics;

    @RequiresApi(api = Build.VERSION_CODES.CUPCAKE)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faq);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(getResources().getString(R.string.app_name_title));
        allocateMemory();
        switch (PAGE) {
            case "FAQ":
                //myTitle.setText(FAQ);
                txtFaqDetail.setText(Html.fromHtml(Constants.STRING_FAQ));
                Linkify.addLinks(txtFaqDetail,Linkify.ALL);
                break;
            case "TERMS":
                // myTitle.setText(TERMS);
                txtFaqDetail.setText(Html.fromHtml(Constants.STRING_TERMS_PRIVACY));
                break;
        }

        setListener();
    }

    private void setListener() {
        txtTermsFAQ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(context, TermsActivity.class));
            }
        });
    }

    private void allocateMemory() {
        PAGE = getIntent().getStringExtra("PAGE");
        txtFaqDetail = findViewById(R.id.txtFaqDetail);
        //myTitle = findViewById(R.id.myTitle);
        txtTermsFAQ = findViewById(R.id.txtTermsFAQ);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_how_works, menu);
        return true;
    }

    public boolean onPrepareOptionsMenu(Menu menu)
    {
        MenuItem home = menu.findItem(R.id.dashboard);
        MenuItem Logout = menu.findItem(R.id.logout);
        MenuItem Login = menu.findItem(R.id.login);
        Log.d("Mobile_USER","Mobile :- "+ Utils.getString(context,Constants.USER_MOBILE));
        if(Utils.getString(context,Constants.USER_MOBILE).equals(""))
        {
            home.setVisible(false);
            Logout.setVisible(false);
            Login.setVisible(true);

        }
        else
        {
            home.setVisible(true);
            Logout.setVisible(true);
            Login.setVisible(false);

        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (android.R.id.home == item.getItemId()) {
            finish();
        }

        int id = item.getItemId();
        if(id == R.id.dashboard) {
            startActivity(new Intent(context, Dashboard.class));
        }else if (id == R.id.logout) {
            final AlertDialog alertDialog = new AlertDialog.Builder(context).create();
            alertDialog.setMessage("Do you want to Logout");
            alertDialog.setButton(DialogInterface.BUTTON_POSITIVE, "Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    String FCM_KEY = "" + Utils.getString(context, Constants.TOKEN);
                    Utils.clearPreference(context);
                    Utils.setString(context, Constants.TOKEN, FCM_KEY);
                    startActivity(new Intent(context, Login.class));
                    finish();
                }
            });
            alertDialog.setButton(DialogInterface.BUTTON_NEGATIVE, "Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    alertDialog.dismiss();
                }
            });
            alertDialog.show();
            finish();
            return true;
        }else if (id == R.id.login) {
            String FCM_KEY = "" + Utils.getString(context, Constants.TOKEN);
            Utils.setString(context, Constants.TOKEN, FCM_KEY);
            startActivity(new Intent(context, Login.class));
        }
        return super.onOptionsItemSelected(item);
    }
}
