package com.suguretaventure.mymarriagegroup.adapters;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.suguretaventure.mymarriagegroup.PersonDesc;
import com.suguretaventure.mymarriagegroup.R;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.getsets.PersonGetSet;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;

/**
 * Created by ankitpatel on 23/02/19.
 */

public class FavArcAdapter extends RecyclerView.Adapter<FavArcAdapter.MyViewHolder> {
    private String TAG = "FAV_ARC_ADAPTER";
    private Context context;
    private LayoutInflater inflater;
    ArrayList<PersonGetSet> arr_adapter;
    private String rid, pid, type, faid, fatype;
    private ProgressDialog pDialog;
    private int mnu;

    public FavArcAdapter(Context context, ArrayList<PersonGetSet> arr_adapter, String fatype) {
        this.context = context;
        this.arr_adapter = arr_adapter;
        this.fatype = fatype;
        rid = "" + Utils.getString(context, Constants.USER_ID);
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_fav_arc, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int i) {
        holder.lblpersonname.setText(arr_adapter.get(i).getName());
        holder.lblpersonedu.setText("Education: " + arr_adapter.get(i).getEducation());
        holder.lblpersonocu.setText("Occupation: " + arr_adapter.get(i).getOccupation());
        holder.lblpersonage.setText("Age: " + arr_adapter.get(i).getAge());

        Glide.with(context)
                .load(Common.GetProfileImageUrl() + arr_adapter.get(i).getImage())
                .apply(RequestOptions.circleCropTransform())
                .into(holder.imgperson);

        holder.lay_pdesc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                context.startActivity(new Intent(context, PersonDesc.class)
                        .putExtra("pid", arr_adapter.get(i).getId())
                );
            }
        });

        holder.imgperson.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                View dialogLayout = inflater.inflate(R.layout.personimage_dialog, null);
                ImageView imgtabledesc = (ImageView) dialogLayout.findViewById(R.id.imgtabledesc);
                builder.setView(dialogLayout);
                Glide.with(context)
                        .load(Common.GetProfileImageUrl() + arr_adapter.get(i).getImage())
                        .into(imgtabledesc);
                Dialog dialog = builder.create();
                dialog.setCancelable(true);
                dialog.show();
            }
        });

        holder.remove_fav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                removeFavArc(arr_adapter.get(i).getFaid(), 0, i);
            }
        });

        holder.remove_arc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                removeFavArc(arr_adapter.get(i).getFaid(), 1, i);
            }
        });
    }

    private void removeFavArc(final String faid, final int fatype, final int position) {
        pDialog = new ProgressDialog(context);
        pDialog.setMessage("Please wait...");
        pDialog.setCancelable(false);
        //showpDialog();
        String WebServiceUrl = Common.GetWebServiceUrl() + "remove_fav_arc.php";
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("faid", faid);
        Log.d("REMOVE_RESPONSE", WebServiceUrl+"?"+params);
        client.post(WebServiceUrl, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                Log.d("REMOVE_RESPONSE", res);
                try {
                    JSONArray response = new JSONArray(res);
                    String error = response.getJSONObject(0).getString("error");
                    if (!error.equals("no error")) {
                        hidePDialog();
                        Common.showDialog(context, error);
                    } else {
                        String success = response.getJSONObject(1).getString("success");
                        if (success.equals("yes")) {
                            hidePDialog();
                            arr_adapter.remove(position);
                            notifyDataSetChanged();
                            if (fatype == 0)
                                Toast.makeText(context, "Removed favourite", Toast.LENGTH_LONG).show();
                            else
                                Toast.makeText(context, "Removed Archive", Toast.LENGTH_LONG).show();
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

            }
        });
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        TextView lblpersonname, lblpersonedu, lblpersonage, lblpersonocu;
        ImageView imgperson, remove_arc, remove_fav;
        LinearLayout lay_pdesc;

        MyViewHolder(View view) {
            super(view);
            lay_pdesc = view.findViewById(R.id.lay_pdesc1);
            lblpersonname = view.findViewById(R.id.lblpersonname1);
            lblpersonedu = view.findViewById(R.id.lblpersonedu1);
            lblpersonage = view.findViewById(R.id.lblpersonage1);
            lblpersonocu = view.findViewById(R.id.lblpersonocu1);
            imgperson = view.findViewById(R.id.imgperson1);
            remove_arc = view.findViewById(R.id.remove_arc);
            remove_fav = view.findViewById(R.id.remove_fav);

            if (fatype.equals("0"))
                remove_arc.setVisibility(View.GONE);
            else
                remove_fav.setVisibility(View.GONE);
        }
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return arr_adapter.size();
    }

    // show process Dialog box
    private void showpDialog() {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }

    // hide process Dialog box
    private void hidePDialog() {
        if (this.pDialog != null) {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }

}
