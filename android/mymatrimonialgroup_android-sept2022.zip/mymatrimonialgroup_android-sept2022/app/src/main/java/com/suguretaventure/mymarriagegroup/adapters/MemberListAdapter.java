package com.suguretaventure.mymarriagegroup.adapters;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.suguretaventure.mymarriagegroup.InvitationReceived;
import com.suguretaventure.mymarriagegroup.MemberDetailsActivity;
import com.suguretaventure.mymarriagegroup.Model.BioData;
import com.suguretaventure.mymarriagegroup.PersonDesc;
import com.suguretaventure.mymarriagegroup.R;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.getsets.PersonGetSet;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utils;

import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;

/**
 * @Author: Vishal Gupta
 * @Date: 3/9/2022
 */
public class MemberListAdapter extends RecyclerView.Adapter<MemberListAdapter.MyViewHolder> {
    private Context context;

    private BioData data;
    private LayoutInflater inflater;
    private String groupId = "";


    public MemberListAdapter(Context context, BioData bioData, String groupId) {
        this.context = context;
        this.groupId = groupId;
        this.data = bioData;

    }

    @NonNull
    @Override
    public MemberListAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_invitation, parent, false);
        return new MemberListAdapter.MyViewHolder(itemView);
    }


    @Override
    public void onBindViewHolder(@NonNull final MemberListAdapter.MyViewHolder holder, final int i) {

            holder.lblStatus.setVisibility(View.GONE);
            holder.ivRemoveRequest.setVisibility(View.GONE);
            holder.btnViewBio.setVisibility(View.GONE);

        Glide.with(context)
                .load(Common.GetRegUserIDImageUrl() + data.detail.get(i).photo)
                .apply(RequestOptions.circleCropTransform())
                .into(holder.imgReqBio);
        Log.d("TAG", "onClick: "+"https://mymarriagegroup.com/jowbcsjfos/jnasdfjnjs/" + data.detail.get(i).photo);

        holder.lblPhone.setText(data.detail.get(i).mobile);
        holder.lblReqNameSur.setText(data.detail.get(i).name);
        holder.rlParent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, MemberDetailsActivity.class);
                intent.putExtra("memberDetail", data.detail.get(i));
                context.startActivity(intent);
            }
        });

        holder.imgReqBio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                View dialogLayout = inflater.inflate(R.layout.personimage_dialog, null);
                ImageView imgtabledesc = (ImageView) dialogLayout.findViewById(R.id.imgtabledesc);
                builder.setView(dialogLayout);
                Glide.with(context)
                        .load(Common.GetRegUserIDImageUrl() + data.detail.get(i).photo)
                        .placeholder(R.drawable.app_logo_new)
                        .into(imgtabledesc);
                Dialog dialog = builder.create();
                dialog.setCancelable(true);
                dialog.show();
            }
        });

        holder.btnReqAccept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String status = "1";
                String toast = "Request Accepted";
                String id = data.detail.get(i).req_id;
                setAction(status, toast, id, i);
            }
        });

        holder.btnReqReject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which){
                            case DialogInterface.BUTTON_POSITIVE:
                                String status = "2";
                                String id = data.detail.get(i).req_id;
                                String toast = "Request Rejected";
                                setAction(status, toast, id, i);
                                break;

                            case DialogInterface.BUTTON_NEGATIVE:
                                //No button clicked
                                break;
                        }
                    }
                };

                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setMessage("Do you want to reject invitation?").setPositiveButton("Yes", dialogClickListener)
                        .setNegativeButton("No", dialogClickListener).show();

            }
        });

       /* holder.ivRemoveRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(context);
                builder.setTitle("Alert!");
                builder.setMessage("Are you sure you want to remove?");
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String status = "0";
                        String id = data.detail.get(i).getId();
                        String toast = "Removed successfully.";
                        setAction(status, toast, id, i);
                    }
                });
                builder.show();


            }
        });*/
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView lblReqNameSur, lblPhone, btnReqAccept, btnReqReject, btnViewBio, lblStatus,from,to;
        public ImageView imgReqBio,ivRemoveRequest;
        public RelativeLayout rlParent;

        public MyViewHolder(View view) {
            super(view);
            imgReqBio = view.findViewById(R.id.imgReqBio);
            lblReqNameSur = view.findViewById(R.id.lblReqNameSur);
            lblPhone = view.findViewById(R.id.lblPhone);
            btnReqAccept = view.findViewById(R.id.btnReqAccept);
            btnReqReject = view.findViewById(R.id.btnReqReject);
            btnReqAccept.setVisibility(View.GONE);
            btnReqReject.setVisibility(View.GONE);
            lblStatus = view.findViewById(R.id.lblStatus);
            btnViewBio = view.findViewById(R.id.btnViewBio);
            rlParent = view.findViewById(R.id.rlParent);
            ivRemoveRequest = view.findViewById(R.id.ivRemoveRequest);
            from = view.findViewById(R.id.invitation_from);
            from.setVisibility(View.GONE);
            to = view.findViewById(R.id.invitation_to);
            to.setVisibility(View.GONE);


        }
    }

    @Override
    public int getItemCount() {
        return data.detail.size();
    }

    public void setAction(final String status, final String toast, String id, final int i) {
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("rid", Utils.getString(context, Constants.USER_ID));
        params.put("status", status);
        params.put("gr_req_id", id);
        Utils.log("MEMBER_LIST", "REQ_SEND_BIO-DATA_URL : " + Constants.SEND_GROUP_RESPONSE + "?" + params);
        client.post(Constants.SEND_GROUP_RESPONSE, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                Utils.log("SEND_GROUP_RESPONSE", "SEND_GROUP_RESPONSE "+status+":" + response);
                Toast.makeText(context, toast, Toast.LENGTH_SHORT).show();
                data.detail.remove(i);
                notifyItemRemoved(i);
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Toast.makeText(context, "Something Went Wrong", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void setClick(TextView btnViewBio, final BioData.Data i) {
        btnViewBio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, MemberDetailsActivity.class);
                intent.putExtra("memberDetail", i);
                context.startActivity(intent);
            }
        });
    }

}
