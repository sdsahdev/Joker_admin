package com.suguretaventure.mymarriagegroup.adapters;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.suguretaventure.mymarriagegroup.GetTogether;
import com.suguretaventure.mymarriagegroup.GetTogetherRegister;
import com.suguretaventure.mymarriagegroup.InterestedGTActivity;
import com.suguretaventure.mymarriagegroup.Model.GetTogetherModel;
import com.suguretaventure.mymarriagegroup.R;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;

import cz.msebera.android.httpclient.Header;

/**
 * Created by ankitpatel on 23/02/19.
 */

public class GetTogetherAdapter extends RecyclerView.Adapter<GetTogetherAdapter.MyViewHolder> {
    private String TAG = "GET_TOGETHER_ADAPTER";
    private Context context;
    private LayoutInflater inflater;
    private ArrayList<GetTogetherModel> arr_adapter;
    private ProgressDialog pDialog;
    private boolean isEditable;
    private int mYear, mMonth, mDay, mHour, mMinute, mAmPm;
    private String date = "", time = "";
    private GetTogether activity;

    public GetTogetherAdapter(Context context, ArrayList<GetTogetherModel> arr_adapter, boolean isEditable) {
        this.context = context;
        this.arr_adapter = arr_adapter;
        this.isEditable = isEditable;
        activity = new GetTogether();
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_gettogether, parent, false);
        return new MyViewHolder(itemView);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int i) {
        if (isEditable) {
            holder.imgGetToEdit.setVisibility(View.VISIBLE);
            if (arr_adapter.get(i).getRegister_userid().equalsIgnoreCase(Utils.getString(context, Constants.USER_ID))) {
                holder.cardGetTO.setVisibility(View.VISIBLE);
                holder.ic_next.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(context, InterestedGTActivity.class);
                        intent.putExtra("gtid", arr_adapter.get(i).getId());
                        intent.putExtra("mgid", arr_adapter.get(i).getGid());
                        context.startActivity(intent);
                    }
                });
            } else {
                holder.cardGetTO.setVisibility(View.GONE);
            }


        } else {
            holder.imgGetToEdit.setVisibility(View.GONE);
            holder.cardGetTO.setVisibility(View.VISIBLE);
            holder.btn_gtreg_list.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(context, InterestedGTActivity.class);
                    intent.putExtra("mgid", arr_adapter.get(i).getGid());
                    intent.putExtra("gtid", arr_adapter.get(i).getId());
                    context.startActivity(intent);
                }
            });

            holder.btn_gtreg_now.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ((GetTogether)context).openDialogRegister(arr_adapter.get(i).getId());
                }
            });
        }
        holder.tvDateTime.setText(arr_adapter.get(i).getGdatetime());
        holder.tvTitle.setText("" + arr_adapter.get(i).getTitle());
        holder.tvVenue.setText(arr_adapter.get(i).getVenue());

        holder.imgGetToEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //creating a popup menu
                PopupMenu popup = new PopupMenu(context, holder.imgGetToEdit);
                //inflating menu from xml resource
                popup.inflate(R.menu.options_menu);
                //adding click listener
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.menu1:
                                Utils.log(TAG, "DATE_TIME_TESTING  " + arr_adapter.get(i).getGdatetime());
                                openDialog(i, arr_adapter.get(i).getId(), arr_adapter.get(i).getTitle(), arr_adapter.get(i).getGdatetime(), arr_adapter.get(i).getVenue());
                                break;
                            case R.id.menu2:
                                //handle menu2 click
                                final AlertDialog.Builder builder = new AlertDialog.Builder(context);
                                builder.setIcon(R.drawable.ic_remove_blue);
                                builder.setTitle("Delete");
                                builder.setMessage("Do you want to delete " + arr_adapter.get(i).getTitle() + " Get-together?");

                                builder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        deleteGroup(dialog, i, arr_adapter.get(i).getId());
                                        notifyDataSetChanged();
                                    }
                                });
                                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.cancel();
                                        dialog.dismiss();
                                    }
                                });
                                builder.show();
                                break;
                        }
                        return false;
                    }
                });
                //displaying the popup
                popup.show();
            }
        });
        /*String inputPattern = "yyyy-MM-dd hh:mm:ss";
        String outputPattern = "dd-MMM-yyyy hh:mm";
        @SuppressLint("SimpleDateFormat")
        SimpleDateFormat inputFormat = new SimpleDateFormat(inputPattern);
        @SuppressLint("SimpleDateFormat")
        SimpleDateFormat outputFormat = new SimpleDateFormat(outputPattern);
        Date date;
        String str = null;
        try {
            date = inputFormat.parse(arr_adapter.get(i).getGtdatetime());
            str = outputFormat.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        holder.lblgttitle.setText(arr_adapter.get(i).getGttitle());
        holder.lblgtdetail.setText(arr_adapter.get(i).getGtdetail());
        holder.lblgtdt.setText(str);
        holder.lblgtvenue.setText("Venue: " + arr_adapter.get(i).getGtvenue());
        holder.txtgtrcount.setText(arr_adapter.get(i).getGtrcount());
        holder.btn_gtreg_now.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkRegUser(arr_adapter.get(i).getGtid());
            }
        });
        holder.btn_gtreg_list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                context.startActivity(new Intent(context, GetTogetherDetail.class)
                        .putExtra("gtid", arr_adapter.get(i).getGtid()));
            }
        });*/
    }

    private void deleteGroup(DialogInterface dialog, final int i, String id) {
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("id", id);
        Utils.log(TAG, "DELETE_URL : " + Constants.APP_DELETE_GET_TOGETHER + "?" + params);
        client.post(Constants.APP_DELETE_GET_TOGETHER, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                String success = "",
                        msg = "";
                Utils.log(TAG, "DELETE_RESPONSE : " + response);
                try {
                    JSONObject res = new JSONObject(response);
                    success = res.getString("success");
                    msg = res.getString("msg");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (success.equalsIgnoreCase("true")) {
                    arr_adapter.remove(i);
                    notifyItemChanged(i);
                    notifyDataSetChanged();
                }
                Toast.makeText(context, "" + msg, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "DELETE_ERROR : " + error.getMessage());
            }
        });
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return arr_adapter.size();
    }

    private void checkRegUser(final String position) {
        this.pDialog = new ProgressDialog(context);
        this.pDialog.setMessage("Sending...");
        this.pDialog.setCancelable(false);
        showpDialog();

        String url = Common.GetWebServiceUrl() + "gt_check_regu.php";
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("gtid", position);
        params.put("regid", "" + Utils.getString(context, Constants.USER_ID));
        client.post(url, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                try {
                    JSONArray response = new JSONArray(res);
                    String error = response.getJSONObject(0).getString("error");
                    if (!error.equals("no error")) {
                        Common.showDialog(context, error);
                    } else {
                        String success = response.getJSONObject(1).getString("success");
                        String message = response.getJSONObject(2).getString("message");
                        Toast.makeText(context, message, Toast.LENGTH_LONG).show();
                        if (success.equals("yes")) {
                            context.startActivity(new Intent(context, GetTogetherRegister.class)
                                    .putExtra("gtid", position));
                        }
                    }
                    hidePDialog();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

            }
        });
    }

    // show process Dialog box
    private void showpDialog() {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }

    // hide process Dialog box
    private void hidePDialog() {
        if (this.pDialog != null) {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }

    private void openDialog(final int pos, final String id, final String title, final String gdatetime, final String venue) {
        final Dialog alertDialog = new Dialog(context);
        alertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        alertDialog.setContentView(R.layout.dailog_get_together);
        alertDialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        // Setting Dialog Title
        final EditText Title = alertDialog.findViewById(R.id.txtGetTogetherTitle);
        final EditText Detail = alertDialog.findViewById(R.id.txtGetTogethermsg);
        final TextView tvTitle = alertDialog.findViewById(R.id.tvTitle);
        final TextView btnGetTogetherCancel = alertDialog.findViewById(R.id.btnGetTogetherCancel);
        TextView btnGetTogetherRegister = alertDialog.findViewById(R.id.btnGetTogetherRegister);
        final TextView txtdobdate = alertDialog.findViewById(R.id.tvDate);
        final TextView txtdobtime = alertDialog.findViewById(R.id.tvTime);
        final String temp = gdatetime;
        tvTitle.setText("Update Get-together");
        btnGetTogetherRegister.setText("Update");
        Title.setText(title);
        Detail.setText(venue);
        txtdobdate.setText(temp.substring(0, 10));
        txtdobtime.setText(temp.substring(11, temp.length()));
        txtdobdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Calendar c = Calendar.getInstance();
                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(context, AlertDialog.THEME_HOLO_LIGHT, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {
                        monthOfYear = monthOfYear + 1;
                        String mnth = (monthOfYear < 10) ? "0" + monthOfYear : "" + monthOfYear;
                        String day = (dayOfMonth < 10) ? "0" + dayOfMonth : "" + dayOfMonth;
                        txtdobdate.setText("");
                        txtdobdate.setText(day + "-" + mnth + "-" + year);
                        date = year + "-" + mnth + "-" + day;
                    }
                }, mYear, mMonth, mDay);
                datePickerDialog.show();
            }
        });

        txtdobtime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                mHour = c.get(Calendar.HOUR);
                mMinute = c.get(Calendar.MINUTE);
                mAmPm = c.get(Calendar.AM_PM);
                TimePickerDialog timePickerDialog = new TimePickerDialog(context,
                        new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay,
                                                  int minute) {
                                String am_pm = (hourOfDay < 12) ? "AM" : "PM";
                                txtdobtime.setText("");
                                txtdobtime.setText(hourOfDay + ":" + minute + " " + am_pm);
                                time = hourOfDay + ":" + minute;
                            }
                        }, mHour, mMinute, false);
                timePickerDialog.show();
            }
        });
        btnGetTogetherRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Title.getText().length() == 0) {
                    Title.setError("Title required");
                } else if (Detail.getText().length() == 0) {
                    Detail.setError("Venue required");
                } else if (txtdobdate.getText().toString().length() == 0) {
                    Toast.makeText(context, "Date required", Toast.LENGTH_LONG).show();
                } else if (txtdobtime.getText().toString().length() == 0) {
                    Toast.makeText(context, "Time required", Toast.LENGTH_LONG).show();
                } else {
                    String tempDate = date + " " + time;
                    if (date.equalsIgnoreCase("") && time.equalsIgnoreCase("")) {
                        tempDate = temp.substring(7, 10) + "-" + temp.substring(4, 6) + "-" + temp.substring(0, 2) + " " + temp.substring(11, temp.length());
                        Utils.log(TAG, "1 " + temp);
                        getTogetherUpdate(pos, alertDialog, id, Title, Detail, venue, gdatetime);
                    } else if (date.equalsIgnoreCase("") && !time.equalsIgnoreCase("")) {
                        Utils.log(TAG, "2 " + temp);
                        String temp_date = temp.substring(6, 10) + "-" + temp.substring(3, 5) + "-" + temp.substring(0, 2) + " " + time;
                        getTogetherUpdate(pos, alertDialog, id, Title, Detail, venue, temp_date);
                    } else if (!date.equalsIgnoreCase("") && time.equalsIgnoreCase("")) {
                        Utils.log(TAG, "3 " + temp);
                        String temp_date = date + " " + temp.substring(11, temp.length());
                        getTogetherUpdate(pos, alertDialog, id, Title, Detail, venue, temp_date);
                    } else if (!date.equalsIgnoreCase("") && !time.equalsIgnoreCase("")) {
                        Utils.log(TAG, "4 " + temp);
                        String temp_date = date + " " + time;
                        getTogetherUpdate(pos, alertDialog, id, Title, Detail, venue, temp_date);
                    }
                }
            }
        });

        btnGetTogetherCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                alertDialog.cancel();
            }
        });
        // Showing Alert Message
        alertDialog.show();
    }

    private void getTogetherUpdate(final int pos, final Dialog alertDialog, String id, EditText title, EditText detail, String venue, String gdatetime) {
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("id", id);
        params.put("title", title.getText().toString().trim());
        params.put("venue", detail.getText().toString().trim());
        params.put("datetime", gdatetime.trim());
        Utils.log(TAG, "UPDATE-GET-TOGETHER-URL : " + Constants.APP_UPDATE_GET_TOGETHER + "?" + params);
        client.post(Constants.APP_UPDATE_GET_TOGETHER, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String success = "", msg = "";
                Utils.log(TAG, "UPDATE-GET-TOGETHER-RESPONSE : " + new String(responseBody));
                try {
                    JSONObject res = new JSONObject(new String(responseBody));
                    success = res.getString("success");
                    msg = res.getString("msg");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (success.equalsIgnoreCase("true")) {
                    notifyItemChanged(pos);
                    notifyDataSetChanged();
                    alertDialog.dismiss();
                    activity.getGTList(true, context);
                }
                Toast.makeText(context, "" + msg, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "UPDATE-GET-TOGETHER-ERROR : " + error.getMessage());
            }
        });
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        //TextView lblgttitle, lblgtdetail, lblgtdt, lblgtvenue, txtgtrcount, btn_gtreg_now, btn_gtreg_list;
        private TextView tvDateTime, tvTitle, tvVenue;
        private ImageView imgGetToEdit, ic_next;
        private CardView cardGetTO;
        private TextView btn_gtreg_list,btn_gtreg_now;

        MyViewHolder(View view) {
            super(view);
            tvDateTime = view.findViewById(R.id.tvDateTime);
            tvTitle = view.findViewById(R.id.tvTitle);
            tvVenue = view.findViewById(R.id.tvVenue);
            imgGetToEdit = view.findViewById(R.id.imgGetToEdit);
            cardGetTO = view.findViewById(R.id.cardGetTO);
            ic_next = view.findViewById(R.id.ic_next);
            btn_gtreg_list = view.findViewById(R.id.btn_gtreg_list);
            btn_gtreg_now = view.findViewById(R.id.btn_gtreg_now);
            /*lblgtvenue = view.findViewById(R.id.lblgtvenue);
            btn_gtreg_now = view.findViewById(R.id.btn_gtreg_now);
            btn_gtreg_list = view.findViewById(R.id.btn_gtreg_list);
            txtgtrcount = view.findViewById(R.id.txtgtrcount);*/
        }
    }
}
