package com.suguretaventure.mymarriagegroup.adapters;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.rilixtech.widget.countrycodepicker.CountryCodePicker;
import com.suguretaventure.mymarriagegroup.Dashboard;
import com.suguretaventure.mymarriagegroup.Login;
import com.suguretaventure.mymarriagegroup.Model.MarketingListModel;
import com.suguretaventure.mymarriagegroup.Model.RegisterModel;
import com.suguretaventure.mymarriagegroup.R;
import com.suguretaventure.mymarriagegroup.UpdateMarketingActivity;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Prefs;
import com.suguretaventure.mymarriagegroup.utils.Utils;
import com.suguretaventure.mymarriagegroup.utils.WebServiceCaller;

import org.json.JSONException;
import org.json.JSONObject;

import cz.msebera.android.httpclient.Header;
import retrofit2.Call;
import retrofit2.Callback;

/**
 * Created by ankitpatel on 23/02/19.
 */

public class MarketingPersonadapter extends RecyclerView.Adapter<MarketingPersonadapter.MyViewHolder> {
    private String TAG = "MARKETING_PERSON_ADAPTER";
    private Context context;
    private LayoutInflater inflater;
    private MarketingListModel marketingPesrsonModel;
    private String rid;

    public MarketingPersonadapter(Context context, MarketingListModel marketingPesrsonModel, String rid) {
        this.context = context;
        this.rid = rid;
        this.marketingPesrsonModel = marketingPesrsonModel;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_marketing_person, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, @SuppressLint("RecyclerView") final int i) {
        if (rid.equalsIgnoreCase("-")) {
            holder.buttonViewOption.setVisibility(View.GONE);
        } else {
            holder.buttonViewOption.setVisibility(View.VISIBLE);
        }
        holder.lblgrptitle.setText(marketingPesrsonModel.data.get(i).name);
        holder.txtgrpcount.setText(marketingPesrsonModel.data.get(i).mobile);
        holder.txtPaidStatus.setVisibility(View.VISIBLE);

        if (marketingPesrsonModel.data.get(i).pay_status.equals("0")){
            holder.txtPaidStatus.setText("Not Paid");
            holder.txtPaidStatus.setTextColor(Color.parseColor("#FC4136"));
        }else {
            holder.txtPaidStatus.setText("Paid");
            holder.txtPaidStatus.setTextColor(Color.parseColor("#71E158"));
        }



        Glide.with(context)
                .load(marketingPesrsonModel.data.get(i).image)
                .apply(RequestOptions.circleCropTransform())
                .into(holder.img);
        holder.buttonViewOption.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu popup = new PopupMenu(context, holder.buttonViewOption);
                popup.inflate(R.menu.options_menu);
                MenuItem delete = popup.getMenu().findItem(R.id.menu2);
                delete.setTitle("Delete");
                //adding click listener
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.menu1:
                                Utils.setString(context, "" + Constants.MV_ID, marketingPesrsonModel.data.get(i).id);
                                Utils.setString(context, "" + Constants.MV_CID, marketingPesrsonModel.data.get(i).cid);
                                Utils.setString(context, "" + Constants.MV_CNAME, marketingPesrsonModel.data.get(i).cname);
                                Utils.setString(context, "" + Constants.MV_NAME, marketingPesrsonModel.data.get(i).name);
                                Utils.setString(context, "" + Constants.MV_ADDRESS, marketingPesrsonModel.data.get(i).address);
                                Utils.setString(context, "" + Constants.MV_MOBILE, marketingPesrsonModel.data.get(i).mobile);
                                Utils.setString(context, "" + Constants.MV_EMAIL, marketingPesrsonModel.data.get(i).email);
                                Utils.setString(context, "" + Constants.MV_IMAGE, marketingPesrsonModel.data.get(i).image);
                                Utils.setString(context, "" + Constants.MV_IMAGE1, marketingPesrsonModel.data.get(i).image1);
                                Utils.setString(context, "" + Constants.MV_IMAGE2, marketingPesrsonModel.data.get(i).image2);
                                Utils.setString(context, "" + Constants.MV_PHOTO, marketingPesrsonModel.data.get(i).photo);
                                Utils.setString(context, "" + Constants.MV_PHOTO1, marketingPesrsonModel.data.get(i).photo1);
                                Utils.setString(context, "" + Constants.MV_PHOTO2, marketingPesrsonModel.data.get(i).photo2);
                                Utils.setString(context, "" + Constants.MV_CITY, marketingPesrsonModel.data.get(i).city);
                                Utils.setString(context, "" + Constants.MV_DESCRIPTION, marketingPesrsonModel.data.get(i).description);
                                Utils.setString(context, "" + Constants.MV_LAT, marketingPesrsonModel.data.get(i).lat);
                                Utils.setString(context, "" + Constants.MV_LON, marketingPesrsonModel.data.get(i).lon);
                                Utils.setString(context, "" + Constants.WEBSITE, marketingPesrsonModel.data.get(i).website);
                                Utils.setString(context, "pay_status" , marketingPesrsonModel.data.get(i).pay_status);
                                context.startActivity(new Intent(context, UpdateMarketingActivity.class));
                                break;
                            case R.id.menu2:
                                //handle menu2 click
                                final AlertDialog.Builder builder = new AlertDialog.Builder(context);
                                builder.setIcon(R.drawable.ic_remove_blue);
                                builder.setTitle("Delete");
                                builder.setMessage("Do you want to delete " + marketingPesrsonModel.data.get(i).cname + " Person?");

                                builder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        deleteGroup1(dialog, i, marketingPesrsonModel, Utils.getString(context, Constants.USER_ID));
                                        notifyDataSetChanged();
                                    }
                                });
                                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.cancel();
                                        dialog.dismiss();
                                    }
                                });
                                builder.show();
                                break;
                        }
                        return false;
                    }
                });
                //displaying the popup
                popup.show();
            }
        });
        holder.lay_mygrp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showData(marketingPesrsonModel, i);

            }
        });
    }

    private void showData(MarketingListModel marketingPesrsonModel, int i) {
        final Dialog alertDialog = new Dialog(context);
        alertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        alertDialog.setContentView(R.layout.dialog_new_marketing_person);
        alertDialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        final EditText txtname, txtaddress, txtemail, txtmobileno, txtCategory, txtdesc, txtCity, txtwebsite;
        final LinearLayout LinSPN, LinCategory;
        final Button btnsendotp;
        TextView btn_create_grp = alertDialog.findViewById(R.id.btn_create_grp);
        TextView txtheading = alertDialog.findViewById(R.id.txtheading);
        TextView tvmandate = alertDialog.findViewById(R.id.tvmandate);
        TextView tvmandate1 = alertDialog.findViewById(R.id.tvmandate1);
        TextView tvmandate2 = alertDialog.findViewById(R.id.tvmandate2);
        TextView tvPayment = alertDialog.findViewById(R.id.tvPayment);
        TextView tvPhoto = alertDialog.findViewById(R.id.tvPhoto);
        TextView tvPhoto1 = alertDialog.findViewById(R.id.tvPhoto1);
        TextView tvPhoto2 = alertDialog.findViewById(R.id.tvPhoto2);
        btnsendotp = alertDialog.findViewById(R.id.btnsendotp);
        btnsendotp.setVisibility(View.GONE);
        txtheading.setText("Marketing Details");
        txtname = alertDialog.findViewById(R.id.txtname);
        CountryCodePicker txtmobileCode = alertDialog.findViewById(R.id.txtmobileCode);
        txtaddress = alertDialog.findViewById(R.id.txtaddress);
        txtemail = alertDialog.findViewById(R.id.txtemail);
        txtmobileno = alertDialog.findViewById(R.id.txtmobileno);
        txtdesc = alertDialog.findViewById(R.id.txtdesc);
        txtCity = alertDialog.findViewById(R.id.txtCity);
        txtwebsite = alertDialog.findViewById(R.id.txtwebsite);
        LinSPN = alertDialog.findViewById(R.id.LinSPN);
        txtCategory = alertDialog.findViewById(R.id.txtCategory);
        LinCategory = alertDialog.findViewById(R.id.LinCategory);
        ImageView imgphotoid_select = alertDialog.findViewById(R.id.imgphotoid_select);
        ImageView imgphotoid_select1 = alertDialog.findViewById(R.id.imgphotoid_select1);
        ImageView imgphotoid_select2 = alertDialog.findViewById(R.id.imgphotoid_select2);
        ImageView imgphotoid = alertDialog.findViewById(R.id.imgphotoid);
        ImageView imgphotoid11 = alertDialog.findViewById(R.id.imgphotoid11);
        ImageView imgphotoid2 = alertDialog.findViewById(R.id.imgphotoid2);
        ImageView imgclose = alertDialog.findViewById(R.id.imgclose);
        RadioGroup rgPaymentOption = alertDialog.findViewById(R.id.rgPaymentOption);
        rgPaymentOption.setVisibility(View.GONE);

        btn_create_grp.setVisibility(View.GONE);
        imgphotoid_select.setVisibility(View.GONE);
        imgphotoid_select1.setVisibility(View.GONE);
        imgphotoid_select2.setVisibility(View.GONE);
        txtmobileCode.setClickable(false);
        tvPayment.setVisibility(View.GONE);
        tvmandate.setVisibility(View.GONE);
        tvmandate1.setVisibility(View.GONE);
        tvmandate2.setVisibility(View.GONE);


 /*       AdView mAdView = alertDialog.findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);*/


        /*mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                // Code to be executed when an ad finishes loading.
            }

            @Override
            public void onAdFailedToLoad(int errorCode) {
                // Code to be executed when an ad request fails.
            }

            @Override
            public void onAdOpened() {
                // Code to be executed when an ad opens an overlay that
                // covers the screen.
            }

            @Override
            public void onAdClicked() {
                // Code to be executed when the user clicks on an ad.
            }

            @Override
            public void onAdLeftApplication() {
                // Code to be executed when the user has left the app.
            }

            @Override
            public void onAdClosed() {
                // Code to be executed when the user is about to return
                // to the app after tapping on an ad.
            }
        });
*/

        imgclose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.dismiss();
            }
        });

        LinSPN.setVisibility(View.GONE);
        LinCategory.setVisibility(View.VISIBLE);
        tvPhoto.setText("Photo");
        tvPhoto1.setText("Photo");
        tvPhoto2.setText("Photo");
        txtname.setText(marketingPesrsonModel.data.get(i).name);
        txtaddress.setText(marketingPesrsonModel.data.get(i).address);
        txtemail.setText(marketingPesrsonModel.data.get(i).email);
        txtmobileno.setText(marketingPesrsonModel.data.get(i).mobile);
        txtdesc.setText(marketingPesrsonModel.data.get(i).description);
        txtCity.setText(marketingPesrsonModel.data.get(i).city);
        txtCategory.setText(marketingPesrsonModel.data.get(i).cname);
        txtwebsite.setText(marketingPesrsonModel.data.get(i).website);

        txtname.setEnabled(false);
        txtaddress.setEnabled(false);
        txtemail.setEnabled(false);
        txtmobileno.setEnabled(false);
        txtdesc.setEnabled(false);
        txtCity.setEnabled(false);
        txtCategory.setEnabled(false);
        txtwebsite.setEnabled(false);

        txtname.setFocusable(false);
        txtaddress.setFocusable(false);
        txtemail.setFocusable(false);
        txtmobileno.setFocusable(false);
        txtdesc.setFocusable(false);
        txtCity.setFocusable(false);
        txtCategory.setFocusable(false);
        txtwebsite.setFocusable(false);

        Glide.with(context)
                .load(marketingPesrsonModel.data.get(i).image)
                .into(imgphotoid);


        if (marketingPesrsonModel.data.get(i).photo1 != null && !marketingPesrsonModel.data.get(i).photo1.equals("")) {
            Glide.with(context)
                    .load(marketingPesrsonModel.data.get(i).image1)
                    .into(imgphotoid11);
        }
        if (marketingPesrsonModel.data.get(i).photo2 != null && marketingPesrsonModel.data.get(i).photo2.equals("")) {
            Glide.with(context)
                    .load(marketingPesrsonModel.data.get(i).image2)
                    .into(imgphotoid2);
        }

        alertDialog.show();
    }


    private void deleteGroup1(final DialogInterface dialog, final int i, final MarketingListModel data, String string) {
        final ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.setTitle("Please wait...");
        progressDialog.show();
        progressDialog.setCancelable(false);

        WebServiceCaller.getClient().deleteMarket(data.data.get(i).id, data.data.get(i).photo).enqueue(new Callback<RegisterModel>() {
            @Override
            public void onResponse(Call<RegisterModel> call, retrofit2.Response<RegisterModel> response) {
                if (response.isSuccessful()) {
                    String res = new String(String.valueOf(response));
                    Utils.log(TAG, "RESPONSE  : " + res);
                    RegisterModel registerModel;
                    registerModel = response.body();
                    if (registerModel.getSuccess()) {
                        data.data.remove(i);
                        notifyItemRemoved(i);
                        notifyItemRangeChanged(i, data.data.size());
                      /*  notifyItemChanged(i);
                        notifyDataSetChanged();*/
                        dialog.dismiss();
                    }
                    Toast.makeText(context, "" + registerModel.getMsg(), Toast.LENGTH_SHORT).show();
                }
                progressDialog.dismiss();
            }

            @Override
            public void onFailure(Call<RegisterModel> call, Throwable t) {
                //swipeContainer.setRefreshing(false)
                //
                Log.d("Error_Message", t.getMessage());
                progressDialog.dismiss();
                Toast.makeText(context, "Server Error  :   " + t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void deleteGroup(final DialogInterface dialog, final int i, final MarketingListModel data, String string) {
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("id", data.data.get(i).id);
        params.put("photo", data.data.get(i).photo);
        Utils.log(TAG, "DELETE_MARKETING_URL : " + Constants.APP_DELETE_MARKETING + "?" + params);
        client.post(Constants.APP_DELETE_MARKETING, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                Utils.log(TAG, "DELETE_MARKETING_RESPONSE : " + response);
                String success = "", msg = "";
                try {
                    JSONObject res = new JSONObject(response);
                    success = res.getString("success");
                    msg = res.getString("msg");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (success.equalsIgnoreCase("true")) {
                    data.data.remove(i);
                    notifyItemChanged(i);
                    notifyDataSetChanged();
                    dialog.dismiss();
                }
                Toast.makeText(context, "" + msg, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "DELETE_MARKETING_ERROR : " + error.getMessage());
            }
        });
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        TextView lblgrptitle, txtgrpcount,txtPaidStatus;
        LinearLayout lay_mygrp;
        ImageView img, buttonViewOption;

        MyViewHolder(View view) {
            super(view);
            lblgrptitle = view.findViewById(R.id.lblgrptitle);
            txtgrpcount = view.findViewById(R.id.txtgrpcount);
            lay_mygrp = view.findViewById(R.id.lay_mygrp);
            img = view.findViewById(R.id.img);
            buttonViewOption = view.findViewById(R.id.buttonViewOption);
            txtPaidStatus = view.findViewById(R.id.txtPaidStatus);
        }
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return marketingPesrsonModel.data.size();
    }


}
