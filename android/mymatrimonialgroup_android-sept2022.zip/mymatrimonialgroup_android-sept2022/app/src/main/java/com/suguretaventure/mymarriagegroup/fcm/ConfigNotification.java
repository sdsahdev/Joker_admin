package com.suguretaventure.mymarriagegroup.fcm;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Date;

/**
 * Created by intel on 5/19/2017.
 */

public class ConfigNotification {

    // global topic to receive app wide push notifications
    public static final String TOPIC_GLOBAL = "global";

    // broadcast receiver intent filters
    public static final String REGISTRATION_COMPLETE = "registrationComplete";
    public static final String PUSH_NOTIFICATION = "pushNotification";

    // id to handle the notification in the notification tray
    public static final int NOTIFICATION_ID =(int) ((new Date().getTime() / 1000L) % Integer.MAX_VALUE);
    public static final int NOTIFICATION_ID_BIG_IMAGE = 101;

    public static final String SHARED_PREF = "ah_firebase";
    public static final String SHARED_PREF_NOTIFICATION = "notification";
    public static final String SHARED_PREF_DATALOAD="data_loading";


    public static SharedPreferences pref;
    public static  SharedPreferences.Editor editor;


    public static String getToken(Context context){

        SharedPreferences pref = context.getSharedPreferences(ConfigNotification.SHARED_PREF, 0);
        String regId = pref.getString("regId", null);

        return regId;
    }


}
