package com.suguretaventure.mymarriagegroup.Model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

public class MarketCity implements Serializable {

    @SerializedName("marketing")
    public ArrayList<CITY> marketing;

    public class CITY implements Serializable {

        @SerializedName("city")
        public String city;

    }
}
