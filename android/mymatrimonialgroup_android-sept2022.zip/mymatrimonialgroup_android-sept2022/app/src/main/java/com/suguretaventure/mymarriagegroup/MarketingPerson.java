package com.suguretaventure.mymarriagegroup;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import com.google.android.material.snackbar.Snackbar;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.RequiresApi;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.suguretaventure.mymarriagegroup.Model.MarketingListModel;
import com.suguretaventure.mymarriagegroup.Model.MarketingPesrsonModel;
import com.suguretaventure.mymarriagegroup.adapters.MarketingPersonadapter;
import com.suguretaventure.mymarriagegroup.adapters.MyGroupAdapter;
import com.suguretaventure.mymarriagegroup.getsets.MyGroupGetSet;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utility;
import com.suguretaventure.mymarriagegroup.utils.Utils;

import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;

public class MarketingPerson extends AppCompatActivity {

    AlertDialog aldialog;
    ActionBar toolbar;
    MarketingPersonadapter marketingPersonadapter;
    MarketingPesrsonModel marketingPesrsonModel;

    private String TAG = "MARKETING_PERSON";
    private Context context = this;
    private RecyclerView rcvgrp;
    private ArrayList<MyGroupGetSet> arr_adapter = new ArrayList<>();
    private MyGroupAdapter grpAdapter;
    private MyGroupGetSet grpGetSet;
    private ProgressDialog pDialog;
    private TextView lblemptygrp, tvMyMarketingTitle;
    private LinearLayout flt_newgroup;
    private String my_rid = "-";
    private Menu myMenu;


    private TextView txtGenderTitle;
    private ImageView imgGenderBack, imgGenderIcon;
    String mgid, mgname, count, image1, URL;
    private Toolbar toolbar_top;
    private MenuItem menuItem;

    private String strcid, strcname, image;
    private FirebaseAnalytics mFirebaseAnalytics;

    public static void dialogShow(Context ctx, String msg) {
        AlertDialog.Builder b1 = new AlertDialog.Builder(ctx);
        b1.setTitle("Error");
        b1.setMessage(msg);
        b1.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        b1.create().show();
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
// clear FLAG_TRANSLUCENT_STATUS flag:
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

// add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);

// finally change the color
        window.setStatusBarColor(getResources().getColor(R.color.colorPrimaryDark));
        setContentView(R.layout.activity_marketing_person);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
       /* getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(getResources().getString(R.string.app_name_title));*/
//        setupToolbar();
        allocateMemory();
        strcid = getIntent().getExtras().getString("cid");
        strcname = getIntent().getExtras().getString("cname");
        Intent intent = this.getIntent();
        if (intent != null) {
            mgid = intent.getStringExtra("mgid");
            mgname = intent.getStringExtra("mgname");
            URL = intent.getStringExtra("URL");
            image1 = intent.getStringExtra("image");
            Utils.log(TAG, "++++++++++++++++++++++" + mgid);
            if (mgid != null) {
                txtGenderTitle.setText("" + mgname);
                if (!image1.equalsIgnoreCase("")) {
                    Glide.with(context)
                            .load(URL + image)
                            .apply(RequestOptions.circleCropTransform())
                            .into(imgGenderIcon);
                }
            } else {
                txtGenderTitle.setText(getResources().getString(R.string.app_name_title));
            }
        }

        if (my_rid.equalsIgnoreCase("-")) {
            tvMyMarketingTitle.setText("Marketing Person List");
        } else {
            tvMyMarketingTitle.setText("My Marketing Person List");
        }

    }


    public void allocateMemory() {
        toolbar_top = findViewById(R.id.toolbar_top);
        rcvgrp = findViewById(R.id.rcvgrp);
//        imgback = findViewById(R.id.imgback);
        RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(this, 1);
        rcvgrp.setLayoutManager(mLayoutManager);
        lblemptygrp = findViewById(R.id.lblemptygrp);
        flt_newgroup = findViewById(R.id.flt_newgroup);

        txtGenderTitle = findViewById(R.id.txtGenderTitle);
        imgGenderIcon = findViewById(R.id.imgGenderIcon);
        imgGenderBack = findViewById(R.id.imgGenderBack);
        tvMyMarketingTitle = findViewById(R.id.tvMyMarketingTitle);
        toolbar_top.inflateMenu(R.menu.menu_marketing);
        setSupportActionBar(toolbar_top);
    }

    private void getMArketingperson(final String rid) {

        if (!Utility.isNetworkAvailable(MarketingPerson.this)) {
            Snackbar.make(rcvgrp, "Internet connection is not available", Snackbar.LENGTH_INDEFINITE).setAction("RETRY", new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    getMArketingperson(rid);
                }
            }).setActionTextColor(getResources().getColor(R.color.colorPrimary)).show();
        } else {
            final ProgressDialog progressDialog = new ProgressDialog(context);
            progressDialog.setTitle("Fetching Data...");
            progressDialog.show();
            progressDialog.setCancelable(false);
            final AsyncHttpClient client = new AsyncHttpClient(true,80,443);
            RequestParams params = new RequestParams();
            params.put("id", strcid);
            params.put("rid", rid);
            Utils.log(TAG, "GET_MARKETING_LIST_CAT_URL : " + Constants.APP_MARKETING_LIST_BY_CAT + "?" + params);
            client.post(Constants.APP_MARKETING_LIST_BY_CAT, params, new AsyncHttpResponseHandler() {
                @Override
                public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                    Utils.log(TAG, "GET_MARKETING_LIST_CAT_RESPONSE : " + new String(responseBody));
                    MarketingListModel model = new Gson().fromJson(new String(responseBody), MarketingListModel.class);
                    if (model.data.size() > 0) {
                        lblemptygrp.setVisibility(View.GONE);
                        rcvgrp.setVisibility(View.VISIBLE);
                        rcvgrp.setLayoutManager(new LinearLayoutManager(context));
                        rcvgrp.setAdapter(new MarketingPersonadapter(context, model, my_rid));
                    } else {
                        lblemptygrp.setVisibility(View.VISIBLE);
                        rcvgrp.setVisibility(View.GONE);
                    }
                    progressDialog.dismiss();
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                    Utils.log(TAG, "GET_MARKETING_LIST_CAT_ERROR : " + error.getMessage());
                    progressDialog.dismiss();
                }
            });
            /*WebServiceCaller.getClient().getMarketingPesrsonModelCall(strcid).enqueue(new Callback<MarketingPesrsonModel>() {
                @Override
                public void onResponse(Call<MarketingPesrsonModel> call, retrofit2.Response<MarketingPesrsonModel> response) {
                    if (response.isSuccessful()) {
                        marketingPesrsonModel = response.body();
                        marketingPersonadapter = new MarketingPersonadapter(MarketingPerson.this, marketingPesrsonModel);
                        rcvgrp.setAdapter(marketingPersonadapter);
                    } else {
                        Toast.makeText(context, "No Data Found", Toast.LENGTH_LONG).show();

                    }
                    progressDialog.dismiss();
                }

                @Override
                public void onFailure(Call<MarketingPesrsonModel> call, Throwable t) {
                    //swipeContainer.setRefreshing(false)
                    //
                    progressDialog.dismiss();
                    Toast.makeText(context, "Server Error", Toast.LENGTH_LONG).show();
                }
            });*/
        }


    }


    // show process Dialog box
    private void showpDialog() {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }

    // hide process Dialog box
    private void hidePDialog() {
        if (this.pDialog != null) {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        this.menuItem = item;
        int id = item.getItemId();
        if (id == R.id.MyMarketing) {
            item.setVisible(false);
            my_rid = Utils.getString(context, Constants.USER_ID);
            tvMyMarketingTitle.setText("My Marketing Person List");
            getMArketingperson(my_rid);
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onBackPressed() {
        if (!my_rid.equalsIgnoreCase("-")) {
            my_rid = "-";
            menuItem.setVisible(true);
            getMArketingperson(my_rid);
            tvMyMarketingTitle.setText("Marketing Person List");
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        this.myMenu = menu;
        getMenuInflater().inflate(R.menu.menu_marketing, menu);
        return true;
    }

    public void showOverflowMenu(boolean showMenu) {
        if (myMenu == null)
            return;
        myMenu.setGroupVisible(R.id.MyMarketing, showMenu);
    }

    @Override
    protected void onResume() {
        super.onResume();
        getMArketingperson(my_rid);
    }

    /*@Override
    protected void onRestart() {
        super.onRestart();
        if (Utils.getString(context, Constants.MV_CID) != null) {
            my_rid = Utils.getString(context, Constants.USER_ID);
            getMArketingperson(Utils.getString(context, Constants.USER_ID));
        } else {
            my_rid = "-";
            getMArketingperson("-");
        }
    }*/
}
