package com.suguretaventure.mymarriagegroup;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.reward.RewardedVideoAd;
import com.google.android.gms.ads.reward.RewardedVideoAdListener;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
//import com.google.android.gms.ads.rewarded.RewardedAdCallback;
import com.google.android.gms.ads.rewarded.RewardedAdCallback;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;
import com.suguretaventure.mymarriagegroup.Model.Members;
import com.suguretaventure.mymarriagegroup.Model.RegisterModel;
import com.suguretaventure.mymarriagegroup.adapters.ImageSliderAdapter;
import com.suguretaventure.mymarriagegroup.adapters.MemberRequestAdapter;
import com.suguretaventure.mymarriagegroup.adapters.PersonAdapter;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.common.NetworkConnetionState;
import com.suguretaventure.mymarriagegroup.getsets.PersonGetSet;
import com.suguretaventure.mymarriagegroup.imageresize.util.Util;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utils;
import com.suguretaventure.mymarriagegroup.utils.WebServiceCaller;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import cz.msebera.android.httpclient.Header;
import retrofit2.Call;
import retrofit2.Callback;

public class PersonDesc extends AppCompatActivity implements PaymentResultListener, RewardedVideoAdListener {
    private String TAG = "PERSON_DESC";
    private Context ctx = this;
    /*private TextView lblpname, lblpedu, lblpocu, lblpincome, lblpheight, lblpdob_dt, lblpdob_place,
            lblpfather, lblpmother, lblp_bro, lblp_sis, lblpaddress, lblpcontact, lblphobbies,
            lblpexpectations, lblpage;*/
    private String fullname;
    private String age;
    private String education;
    private String occupation;
    private String income;
    private String height;
    private String weight;
    private String blood;
    private String bdate;
    private String date;
    private String btime;
    private String bplace;
    private String father;
    private String mother;
    private String brother;
    private String sister;
    private String address;
    private Date finaldate;
    private String contact_person;
    private String contact_person_number;
    private String relation;
    private String mobile;
    private String mobile2;
    private String hobbies;
    private String expect;
    private String photo1;
    private String photo2;
    private String degree;
    private String verified;
    private String verifiedBy;
    private String req_status;
    private String bio_rid;
    private String email;
    private boolean isContactPerson = false;
    private boolean isContactNo = false;
    private String complexion1, ras_tithi1, religion1, marital1, motherTongue1, kulDevta1, gender;
    public static String checkstatus = "0";
    TextInputLayout viewTime1, viewcontact;
    //private ImageView pimage;
    private ProgressDialog pDialog;
    private LayoutInflater inflater;
    private String imgname;
    ActionBar toolbar;
    private LinearLayout LinRequest;
    TextView btnReqAccept, btnReqReject, txtsendinv, contactDetailsTextView, relationAndContactTextView;
    String request = "", id = "", Gid = "";
    TextView tvVerified, tvIsPaid, tvPublishedOn, addressUploaded;
    private TextInputEditText viewFullName, viewAge, viewBlood, viewWeight, viewHeight, viewDate, viewTime, viewPlace;
    private TextInputEditText viewFather, viewMother, viewSister, viewBrother;
    private TextInputEditText viewEducation, viewOccupation, viewIncome, viewHobbies, viewExpectations;
    private TextInputEditText viewAddress, viewDegree, viewContactPerson, viewRelation, viewMobile, viewEmail;
    private TextInputEditText viewComplexion, viewRasTithi, viewReligion, viewMarital, viewMotherTongue, viewKulDevta, viewGender, viewDrinkingHabit, viewSmokingHabit, viewDietary, txtOccDetails, viewRelatives, viewRelativesWhoKnows, viewNativePlace;
    private TextInputEditText viewFatherOccup, viewMotherOccup, viewSurnameInCommunity, viewPresentResCity;
    //IMAGE SLIDER
    private ViewPager vpImage;

    private int page = 0;
    private Runnable runnable;
    private ImageSliderAdapter sliderAdapter;
    private TabLayout tabLayout;
    private TextView tvImagesCount;

    private ArrayList<String> imgArray;
    private ActionBar actionBar;
    ProgressDialog dialog;
    int currentPage = 0;
    Timer timer;
    final long DELAY_MS = 500;//delay in milliseconds before task is to be executed
    final long PERIOD_MS = 3000; // time in milliseconds between successive task executions.
    private FloatingActionButton fab;

    Button btnConvertToPremium;
    private PersonGetSet personGetSet;
    private String RidFrom, Rid;
    private ArrayList<PersonGetSet> arr_adapter = new ArrayList<>();
    private PersonAdapter personAdapter;
    private RecyclerView rcvpersonlist;

    private RewardedAd rewardedAd;
    RewardedAdLoadCallback rewardedAdLoadCallback;
    RewardedAdCallback rewardedAdCallback;

    private RewardedVideoAd mAd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_person_desc);

        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        /*Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);*/
//        setupToolbar();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        allocateMemory();


        actionBar = getSupportActionBar();
        //actionBar.setTitle(title);
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setBackgroundDrawable(getResources().getDrawable(R.drawable.actionbar_background));
        if (new NetworkConnetionState().isNetworkAvailable(ctx)) {
            request = "" + getIntent().getStringExtra("request");
            int type = getIntent().getIntExtra("type", 0);
            boolean flag_my_post = getIntent().getBooleanExtra("flag_my_post", false);
            id = getIntent().getStringExtra("pid");
            Gid = getIntent().getStringExtra("gid");


            if (request.equalsIgnoreCase("1")) {
                if ((type == 0 || type == 2)) {
                    LinRequest.setVisibility(View.VISIBLE);
                } else {
                    LinRequest.setVisibility(View.GONE);
                }
                viewMobile.setVisibility(View.GONE);
                txtsendinv.setVisibility(View.GONE);
            } else {
                if (type == 2) {
                    LinRequest.setVisibility(View.VISIBLE);
                } else {
                    LinRequest.setVisibility(View.GONE);
                }

                viewMobile.setVisibility(View.VISIBLE);
                txtsendinv.setVisibility(View.VISIBLE);
            }
            if (flag_my_post) {
                LinRequest.setVisibility(View.GONE);
            }

            getPersonDetail(type);

            /*if (type == 0) {
                LinRequest.setVisibility(View.GONE);
                viewMobile.setVisibility(View.VISIBLE);
                txtsendinv.setVisibility(View.VISIBLE);
            } else {
                LinRequest.setVisibility(View.VISIBLE);
                viewMobile.setVisibility(View.GONE);
                txtsendinv.setVisibility(View.GONE);
            }*/
            fab = (FloatingActionButton) findViewById(R.id.fabshare);
            fab.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    shareItem(Common.GetProfileImageUrl() + imgname);
                }
            });

            setListener();
        } else {
            networkAlert();
        }

        AdView adViewPersonDesc = findViewById(R.id.adViewPersonDesc);
        AdRequest adRequest = new AdRequest.Builder().build();
        adViewPersonDesc.loadAd(adRequest);

        //  MobileAds.initialize(this, "ca-app-pub-3940256099942544~3347511713");
        MobileAds.initialize(this, "ca-app-pub-9760169068393412/7622350861");
        // Use an activity context to get the rewarded video instance.
        mAd = MobileAds.getRewardedVideoAdInstance(this);
        mAd.setRewardedVideoAdListener(this);
        loadRewardedVideoAd();




       /* RidFrom = getIntent().getExtras().getString("from");
        if (RidFrom.equals("group")) {
          //  lay_search.setVisibility(View.GONE);
           // lblgroupoccu.setText("Group Member Posts");
            Rid = getIntent().getExtras().getString("Rid");
        } else {
          //  lay_search.setVisibility(View.VISIBLE);
          //  lblgroupoccu.setText("My Biodatas");
            Rid = "" + Utils.getString(ctx, Constants.USER_ID);
        }*/


    }

    private void loadRewardedVideoAdv() {
        if (!mAd.isLoaded()) {
            mAd.loadAd(getString(R.string.id_block_activity), new AdRequest.Builder().build());
        }
    }

    @Override
    public void onResume() {
        mAd.resume(this);
        super.onResume();
        loadRewardedVideoAd();
    }

    @Override
    public void onPause() {
        mAd.pause(this);
        super.onPause();
    }

    @Override
    public void onDestroy() {
        mAd.destroy(this);
        super.onDestroy();
    }

    private void loadRewardedVideoAd() {
        mAd.loadAd("ca-app-pub-9760169068393412/7622350861",
                new AdRequest.Builder().build());
    }

    private void setDecoration(final ArrayList<String> image) {


        sliderAdapter = new ImageSliderAdapter(ctx, image);
        vpImage.setAdapter(sliderAdapter);
//        tabLayout.setupWithViewPager(vpImage);

        /*After setting the adapter use the timer */
        final Handler handler = new Handler();
        final Runnable Update = new Runnable() {
            public void run() {
                if (currentPage == image.size()) {
                    currentPage = 0;
                }
                vpImage.setCurrentItem(currentPage++, true);
            }
        };

        timer = new Timer(); // This will create a new Thread
        timer.schedule(new TimerTask() { // task to be scheduled
            @Override
            public void run() {
                handler.post(Update);
            }
        }, DELAY_MS, PERIOD_MS);

//        tabLayout.setupWithViewPager(vpImage, true);
//        runnable.run();
    }

    private void setListener() {
        btnReqAccept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendDataToServer(id, 1);
            }
        });

        btnReqReject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case DialogInterface.BUTTON_POSITIVE:
                                sendDataToServer(id, 0);
                                break;

                            case DialogInterface.BUTTON_NEGATIVE:
                                //No button clicked
                                break;
                        }
                    }
                };

                androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(PersonDesc.this);
                builder.setMessage("Do you want to reject?").setPositiveButton("Yes", dialogClickListener)
                        .setNegativeButton("No", dialogClickListener).show();
            }
        });
       /* txtsendinv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                startActivity(new Intent(PersonDesc.this,SendInvitationActivity.class).putExtra("bid",id));

                dialog = new ProgressDialog(ctx);
                dialog.setMessage("Sending...");
                dialog.setCancelable(false);
                dialog.show();
                sendRequest(id, Utils.getString(ctx, Constants.USER_ID));
                .setEnabled(false);
            }
        });*/

        txtsendinv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getMyPosts();
            }
        });

        btnConvertToPremium.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (Utils.getString(PersonDesc.this, Constants.USER_IS_VIP).equals("1")) {
                    startPayment("15");
                } else {
                    showPremiumDialog();
                }
            }
        });
    }

    /*
     * Start Payment Section
     * */

    private void showPremiumDialog() {
        final BottomSheetDialog bottomSheerDialog = new BottomSheetDialog(this);
        View parentView = getLayoutInflater().inflate(R.layout.layout_primium_dialog, null);
        bottomSheerDialog.setContentView(parentView);
        ImageView imageView = parentView.findViewById(R.id.imgLogo);
        Button btnSubscription = parentView.findViewById(R.id.btnSubscription);
        imageView.startAnimation(AnimationUtils.loadAnimation(parentView.getContext(), R.anim.zoom_in_zoom_out));
        btnSubscription.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startPayment("15");
                bottomSheerDialog.dismiss();
            }
        });
        bottomSheerDialog.show();
    }

    public void startPayment(String amount) {
        Checkout.preload(getApplicationContext());
        final Activity activity = this;
        String amount_ = String.valueOf(Integer.parseInt(amount) * 100 * 75);
        final Checkout co = new Checkout();
        co.setKeyID("rzp_live_rqh0DabOcTj5iZ");

        try {
            JSONObject options = new JSONObject();
            options.put("name", "" + Utils.getString(ctx, Constants.USER_NAME));
            options.put("description", "Add Bio Data Charge");
            //You can omit the image option to fetch the image from dashboard
            options.put("image", "");
            options.put("currency", "INR");
            options.put("amount", amount_);

            JSONObject preFill = new JSONObject();
            preFill.put("email", "" + Utils.getString(ctx, Constants.USER_EMAIL));
            preFill.put("contact", "" + Utils.getString(ctx, Constants.USER_MOBILE));

            options.put("prefill", preFill);

            co.open(activity, options);
        } catch (Exception e) {
            Toast.makeText(activity, "Error in payment: " + e.getMessage(), Toast.LENGTH_SHORT)
                    .show();
            e.printStackTrace();
        }
    }


    private void covertToPremiumBiodata(final String razorPayId) {

        pDialog = new ProgressDialog(ctx);
        pDialog.setMessage("Please wait...");
        pDialog.setCancelable(false);
        showpDialog();

        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        RequestParams params = new RequestParams();
        params.put("rid", Utils.getString(ctx, Constants.USER_ID));
        params.put("bid", id);
        params.put("pay_id", razorPayId);
        Utils.log(TAG, "REQUEST_URL : " + Constants.SET_PREMIUM_BIODATA + "?" + params);
        client.post(Constants.SET_PREMIUM_BIODATA, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                Utils.log(TAG, "REQUEST_RESPONSE : " + response);
                Utils.setString(PersonDesc.this, Constants.USER_IS_FIRST_PROFILE_UPLOADED, "1");
                Utils.setString(PersonDesc.this, Constants.USER_IS_VIP, "1");
                Toast.makeText(PersonDesc.this, "Biodata converted to premium successfully", Toast.LENGTH_SHORT).show();
               /* BioData data = new Gson().fromJson(response, BioData.class);
                Utils.log("REQ_RESPONSE", data.totalRequest);*/
                hidePDialog();
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "REQUEST_ERROR : " + error.getMessage());
                hidePDialog();
            }
        });
    }


    @Override
    public void onPaymentSuccess(String s) {
        try {
//            Toast.makeText(this, "Payment Successful: " + s, Toast.LENGTH_SHORT).show();

            covertToPremiumBiodata(s);
        } catch (Exception e) {
            Utils.log(TAG, "Exception in onPaymentSuccess : " + e.getMessage());
        }
    }


    @Override
    public void onPaymentError(int i, String s) {
        try {
            Toast.makeText(this, "Payment processing cancelled by user", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Utils.log(TAG, "Exception in onPaymentError : " + e.getMessage());
        }
    }


    /*
     * End Payment Section
     * */


    private void sendDataToServer(String id, int i) {


        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        RequestParams params = new RequestParams();
        params.put("bid", id);
        params.put("rid", Utils.getString(ctx, Constants.USER_ID));
        params.put("status", "" + i);
        Utils.log(TAG, Constants.APP_BIODATA_VERIFIED + "?" + params);
        client.post(Constants.APP_BIODATA_VERIFIED, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                String success = "", msg = "";
                Utils.log(TAG, "APP_BIODATA_VERIFIED_RESPONSE : " + res);
//                {"success":true,"msg":"Biodata Request Sucesfully Verified"}
                try {
                    JSONObject object = new JSONObject(res);
                    success = object.getString("success");
                    msg = object.getString("msg");

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                if (success.equalsIgnoreCase("true")) {
                    Toast.makeText(PersonDesc.this, "" + msg, Toast.LENGTH_LONG).show();
                    PersonDesc.super.onBackPressed();
                } else {
                    Toast.makeText(PersonDesc.this, "" + msg, Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "APP_BIODATA_VERIFIED_ERROR : " + error.getMessage());
            }
        });
    }

    private void networkAlert() {
        AlertDialog.Builder b1 = new AlertDialog.Builder(ctx);
        b1.setTitle("Network Error");
        b1.setMessage("No internet connection found. Please check your phone settings to turn on the internet.");
        b1.setPositiveButton("Retry", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (new NetworkConnetionState().isNetworkAvailable(ctx)) {
                    int type = getIntent().getIntExtra("type", 0);
                    getPersonDetail(type);
                } else {
                    networkAlert();
                }
            }
        });
        b1.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        b1.create().show();
    }

    public void getPersonDetail(final int type) {
        pDialog = new ProgressDialog(ctx);
        pDialog.setMessage("Please wait...");
        pDialog.setCancelable(false);
        showpDialog();
        imgArray = new ArrayList<>();
        String WebServiceUrl = Common.GetWebServiceUrl() + "person_list.php";
        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        RequestParams data = new RequestParams();
        data.put("pid", id);
        data.put("gid", String.valueOf(0));
        data.put("rid", Utils.getString(ctx, Constants.USER_ID));
        if (type == 2) {
            data.put("is_premium", "1");
        }
        Log.d("URL_PERSONLIST", WebServiceUrl + "?" + data);
        client.post(WebServiceUrl, data, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                Utils.log(TAG, res.toString());
                try {
                    JSONArray response = new JSONArray(res);
                    String error = response.getJSONObject(0).getString("error");
                    if (error.equals("no error") == false) {
                        hidePDialog();
                        Common.showDialog(ctx);
                    } else {
                        int total = response.getJSONObject(1).getInt("total");
                        if (total == 0) {
                            hidePDialog();
                            Toast.makeText(ctx, "No Data Found", Toast.LENGTH_LONG).show();
                        } else {
                            int size = response.length();
                            for (int i = 2; i < size; i++) //3
                            {
                                JSONObject object = response.getJSONObject(i);
                                fullname = object.getString("name");
                                age = object.getString("age");
                                imgname = object.getString("img");
                                photo1 = object.getString("photo1");
                                photo2 = object.getString("photo2");
                                education = object.getString("edu");
                                occupation = object.getString("occu");
                                income = object.getString("ic");
                                height = object.getString("ht");
                                weight = object.getString("wt");
                                blood = object.getString("blood");
                                bdate = object.getString("bdate");
                                degree = object.getString("degree");
                                verified = object.getString("verified");
                                verifiedBy = object.getString("verifiedby");
                                SimpleDateFormat input = new SimpleDateFormat("yyyy-MM-dd");
                                SimpleDateFormat output = new SimpleDateFormat("dd-MM-yyyy");

                                try {
                                    finaldate = input.parse(bdate);
                                } catch (ParseException e) {
                                    e.printStackTrace();
                                }

                                date = output.format(finaldate);
                                btime = object.getString("btime");
                                bplace = object.getString("bplace");
                                father = object.getString("fname");
                                mother = object.getString("mname");
                                /*if (!object.getString("motheroccup").equals("")) {
//                                    mother = object.getString("mname") + ", (" + object.getString("motheroccup") + ")";

                                } else {
                                    mother = object.getString("mname");
                                }*/

                                if (object.has("mail")) {
                                    email = object.getString("mail");
                                }
                                brother = object.getString("bro");
                                sister = object.getString("sis");
                                address = object.getString("addr");
                                contact_person = object.getString("contact_person");
                                contact_person_number = object.getString("contact_person_number");
                                relation = object.getString("relatio");
                                mobile = object.getString("mob");
                                mobile2 = object.getString("mob2");
                                hobbies = object.getString("hb");
                                expect = object.getString("exp");
                                req_status = object.getString("status");
                                Log.d(TAG, "onSuccess: Request status" + req_status);
                                bio_rid = object.getString("rid");
                                //  email = object.getString("email");
                                //Add Details in view
                                actionBar.setTitle(fullname);

                                complexion1 = object.getString("complexion");
                                ras_tithi1 = object.getString("rastithi");
                                religion1 = object.getString("religion");
                                marital1 = object.getString("marital");
                                kulDevta1 = object.getString("kuldaivat");
                                gender = object.getString("gen");
                                motherTongue1 = object.getString("mothertongue");

                                viewFullName.setText(fullname + " ");
                                viewAge.setText(age + " ");

                                if (!blood.equalsIgnoreCase("--- Select Blood Group ---")) {
                                    viewBlood.setText(blood + " ");
                                } else {
                                    viewBlood.setText(" ");
                                }

                                if (blood.equals("-")) {
                                    viewBlood.setText(" ");
                                }

                                viewWeight.setText(weight + " ");
                                viewHeight.setText(height + " ");

                                if (btime.equals("00:00 AM")) {
                                    viewTime.setVisibility(View.GONE);
                                }
                                if (!bdate.equals("0000-00-00")) {
                                    viewDate.setText(date + " ");
                                } else {
                                    viewDate.setText(" ");
                                }
                                viewTime.setText(btime + " ");
                                viewPlace.setText(bplace + " ");
                                viewFather.setText(father + " ");
                                viewMother.setText(mother + " ");
                                viewSister.setText(sister + " ");
                                viewBrother.setText(brother + " ");
                                viewEducation.setText(education + " ");
                                viewOccupation.setText(occupation + " ");
                                viewIncome.setText(income + " ");
                                viewHobbies.setText(hobbies + " ");
                                viewExpectations.setText(expect + " ");
                                viewAddress.setText(address + " ");
                                if (email == null) {
                                    viewEmail.setText("-");
                                } else {
                                    viewEmail.setText(email + " ");
                                }

                                viewContactPerson.setText(contact_person + " ");

                                contactDetailsTextView.setText(Util.getUnderlinedText(getResources().getString(R.string.for_contact_details_please_click_here)));
                                contactDetailsTextView.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        //  loadRewardedVideoAd();
                                        isContactPerson = true;
                                        if (mAd.isLoaded()) {
                                            mAd.show();
                                        } else {
                                            loadRewardedVideoAdv();
                                        }
                                    }
                                });
                                relationAndContactTextView.setText(Util.getUnderlinedText(getResources().getString(R.string.for_contact_numbers_please_click_here)));
                                relationAndContactTextView.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        //Toast.makeText(PersonDesc.this, "123", Toast.LENGTH_LONG).show();
                                        //   loadRewardedVideoAd();
                                        isContactNo = true;
                                        if (mAd.isLoaded()) {
                                            mAd.show();
                                        }
                                    }
                                });

                                viewDegree.setText(degree + " ");
                                viewRelation.setText(relation + " ");
                                viewMobile.setText(mobile + " / " + mobile2);

                                viewComplexion.setText(complexion1 + " ");
                                viewRasTithi.setText(ras_tithi1 + " ");
                                viewReligion.setText(religion1 + " ");
                                viewMarital.setText(marital1 + " ");
                                viewMotherTongue.setText(motherTongue1 + " ");
                                viewKulDevta.setText(kulDevta1 + " ");

                                if (!object.getString("smoking_habits").equals("")) {
                                    viewSmokingHabit.setText(object.getString("smoking_habits"));
                                    viewSmokingHabit.setFocusableInTouchMode(false);
                                } else {
                                    viewSmokingHabit.setText("-");
                                }

                                if (!object.getString("drinking_habits").equals("")) {
                                    viewDrinkingHabit.setText(object.getString("drinking_habits"));
                                    viewDrinkingHabit.setFocusableInTouchMode(false);
                                } else {
                                    viewDrinkingHabit.setText("-");
                                }

                                if (!object.getString("diatary_habits").equals("")) {
                                    viewDietary.setText(object.getString("diatary_habits"));
                                    viewDietary.setFocusableInTouchMode(false);
                                } else {
                                    viewDietary.setText("-");
                                }


                                if (!object.getString("fatheroccup").equals("")) {
                                    viewFatherOccup.setText(object.getString("fatheroccup"));
                                    viewFatherOccup.setFocusableInTouchMode(false);
                                } else {
                                    viewFatherOccup.setText("-");
                                }
                                if (!object.getString("motheroccup").equals("")) {
                                    viewMotherOccup.setText(object.getString("motheroccup"));
                                    viewMotherOccup.setFocusableInTouchMode(false);
                                } else {
                                    viewMotherOccup.setText("-");
                                }

                                if (!object.getString("rel_surname").equals("")) {
                                    viewSurnameInCommunity.setText(object.getString("rel_surname"));
                                    viewSurnameInCommunity.setFocusableInTouchMode(false);
                                } else {
                                    viewSurnameInCommunity.setText("-");
                                }
                                if (!object.getString("city").equals("")) {
                                    viewPresentResCity.setText(object.getString("city"));
                                    viewPresentResCity.setFocusableInTouchMode(false);
                                } else {
                                    viewPresentResCity.setText("-");
                                }

                             /*   if (!object.getString("email").equals("")) {
                                    viewEmail.setText(object.getString("email"));
                                } else {
                                    viewEmail.setText("-");
                                }*/

                                if (gender.equals("0")) {
                                    viewGender.setText("Female" + " ");
                                } else {
                                    viewGender.setText("Male" + " ");
                                }

                                if (verified.equals("1")) {
//                                    tvVerified.setText("Uploaded By: " + verifiedBy);
//                                    tvVerified.setTextColor(Color.parseColor("#ED8A19"));
                                    btnConvertToPremium.setVisibility(View.GONE);
                                    if (request.equalsIgnoreCase("0") || type == 2) {
                                        LinRequest.setVisibility(View.GONE);
                                    }
                                }

                                setEditable();
                                /***************************************************************/
                                imgArray.add(Common.GetProfileImageUrl() + imgname);

                                if (!photo1.equals("img1.png")) {
                                    if (!photo1.equals("")) {
                                        imgArray.add(Common.GetProfileImageUrl() + photo1);
                                    }
                                }
                                if (!photo2.equals("img1.png")) {
                                    if (!photo2.equals("")) {
                                        imgArray.add(Common.GetProfileImageUrl() + photo2);
                                    }
                                }

                                if (req_status.equals("2")) {
                                    viewMobile.setVisibility(View.VISIBLE);
                                    viewcontact.setVisibility(View.VISIBLE);
                                } else {
                                    viewMobile.setVisibility(View.GONE);
                                    viewcontact.setVisibility(View.GONE);
                                }

                                checkPremiumButton(object);

                                if (bio_rid.equals(Utils.getString(ctx, Constants.USER_ID))) {
                                    txtsendinv.setVisibility(View.GONE);
                                    btnConvertToPremium.setVisibility(View.VISIBLE);

                                    checkPremiumButton(object);

                                } else {
                                    btnConvertToPremium.setVisibility(View.GONE);
                                    if (LinRequest.getVisibility() == View.GONE) {
                                        if (req_status.equals("0")) {
                                            txtsendinv.setVisibility(View.VISIBLE);
                                            txtsendinv.setText("Send Request");
                                            txtsendinv.setEnabled(true);
                                        } else {
                                            txtsendinv.setText("Request Already Sent");
                                            txtsendinv.setEnabled(false);
                                        }
                                    }
                                }

                                tvImagesCount.setText(String.valueOf(imgArray.size()) + " Images");
                                setDecoration(imgArray);
                                SimpleDateFormat fromUser = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                SimpleDateFormat myFormat = new SimpleDateFormat("MMM dd, yyyy");
                                String reformattedStr = "";
                                String pay_date = object.getString("pay_date");
                                try {
                                    reformattedStr = myFormat.format(fromUser.parse(pay_date));
                                } catch (ParseException e) {
                                    e.printStackTrace();
                                }

                                String uploadedBy = object.getString("rid_name");
                                String is_address_uploaded = object.getString("is_address");
                                tvVerified.setText("Uploaded: " + uploadedBy);
                                addressUploaded.setText("Address upload: " + is_address_uploaded);

//                                tvVerified.setTextColor(Color.parseColor("#ED8A19"));

                                int is_paid = object.getInt("is_paid");
                                if (is_paid == 0) {
                                    tvIsPaid.setText("Payment verified: No");
                                    tvIsPaid.setTextColor(Color.parseColor("#ED8A19"));
                                } else {
                                    tvIsPaid.setText("Payment verified: Yes");
                                    tvIsPaid.setTextColor(Color.parseColor("#71E158"));
                                }

                                tvPublishedOn.setText("Published: " + reformattedStr);


                                try {
                                    if (!object.getString("occDetails").equals("")) {
                                        txtOccDetails.setText(object.getString("occDetails"));
                                    } else {
                                        txtOccDetails.setText("-");
                                    }
                                } catch (Exception e) {
                                    txtOccDetails.setText("-");
                                    e.printStackTrace();
                                }
                                try {
                                    if (!object.getString("relatives").equals("")) {
                                        viewRelatives.setText(object.getString("relatives"));
                                    } else {
                                        viewRelatives.setText("-");
                                    }
                                } catch (Exception e) {
                                    viewRelatives.setText("-");
                                    e.printStackTrace();
                                }

                                try {
                                    if (!object.getString("relative_who_knows").equals("")) {
                                        viewRelativesWhoKnows.setText(object.getString("relative_who_knows"));
                                    } else {
                                        viewRelativesWhoKnows.setText("-");
                                    }
                                } catch (Exception e) {
                                    viewRelativesWhoKnows.setText("-");
                                    e.printStackTrace();
                                }
                                try {
                                    if (!object.getString("nativeplace").equals("")) {
                                        viewNativePlace.setText(object.getString("nativeplace"));
                                    } else {
                                        viewNativePlace.setText("-");
                                    }
                                } catch (Exception e) {
                                    viewNativePlace.setText("-");
                                    e.printStackTrace();
                                }

                                /*lblpincome.setText(income);
                                lblpname.setText(fullname);
                                lblpage.setText(age);
                                lblpedu.setText(education);
                                lblpocu.setText(occupation);
                                lblpheight.setText(height
                                        + " / " + weight
                                        + " / " + blood);
                                lblpdob_dt.setText(bdate
                                        + " " + btime);
                                lblpdob_place.setText(bplace);
                                lblpfather.setText(father);
                                lblpmother.setText(mother);
                                lblp_bro.setText(brother);
                                lblp_sis.setText(sister);
                                lblpaddress.setText(address);
                                lblpcontact.setText(contact_person + "( " + relation + " )" +
                                        "\n" + mobile);
                                lblphobbies.setText(hobbies);
                                lblpexpectations.setText(expect);*/
                                hidePDialog();
                            }
                            hidePDialog();
                        }
                        hidePDialog();
                    }
                } catch (JSONException e) {
                    hidePDialog();
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

            }
        });
    }

    private void checkPremiumButton(JSONObject object) {
        try {
            if (object.getString("is_premium").equals("1")) {
                btnConvertToPremium.setVisibility(View.GONE);
            } else {
                btnConvertToPremium.setVisibility(View.VISIBLE);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void setEditable() {
        viewFullName.setEnabled(false);
        viewAge.setEnabled(false);
        viewBlood.setEnabled(false);
        viewWeight.setEnabled(false);
        viewHeight.setEnabled(false);
        viewDate.setEnabled(false);
        viewTime.setEnabled(false);
        viewPlace.setEnabled(false);
        viewFather.setEnabled(false);
        viewMother.setEnabled(false);
        viewSister.setEnabled(false);
        viewBrother.setEnabled(false);
        viewEducation.setEnabled(false);
        viewOccupation.setEnabled(false);
        viewIncome.setEnabled(false);
        viewHobbies.setEnabled(false);
        viewExpectations.setEnabled(false);
        viewAddress.setEnabled(false);
        viewEmail.setEnabled(false);
        viewContactPerson.setEnabled(false);
        viewRelation.setEnabled(false);
        viewMobile.setEnabled(false);
        viewDegree.setEnabled(false);

        viewComplexion.setEnabled(false);
        viewRasTithi.setEnabled(false);
        viewReligion.setEnabled(false);
        viewMarital.setEnabled(false);
        viewMotherTongue.setEnabled(false);
        viewKulDevta.setEnabled(false);
        viewGender.setEnabled(false);
    }

    private void allocateMemory() {
        // pimage = findViewById(R.id.pimage);
        /*lblpname = findViewById(R.id.lblpname);
        lblpage = findViewById(R.id.lblpage);
        lblpedu = findViewById(R.id.lblpedu);
        lblpocu = findViewById(R.id.lblpocu);
        lblpincome = findViewById(R.id.lblpincome);
        lblpheight = findViewById(R.id.lblpheight);
        lblpdob_dt = findViewById(R.id.lblpdob_dt);
        lblpdob_place = findViewById(R.id.lblpdob_place);
        lblpfather = findViewById(R.id.lblpfather);
        lblpmother = findViewById(R.id.lblpmother);
        lblp_bro = findViewById(R.id.lblp_bro);
        lblp_sis = findViewById(R.id.lblp_sis);
        lblpaddress = findViewById(R.id.lblpaddress);
        lblpcontact = findViewById(R.id.lblpcontact);
        lblphobbies = findViewById(R.id.lblphobbies);
        lblpexpectations = findViewById(R.id.lblpexpectations);*/
        LinRequest = findViewById(R.id.LinRequest);
        btnReqAccept = findViewById(R.id.btnReqAccept);
        btnReqReject = findViewById(R.id.btnReqReject);
        txtsendinv = findViewById(R.id.txtsendinv);
        contactDetailsTextView = findViewById(R.id.contactDetailsTextView);
        relationAndContactTextView = findViewById(R.id.relationAndContactTextView);
        imgArray = new ArrayList<>();

        //IMAGE SLIDER
        vpImage = findViewById(R.id.vpImage);
//        fabShareBioData = findViewById(R.id.fabShareBioData);
        tabLayout = findViewById(R.id.tabLayout);
        tvImagesCount = findViewById(R.id.tvImagesCount);

        viewFullName = findViewById(R.id.viewFullName);
        tvVerified = findViewById(R.id.tvVerified);
        tvIsPaid = findViewById(R.id.tvIsPaid);
        tvPublishedOn = findViewById(R.id.tvPublishedOn);
        addressUploaded = findViewById(R.id.addressUploaded);
        viewAge = findViewById(R.id.viewAge);
        viewBlood = findViewById(R.id.viewBlood);
        viewWeight = findViewById(R.id.viewWeight);
        viewHeight = findViewById(R.id.viewHeight);
        viewTime1 = findViewById(R.id.viewTime1);
        viewcontact = findViewById(R.id.viewcontact);
        viewDate = findViewById(R.id.viewDate);
        viewTime = findViewById(R.id.viewTime);
        viewPlace = findViewById(R.id.viewPlace);

        viewFather = findViewById(R.id.viewFather);
        viewMother = findViewById(R.id.viewMother);
        viewSister = findViewById(R.id.viewSister);
        viewBrother = findViewById(R.id.viewBrother);

        viewEducation = findViewById(R.id.viewEducation);
        viewOccupation = findViewById(R.id.viewOccupation);
        viewIncome = findViewById(R.id.viewIncome);
        viewHobbies = findViewById(R.id.viewHobbies);
        viewExpectations = findViewById(R.id.viewExpectations);

        viewAddress = findViewById(R.id.viewAddress);
        viewEmail = findViewById(R.id.viewEmail);
        viewDegree = findViewById(R.id.viewDegree);
        viewContactPerson = findViewById(R.id.viewContactPerson);
        setMaskFilter(viewContactPerson);
        viewRelation = findViewById(R.id.viewRelation);
        setMaskFilter(viewRelation);
        viewMobile = findViewById(R.id.viewMobile);

        viewComplexion = findViewById(R.id.viewComplexion);
        viewRasTithi = findViewById(R.id.viewRasTithi);
        viewReligion = findViewById(R.id.viewReligion);
        viewMarital = findViewById(R.id.viewMarital);
        viewMotherTongue = findViewById(R.id.viewMotherTongue);
        viewKulDevta = findViewById(R.id.viewKulDevta);
        viewGender = findViewById(R.id.viewGender);
        viewSmokingHabit = findViewById(R.id.viewSmokingHabit);
        viewDrinkingHabit = findViewById(R.id.viewDrinkingHabit);
        viewDietary = findViewById(R.id.viewDietary);
        txtOccDetails = findViewById(R.id.txtOccDetails);
        viewRelatives = findViewById(R.id.viewRelatives);
        viewRelativesWhoKnows = findViewById(R.id.viewRelativesWhoKnows);
        viewNativePlace = findViewById(R.id.viewNativePlace);
        viewFatherOccup = findViewById(R.id.viewFatherOccup);
        viewMotherOccup = findViewById(R.id.viewMotherOccup);
        viewSurnameInCommunity = findViewById(R.id.viewSurnameInCommunity);
        viewPresentResCity = findViewById(R.id.viewPresentResCity);

        btnConvertToPremium = findViewById(R.id.btnConvertToPremium);


    }

    private void setMaskFilter(TextView textView) {
        if (Build.VERSION.SDK_INT >= 11) {
            textView.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }
        float radius = textView.getTextSize() / 3;
        BlurMaskFilter filter = new BlurMaskFilter(radius, BlurMaskFilter.Blur.NORMAL);
        textView.getPaint().setMaskFilter(filter);
    }

    // show process Dialog box
    private void showpDialog() {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }

    // hide process Dialog box
    private void hidePDialog() {
        if (this.pDialog != null) {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }

    public void shareItem(String url) {
        Log.e("ShareImageUrl", url);
        Picasso.with(getApplicationContext()).load(url).into(new Target() {
            @Override
            public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
                final String appPackageName = getPackageName();
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("image/*");
                String sharetext = "Name: " + fullname + "\nAge: " + age +
                        "\nHeight: " + height + "\nIncome: " + income +
                        "\nEducation: " + education + "\nOccupation: " + occupation +
                        "\nCity: " + viewPresentResCity.getText().toString() +
                        "\n\nfor more details click on below link to download app. \nhttps://play.google.com/store/apps/details?id=" + appPackageName;
                i.putExtra(Intent.EXTRA_STREAM, getLocalBitmapUri(bitmap));
                i.putExtra(Intent.EXTRA_TEXT, sharetext);
                startActivity(Intent.createChooser(i, "Share Bio-Data Using : "));
                Log.d(TAG, "onBitmapLoaded: " + sharetext);
            }

            @Override
            public void onBitmapFailed(Drawable errorDrawable) {
            }

            @Override
            public void onPrepareLoad(Drawable placeHolderDrawable) {
            }
        });
    }

    public Uri getLocalBitmapUri(Bitmap bmp) {
        Uri bmpUri = null;
        try {
            File file = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES)
                    , "share_image_" + System.currentTimeMillis() + ".png");
            FileOutputStream out = new FileOutputStream(file);
            bmp.compress(Bitmap.CompressFormat.PNG, 100, out);
            out.close();
//            bmpUri = Uri.fromFile(file);
            bmpUri = FileProvider.getUriForFile(PersonDesc.this, BuildConfig.APPLICATION_ID + ".provider", file);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return bmpUri;
    }

   /* public void setupToolbar() {
        toolbar = getSupportActionBar();
        assert toolbar != null;
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);
    }*/

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if (checkstatus.equals("1")) {
            getMenuInflater().inflate(R.menu.menu_edit_bio, menu);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (android.R.id.home == item.getItemId()) {
            finish();
        }

        int itemId = item.getItemId();
        if (itemId == R.id.edtbio) {
            Intent intent = new Intent(ctx, UpdateBiodata.class);
            intent.putExtra("bid", id);
            intent.putExtra("rid", Utils.getString(ctx, Constants.USER_ID));
            startActivity(intent);

        } else if (itemId == R.id.deletebio) {

            final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(ctx);
            builder.setIcon(R.drawable.ic_remove_blue);
            builder.setTitle("Delete Bio-Data");
            builder.setMessage("Do you want to Delete Bio-Data?");

            builder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    deleteBiodata(id, Utils.getString(ctx, Constants.USER_ID));
                }
            });
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                    dialog.dismiss();
                }
            });
            builder.show();
        }
        return super.onOptionsItemSelected(item);
    }

    public void deleteBiodata(String biodataid, String rid) {
        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        RequestParams params = new RequestParams();
        params.put("rid", rid);
        params.put("biodataid", biodataid);
        Utils.log(TAG, "DELETE_BIO-DATA_URL : " + Constants.DELETE_BIODATA + "?" + params);
        client.post(Constants.DELETE_BIODATA, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                Utils.log(TAG, "DELETE_BIO-DATA_RESPONSE : " + response);
                Toast.makeText(ctx, "Bio Data Delete Successful", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(PersonDesc.this, MyPosts.class).putExtra("from", "dashboard")
                        .putExtra("gender", "-1"));
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Toast.makeText(ctx, "Something Went Wrong", Toast.LENGTH_SHORT).show();
            }
        });
    }


    public void sendRequest(String bid, String rid) {
        WebServiceCaller.getClient().sendRequest(rid, bid).enqueue(new Callback<RegisterModel>() {
            @Override
            public void onResponse(Call<RegisterModel> call, retrofit2.Response<RegisterModel> response) {
                if (response.isSuccessful()) {
                    String res = new String(String.valueOf(response));
                    Utils.log(TAG, "RESPONSE  : " + res);
                    RegisterModel registerModel;
                    registerModel = response.body();
                    if (registerModel.getSuccess()) {
                        Toast.makeText(ctx, "Request Sent Successful", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(PersonDesc.this, InvitationSent.class)
                                .putExtra("from", "dashboard_invitation_sent"));
                        txtsendinv.setEnabled(false);
                        txtsendinv.setText("Request Already Sent");
                    } else {
                        Toast.makeText(ctx, registerModel.getMsg(), Toast.LENGTH_SHORT).show();
                        txtsendinv.setEnabled(true);
                    }
                }
                dialog.dismiss();

            }

            @Override
            public void onFailure(Call<RegisterModel> call, Throwable t) {
                //swipeContainer.setRefreshing(false)
                //
                dialog.dismiss();
                Log.d("Error_Message", t.getMessage());

                Toast.makeText(PersonDesc.this, "Server Error  :   " + t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

        /*AsyncHttpClient client = new AsyncHttpClient(true, 80, 433);
        RequestParams params = new RequestParams();
        params.put("rid", rid);
        params.put("bid", bid);
        Utils.log(TAG, "REQ_SEND_BIO-DATA_URL : " + Constants.BIO_REQ_SEND + "?" + params);
        client.get(Constants.BIO_REQ_SEND + "?" + params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                dialog.dismiss();
                Utils.log(TAG, "REQ_SEND_BIO-DATA_RESPONSE : " + response);
                String success = "", msg = "";
                try {
                    JSONObject object = new JSONObject(response);
                    success = object.getString("success");
                    msg = object.getString("msg");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (success.equals("true")) {
                    Toast.makeText(ctx, "Request Sent Successful", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(PersonDesc.this, InvitationSent.class)
                            .putExtra("from", "dashboard_invitation_sent"));
                    txtsendinv.setEnabled(true);
                }
                if (success.equals("false")) {
                    Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show();
                    txtsendinv.setEnabled(true);
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Toast.makeText(ctx, error.getMessage(), Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        });*/
    }


    public void sendRequest_frombid(String bid, String rid, String from_bid, final Dialog alertDialog__) {
        WebServiceCaller.getClient().sendRequest_from(rid, bid, from_bid).enqueue(new Callback<RegisterModel>() {
            @Override
            public void onResponse(Call<RegisterModel> call, retrofit2.Response<RegisterModel> response) {
                if (response.isSuccessful()) {
                    String res = new String(String.valueOf(response));
                    Utils.log(TAG, "RESPONSE  : " + res);
                    RegisterModel registerModel;
                    registerModel = response.body();
                    if (registerModel.getSuccess()) {
                        Toast.makeText(ctx, "Request Sent Successful", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(PersonDesc.this, InvitationSent.class)
                                .putExtra("from", "dashboard_invitation_sent"));
                        txtsendinv.setEnabled(false);
                        txtsendinv.setText("Request Already Sent");
                    } else {
                        Toast.makeText(ctx, registerModel.getMsg(), Toast.LENGTH_SHORT).show();
                        txtsendinv.setEnabled(true);
                    }
                }
                alertDialog__.dismiss();

            }

            @Override
            public void onFailure(Call<RegisterModel> call, Throwable t) {
                //swipeContainer.setRefreshing(false)
                //
                dialog.dismiss();
                Log.d("Error_Message", t.getMessage());

                Toast.makeText(PersonDesc.this, "Server Error  :   " + t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

    }

    private void openDialog() {
        final Dialog alertDialog = new Dialog(PersonDesc.this);
        alertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LayoutInflater inflater = getLayoutInflater();
        View alert = inflater.inflate(R.layout.dialog_contact_person, null, false);
        alertDialog.setContentView(alert);

        final AdView adViewHome = alertDialog.findViewById(R.id.adViewHome);
        AdRequest adRequest = new AdRequest.Builder().build();

        adViewHome.loadAd(adRequest);
        adViewHome.setVisibility(View.VISIBLE);
//        final RelativeLayout bannerLayout = alertDialog.findViewById(R.id.bannerLayout);
        final ImageView closeImgView = alertDialog.findViewById(R.id.closeImgView);
        final ImageView copyImageView = alertDialog.findViewById(R.id.copyImageView);
        final ImageView callImageView = alertDialog.findViewById(R.id.callImageView);
        final ImageView shareImageView = alertDialog.findViewById(R.id.shareImageView);
        final LinearLayout contactDetailLayout = alertDialog.findViewById(R.id.contactDetailLayout);
        final LinearLayout contactNoLinearLayout = alertDialog.findViewById(R.id.contactNoLinearLayout);
        final TextInputEditText viewContactPerson = alertDialog.findViewById(R.id.viewContactPerson);
        final TextInputLayout contactPersonTextInput = alertDialog.findViewById(R.id.contactPersonTextInput);
        final TextInputEditText contactNo = alertDialog.findViewById(R.id.contactNo);
        final RelativeLayout bannerLayout = alertDialog.findViewById(R.id.bannerLayout);
        final View contactView = alertDialog.findViewById(R.id.contactView);
        final View contactPersonView = alertDialog.findViewById(R.id.contactPersonView);

        viewContactPerson.setText(contact_person);
        contactNo.setText(relation);

        if (isContactPerson) {
            contactView.setVisibility(View.GONE);
            contactNoLinearLayout.setVisibility(View.GONE);
            contactPersonView.setVisibility(View.VISIBLE);
            contactPersonTextInput.setVisibility(View.VISIBLE);
            isContactPerson = false;
        }
        if (isContactNo) {
            contactPersonView.setVisibility(View.GONE);
            contactPersonTextInput.setVisibility(View.GONE);
            contactView.setVisibility(View.VISIBLE);
            contactNoLinearLayout.setVisibility(View.VISIBLE);
            isContactNo = false;
        }

        closeImgView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.cancel();
            }

        });

        copyImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("label", relation);
                clipboard.setPrimaryClip(clip);
                Toast.makeText(ctx, "Phone No. is copied.", Toast.LENGTH_SHORT).show();
            }
        });

        callImageView.setOnClickListener(view -> {

            String[] phoneNo = relation.split(" ");
            String phNo = "";
            for (int i = 0; i < phoneNo.length; i++) {
                if (!TextUtils.isEmpty(phoneNo[i]) && phoneNo[i].length() == 10) {
                    try {
                        Long.parseLong(phoneNo[i]);
                        phNo = phoneNo[i];
                        break;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
            if (!TextUtils.isEmpty(phNo)) {
                Intent intent = new Intent(Intent.ACTION_CALL);
                intent.setData(Uri.parse("tel:" + phNo));
                startActivity(intent);
            } else {
                Toast.makeText(ctx, "Not a valid phone number.", Toast.LENGTH_SHORT).show();
            }
        });

        shareImageView.setOnClickListener(view -> {
            Intent intent = new Intent(android.content.Intent.ACTION_SEND);
            String shareBody = "Share Phone Number";
            intent.setType("text/plain");
            intent.putExtra(android.content.Intent.EXTRA_TEXT, relation);
            /*Fire!*/
            startActivity(Intent.createChooser(intent, "Share Using"));
        });

        alertDialog.show();
    }

   /* private void loadRewardedAd()
    {
        // Creating  an Ad Request
        AdRequest adRequest = new AdRequest.Builder().build();

        // load Rewarded Ad with the Request
        rewardedAd.loadAd(adRequest, rewardedAdLoadCallback);

        // Showing a simple Toast message to user when Rewarded an ad is Loading
        Toast.makeText (PersonDesc.this, "Rewarded Ad is loading ", Toast.LENGTH_LONG).show();
    }*/

    /* private void showRewardedAd() {
         if (rewardedAd.isLoaded()) {

             //creating the Rewarded Ad Callback and showing the user appropriate message
             rewardedAdCallback = new RewardedAdCallback() {@Override
             public void onRewardedAdOpened() {
                 // Showing a simple Toast message to user when Rewarded Ad is opened
               //  Toast.makeText(PersonDesc.this, "Rewarded Ad is Opened", Toast.LENGTH_LONG).show();
             }

                 @Override
                 public void onRewardedAdClosed() {
                     // Showing a simple Toast message to user when Rewarded Ad is closed
                  //   Toast.makeText(PersonDesc.this, "Rewarded Ad Closed", Toast.LENGTH_LONG).show();

                 }

                 @Override
                 public void onUserEarnedReward(RewardItem reward) {
                     // Showing a simple Toast message to user when user earned the reward by completely watching the Rewarded Ad
                //     Toast.makeText(PersonDesc.this, "You won the reward :" + reward.getAmount(), Toast.LENGTH_LONG).show();

                 }

                 @Override
                 public void onRewardedAdFailedToShow(int i) {
                     super.onRewardedAdFailedToShow(i);
                 }
             };

             //showing the ad Rewarded Ad if it is loaded
             rewardedAd.show(PersonDesc.this, rewardedAdCallback);

             // Showing a simple Toast message to user when an Rewarded ad is shown to the user
          //   Toast.makeText(PersonDesc.this, "Rewarded Ad  is loaded and Now showing ad  ", Toast.LENGTH_LONG).show();

         }
         else {
             //Load the Rewarded ad if it is not loaded
             loadRewardedAd();

             // Showing a simple Toast message to user when Rewarded ad is not loaded
           //  Toast.makeText(PersonDesc.this, "Rewarded Ad is not Loaded ", Toast.LENGTH_LONG).show();

         }


     }
 */
    void setAdapter() {
        personAdapter = new PersonAdapter(ctx, arr_adapter, RidFrom, 0, true);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        rcvpersonlist.setLayoutManager(mLayoutManager);
        rcvpersonlist.setAdapter(personAdapter);
    }

    public void getMyPosts() {
        pDialog = new ProgressDialog(ctx);
        pDialog.setMessage("Please wait...");
        pDialog.setCancelable(false);
        showpDialog();
        String WebServiceUrl = Common.GetWebServiceUrl() + "person_list.php";

        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        RequestParams params = new RequestParams();
        params.put("rid", Utils.getString(ctx, Constants.USER_ID));
        params.put("gender", "-1");
        params.put("gid", Gid);

        client.post(WebServiceUrl, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                Log.d("trace response", res);
                try {
                    JSONArray response = new JSONArray(res);
                    String error = response.getJSONObject(0).getString("error");
                    if (error.equals("no error") == false) {
                        Common.showDialog(ctx);
                    } else {
                        arr_adapter.clear();
                        int total = response.getJSONObject(1).getInt("total");
                        if (total == 0) {
                            Toast.makeText(ctx, "No biodata uploaded.Please upload your biodata to send invitation.", Toast.LENGTH_SHORT).show();
                        } else {
                            int size = response.length();
                            for (int i = 2; i < size; i++) //3
                            {
                                JSONObject object = response.getJSONObject(i);
                                personGetSet = new PersonGetSet();
                                personGetSet.setId(object.getString("id"));
                                personGetSet.setName(object.getString("name"));
                                personGetSet.setAge(object.getString("age"));
                                personGetSet.setEducation(object.getString("edu"));
                                personGetSet.setOccupation(object.getString("occu"));
                                personGetSet.setImage(object.getString("photo"));
                                personGetSet.setVerified(object.getString("verified"));
                                personGetSet.setGender(object.getString("gen"));
                                personGetSet.setPay_date(object.getString("pay_date"));
                                personGetSet.setRid_name(object.getString("rid_name"));
                                personGetSet.setIs_premium(object.getString("is_premium"));
                                //setAdapter();

                                arr_adapter.add(personGetSet);
                            }
                            sendVerified();
                            hidePDialog();
                        }
                        hidePDialog();
                    }
                    hidePDialog();

                } catch (JSONException e) {
                    hidePDialog();
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

            }
        });
    }


    private void sendVerified() {

        final Dialog alertDialog = new Dialog(ctx);
        LayoutInflater inflater = getLayoutInflater();
        View convertView = (View) inflater.inflate(R.layout.layout_bio_request, null);
        alertDialog.setContentView(convertView);
        alertDialog.setCancelable(false);
        alertDialog.setTitle("Send request to publish");
        RecyclerView recyclerView = convertView.findViewById(R.id.rcvMemberList);
        LinearLayout LinSendRequest = convertView.findViewById(R.id.LinSendRequest);
        Button btnCancel = convertView.findViewById(R.id.btn);
        Button btnSend = convertView.findViewById(R.id.btnSend);
        final EditText txt_search_mname = convertView.findViewById(R.id.txt_search_mname);


        /*final AlertDialog dialog = alertDialog.create();*/
        alertDialog.show();

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.dismiss();
            }
        });


        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendRequest_frombid(id, Utils.getString(ctx, Constants.USER_ID), personAdapter.getSelectedValue(), alertDialog);
            }
        });

       /* alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
*/
        /*alertDialog.setPositiveButton("Send to Publish", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });*/
        personAdapter = new PersonAdapter(ctx, arr_adapter, "sendBioRequest", 0, true);
        recyclerView.setLayoutManager(new LinearLayoutManager(ctx));
        recyclerView.setAdapter(personAdapter);
        alertDialog.setCancelable(false);

    }

    private void dismissAlert(AlertDialog dialog) {
        dialog.dismiss();
    }

    @Override
    public void onRewardedVideoAdLoaded() {
        Log.d(TAG, "Rewarded: onRewardedVideoAdLoaded");
    }

    @Override
    public void onRewardedVideoAdOpened() {
        Log.d(TAG, "Rewarded: onRewardedVideoAdOpened");
    }

    @Override
    public void onRewardedVideoStarted() {
        Log.d(TAG, "Rewarded: onRewardedVideoStarted");
    }

    @Override
    public void onRewardedVideoAdClosed() {
        Log.d(TAG, "Rewarded: onRewardedVideoAdClosed");
//        openDialog();
//        Toast.makeText(ctx, "To see contact details continue video", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRewarded(com.google.android.gms.ads.reward.RewardItem rewardItem) {
        Log.i(TAG, "Rewarded:  onRewarded! currency: " + rewardItem.getType() + "  amount: " +
                rewardItem.getAmount());
        openDialog();
    }

    @Override
    public void onRewardedVideoAdLeftApplication() {
        Log.i(TAG, "Rewarded: onRewardedVideoAdLeftApplication ");
    }

    @Override
    public void onRewardedVideoAdFailedToLoad(int i) {
        Log.i(TAG, "Rewarded: onRewardedVideoAdFailedToLoad: " + i);
    }

    @Override
    public void onRewardedVideoCompleted() {
        Log.i(TAG, "Rewarded: onRewardedVideoCompleted: ");
    }
}
