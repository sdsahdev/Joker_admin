package com.suguretaventure.mymarriagegroup.utils;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;

import com.google.gson.Gson;

/**
 * Created by SPARROW on 4/24/2018.
 */

public class Utility {

    public static boolean isNetworkAvailable(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    public static <T> T Gson(String response, Class<T> typeClass) {
        return new Gson().fromJson(response, typeClass);
    }

    public static void log(String TAG, String Message) {
        /*Log.d(TAG, Message);*/
    }
}
