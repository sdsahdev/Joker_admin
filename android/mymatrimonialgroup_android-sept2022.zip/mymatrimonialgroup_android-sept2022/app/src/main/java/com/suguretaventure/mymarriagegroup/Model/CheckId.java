package com.suguretaventure.mymarriagegroup.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CheckId {
    @SerializedName("error")
    @Expose
    private String error;

    @SerializedName("success")
    @Expose
    private String success;

    @SerializedName("message")
    @Expose
    private String msg;

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public String getSuccess() {
        return success;
    }

    public void setSuccess(String success) {
        this.success = success;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
