package com.suguretaventure.mymarriagegroup;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.suguretaventure.mymarriagegroup.Model.AddGroupModel;
import com.suguretaventure.mymarriagegroup.common.AppController;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.common.NetworkConnetionState;
import com.suguretaventure.mymarriagegroup.imageresize.core.ImageCompressTask;
import com.suguretaventure.mymarriagegroup.imageresize.listeners.IImageCompressTaskListener;
import com.suguretaventure.mymarriagegroup.imageresize.util.Util;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.ExifUtil;
import com.suguretaventure.mymarriagegroup.utils.Utility;
import com.suguretaventure.mymarriagegroup.utils.Utils;
import com.suguretaventure.mymarriagegroup.utils.WebServiceCaller;
import com.wafflecopter.multicontactpicker.ContactResult;
import com.wafflecopter.multicontactpicker.LimitColumn;
import com.wafflecopter.multicontactpicker.MultiContactPicker;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;

import static com.suguretaventure.mymarriagegroup.utils.ExifUtil.rotate;

public class MyProfile extends AppCompatActivity {
    private String TAG = "MY_PROFILE";
    Context ctx = this;
    private TextView lblupdateprofile, lblprofilename, lblprofileemail, lblprofilemobile, tvChangePassword;
    private ProgressDialog pDialog;
    private ImageView imgprofileimg, myProfileAddress, copyImageView, callImageView, shareImageView;
    ActionBar toolbar;
    AlertDialog aldialog;
    //Create Group
    private String CameraFileAbsolutePath;
    private ImageView imgphotoid, imgphotoid_select;
    private static final int READ_CONTACT_REQUEST = 1;
    private static final int CONTACT_PICKER_REQUEST = 2;
    private static final int GALLARY = 1;
    private static final int CAMERA = 2;
    private static final int REQUEST_MULTIPLE_PERMISSION = 100;
    String gid = "";
    String imageUrl = "";
    private List<ContactResult> mContacts = new ArrayList<>();
    private ExecutorService mExecutorService = Executors.newFixedThreadPool(1);
    private ImageCompressTask imageCompressTask;
    private FirebaseAnalytics mFirebaseAnalytics;
    private LayoutInflater inflater;

    private IImageCompressTaskListener iImageCompressTaskListener = new IImageCompressTaskListener() {
        @Override
        public void onComplete(List<File> compressed) {
            File file = compressed.get(0);
            imgphotoid.setImageBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()));

        }

        @Override
        public void onError(Throwable error) {
        }
    };
    Bundle bundle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_profile);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        bundle = getIntent().getExtras();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        getSupportActionBar().setTitle(getResources().getString(R.string.app_name_title));

        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
//        setupToolbar();
        allocateMemory();
        if (bundle.getBoolean("flagDetail")) {
            getSupportActionBar().setTitle("Details");
            lblupdateprofile.setVisibility(View.GONE);
            tvChangePassword.setVisibility(View.GONE);
        } else {
            getSupportActionBar().setTitle("My Profile");
            lblupdateprofile.setVisibility(View.VISIBLE);
            tvChangePassword.setVisibility(View.GONE);
        }
        if (new NetworkConnetionState().isNetworkAvailable(ctx)) {
            getProfileDetail();
        } else {
            networkAlert();
        }
        setListeners();
    }

    private void setListeners() {
        lblupdateprofile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ctx, ProfileUpdateActivity.class));
            }
        });
        tvChangePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ctx, ChangePassword.class));
            }
        });

        imgprofileimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(MyProfile.this);
                inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                View dialogLayout = inflater.inflate(R.layout.personimage_dialog, null);
                ImageView imgtabledesc = (ImageView) dialogLayout.findViewById(R.id.imgtabledesc);
                builder.setView(dialogLayout);
                Glide.with(MyProfile.this)
                        .load(imageUrl)
                        .placeholder(R.drawable.app_logo_new)
                        .into(imgtabledesc);
                Dialog dialog = builder.create();
                dialog.setCancelable(true);
                dialog.show();
            }
        });

        copyImageView.setOnClickListener(view -> {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            ClipData clip = ClipData.newPlainText("label", lblprofilemobile.getText().toString());
            clipboard.setPrimaryClip(clip);
            Toast.makeText(MyProfile.this, "Phone No. is copied.", Toast.LENGTH_SHORT).show();
        });

        callImageView.setOnClickListener(view -> {
            String[] phoneNo = lblprofilemobile.getText().toString().split(" ");
            String phNo = "";
            for (int i = 0; i < phoneNo.length; i++) {
                if (!TextUtils.isEmpty(phoneNo[i]) && phoneNo[i].length() == 10) {
                    try {
                        Long.parseLong(phoneNo[i]);
                        phNo = phoneNo[i];
                        break;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
            if (!TextUtils.isEmpty(phNo)) {
                Intent intent = new Intent(Intent.ACTION_CALL);
                intent.setData(Uri.parse("tel:" + phNo));
                startActivity(intent);
            } else {
                Toast.makeText(MyProfile.this, "Not a valid phone number.", Toast.LENGTH_SHORT).show();
            }
        });

        shareImageView.setOnClickListener(view -> {
            Intent intent = new Intent(android.content.Intent.ACTION_SEND);
            String shareBody = "Share Phone Number";
            intent.setType("text/plain");
            intent.putExtra(android.content.Intent.EXTRA_TEXT, lblprofilemobile.getText().toString());
            /*Fire!*/
            startActivity(Intent.createChooser(intent, "Share Using"));
        });
    }

    private void networkAlert() {
        AlertDialog.Builder b1 = new AlertDialog.Builder(ctx);
        b1.setTitle("Network Error");
        b1.setMessage("No internet connection found. Please check your phone settings to turn on the internet.");
        b1.setPositiveButton("Retry", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (new NetworkConnetionState().isNetworkAvailable(ctx)) {
                    getProfileDetail();
                } else {
                    networkAlert();
                }
            }
        });
        b1.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        b1.create().show();
    }

    public void getProfileDetail() {
        pDialog = new ProgressDialog(ctx);
        pDialog.setMessage("Please wait...");
        pDialog.setCancelable(false);
        //showpDialog();

        String WebServiceUrl = "";
        if (bundle.getBoolean("flagDetail")) {
            WebServiceUrl = Common.GetWebServiceUrl() + "myprofile.php?rid=" + bundle.getString("rId");
        } else {
            WebServiceUrl = Common.GetWebServiceUrl() + "myprofile.php?rid=" + Utils.getString(ctx, Constants.USER_ID);
        }
        Utils.log(TAG, "URL : " + WebServiceUrl);
        JsonArrayRequest request = new JsonArrayRequest(WebServiceUrl, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                Utils.log(TAG, response.toString());
                for (int i = 0; i < response.length(); i++) {
                    try {
                        JSONObject obj = response.getJSONObject(i);
                        lblprofilename.setText(obj.getString("name") + " " + obj.getString("sname"));
                        lblprofilemobile.setText(obj.getString("mob"));
                        lblprofileemail.setText(obj.getString("email"));


                        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                        StrictMode.setThreadPolicy(policy);


                        imageUrl = obj.getString("url") + obj.getString("photo");
                        Glide.with(MyProfile.this)
                                .load(obj.getString("url") + obj.getString("photo"))
                                .apply(RequestOptions.circleCropTransform()).into(imgprofileimg);

                        Glide.with(MyProfile.this)
                                .load(obj.getString("url1") + obj.getString("addr"))
                                .into(myProfileAddress);

                        hidePDialog();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                hidePDialog();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                hidePDialog();
                Utils.log(TAG, error.getMessage().toString());
                Common.showDialog(ctx);
            }
        });
        request.setRetryPolicy(new DefaultRetryPolicy(2000, 3, 1));
        AppController.getInstance().addToRequestQueue(request);
    }

    private void allocateMemory() {
        lblprofileemail = findViewById(R.id.lblprofileemail);
        lblprofilemobile = findViewById(R.id.lblprofilemobile);
        lblprofilename = findViewById(R.id.lblprofilename);
        lblupdateprofile = findViewById(R.id.lblupdateprofile);
        imgprofileimg = findViewById(R.id.imgprofileimg);
        myProfileAddress = findViewById(R.id.myProfileAddress);
        tvChangePassword = findViewById(R.id.tvChangePassword);

        copyImageView = findViewById(R.id.copyImageView);
        shareImageView = findViewById(R.id.shareImageView);
        callImageView = findViewById(R.id.callImageView);
    }

    // show process Dialog box
    private void showpDialog() {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }

    // hide process Dialog box
    private void hidePDialog() {
        if (this.pDialog != null) {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (new NetworkConnetionState().isNetworkAvailable(ctx)) {
            getProfileDetail();
        } else {
            networkAlert();
        }
    }

    public void setupToolbar() {
        toolbar = getSupportActionBar();
        assert toolbar != null;
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);
    }

    private void addGroup() {
        AlertDialog.Builder builder = new AlertDialog.Builder(ctx);

        LayoutInflater layoutInflater = LayoutInflater.from(ctx);
        final View myview = layoutInflater.inflate(R.layout.dialog_new_group, null);
        builder.setView(myview);

        final TextView txtgtitle = myview.findViewById(R.id.txtgtitle);
        TextView btn_create_grp = myview.findViewById(R.id.btn_create_grp);

        imgphotoid_select = myview.findViewById(R.id.imgphotoid_select);
        imgphotoid = myview.findViewById(R.id.imgphotoid);

        imgphotoid_select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //storage.write("type","1"); //user image
                requestPermission();
            }
        });

        btn_create_grp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (txtgtitle.getText().toString().length() == 0) {
                    txtgtitle.setError("Group Title required");
                } else {

                    createNewGroup(txtgtitle.getText().toString(), aldialog);

                }
            }
        });
        aldialog = builder.create();
        final Window window = aldialog.getWindow();
        assert window != null;
        aldialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        window.setBackgroundDrawableResource(R.color.colorTransparent);
        window.setGravity(Gravity.CENTER);
        aldialog.show();
    }

    private void createNewGroup(final String gtitle, final AlertDialog aldialog) {

        if (!Utility.isNetworkAvailable(ctx)) {
            /*Snackbar.make(rcvgrp, "Internet connection is not available", Snackbar.LENGTH_INDEFINITE).setAction("RETRY", new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int permissionCheck = ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS);
                    if (permissionCheck == PackageManager.PERMISSION_GRANTED) {
                        Intent contactPicker = new Intent(ctx, ContactPickerActivity.class);
                        startActivityForResult(contactPicker, CONTACT_PICKER_REQUEST);
                    } else {
                        createNewGroup(gtitle, aldialog);
                    }
                }
            }).setActionTextColor(getResources().getColor(R.color.colorPrimary)).show();*/
        } else {
            final ProgressDialog progressDialog = new ProgressDialog(ctx);
            progressDialog.setTitle("Please wait...");
            progressDialog.show();
            progressDialog.setCancelable(false);
            int compressionRatio = 2; //1 == originalImage, 2 = 50% compression, 4=25% compress
            MultipartBody.Part part;
            if (CameraFileAbsolutePath != null) {
                File file = new File(CameraFileAbsolutePath);
                try {
                    Bitmap bitmap = BitmapFactory.decodeFile(file.getPath());
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 70, new FileOutputStream(file));
                } catch (Throwable t) {
                    Log.e("ERROR", "Error compressing file." + t.toString());
                    t.printStackTrace();
                }
                // Create a request body with file and image media type
                RequestBody fileReqBody = RequestBody.create(MediaType.parse("image/*"), file);
                part = MultipartBody.Part.createFormData("image", file.getName(), fileReqBody);
            } else {
                part = MultipartBody.Part.createFormData("image", "img1.png");
            }
            // Create MultipartBody.Part using file request-body,file name and part name
            //Create request body with text description and text media type
            RequestBody description1 = RequestBody.create(MediaType.parse("text/plain"), Utils.getString(ctx, Constants.USER_ID));
            RequestBody description2 = RequestBody.create(MediaType.parse("text/plain"), gtitle);
            WebServiceCaller.getClient().addGroupModelCall(part, description1, description2).enqueue(new Callback<AddGroupModel>() {
                @Override
                public void onResponse(Call<AddGroupModel> call, retrofit2.Response<AddGroupModel> response) {
                    Utils.log(TAG, response.toString());
                    if (response.isSuccessful()) {
                        Toast.makeText(ctx, response.body().getMsg(), Toast.LENGTH_LONG).show();
                        CameraFileAbsolutePath = null;
                        hidePDialog();
                        aldialog.dismiss();
                        gid = response.body().getGid();
                        int permissionCheck = ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS);
                        if (permissionCheck == PackageManager.PERMISSION_GRANTED) {


                            new MultiContactPicker.Builder(MyProfile.this) //Activity/fragment context
                                    .hideScrollbar(false) //Optional - default: false
                                    .showTrack(true) //Optional - default: true
                                    .searchIconColor(Color.WHITE) //Option - default: White
                                    .setChoiceMode(MultiContactPicker.CHOICE_MODE_MULTIPLE) //Optional - default: CHOICE_MODE_MULTIPLE
                                    .handleColor(ContextCompat.getColor(MyProfile.this, R.color.colorPrimary)) //Optional - default: Azure Blue
                                    .bubbleColor(ContextCompat.getColor(MyProfile.this, R.color.colorPrimary)) //Optional - default: Azure Blue
                                    .bubbleTextColor(Color.WHITE) //Optional - default: White
                                    .setTitleText("Select Contacts") //Optional - default: Select Contacts

                                    .setLoadingType(MultiContactPicker.LOAD_ASYNC) //Optional - default LOAD_ASYNC (wait till all loaded vs stream results)
                                    .limitToColumn(LimitColumn.PHONE) //Optional - default NONE (Include phone + email, limiting to one can improve loading time)
                                    .setActivityAnimations(android.R.anim.fade_in, android.R.anim.fade_out,
                                            android.R.anim.fade_in,
                                            android.R.anim.fade_out) //Optional - default: No animation overrides
                                    .showPickerForResult(CONTACT_PICKER_REQUEST);




                           /* Intent contactPicker = new Intent(ctx, ContactPickerActivity.class);
                            startActivityForResult(contactPicker, CONTACT_PICKER_REQUEST);*/
                        } else {
                            launchContactPicker();
                        }
                    } else {
                        Toast.makeText(ctx, "Error api", Toast.LENGTH_LONG).show();
                    }
                    progressDialog.dismiss();
                }

                @Override
                public void onFailure(Call<AddGroupModel> call, Throwable t) {
                    //swipeContainer.setRefreshing(false)
                    //
                    progressDialog.dismiss();
                    Toast.makeText(ctx, "Server Error", Toast.LENGTH_LONG).show();
                    Utils.log(TAG, t.getMessage());
                }
            });
        }
    }

    public void launchContactPicker() {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.READ_CONTACTS},
                READ_CONTACT_REQUEST);
    }

    void requestPermission() {
        if (PackageManager.PERMISSION_GRANTED !=
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ||
                PackageManager.PERMISSION_GRANTED != ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)) {
            String[] PermissionList = {Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.CAMERA};
            if (ActivityCompat.shouldShowRequestPermissionRationale
                    (this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ||
                    ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA)) {

                ActivityCompat.requestPermissions(this, PermissionList,
                        REQUEST_MULTIPLE_PERMISSION);
            } else {
                ActivityCompat.requestPermissions(this, PermissionList,
                        REQUEST_MULTIPLE_PERMISSION);
            }
        } else {
            showDialogBox();
        }
    }

    private void showDialogBox() {
        androidx.appcompat.app.AlertDialog.Builder b1 = new androidx.appcompat.app.AlertDialog.Builder(ctx);
        b1.setTitle("Select Photo");
        b1.setIcon(R.mipmap.logo1);
        b1.setMessage("I want to select photo");
        b1.setPositiveButton("Using CAMERA", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);


                File image = null;
                try {
                    image = Util.CreteFileWithUniqueName(ctx);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                CameraFileAbsolutePath = image.getAbsolutePath();

                Uri photoURI = FileProvider.getUriForFile(ctx,
                        BuildConfig.APPLICATION_ID + ".provider", image);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(intent, CAMERA);
            }
        });
        b1.setNegativeButton("using Gallery", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent = new Intent(Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, GALLARY);
            }
        });

        b1.create().show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.dashboard, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }

        int id = item.getItemId();
        if (id == R.id.addGroup) {
            addGroup();
        } else if (id == R.id.dashboard) {
            startActivity(new Intent(ctx, Dashboard.class));
        } else if (id == R.id.myGroup) {
            startActivity(new Intent(ctx, MyGroup.class));
        } else if (id == R.id.myPost) {
            startActivity(new Intent(ctx, MyPosts.class)
                    .putExtra("from", "dashboard")
                    .putExtra("gender", "-1"));
        } else if (id == R.id.myFev) {
            startActivity(new Intent(ctx, MyFav_Arc.class)
                    .putExtra("from", "dashboard_fav"));
        } else if (id == R.id.myArchive) {
            startActivity(new Intent(ctx, MyFav_Arc.class)
                    .putExtra("from", "dashboard_arc"));
        } else if (id == R.id.myRequest) {
            startActivity(new Intent(ctx, MyRequestActivity.class).putExtra("from", "dashboard_req"));
        } else if (id == R.id.gettogather) {
            startActivity(new Intent(ctx, GetTogether.class));
        } else if (id == R.id.myMarketing) {
            startActivity(new Intent(ctx, MyMarketActivity.class));
        } else if (id == R.id.invsent) {
            startActivity(new Intent(ctx, InvitationSent.class)
                    .putExtra("from", "dashboard_invitation_sent"));
        } else if (id == R.id.invreceive) {
            startActivity(new Intent(ctx, InvitationReceived.class)
                    .putExtra("from", "dashboard_invitation_receive"));
        } else if (id == R.id.myIncite) {
            shareMessage("https://play.google.com/store/apps/details?id=com.suguretaventure.mymarriagegroup");
        } else if (id == R.id.logout) {
            final AlertDialog alertDialog = new AlertDialog.Builder(ctx).create();
            alertDialog.setMessage("Do you want to Logout");
            alertDialog.setButton(DialogInterface.BUTTON_POSITIVE, "Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    String FCM_KEY = "" + Utils.getString(ctx, Constants.TOKEN);
                    Utils.clearPreference(ctx);
                    Utils.setString(ctx, Constants.TOKEN, FCM_KEY);
                    startActivity(new Intent(ctx, Login.class));
                    finish();
                }
            });
            alertDialog.setButton(DialogInterface.BUTTON_NEGATIVE, "Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    alertDialog.dismiss();
                }
            });
            alertDialog.show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        getProfileDetail();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GALLARY && resultCode == RESULT_OK &&
                data != null) {
            Uri uri = data.getData();
            Cursor cursor = MediaStore.Images.Media.query(getContentResolver(),
                    uri, new String[]{MediaStore.Images.Media.DATA});
            if (cursor != null && cursor.moveToFirst()) {
                CameraFileAbsolutePath = cursor.getString(cursor.getColumnIndexOrThrow
                        (MediaStore.Images.Media.DATA));
                imageCompressTask = new ImageCompressTask(this, CameraFileAbsolutePath,
                        iImageCompressTaskListener);
                mExecutorService.execute(imageCompressTask);
                Bitmap bmp = BitmapFactory.decodeFile(CameraFileAbsolutePath);
                imgphotoid.setImageBitmap(bmp);
            }

        } else if (requestCode == CAMERA) {
            if (CameraFileAbsolutePath != null) {
                File imgFile = new File(CameraFileAbsolutePath);
                if (imgFile.exists()) {
                    imageCompressTask = new ImageCompressTask(this, CameraFileAbsolutePath,
                            iImageCompressTaskListener);
                    mExecutorService.execute(imageCompressTask);
                    Bitmap bmp = BitmapFactory.decodeFile(CameraFileAbsolutePath);
                    imgphotoid.setImageBitmap(bmp);
                    // imgphotoid.setImageBitmap(image);
                }
            }
        } else if (resultCode == CONTACT_PICKER_REQUEST) {

            //contacts were selected
            if (resultCode == RESULT_OK) {

                if (data != null) {


                    List<ContactResult> results = MultiContactPicker.obtainResult(data);
                    Log.d("MyTag", results.get(0).getDisplayName());

                    if (results != null) {
                        for (ContactResult selectedContact : results) {
                            List<String> list = new ArrayList<>();
                            list.add(selectedContact.getPhoneNumbers() + "|" + selectedContact.getDisplayName());
                            mContacts.add(selectedContact);

                        }
                    }

                    setRecyclerView(gid);
                }

            } else if (resultCode == RESULT_CANCELED) {
                System.out.println("User closed the picker without selecting items.");
            }
        }
    }

    private void shareMessage(String message) {
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, message);
        startActivity(intent);
    }

    private void setRecyclerView(String gid) {
        ArrayList<String> name = new ArrayList<>();
        ArrayList<String> no = new ArrayList<>();
        for (int i = 0; i < mContacts.size(); i++) {
            name.add(mContacts.get(i).getDisplayName());
            String temp_name = mContacts.get(i).getDisplayName();
            String temp_no = mContacts.get(i).getPhoneNumbers().get(0).getNumber().replace("-", "");
            String nameNo = temp_no + "|" + temp_name;

            no.add(nameNo);
        }
    }
}
