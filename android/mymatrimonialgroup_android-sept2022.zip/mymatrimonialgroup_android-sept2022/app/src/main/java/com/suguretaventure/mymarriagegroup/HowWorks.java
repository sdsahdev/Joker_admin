package com.suguretaventure.mymarriagegroup;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import android.text.Html;
import android.text.util.Linkify;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.suguretaventure.mymarriagegroup.common.AppController;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;

public class HowWorks extends AppCompatActivity {
    private String TAG = "HOW_WORKS";
    private Context ctx = this;
    private ProgressDialog pDialog;
    ImageView imgback;
    private TextView txthowworks, txtFAQ, txtTerms, txtTerms1;
    private FirebaseAnalytics mFirebaseAnalytics;

    /*String str = "<center><h1><font color='#DA4313'>Concept, Vision, Mission &amp; Values; Terms & Privacy Policy and FAQ</font></h1></center>" +
            "<h2><font color='#DA4313'>Concept:</font></h2>" +
            "<p>Anyone in the world can download this app &amp; can form a marriage/ matrimonial group for its own community. This group will be a special group only for its community. All profiles in your group are verified by admin first and then added. Therefore you have a group of genuine profiles amongst your community. It’s also a place for all marriage related commercials such as Marriage hall, catering, photographers etc available city wise, all over the world. As on today there is no such app in the world &amp; we are proud to launch the same.</p>" +
            "<h2><font color='#DA4313'>Vision:</font></h2>" +
            "<p>(i) Our vision is that in all parts of the world such marriage groups shall become functional. (ii) All marriage related commercials shall also be made available to these groups. (iii) To provide a perfect app for this purpose and make it number 1 in its category. </p>" +
            "<h2><font color='#DA4313'>Mission:</font></h2>" +
            "<p>(i) To connect you to such genuine &amp; eminent families in your community (ii) The genuineness can be verifiable through your known relatives, friends and admin. (iii) We shall provide this in a simplest form, user friendly manner, easy to use and at the same time provide security to members.</p>" +
            "<h2><font color='#DA4313'>Values:</font></h2>" +
            "<p>(i) Genuineness (ii) Verifiability and (iii) Security are the values of this app. We shall take all possible measures to implement the same.</p>";*/
    ActionBar toolbar;

    /*"<h2><font color='#DA4313'>FAQ:</font></h2>";*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_how_works);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(getResources().getString(R.string.app_name_title));
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
//        setupToolbar();
        allocateMemory();
        txthowworks.setText(Html.fromHtml(Constants.STRING_HOW_THIS_APP_WORK));
        Linkify.addLinks(txthowworks, Linkify.ALL);

//        setHowWorks();
        setListener();
    }

    private void setListener() {
        txtFAQ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ctx, FAQActivity.class).putExtra("PAGE", "FAQ"));
            }
        });
        txtTerms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ctx, FAQActivity.class).putExtra("PAGE", "TERMS"));
            }
        });
    }

    private void setHowWorks() {
        pDialog = new ProgressDialog(ctx);
        pDialog.setMessage("Please wait...");
        pDialog.setCancelable(false);
        showpDialog();

        //call web service
        String WebServiceUrl = Common.GetWebServiceUrl() +
                "howworks.php";
        JsonArrayRequest request = new JsonArrayRequest(WebServiceUrl,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Utils.log(TAG, response.toString());
                        try {
                            String error = response.getJSONObject(0).getString("error");
                            if (!error.equals("no error"))
                                Common.showDialog(ctx, error);
                            else {
                                String message = response.getJSONObject(1).getString("detail");
                                txthowworks.setText(message);
                                hidePDialog();
                            }
                            hidePDialog();
                        } catch (JSONException e) {
                            hidePDialog();
                            Common.showDialog(ctx, "Key does not exists " + e.getMessage());
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                hidePDialog();
                Common.showDialog(ctx);
            }
        });
        request.setRetryPolicy(new DefaultRetryPolicy(2000, 3, 1));
        AppController.getInstance().addToRequestQueue(request);
    }

    // show process Dialog box
    private void showpDialog() {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }

    // hide process Dialog box
    private void hidePDialog() {
        if (this.pDialog != null) {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }

    private void allocateMemory() {
        txthowworks = findViewById(R.id.txthowworks);
//        imgback = findViewById(R.id.imgback);
        txtFAQ = findViewById(R.id.txtFAQ);
        txtTerms = findViewById(R.id.txtTerms);
        txtTerms1 = findViewById(R.id.txtTerms1);
    }

    public void setupToolbar() {
        toolbar = getSupportActionBar();
        assert toolbar != null;
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_how_works, menu);
        return true;
    }

    public boolean onPrepareOptionsMenu(Menu menu)
    {
        MenuItem home = menu.findItem(R.id.dashboard);
        MenuItem Logout = menu.findItem(R.id.logout);
        MenuItem Login = menu.findItem(R.id.login);
        Log.d("Mobile_USER","Mobile :- "+Utils.getString(ctx,Constants.USER_MOBILE));
        if(Utils.getString(ctx,Constants.USER_MOBILE).equals(""))
        {
            home.setVisible(false);
            Logout.setVisible(false);
            Login.setVisible(true);

        }
        else
        {
            home.setVisible(true);
            Logout.setVisible(true);
            Login.setVisible(false);

        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (android.R.id.home == item.getItemId()) {
            finish();
        }

        int id = item.getItemId();
        if(id == R.id.dashboard) {
            startActivity(new Intent(ctx, Dashboard.class));
        }else if (id == R.id.logout) {
            final AlertDialog alertDialog = new AlertDialog.Builder(ctx).create();
            alertDialog.setMessage("Do you want to Logout");
            alertDialog.setButton(DialogInterface.BUTTON_POSITIVE, "Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    String FCM_KEY = "" + Utils.getString(ctx, Constants.TOKEN);
                    Utils.clearPreference(ctx);
                    Utils.setString(ctx, Constants.TOKEN, FCM_KEY);
                    startActivity(new Intent(ctx, Login.class));
                    finish();
                }
            });
            alertDialog.setButton(DialogInterface.BUTTON_NEGATIVE, "Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    alertDialog.dismiss();
                }
            });
            alertDialog.show();
            finish();
            return true;
        }else if (id == R.id.login) {
            String FCM_KEY = "" + Utils.getString(ctx, Constants.TOKEN);
            Utils.setString(ctx, Constants.TOKEN, FCM_KEY);
            startActivity(new Intent(ctx, Login.class));
        }
        return super.onOptionsItemSelected(item);
    }
}
