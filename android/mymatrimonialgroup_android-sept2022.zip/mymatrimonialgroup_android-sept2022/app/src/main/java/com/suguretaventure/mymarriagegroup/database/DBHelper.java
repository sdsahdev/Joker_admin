package com.suguretaventure.mymarriagegroup.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class DBHelper extends SQLiteOpenHelper {
    public static final int DB_VERSION = 1;
    public static final String DATABASE_NAME = "MyDBName.db";
    public static final String BIODATA_TABLE_NAME = "biodata";
    public static final String ID_COL = "id";
    public static final String USER_ID = "user_id";
    public static final String NAME_COL = "name";
    public static final String MIDDLE_NAME_COL = "middle_name";
    public static final String SURNAME_COL = "surname";
    public static final String AGE_COL = "age";
    public static final String EDUCATION_COL = "education";
    public static final String DEGREE_COL = "degree";
    public static final String OCCUPATION_COL = "occupation";
    public static final String OCCUPATION_DETAIL_COL = "occupation_detail";
    public static final String CURRENCY_COL = "currency";
    public static final String ANNUAL_INCOME_COL = "annual_income";
    public static final String CITY_COL = "city";
    public static final String DATE_OF_BIRTH_COL = "date_of_birth";
    public static final String TIME_OF_BIRTH_COL = "time_of_birth";
    public static final String PLACE_OF_BIRTH_COL = "place_of_birth";
    public static final String HEIGHT_COL = "height";
    public static final String WEIGHT_COL = "weight";
    public static final String BLOOD_GROUP_COL = "blood_group";
    public static final String COMPLEXION_COL = "complexion";
    public static final String ZODIAC_COL = "zodiac";
    public static final String FATHERS_NAME_COL = "fathers_name";
    public static final String FATHERS_OCCUPATION_COL = "fathers_occupation";
    public static final String MOTHER_NAME_COL = "mother_name";
    public static final String MOTHER_OCCUPATION_COL = "mother_occupation";
    public static final String BROTHERS_NAME_OCCUPATION_COL = "brothers_name_occupation";
    public static final String SISTERS_NAME_OCCUPATION_COL = "sisters_name_occupation";
    public static final String RELIGION_COL = "religion";
    public static final String MARITIAL_STATUS_COL = "maritial_status";
    public static final String MOTHER_TONGUE_COL = "mother_tongue";
    public static final String KUL_DAIVAT_COL = "kul_daivat";
    public static final String CLOSE_RELATIVES_COL = "close_relatives";
    public static final String ADDRESS_COL = "address";
    public static final String NATIVE_PLACE_COL = "native_place";
    public static final String HOBBIES_COL = "hobbies";
    public static final String EXPECTATION_COL = "expectation";
    public static final String SURNAME_COMMUNITY_COL = "surname_community";
    public static final String DRINKING_HABITS_COL = "drinking_habits";
    public static final String SMOKING_HABITS_COL = "smoking_habits";
    public static final String DIETARY_HABITS_COL = "dietary_habits";
    public static final String NAME_TO_CONTACT_COL = "name_to_contact";
    public static final String ITS_RELATION_COL = "its_relation";
    public static final String CONTACT_NUMBER_COL = "contact_no";
    public static final String EMAIL_COL = "email_id";
    public static final String MG_ID = "mg_id";
    public static final String GENDER = "gender";
    public static final String MG_NAME = "mg_name";
    public static final String IMAGE = "image";
    public static final String URL = "url";
    public static final String HANDICAP = "pHandicap";
    public static final String SCITIZEN = "sCitizen";

    private HashMap hp;

    public DBHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // along with their data types.
        String query = "CREATE TABLE " + BIODATA_TABLE_NAME + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + USER_ID + " TEXT, "
                + NAME_COL + " TEXT,"
                + MIDDLE_NAME_COL + " TEXT,"
                + SURNAME_COL + " TEXT,"
                + AGE_COL + " TEXT,"
                + EDUCATION_COL + " TEXT,"
                + DEGREE_COL + " TEXT,"
                + OCCUPATION_COL + " TEXT,"
                + OCCUPATION_DETAIL_COL + " TEXT,"
                + CURRENCY_COL + " TEXT,"
                + ANNUAL_INCOME_COL + " TEXT,"
                + CITY_COL + " TEXT,"
                + DATE_OF_BIRTH_COL + " TEXT,"
                + TIME_OF_BIRTH_COL + " TEXT,"
                + PLACE_OF_BIRTH_COL + " TEXT,"
                + HEIGHT_COL + " TEXT,"
                + WEIGHT_COL + " TEXT,"
                + BLOOD_GROUP_COL + " TEXT,"
                + COMPLEXION_COL + " TEXT,"
                + ZODIAC_COL + " TEXT,"
                + FATHERS_NAME_COL + " TEXT,"
                + FATHERS_OCCUPATION_COL + " TEXT,"
                + MOTHER_NAME_COL + " TEXT,"
                + MOTHER_OCCUPATION_COL + " TEXT,"
                + BROTHERS_NAME_OCCUPATION_COL + " TEXT,"
                + SISTERS_NAME_OCCUPATION_COL + " TEXT,"
                + RELIGION_COL + " TEXT,"
                + MARITIAL_STATUS_COL + " TEXT,"
                + MOTHER_TONGUE_COL + " TEXT,"
                + KUL_DAIVAT_COL + " TEXT,"
                + CLOSE_RELATIVES_COL + " TEXT,"
                + ADDRESS_COL + " TEXT,"
                + NATIVE_PLACE_COL + " TEXT,"
                + HOBBIES_COL + " TEXT,"
                + EXPECTATION_COL + " TEXT,"
                + SURNAME_COMMUNITY_COL + " TEXT,"
                + DRINKING_HABITS_COL + " TEXT,"
                + SMOKING_HABITS_COL + " TEXT,"
                + DIETARY_HABITS_COL + " TEXT,"
                + NAME_TO_CONTACT_COL + " TEXT,"
                + ITS_RELATION_COL + " TEXT,"
                + CONTACT_NUMBER_COL + " TEXT,"
                + EMAIL_COL + " TEXT,"
                + MG_ID + " TEXT,"
                + GENDER + " TEXT,"
                + MG_NAME + " TEXT,"
                + IMAGE + " TEXT,"
                + HANDICAP + " TEXT,"
                + SCITIZEN + " TEXT,"
                + URL + " TEXT)";

        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + BIODATA_TABLE_NAME);
        onCreate(db);
    }


    public boolean insertBiodata(int userId, String fullname, String middle, String surname, String age, String education,
                                 String specialization, String occupation, String occDetails, String income,
                                 String income1, String city1, String dobdate, String dobtime,
                                 String dobplace, String height, String weight, String blood, String complexion,
                                 String ras_tithi, String fathername, String fatherOccup, String mothername,
                                 String motherOccup, String brothers, String sisters, String religion, String marital,
                                 String motherTongue, String kulDevta, String relative, String address, String nativePlace,
                                 String hobbies, String expectation, String rel_surname, String drinkingHabits, String smokingHabits,
                                 String diataryHabits, String person_name, String relation, String contact, String email,
                                 String mg_id, String gender, String mg_name, String image, String url,String pHandicap,String sCitizen) {

        long result = -1;
        try {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put("user_id",userId);
            contentValues.put("name", fullname);
            contentValues.put("middle_name", middle);
            contentValues.put("surname", surname);
            contentValues.put("age", age);
            contentValues.put("education", education);
            contentValues.put("degree", specialization);
            contentValues.put("occupation", occupation);
            contentValues.put("occupation_detail", occDetails);
            contentValues.put("currency", income);
            contentValues.put("annual_income", income1);
            contentValues.put("city", city1);
            contentValues.put("date_of_birth", dobdate);
            contentValues.put("time_of_birth", dobtime);
            contentValues.put("place_of_birth", dobplace);
            contentValues.put("height", height);
            contentValues.put("weight", weight);
            contentValues.put("blood_group", blood);
            contentValues.put("complexion", complexion);
            contentValues.put("zodiac", ras_tithi);
            contentValues.put("fathers_name", fathername);
            contentValues.put("fathers_occupation", fatherOccup);
            contentValues.put("mother_name", mothername);
            contentValues.put("mother_occupation", motherOccup);
            contentValues.put("brothers_name_occupation", brothers);
            contentValues.put("sisters_name_occupation", sisters);
            contentValues.put("religion", religion);
            contentValues.put("maritial_status", marital);
            contentValues.put("mother_tongue", motherTongue);
            contentValues.put("kul_daivat", kulDevta);
            contentValues.put("close_relatives", relative);
            contentValues.put("address", address);
            contentValues.put("native_place", nativePlace);
            contentValues.put("hobbies", hobbies);
            contentValues.put("expectation", expectation);
            contentValues.put("surname_community", rel_surname);
            contentValues.put("drinking_habits", drinkingHabits);
            contentValues.put("smoking_habits", smokingHabits);
            contentValues.put("dietary_habits", diataryHabits);
            contentValues.put("name_to_contact", person_name);
            contentValues.put("its_relation", relation);
            contentValues.put("contact_no", contact);
            contentValues.put("email_id", email);
            contentValues.put("mg_id", mg_id);
            contentValues.put("gender", gender);
            contentValues.put("mg_name", mg_name);
            contentValues.put("image", image);
            contentValues.put("url", url);
            contentValues.put("pHandicap", pHandicap);
            contentValues.put("sCitizen", sCitizen);
            result = db.insert(BIODATA_TABLE_NAME, null, contentValues);

        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    public boolean updateBiodata(String id,String fullname, String middle, String surname, String age, String education,
                                 String specialization, String occupation, String occDetails, String income,
                                 String income1, String city1, String dobdate, String dobtime,
                                 String dobplace, String height, String weight, String blood, String complexion,
                                 String ras_tithi, String fathername, String fatherOccup, String mothername,
                                 String motherOccup, String brothers, String sisters, String religion, String marital,
                                 String motherTongue, String kulDevta, String relative, String address, String nativePlace,
                                 String hobbies, String expectation, String rel_surname, String drinkingHabits, String smokingHabits,
                                 String diataryHabits, String person_name, String relation, String contact, String email,
                                 String mg_id, String gender, String mg_name, String image, String url,String pHandicap,
                                        String sCitizen) {

        long result = -1;
        try {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put("name", fullname);
            contentValues.put("middle_name", middle);
            contentValues.put("surname", surname);
            contentValues.put("age", age);
            contentValues.put("education", education);
            contentValues.put("degree", specialization);
            contentValues.put("occupation", occupation);
            contentValues.put("occupation_detail", occDetails);
            contentValues.put("currency", income);
            contentValues.put("annual_income", income1);
            contentValues.put("city", city1);
            contentValues.put("date_of_birth", dobdate);
            contentValues.put("time_of_birth", dobtime);
            contentValues.put("place_of_birth", dobplace);
            contentValues.put("height", height);
            contentValues.put("weight", weight);
            contentValues.put("blood_group", blood);
            contentValues.put("complexion", complexion);
            contentValues.put("zodiac", ras_tithi);
            contentValues.put("fathers_name", fathername);
            contentValues.put("fathers_occupation", fatherOccup);
            contentValues.put("mother_name", mothername);
            contentValues.put("mother_occupation", motherOccup);
            contentValues.put("brothers_name_occupation", brothers);
            contentValues.put("sisters_name_occupation", sisters);
            contentValues.put("religion", religion);
            contentValues.put("maritial_status", marital);
            contentValues.put("mother_tongue", motherTongue);
            contentValues.put("kul_daivat", kulDevta);
            contentValues.put("close_relatives", relative);
            contentValues.put("address", address);
            contentValues.put("native_place", nativePlace);
            contentValues.put("hobbies", hobbies);
            contentValues.put("expectation", expectation);
            contentValues.put("surname_community", rel_surname);
            contentValues.put("drinking_habits", drinkingHabits);
            contentValues.put("smoking_habits", smokingHabits);
            contentValues.put("dietary_habits", diataryHabits);
            contentValues.put("name_to_contact", person_name);
            contentValues.put("its_relation", relation);
            contentValues.put("contact_no", contact);
            contentValues.put("email_id", email);
            contentValues.put("mg_id", mg_id);
            contentValues.put("gender", gender);
            contentValues.put("mg_name", mg_name);
            contentValues.put("image", image);
            contentValues.put("url", url);
            contentValues.put("pHandicap", pHandicap);
            contentValues.put("sCitizen", sCitizen);
            result = db.update(BIODATA_TABLE_NAME, contentValues, "id = " + id, null);

        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (result == -1) {
            return false;
        } else {
            return true;
        }


    }


    public void deleteBiodata(Integer id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + BIODATA_TABLE_NAME + " WHERE " + ID_COL + "= '" + id + "'");

        db.delete(BIODATA_TABLE_NAME,
                "id = ? ",
                new String[]{Integer.toString(id)});
        db.close();
    }


    public JSONArray getBiodata(String userId, String groupId) {
        JSONArray jsonArray = new JSONArray();
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT * FROM " + BIODATA_TABLE_NAME + " WHERE " + MG_ID + "= '" + groupId + "'" ;

        Cursor cursor = null;
        cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {
                String id = cursor.getString(cursor.getColumnIndex("id"));
                String fullname = cursor.getString(cursor.getColumnIndex("name"));
                String middle = cursor.getString(cursor.getColumnIndex("middle_name"));
                String surname = cursor.getString(cursor.getColumnIndex("surname"));
                String age = cursor.getString(cursor.getColumnIndex("age"));
                String education = cursor.getString(cursor.getColumnIndex("education"));
                String specialization = cursor.getString(cursor.getColumnIndex("degree"));
                String occupation = cursor.getString(cursor.getColumnIndex("occupation"));
                String occDetails = cursor.getString(cursor.getColumnIndex("occupation_detail"));
                String currency = cursor.getString(cursor.getColumnIndex("currency"));
                String income1 = cursor.getString(cursor.getColumnIndex("annual_income"));
                String city = cursor.getString(cursor.getColumnIndex("city"));
                String dobdate = cursor.getString(cursor.getColumnIndex("date_of_birth"));
                String dobtime = cursor.getString(cursor.getColumnIndex("time_of_birth"));
                String dobplace = cursor.getString(cursor.getColumnIndex("place_of_birth"));
                String height = cursor.getString(cursor.getColumnIndex("height"));
                String weight = cursor.getString(cursor.getColumnIndex("weight"));
                String blood = cursor.getString(cursor.getColumnIndex("blood_group"));
                String complexion = cursor.getString(cursor.getColumnIndex("complexion"));
                String ras_tithi = cursor.getString(cursor.getColumnIndex("zodiac"));
                String fathername = cursor.getString(cursor.getColumnIndex("fathers_name"));
                String fatherOccup = cursor.getString(cursor.getColumnIndex("fathers_occupation"));
                String mothername = cursor.getString(cursor.getColumnIndex("mother_name"));
                String motherOccup = cursor.getString(cursor.getColumnIndex("mother_occupation"));
                String brothers = cursor.getString(cursor.getColumnIndex("brothers_name_occupation"));
                String sisters = cursor.getString(cursor.getColumnIndex("sisters_name_occupation"));
                String religion = cursor.getString(cursor.getColumnIndex("religion"));
                String marital = cursor.getString(cursor.getColumnIndex("maritial_status"));
                String motherTongue = cursor.getString(cursor.getColumnIndex("mother_tongue"));
                String kulDevta = cursor.getString(cursor.getColumnIndex("kul_daivat"));
                String relative = cursor.getString(cursor.getColumnIndex("close_relatives"));
                String address = cursor.getString(cursor.getColumnIndex("address"));
                String nativePlace = cursor.getString(cursor.getColumnIndex("native_place"));
                String hobbies = cursor.getString(cursor.getColumnIndex("hobbies"));
                String expectation = cursor.getString(cursor.getColumnIndex("expectation"));
                String rel_surname = cursor.getString(cursor.getColumnIndex("surname_community"));
                String drinkingHabits = cursor.getString(cursor.getColumnIndex("drinking_habits"));
                String smokingHabits = cursor.getString(cursor.getColumnIndex("smoking_habits"));
                String diataryHabits = cursor.getString(cursor.getColumnIndex("dietary_habits"));
                String person_name = cursor.getString(cursor.getColumnIndex("name_to_contact"));
                String relation = cursor.getString(cursor.getColumnIndex("its_relation"));
                String contact = cursor.getString(cursor.getColumnIndex("contact_no"));
                String email = cursor.getString(cursor.getColumnIndex("email_id"));

                String mg_id = cursor.getString(cursor.getColumnIndex("mg_id"));
                String gender = cursor.getString(cursor.getColumnIndex("gender"));
                String mg_name = cursor.getString(cursor.getColumnIndex("mg_name"));
                String image = cursor.getString(cursor.getColumnIndex("image"));
                String url = cursor.getString(cursor.getColumnIndex("url"));
                String pHandicap = cursor.getString(cursor.getColumnIndex("pHandicap"));
                String sCitizen = cursor.getString(cursor.getColumnIndex("sCitizen"));

                try {
                    JSONObject jsonObject1 = new JSONObject();
                    jsonObject1.put("id", id);
                    jsonObject1.put("name", fullname);
                    jsonObject1.put("middlename", middle);
                    jsonObject1.put("surname", surname);
                    jsonObject1.put("age", age);
                    jsonObject1.put("education", education);
                    jsonObject1.put("degree", specialization);
                    jsonObject1.put("occupation", occupation);
                    jsonObject1.put("occupation_detail", occDetails);
                    jsonObject1.put("currency", currency);
                    jsonObject1.put("annual_income", income1);
                    jsonObject1.put("city", city);
                    jsonObject1.put("date_of_birth", dobdate);
                    jsonObject1.put("time_of_birth", dobtime);
                    jsonObject1.put("place_of_birth", dobplace);
                    jsonObject1.put("height", height);
                    jsonObject1.put("weight", weight);
                    jsonObject1.put("blood_group", blood);
                    jsonObject1.put("complexion", complexion);
                    jsonObject1.put("zodiac", ras_tithi);
                    jsonObject1.put("fathers_name", fathername);
                    jsonObject1.put("fathers_occupation", fatherOccup);
                    jsonObject1.put("mother_name", mothername);
                    jsonObject1.put("mother_occupation", motherOccup);
                    jsonObject1.put("brothers_name_occupation", brothers);
                    jsonObject1.put("sisters_name_occupation", sisters);
                    jsonObject1.put("religion", religion);
                    jsonObject1.put("maritial_status", marital);
                    jsonObject1.put("mother_tongue", motherTongue);
                    jsonObject1.put("kul_daivat", kulDevta);
                    jsonObject1.put("close_relatives", relative);
                    jsonObject1.put("address", address);
                    jsonObject1.put("native_place", nativePlace);
                    jsonObject1.put("hobbies", hobbies);
                    jsonObject1.put("expectation", expectation);
                    jsonObject1.put("surname_community", rel_surname);
                    jsonObject1.put("drinking_habits", drinkingHabits);
                    jsonObject1.put("smoking_habits", smokingHabits);
                    jsonObject1.put("dietary_habits", diataryHabits);
                    jsonObject1.put("name_to_contact", person_name);
                    jsonObject1.put("its_relation", relation);
                    jsonObject1.put("contact_no", contact);
                    jsonObject1.put("email_id", email);

                    jsonObject1.put("mg_id", mg_id);
                    jsonObject1.put("gender", gender);
                    jsonObject1.put("mg_name", mg_name);
                    jsonObject1.put("image", image);
                    jsonObject1.put("url", url);
                    jsonObject1.put("pHandicap", pHandicap);
                    jsonObject1.put("sCitizen", sCitizen);

                    jsonArray.put(jsonObject1);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } while (cursor.moveToNext());

            cursor.close();
            db.close();
        }
        return jsonArray;
    }
}