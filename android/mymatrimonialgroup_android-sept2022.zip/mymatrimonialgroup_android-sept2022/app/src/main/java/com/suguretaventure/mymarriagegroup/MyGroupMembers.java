package com.suguretaventure.mymarriagegroup;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.suguretaventure.mymarriagegroup.Model.GroupListModel;
import com.suguretaventure.mymarriagegroup.Model.MemberData;
import com.suguretaventure.mymarriagegroup.Model.Members;
import com.suguretaventure.mymarriagegroup.adapters.MemberAdapter;
import com.suguretaventure.mymarriagegroup.common.NetworkConnetionState;
import com.suguretaventure.mymarriagegroup.getsets.MyGrpRegListGetSet;
import com.suguretaventure.mymarriagegroup.getsets.PersonGetSet;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utils;
import com.wafflecopter.multicontactpicker.ContactResult;
import com.wafflecopter.multicontactpicker.LimitColumn;
import com.wafflecopter.multicontactpicker.MultiContactPicker;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;
/*import mx.com.quiin.contactpicker.Contact;
import mx.com.quiin.contactpicker.SimpleContact;
import mx.com.quiin.contactpicker.interfaces.ContactSelectionListener;
import mx.com.quiin.contactpicker.ui.ContactPickerActivity;*/

public class MyGroupMembers extends AppCompatActivity {
    private static final int READ_CONTACT_REQUEST = 1;
    private static final int CONTACT_PICKER_REQUEST = 2;
    private LinearLayout flt_addmember;
    ActionBar toolbar;
    ImageView imgback;
    private Context ctx = this;
    private RecyclerView mg_reguserlist;
    private ArrayList<MyGrpRegListGetSet> arr_adapter = new ArrayList<>();
    private  ArrayList<Members.Member> memberList;

    /*private MyGrpRegListAdapter myGrpRegAdapter;
    private MyGrpRegListGetSet myGrpRegGetSet;*/
    private ProgressDialog pDialog;
    private String TAG = "MY_GROUP_MEMBER", group_status;
    private TextView lblgrptitle;
    private String mgid, gendar, mgname, image, URL, GROUP_MEMBER; //mygroupid
    private String rid; //reguserid
    private List<ContactResult> mContacts = new ArrayList<>();
    private Menu menu;
    MenuInflater inflater;
    private ImageView imggrpicontitle;
    private int count = 0;
    private TextView txtGenderTitle;
    private ImageView imgGenderBack, imgGenderIcon, imgGenderMore;
    private Toolbar toolbar_top;
    private MemberAdapter adapter_member ;
    private FirebaseAnalytics mFirebaseAnalytics;

    private static String convertStringArrayToString(ArrayList<String> strArr) {
        StringBuilder sb = new StringBuilder();
        if (sb.toString() != null) {
            for (String str : strArr)
                sb.append(str).append("-");
            return sb.substring(0, sb.length() - 1);
        } else {
            return "";
        }
    }

    private EditText txt_search_mname;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_group_members);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Window window = getWindow();
// clear FLAG_TRANSLUCENT_STATUS flag:
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

// add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);

// finally change the color
        window.setStatusBarColor(getResources().getColor(R.color.colorPrimaryDark));
        allocateMemory();
        setSupportActionBar(toolbar_top);
        if (NetworkConnetionState.isNetworkAvailable(ctx)) {
            getMembers();
            setListener();
        } else {
            networkAlert();
        }



        txt_search_mname.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Utils.log(TAG, "2. s " + s + " : start " + start + " : before " + before + " : count " + count);
                if (txt_search_mname.getText().toString().equalsIgnoreCase("")) {
                    adapter_member.updateList(memberList);

                } else {
                    filter(txt_search_mname.getText().toString());
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                /*if (txt_search_pname.getText().toString().equalsIgnoreCase("")) {
                    getPersonBiodataList("", Common.GetWebServiceUrl() + "person_list.php");
                }*/
            }
        });
    }

    void filter(String text){
        ArrayList<Members.Member> temp = new ArrayList();
        for(Members.Member d: memberList){
            //or use .equal(text) with you want equal match
            //use .toLowerCase() for better matches
            if(d.firstname.toLowerCase().contains(text.toLowerCase()) || d.surname.toLowerCase().contains(text.toLowerCase()) || d.mobile.toLowerCase().contains(text.toLowerCase())){
                temp.add(d);
            }
        }
        //update recyclerview
        adapter_member.updateList(temp);
    }

    private void setListener() {
        imgGenderBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyGroupMembers.super.onBackPressed();
            }
        });

        flt_addmember.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchContactPicker();
            }
        });
    }

    private void networkAlert() {
        AlertDialog.Builder b1 = new AlertDialog.Builder(ctx);
        b1.setTitle("Network Error");
        b1.setMessage("No internet connection found. Please check your phone settings to turn on the internet.");
        b1.setPositiveButton("Retry", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (new NetworkConnetionState().isNetworkAvailable(ctx)) {
                    /*checkAdminUser();*/
                    getMembers();
                } else {
                    networkAlert();
                }
            }
        });
        b1.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        b1.create().show();
    }

    public void allocateMemory() {
        mg_reguserlist = findViewById(R.id.mg_reguserlist);
        imggrpicontitle = findViewById(R.id.imggrpicontitle);
        mgid = getIntent().getExtras().getString("mgid");
        gendar = getIntent().getExtras().getString("gendar");
        mgname = getIntent().getExtras().getString("mgname");
        image = getIntent().getExtras().getString("image");
        URL = getIntent().getExtras().getString("URL");
        GROUP_MEMBER = getIntent().getExtras().getString("GROUP_MEMBER");
        Utils.log("GROUP_MEMBER", GROUP_MEMBER);
        lblgrptitle = findViewById(R.id.lblgrptitle);
        flt_addmember = findViewById(R.id.flt_addmember);
        rid = Utils.getString(ctx, Constants.USER_ID);
        lblgrptitle.setText(mgname);
        if (!image.equalsIgnoreCase("")) {
            Glide.with(ctx).load(image).apply(RequestOptions.circleCropTransform()).into(imggrpicontitle);
        }

        toolbar_top = findViewById(R.id.toolbar_top);
        txtGenderTitle = toolbar_top.findViewById(R.id.txtGenderTitle);
        imgGenderBack = toolbar_top.findViewById(R.id.imgGenderBack);
        imgGenderIcon = toolbar_top.findViewById(R.id.imgGenderIcon);
        txt_search_mname = findViewById(R.id.txt_search_mname);


        txtGenderTitle.setText("" + mgname);
        Glide.with(ctx)
                .load(URL + image)
                .apply(RequestOptions.circleCropTransform())
                .into(imgGenderIcon);
    }

    public void getMembers() {
        pDialog = new ProgressDialog(ctx);
        pDialog.setMessage("Group Member(s)...");
        showpDialog();
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("gid", mgid);
        Utils.log(TAG, "GET_MEMBER_LIST_URL : " + Constants.APP_MEMBER_LIST + "?" + params);
        client.post(Constants.APP_MEMBER_LIST, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {

                String response = new String(responseBody);
                Utils.log(TAG, "GET_MEMBER_LIST_RESPONSE : " + response);
                Members data = new Gson().fromJson(response, Members.class);
                mg_reguserlist.setLayoutManager(new LinearLayoutManager(ctx));
                String Admin = "0";
                if (data.aid.equals(Utils.getString (ctx, Constants.USER_ID))) {
                    Admin = "1";
                    if (data.aid.equals(Utils.getString(ctx, Constants.USER_ID))) {
                        if (count == 0) {
                            count++;
                            inflater.inflate(R.menu.menu_add_member, menu);
                            if (GROUP_MEMBER.equals("1")) {
                                menu.findItem(R.id.deleteGroup).setTitle("Delete Group");
                                group_status = "Delete Group";
                            } else {
                                menu.findItem(R.id.deleteGroup).setTitle("Leave Group");
                                group_status = "Leave Group";
                            }
                        }
                    }
                } else {
                    inflater.inflate(R.menu.leave_member, menu);
                }

                memberList = data.members;
                adapter_member = new MemberAdapter(ctx,data.members , data.aid, mgid);
                mg_reguserlist.setAdapter(adapter_member);
                adapter_member.notifyDataSetChanged();
                hidePDialog();
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "GET_MEMBER_LIST_ERROR : " + error.getMessage());
                try {
                    hidePDialog();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void showpDialog() {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }

    private void hidePDialog() {
        if (this.pDialog != null) {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    public void setupToolbar() {
        toolbar = getSupportActionBar();
        assert toolbar != null;
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case CONTACT_PICKER_REQUEST:
                //contacts were selected

                if (resultCode == RESULT_OK) {

                    if (data != null) {

                        List<ContactResult> results = MultiContactPicker.obtainResult(data);
                        Log.d("MyTag", results.get(0).getDisplayName());

                        if (results != null) {
                            for (ContactResult selectedContact : results) {
                                List<String> list = new ArrayList<>();
                                list.add(selectedContact.getPhoneNumbers() + "|" + selectedContact.getDisplayName());
                                mContacts.add(selectedContact);

                            }
                        }

                        setRecyclerView();
                    }

                } else if (resultCode == RESULT_CANCELED) {
                    System.out.println("User closed the picker without selecting items.");
                }


                break;

            default:
                super.onActivityResult(requestCode, resultCode, data);
        }

    }


     /* if (data != null) {
                    TreeSet<SimpleContact> selectedContacts = (TreeSet<SimpleContact>) data.getSerializableExtra(ContactPickerActivity.CP_SELECTED_CONTACTS);
                    if (selectedContacts != null) {
                        for (SimpleContact selectedContact : selectedContacts) {
                            List<String> list = new ArrayList<>();
                            list.add(selectedContact.getCommunication() + "|" + selectedContact.getDisplayName());
                            mContacts.add(new Contact(selectedContact.getDisplayName(), list));
                        }
                    }
                }
            setRecyclerView(gid);
        }*/


    private void setRecyclerView() {
        ArrayList<String> name = new ArrayList<>();
        ArrayList<String> no = new ArrayList<>();
        for (int i = 0; i < mContacts.size(); i++) {
            name.add(mContacts.get(i).getDisplayName());
            String temp_name = mContacts.get(i).getDisplayName();
            String temp_no = mContacts.get(i).getPhoneNumbers().get(0).getNumber().replace("-","");
            String nameNo = temp_no + "|" + temp_name;

            no.add(nameNo);
        }

        Utils.log(TAG, convertStringArrayToString(name));
        Utils.log(TAG, convertStringArrayToString(no));
        pDialog = new ProgressDialog(ctx);
        pDialog.setMessage("Contact(s) Adding...");
        showpDialog();
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("gid", mgid);
        params.put("id", Utils.getString(ctx, Constants.USER_ID));
        params.put("mobile", convertStringArrayToString(no));
        Utils.log(TAG, "ADD_CONTACT_LIST_URL : " + Constants.APP_ADD_MEMBER + "?" + params);
        client.post(Constants.APP_ADD_MEMBER, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                Utils.log(TAG, "ADD_CONTACT_LIST_RESPONSE : " + response);
                MemberData data = new Gson().fromJson(response, MemberData.class);
                if (data.members.size() > 0) {
                    Toast.makeText(ctx, "Member Invited Successfully.", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(ctx, "Member Added Successfully.", Toast.LENGTH_LONG).show();
                }
                hidePDialog();
                getMembers();
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "ADD_CONTACT_LIST_ERROR : " + error.getMessage());
                hidePDialog();
            }
        });
    }

    private void toggleViews() {
        lblgrptitle.setText("Contacts selected: ");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case READ_CONTACT_REQUEST:
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    launchContactPicker();
                }
        }
    }

    public void launchContactPicker() {
        int permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS);
        if (permissionCheck == PackageManager.PERMISSION_GRANTED) {


            new MultiContactPicker.Builder(MyGroupMembers.this) //Activity/fragment context
                    .hideScrollbar(false) //Optional - default: false
                    .showTrack(true) //Optional - default: true
                    .searchIconColor(Color.WHITE) //Option - default: White
                    .setChoiceMode(MultiContactPicker.CHOICE_MODE_MULTIPLE) //Optional - default: CHOICE_MODE_MULTIPLE
                    .handleColor(ContextCompat.getColor(MyGroupMembers.this, R.color.colorPrimary)) //Optional - default: Azure Blue
                    .bubbleColor(ContextCompat.getColor(MyGroupMembers.this, R.color.colorPrimary)) //Optional - default: Azure Blue
                    .bubbleTextColor(Color.WHITE) //Optional - default: White
                    .setTitleText("Select Contacts") //Optional - default: Select Contacts

                    .setLoadingType(MultiContactPicker.LOAD_ASYNC) //Optional - default LOAD_ASYNC (wait till all loaded vs stream results)
                    .limitToColumn(LimitColumn.PHONE) //Optional - default NONE (Include phone + email, limiting to one can improve loading time)
                    .setActivityAnimations(android.R.anim.fade_in, android.R.anim.fade_out,
                            android.R.anim.fade_in,
                            android.R.anim.fade_out) //Optional - default: No animation overrides
                    .showPickerForResult(CONTACT_PICKER_REQUEST);


            /* Intent contactPicker = new Intent(this, ContactPickerActivity.class);
            contactPicker.putExtra(ContactPickerActivity.DISPLAY_SERVICE,false);
            startActivityForResult(contactPicker, CONTACT_PICKER_REQUEST);*/

        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_CONTACTS},
                    READ_CONTACT_REQUEST);
        }
    }


    @SuppressLint("ResourceType")
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        this.menu = menu;
        inflater = getMenuInflater();
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.addmembar:
                launchContactPicker();
                return true;

            case android.R.id.home:
                finish();
                break;

            case R.id.home:
                startActivity(new Intent(MyGroupMembers.this, Dashboard.class));
                break;

            case R.id.deleteGroup:
                final AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
                builder.setIcon(R.drawable.ic_remove_blue);
                builder.setTitle(group_status);
                builder.setMessage("Do you want to " + group_status + "?");
                builder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        deleteGroup();
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        dialog.dismiss();
                    }
                });
                builder.show();
                break;

            case R.id.LeaveGroup:
                final AlertDialog.Builder builder1 = new AlertDialog.Builder(ctx);
                builder1.setIcon(R.drawable.ic_exit_to_app_black_24dp);
                builder1.setTitle("Leave Member");
                builder1.setMessage("Do you want to Leave from this group?");
                builder1.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        memberRemove();
                        Toast.makeText(ctx, "Leaved", Toast.LENGTH_LONG).show();
                    }
                });
                builder1.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        dialog.dismiss();
                    }
                });
                builder1.show();
                break;

        }
        return super.onOptionsItemSelected(item);
    }

    public void deleteGroup() {
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        final RequestParams params = new RequestParams();
        params.put("rid", Utils.getString(ctx, Constants.USER_ID));
        params.put("gid", mgid);
        Utils.log(TAG, "DELETE_GROUP_URL : " + Constants.Delete_Group + "?" + params);
        client.post(Constants.Delete_Group, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                Utils.log(TAG, "DELETE_GROUP_RESPONSE : " + response);
                String success = "", message = "";
                try {
                    JSONObject res = new JSONObject(response);
                    success = res.getString("success");
                    message = res.getString("msg");
                    Log.d("API_RESPONSE", success);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (message.equals("Delete")) {
                    deleteGroupFinal();
                } else {
                    Toast.makeText(ctx, group_status + " Successfully", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(MyGroupMembers.this, Dashboard.class));
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "REMOVE_MEMBER_ERROR : " + error.getMessage());
                Toast.makeText(ctx, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void deleteGroupFinal() {
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        final RequestParams params = new RequestParams();
        params.put("rid", Utils.getString(ctx, Constants.USER_ID));
        params.put("gid", mgid);
        Utils.log(TAG, "DELETE_GROUP_URL : " + Constants.Delete_Group_Final + "?" + params);
        client.post(Constants.Delete_Group_Final, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                Utils.log(TAG, "DELETE_GROUP_RESPONSE : " + response);
                String success = "", message = "";
                try {
                    JSONObject res = new JSONObject(response);
                    success = res.getString("success");
                    message = res.getString("message");
                    Log.d("API_RESPONSE", success);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                Toast.makeText(ctx, "Group Deleted Successfully", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(MyGroupMembers.this, Dashboard.class));
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "REMOVE_MEMBER_ERROR : " + error.getMessage());
                Toast.makeText(ctx, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void memberRemove() {
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        final RequestParams params = new RequestParams();
        params.put("rid", Utils.getString(ctx, Constants.USER_ID));
        params.put("gid", mgid);
        Utils.log(TAG, "REMOVE_MEMBER_URL : " + Constants.APP_MEMBER_REMOVE + "?" + params);
        client.post(Constants.APP_MEMBER_REMOVE, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                Utils.log(TAG, "REMOVE_MEMBER_RESPONSE : " + response);
                String success = "", message = "";
                try {
                    JSONObject res = new JSONObject(response);
                    success = res.getString("success");
                    message = res.getString("message");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                Utils.log(TAG, " SUCCESS " + success);
                if (success.equals("yes")) {
                    startActivity(new Intent(MyGroupMembers.this, Dashboard.class));
                } else {
                    Toast.makeText(ctx, message, Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "REMOVE_MEMBER_ERROR : " + error.getMessage());
            }
        });
    }
}
