package com.suguretaventure.mymarriagegroup;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;
import com.suguretaventure.mymarriagegroup.Model.MarketAddPersonModel;
import com.suguretaventure.mymarriagegroup.Model.MarketingModel;
import com.suguretaventure.mymarriagegroup.imageresize.core.ImageCompressTask;
import com.suguretaventure.mymarriagegroup.imageresize.listeners.IImageCompressTaskListener;
import com.suguretaventure.mymarriagegroup.imageresize.util.Util;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.ExifUtil;
import com.suguretaventure.mymarriagegroup.utils.Utils;
import com.suguretaventure.mymarriagegroup.utils.WebServiceCaller;
import com.yalantis.ucrop.UCrop;

import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import cz.msebera.android.httpclient.Header;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;

public class UpdateMarketingActivity extends AppCompatActivity implements PaymentResultListener {
    private String TAG = "UPDATE_MARKETING_ACTIVITY";
    private Context context = this;
    private String id;
    private String cid;
    private String cname;
    private String name;
    private String address;
    private String mobile;
    private String email;
    private String image;
    private String description;
    private String city;
    private String website;
    private String photo,photo1,photo2;
    private String lat;
    private String lon;

    private EditText txtname, txtaddress, txtemail, txtmobileno, txtdesc, txtque, txtans, txtphotoid, txtCity, txtwebsite;
    private Spinner spnCategoryUpdate;
    private ArrayList<String> ListCategory, ListCategoryId;

    private static final int GALLARY = 1;
    private static final int CAMERA = 2;
    private static final int REQUEST_MULTIPLE_PERMISSION = 100;
    private ExecutorService mExecutorService = Executors.newFixedThreadPool(1);
    private ImageCompressTask imageCompressTask;
    private Bitmap image_bitmap = null;

    private TextView btn_create_grp;
    private String CameraFileAbsolutePath, CameraFileAbsolutePath1, CameraFileAbsolutePath2;
    private int imageUploadType;
    private ImageView imgphotoid, imgphotoid11, imgphotoid2, imgphotoid_select, imgphotoid_select1, imgphotoid_select2;

    RadioGroup rgPaymentOption;
    RadioButton rbtnYes,rbtnNo;

    private Uri photoUri;
    private FirebaseAnalytics mFirebaseAnalytics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_marketing);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        getSupportActionBar().setTitle(getResources().getString(R.string.app_name_title));
        allocatememory();
        getData();
        setListener();
    }

    private void getCategory() {
        ListCategory = new ArrayList<>();
        ListCategoryId = new ArrayList<>();

        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        Utils.log(TAG, Constants.APP_GET_MARKETING_LIST);
        client.post(Constants.APP_GET_MARKETING_LIST, null, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                Utils.log(TAG, "APP_GET_MARKETING_LIST_RESPONSE : " + new String(responseBody));
                MarketingModel model = new Gson().fromJson(new String(responseBody), MarketingModel.class);
                for (int i = 0; i < model.data.size(); i++) {
                    ListCategory.add("" + model.data.get(i).cname);
                    ListCategoryId.add("" + model.data.get(i).cid);
                }
                ArrayAdapter AgenttypeAdapter = new ArrayAdapter(context, R.layout.my_spinner, R.id.tvSpinner, ListCategory);
                spnCategoryUpdate.setAdapter(AgenttypeAdapter);

                if (cid != null) {
                    for (int i = 0; i < ListCategory.size(); i++) {
                        if (cid.equalsIgnoreCase("" + ListCategoryId.get(i))) {
                            spnCategoryUpdate.setSelection(i);
                        }
                    }
                } else {
                    Toast.makeText(UpdateMarketingActivity.this, "0000000", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "APP_GET_MARKETING_LIST_ERROR : " + error.getMessage());

            }
        });

    }

    private void setListener() {
        imgphotoid_select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //storage.write("type","1"); //user image
                imageUploadType = 1;
                requestPermission();
            }
        });


        imgphotoid_select1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //storage.write("type","1"); //user image
                imageUploadType = 2;
                requestPermission();
            }
        });


        imgphotoid_select2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //storage.write("type","1"); //user image
                requestPermission();
                imageUploadType = 3;
            }
        });


        rbtnNo.setChecked(true);
        rgPaymentOption.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if (radioGroup.getCheckedRadioButtonId() == R.id.rbtnYes) {
                    btn_create_grp.setText("Proceed to Pay");

                }
                if (radioGroup.getCheckedRadioButtonId() == R.id.rbtnNo)  {
                    btn_create_grp.setText("Update");
                }
            }
        });

        btn_create_grp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (txtname.getText().toString().length() == 0) {
                    txtname.setError("Title required");
                } else if (txtaddress.getText().toString().length() == 0) {
                    txtaddress.setError("Address required");
                } else if (txtemail.getText().toString().length() == 0) {
                    txtemail.setError("Email required");
                } else if (txtmobileno.getText().toString().length() < 0) {
                    txtmobileno.setError("Mobile Number required");
                } else if (txtCity.getText().toString().length() < 0) {
                    txtCity.setError("City required");
                } else if (txtdesc.getText().toString().length() == 0) {
                    txtdesc.setError("Description required");
                } else {
                    name = txtname.getText().toString();
                    address = txtaddress.getText().toString();
                    email = txtemail.getText().toString();
                    mobile = txtmobileno.getText().toString();
                    description = txtdesc.getText().toString();
                    city = txtCity.getText().toString();
                    website = txtwebsite.getText().toString();
                    // createNewGroup(txtgtitle.getText().toString(),aldialog);

                    if (!Utils.getString(context, "pay_status").equals("0")){
                        updateMrketingPerson(Utils.getString(context, "pay_status"));
                    }else {
                        if (rbtnYes.isChecked()) {
                            startPayment();
                        } else {
                            updateMrketingPerson("0");
                        }
                    }

                }
            }
        });
    }

    private void allocatememory() {
        txtname = findViewById(R.id.txtname);
        txtaddress = findViewById(R.id.txtaddress);
        txtemail = findViewById(R.id.txtemail);
        txtmobileno = findViewById(R.id.txtmobileno);
        txtdesc = findViewById(R.id.txtdesc);
        txtque = findViewById(R.id.txtque);
        txtans = findViewById(R.id.txtans);
        txtphotoid = findViewById(R.id.txtphotoid);
        btn_create_grp = findViewById(R.id.btn_create_grp);
        imgphotoid_select = findViewById(R.id.imgphotoid_select);
        imgphotoid_select1 = findViewById(R.id.imgphotoid_select1);
        imgphotoid_select2 = findViewById(R.id.imgphotoid_select2);
        imgphotoid = findViewById(R.id.imgphotoid);
        imgphotoid11 = findViewById(R.id.imgphotoid11);
        imgphotoid2 = findViewById(R.id.imgphotoid2);
        txtCity = findViewById(R.id.txtCity);
        txtwebsite = findViewById(R.id.txtwebsite);
        spnCategoryUpdate = findViewById(R.id.spnCategoryUpdate);
        rgPaymentOption = findViewById(R.id.rgPaymentOption);
        rbtnYes = findViewById(R.id.rbtnYes);
        rbtnNo = findViewById(R.id.rbtnNo);
    }

    private void getData() {
        id = "" + Utils.getString(context, "" + Constants.MV_ID);
        cid = "" + Utils.getString(context, "" + Constants.MV_CID);
        cname = "" + Utils.getString(context, "" + Constants.MV_CNAME);
        name = "" + Utils.getString(context, "" + Constants.MV_NAME);
        address = "" + Utils.getString(context, "" + Constants.MV_ADDRESS);
        mobile = "" + Utils.getString(context, "" + Constants.MV_MOBILE);
        email = "" + Utils.getString(context, "" + Constants.MV_EMAIL);
        image = "" + Utils.getString(context, "" + Constants.MV_IMAGE);
        photo = "" + Utils.getString(context, "" + Constants.MV_PHOTO);
        photo1 = "" + Utils.getString(context, "" + Constants.MV_PHOTO1);
        photo2 = "" + Utils.getString(context, "" + Constants.MV_PHOTO2);
        description = "" + Utils.getString(context, "" + Constants.MV_DESCRIPTION);
        lat = "" + Utils.getString(context, "" + Constants.MV_LAT);
        lon = "" + Utils.getString(context, "" + Constants.MV_LON);
        city = "" + Utils.getString(context, "" + Constants.MV_CITY);
        website = "" + Utils.getString(context, "" + Constants.WEBSITE);
        Utils.log(TAG, "MY_CID : " + cid);
        getCategory();

        txtname.setText("" + name);
        txtaddress.setText("" + address);
        txtemail.setText("" + email);
        txtmobileno.setText("" + mobile);
        txtdesc.setText("" + description);
        txtCity.setText("" + city);
        txtwebsite.setText("" + website);
        txtque.setText("");
        txtans.setText("");
        txtphotoid.setText("");
        Glide.with(context).load(Utils.getString(context, "" + Constants.MV_IMAGE)).into(imgphotoid);

        if (!Utils.getString(context, "" + Constants.MV_IMAGE1).equals("")){
            Glide.with(context).load(Utils.getString(context, "" + Constants.MV_IMAGE1)).into(imgphotoid11);
        }

        if (!Utils.getString(context, "" + Constants.MV_IMAGE2).equals("")){
            Glide.with(context).load(Utils.getString(context, "" + Constants.MV_IMAGE2)).into(imgphotoid2);
        }

        if (!Utils.getString(context, "pay_status").equals("0")){
            rgPaymentOption.setVisibility(View.GONE);
        }

    }

    private void updateMrketingPerson(String razorPayId) {
        final ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.setTitle("Please wait...");
        progressDialog.show();
        progressDialog.setCancelable(false);
        RequestBody fileReqBody,fileReqBody1,fileReqBody2;
        MultipartBody.Part part,part1,part2;
        File file,file1,file2;
        if (CameraFileAbsolutePath != null) {
            file = new File(CameraFileAbsolutePath);
            Utils.log("API_DATA",CameraFileAbsolutePath);
            // Create a request body with file and image media type
            fileReqBody = RequestBody.create(MediaType.parse("image/*"), file);
            // Create MultipartBody.Part using file request-body,file name and part name
            part = MultipartBody.Part.createFormData("image", file.getName(), fileReqBody);
        } else {
            fileReqBody = RequestBody.create(MediaType.parse("image/*"), "");
            // Create MultipartBody.Part using file request-body,file name and part name
            part = MultipartBody.Part.createFormData("image", "");
        }


        if (CameraFileAbsolutePath1 != null) {
            file1 = new File(CameraFileAbsolutePath1);
            Utils.log("API_DATA",CameraFileAbsolutePath1);
            // Create a request body with file and image media type
            fileReqBody1 = RequestBody.create(MediaType.parse("image/*"), file1);
            // Create MultipartBody.Part using file request-body,file name and part name
            part1 = MultipartBody.Part.createFormData("image", file1.getName(), fileReqBody1);
        } else {
            fileReqBody1 = RequestBody.create(MediaType.parse("image/*"), "");
            // Create MultipartBody.Part using file request-body,file name and part name
            part1 = MultipartBody.Part.createFormData("image", "");
        }

        if (CameraFileAbsolutePath2 != null) {
            file2 = new File(CameraFileAbsolutePath2);
            Utils.log("API_DATA",CameraFileAbsolutePath2);
            // Create a request body with file and image media type
            fileReqBody2 = RequestBody.create(MediaType.parse("image/*"), file2);
            // Create MultipartBody.Part using file request-body,file name and part name
            part2 = MultipartBody.Part.createFormData("image", file2.getName(), fileReqBody2);
        } else {
            fileReqBody2 = RequestBody.create(MediaType.parse("image/*"), "");
            // Create MultipartBody.Part using file request-body,file name and part name
            part2 = MultipartBody.Part.createFormData("image", "");
        }







        //Create request body with text description and text media type
        RequestBody description1 = RequestBody.create(MediaType.parse("text/plain"), id);
        RequestBody description2 = RequestBody.create(MediaType.parse("text/plain"), photo);

        RequestBody description3 = RequestBody.create(MediaType.parse("text/plain"), txtname.getText().toString());
        RequestBody description4 = RequestBody.create(MediaType.parse("text/plain"), txtaddress.getText().toString());
        RequestBody description5 = RequestBody.create(MediaType.parse("text/plain"), txtmobileno.getText().toString());
        RequestBody description6 = RequestBody.create(MediaType.parse("text/plain"), txtemail.getText().toString());
        RequestBody description7 = RequestBody.create(MediaType.parse("text/plain"), txtdesc.getText().toString());
        RequestBody description10 = RequestBody.create(MediaType.parse("text/plain"), city);
        RequestBody description11 = RequestBody.create(MediaType.parse("text/plain"), cid);
        RequestBody description12 = RequestBody.create(MediaType.parse("text/plain"), website);
        RequestBody description8 = RequestBody.create(MediaType.parse("text/plain"), "lat");
        RequestBody description9 = RequestBody.create(MediaType.parse("text/plain"), "lon");

        RequestBody description13 = RequestBody.create(MediaType.parse("text/plain"), photo1);
        RequestBody description14 = RequestBody.create(MediaType.parse("text/plain"), photo2);
        RequestBody description15 = RequestBody.create(MediaType.parse("text/plain"), razorPayId);


        Utils.log(TAG, "description1  : " + id);
        Utils.log(TAG, "description2  : " + photo);
        Utils.log(TAG, "description3  : " + txtname.getText().toString());
        Utils.log(TAG, "description4  : " + txtaddress.getText().toString());
        Utils.log(TAG, "description5  : " + txtmobileno.getText().toString());
        Utils.log(TAG, "description6  : " + txtemail.getText().toString());
        Utils.log(TAG, "description7  : " + txtdesc.getText().toString());
        Utils.log(TAG, "description10  : " + city);
        Utils.log(TAG, "description11  : " + cid);
        Utils.log(TAG, "description8  : " + "lat");
        Utils.log(TAG, "description9  : " + "lon");
        WebServiceCaller.getClient().marketUpdatePersonModelCall(part,part1,part2, description1, description2,description13,description14, description3, description4, description5, description6, description7, description8, description9, description10, description11, description12,description15).enqueue(new Callback<MarketAddPersonModel>() {
            @Override
            public void onResponse(Call<MarketAddPersonModel> call, retrofit2.Response<MarketAddPersonModel> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(context, response.body().getMsg(), Toast.LENGTH_LONG).show();
                    UpdateMarketingActivity.super.onBackPressed();
                } else {
                    Toast.makeText(context, "Error", Toast.LENGTH_LONG).show();

                }
                Utils.setString(context, "" + Constants.MV_CID, null);
                Utils.setString(context, "" + Constants.MV_CNAME, null);
                Utils.setString(context, "" + Constants.MV_NAME, null);
                Utils.setString(context, "" + Constants.MV_ADDRESS, null);
                Utils.setString(context, "" + Constants.MV_MOBILE, null);
                Utils.setString(context, "" + Constants.MV_EMAIL, null);
                Utils.setString(context, "" + Constants.MV_IMAGE, null);
                Utils.setString(context, "" + Constants.MV_IMAGE1, null);
                Utils.setString(context, "" + Constants.MV_IMAGE2, null);
                Utils.setString(context, "" + Constants.MV_PHOTO, null);
                Utils.setString(context, "" + Constants.MV_PHOTO1, null);
                Utils.setString(context, "" + Constants.MV_PHOTO2, null);
                Utils.setString(context, "" + Constants.MV_DESCRIPTION, null);
                Utils.setString(context, "" + Constants.MV_LAT, null);
                Utils.setString(context, "" + Constants.MV_LON, null);
                Utils.setString(context, "" + Constants.WEBSITE, null);
                Utils.setString(context, "pay_status" , null);
                progressDialog.dismiss();
            }

            @Override
            public void onFailure(Call<MarketAddPersonModel> call, Throwable t) {
                //swipeContainer.setRefreshing(false)
                //
                progressDialog.dismiss();
                Toast.makeText(context, "Error", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void showDialogBox() {
        androidx.appcompat.app.AlertDialog.Builder b1 = new androidx.appcompat.app.AlertDialog.Builder(context);
        b1.setTitle("Select Photo");
        b1.setIcon(R.mipmap.logo1);
        b1.setMessage("I want to select photo");
        b1.setPositiveButton("Using CAMERA", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                File image = null;
                try {
                    image = Util.CreteFileWithUniqueName(context);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (imageUploadType == 1) {
                    CameraFileAbsolutePath = image.getAbsolutePath();
                }
                if (imageUploadType == 2) {
                    CameraFileAbsolutePath1 = image.getAbsolutePath();
                }
                if (imageUploadType == 3) {
                    CameraFileAbsolutePath2 = image.getAbsolutePath();
                }
                Uri photoURI = FileProvider.getUriForFile(context,
                        BuildConfig.APPLICATION_ID + ".provider", image);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(intent, CAMERA);
            }
        });
        b1.setNegativeButton("using Gallery", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent = new Intent(Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, GALLARY);
            }
        });

        b1.create().show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GALLARY && resultCode == RESULT_OK &&
                data != null) {

            Uri uri = data.getData();
            Cursor cursor = MediaStore.Images.Media.query(getContentResolver(),
                    uri, new String[]{MediaStore.Images.Media.DATA});
            if (cursor != null && cursor.moveToFirst()) {
                switch (imageUploadType) {
                    case 1:
                        CameraFileAbsolutePath = cursor.getString(cursor.getColumnIndexOrThrow
                                (MediaStore.Images.Media.DATA));
                        photoUri = Uri.parse("file:"+CameraFileAbsolutePath);
                        break;
                    case 2:
                        CameraFileAbsolutePath1 = cursor.getString(cursor.getColumnIndexOrThrow
                                (MediaStore.Images.Media.DATA));

                        photoUri = Uri.parse("file:"+CameraFileAbsolutePath1);

                        break;
                    case 3:
                        CameraFileAbsolutePath2 = cursor.getString(cursor.getColumnIndexOrThrow
                                (MediaStore.Images.Media.DATA));
                        photoUri = Uri.parse("file:"+CameraFileAbsolutePath2);
                        break;
                }

            }
            if (photoUri!=null){
                File destimage = null;
                try {
                    destimage = Util.CreteFileWithUniqueName(this);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                File file = new File(uri.getPath());
                UCrop.of(photoUri, Uri.fromFile(destimage))
                        .withAspectRatio(8f, 5f)
                        .withMaxResultSize(1024, 650)
                        .start(UpdateMarketingActivity.this);
            }




            /*Uri uri = data.getData();
            Cursor cursor = MediaStore.Images.Media.query(getContentResolver(),
                    uri, new String[]{MediaStore.Images.Media.DATA});
            if (cursor != null && cursor.moveToFirst()) {
                String imgPath = cursor.getString(cursor.getColumnIndexOrThrow
                        (MediaStore.Images.Media.DATA));
                imageCompressTask = new ImageCompressTask(this, imgPath,
                        iImageCompressTaskListener);
                mExecutorService.execute(imageCompressTask);
                if (imageUploadType == 1) {
                    CameraFileAbsolutePath = imgPath;
                    Bitmap bmp = BitmapFactory.decodeFile(imgPath);
                    imgphotoid.setRotation(ExifUtil.getCameraPhotoOrientation(CameraFileAbsolutePath));
                    imgphotoid.setImageBitmap(bmp);
                }

                if (imageUploadType == 2) {
                    CameraFileAbsolutePath1 = imgPath;
                    Bitmap bmp = BitmapFactory.decodeFile(imgPath);
                    imgphotoid11.setRotation(ExifUtil.getCameraPhotoOrientation(CameraFileAbsolutePath1));
                    imgphotoid11.setImageBitmap(bmp);
                }

                if (imageUploadType == 3) {
                    CameraFileAbsolutePath2 = imgPath;
                    Bitmap bmp = BitmapFactory.decodeFile(imgPath);
                    imgphotoid2.setRotation(ExifUtil.getCameraPhotoOrientation(CameraFileAbsolutePath2));
                    imgphotoid2.setImageBitmap(bmp);
                }
            }*/

        } else if (requestCode == CAMERA) {


            switch (imageUploadType){
                case 1:
                    photoUri = Uri.parse("file:"+CameraFileAbsolutePath);
                    break;
                case 2:
                    photoUri = Uri.parse("file:"+CameraFileAbsolutePath1);
                    break;
                case 3:
                    photoUri = Uri.parse("file:"+CameraFileAbsolutePath2);
                    break;
            }
            if (photoUri!=null){
                File destimage = null;
                try {
                    destimage = Util.CreteFileWithUniqueName(this);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                UCrop.of(photoUri, Uri.fromFile(destimage))
                        .withAspectRatio(8f, 5f)
                        .withMaxResultSize(1024, 650)
                        .start(UpdateMarketingActivity.this);
            }


           /* if (imageUploadType == 1) {
                File imgFile = new File(CameraFileAbsolutePath);
                if (imgFile.exists()) {
                    imageCompressTask = new ImageCompressTask(this, CameraFileAbsolutePath,
                            iImageCompressTaskListener);
                    mExecutorService.execute(imageCompressTask);
                    Bitmap bmp = BitmapFactory.decodeFile(CameraFileAbsolutePath);
                    imgphotoid.setRotation(ExifUtil.getCameraPhotoOrientation(CameraFileAbsolutePath));
                    imgphotoid.setImageBitmap(bmp);
                }
            }

            if (imageUploadType == 2) {
                File imgFile = new File(CameraFileAbsolutePath1);
                if (imgFile.exists()) {
                    imageCompressTask = new ImageCompressTask(this, CameraFileAbsolutePath1,
                            iImageCompressTaskListener);
                    mExecutorService.execute(imageCompressTask);
                    Bitmap bmp = BitmapFactory.decodeFile(CameraFileAbsolutePath1);
                    imgphotoid11.setRotation(ExifUtil.getCameraPhotoOrientation(CameraFileAbsolutePath1));
                    imgphotoid11.setImageBitmap(bmp);
                }
            }

            if (imageUploadType == 3) {
                File imgFile = new File(CameraFileAbsolutePath2);
                if (imgFile.exists()) {
                    imageCompressTask = new ImageCompressTask(this, CameraFileAbsolutePath2,
                            iImageCompressTaskListener);
                    mExecutorService.execute(imageCompressTask);
                    Bitmap bmp = BitmapFactory.decodeFile(CameraFileAbsolutePath2);
                    imgphotoid2.setRotation(ExifUtil.getCameraPhotoOrientation(CameraFileAbsolutePath2));
                    imgphotoid2.setImageBitmap(bmp);
                }
            }*/
        }else if (resultCode == RESULT_OK && requestCode == UCrop.REQUEST_CROP) {
            final Uri resultUri = UCrop.getOutput(data);

            Log.e("CROP IMAGE PATH", resultUri.toString());

            Bitmap cursor = null;
            try {
                cursor = MediaStore.Images.Media.getBitmap(getContentResolver(),
                        resultUri);
            } catch (IOException e) {
                e.printStackTrace();
            }
            if ( imageUploadType== 1) {
                imgphotoid.setImageBitmap(cursor);
            } else if (imageUploadType == 2) {
                imgphotoid11.setImageBitmap(cursor);
            } else if (imageUploadType == 3) {
                imgphotoid2.setImageBitmap(cursor);
            }

        }
    }

    private IImageCompressTaskListener iImageCompressTaskListener = new IImageCompressTaskListener() {
        @Override
        public void onComplete(List<File> compressed) {
            File file = compressed.get(0);
            if (imageUploadType == 1) {
                imgphotoid.setImageBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()));
            }
            if (imageUploadType == 2) {
                imgphotoid11.setImageBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()));
            }

            if (imageUploadType == 3) {
                imgphotoid2.setImageBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()));
            }
        }

        @Override
        public void onError(Throwable error) {
        }
    };

    void requestPermission() {
        if (PackageManager.PERMISSION_GRANTED !=
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ||
                PackageManager.PERMISSION_GRANTED != ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)) {
            String[] PermissionList = {Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.CAMERA};
            if (ActivityCompat.shouldShowRequestPermissionRationale
                    (this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ||
                    ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA)) {

                ActivityCompat.requestPermissions(this, PermissionList,
                        REQUEST_MULTIPLE_PERMISSION);
            } else {
                ActivityCompat.requestPermissions(this, PermissionList,
                        REQUEST_MULTIPLE_PERMISSION);
            }
        } else {
            showDialogBox();
        }
    }


    public void startPayment() {
        final Activity activity = this;

        final Checkout co = new Checkout();

        try {
            JSONObject options = new JSONObject();
            options.put("name", "" + Utils.getString(context, Constants.USER_NAME));
            options.put("description", "Add Market Charge");
            //You can omit the image option to fetch the image from dashboard
            options.put("image", "");
            options.put("currency", "USD");
            options.put("amount", "100");

            JSONObject preFill = new JSONObject();
            preFill.put("email", "" + Utils.getString(context, Constants.USER_EMAIL));
            preFill.put("contact", "" + Utils.getString(context, Constants.USER_MOBILE));

            options.put("prefill", preFill);

            co.open(activity, options);
        } catch (Exception e) {
            Toast.makeText(activity, "Error in payment: " + e.getMessage(), Toast.LENGTH_SHORT)
                    .show();
            e.printStackTrace();
        }
    }

    /**
     * The name of the function has to be
     * onPaymentSuccess
     * Wrap your code in try catch, as shown, to ensure that this method runs correctly
     */
    @SuppressWarnings("unused")
    @Override
    public void onPaymentSuccess(String razorpayPaymentID) {
        try {
            updateMrketingPerson(razorpayPaymentID);

        } catch (Exception e) {
            Utils.log(TAG, "Exception in onPaymentSuccess : " + e.getMessage());
        }
    }

    /**
     * The name of the function has to be
     * onPaymentError
     * Wrap your code in try catch, as shown, to ensure that this method runs correctly
     */
    @SuppressWarnings("unused")
    @Override
    public void onPaymentError(int code, String response) {
        try {
            Toast.makeText(this, "Payment failed: " + code + " " + response, Toast.LENGTH_SHORT).show();
            Log.d("PAYMENT_CODE", String.valueOf(code));
            Log.d("PAYMENT_RESPONSE", response);

        } catch (Exception e) {
            Utils.log(TAG, "Exception in onPaymentError : " + e.getMessage());
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
