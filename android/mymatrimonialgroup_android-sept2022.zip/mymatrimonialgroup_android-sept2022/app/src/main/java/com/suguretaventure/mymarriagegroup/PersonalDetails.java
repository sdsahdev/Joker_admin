package com.suguretaventure.mymarriagegroup;

import android.app.ProgressDialog;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.jaredrummler.materialspinner.MaterialSpinner;
import com.suguretaventure.mymarriagegroup.Model.PesonDetailsModel;
import com.suguretaventure.mymarriagegroup.utils.Utility;
import com.suguretaventure.mymarriagegroup.utils.Utils;
import com.suguretaventure.mymarriagegroup.utils.WebServiceCaller;

import retrofit2.Call;
import retrofit2.Callback;

public class PersonalDetails extends AppCompatActivity {

    private EditText txtfullname, txtsurname, txteducation, txtincome, txtheight, txtweight, txtblood, txtdobdate, txtdobtime, txtdobplace, txthobbies, txtexpectation, txtfathername, txtmothername, txtbroname, txtsisname, txtaddress, txtcontact1, txtcontact2, txtmailid, txtbgphotoid;
    private TextView lblskip;
    private RadioGroup rdogrpgender;
    private RadioButton rdomale, rdofemale;
    //private Spinner spnoccupation;
    private MaterialSpinner spnoccupation1, spnblood;
    ImageView img, imgback;
    String rid;
    private FirebaseAnalytics mFirebaseAnalytics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_details);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        initi();
        rid = getIntent().getExtras().getString("Rid");

        getDetails(rid);

    }

    public void initi() {

        img = findViewById(R.id.img);
///        imgback = findViewById(R.id.imgback);
        txtfullname = findViewById(R.id.txtfullname);
        txtsurname = findViewById(R.id.txtsurname);
        txteducation = findViewById(R.id.txteducation);
        txtincome = findViewById(R.id.txtincome);
        txtheight = findViewById(R.id.txtheight);
        txtweight = findViewById(R.id.txtweight);
        txtblood = findViewById(R.id.txtblood);
        txtdobdate = findViewById(R.id.txtdobdate);
        txtdobtime = findViewById(R.id.txtdobtime);
        txtdobplace = findViewById(R.id.txtdobplace);
        txthobbies = findViewById(R.id.txthobbies);
        txtexpectation = findViewById(R.id.txtexpectation);
        txtfathername = findViewById(R.id.txtfathername);
        txtmothername = findViewById(R.id.txtmothername);
        txtbroname = findViewById(R.id.txtbroname);
        txtsisname = findViewById(R.id.txtsisname);
        txtaddress = findViewById(R.id.txtaddress);
        txtcontact1 = findViewById(R.id.txtcontact1);
        txtcontact2 = findViewById(R.id.txtcontact2);
        txtmailid = findViewById(R.id.txtmailid);

        imgback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
       /* rdogrpgender = findViewById(R.id.rdogrpgender);
        rdomale = findViewById(R.id.rdomale);
        rdofemale = findViewById(R.id.rdofemale);*/
        /* gender = "1";

        bgroupAdapter = new ArrayAdapter<String>(ctx,
                android.R.layout.simple_spinner_item,
                ctx.getResources().getStringArray(R.array.blood));
        bgroupAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnblood.setAdapter(bgroupAdapter);*/
    }

    public void getDetails(final String rid) {
        Utils.log("TAG_BIO-DATA", rid);
        if (!Utility.isNetworkAvailable(PersonalDetails.this)) {
            /*Snackbar.make(txtaddress, "Internet connection is not available", Snackbar.LENGTH_INDEFINITE).setAction("RETRY", new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    getDetails(rid);
                }
            }).setActionTextColor(getResources().getColor(R.color.colorPrimary)).show();*/
        } else {
            final ProgressDialog progressDialog = new ProgressDialog(PersonalDetails.this);
            progressDialog.setTitle("Fetching Data...");
            progressDialog.show();
            progressDialog.setCancelable(false);

            WebServiceCaller.getClient().getPesonDetailsModelCall(rid).enqueue(new Callback<PesonDetailsModel>() {
                @Override
                public void onResponse(Call<PesonDetailsModel> call, retrofit2.Response<PesonDetailsModel> response) {
                    if (response.isSuccessful()) {

                        PesonDetailsModel pesonDetailsModel = response.body();
                        if (pesonDetailsModel.getSuccess()) {
                            if (pesonDetailsModel.getDetail().size() > 0) {
                                txtfullname.setText(pesonDetailsModel.getDetail().get(0).getName());
                                txtsurname.setText(pesonDetailsModel.getDetail().get(0).getSurname());
                                txteducation.setText(pesonDetailsModel.getDetail().get(0).getEducation());
                                txtincome.setText(pesonDetailsModel.getDetail().get(0).getIncome());
                                txtheight.setText(pesonDetailsModel.getDetail().get(0).getHeight());
                                txtweight.setText(pesonDetailsModel.getDetail().get(0).getWeight());
                                txtblood.setText("Blood group : " + pesonDetailsModel.getDetail().get(0).getBlood());
                                txtdobdate.setText(pesonDetailsModel.getDetail().get(0).getBirthdate());
                                txtdobtime.setText(pesonDetailsModel.getDetail().get(0).getBirthtime());
                                txtdobplace.setText(pesonDetailsModel.getDetail().get(0).getBirthplace());
                                txthobbies.setText(pesonDetailsModel.getDetail().get(0).getHobbies());
                                txtexpectation.setText(pesonDetailsModel.getDetail().get(0).getExpectation());
                                txtfathername.setText(pesonDetailsModel.getDetail().get(0).getFathername());
                                txtmothername.setText(pesonDetailsModel.getDetail().get(0).getMothername());
                                txtbroname.setText(pesonDetailsModel.getDetail().get(0).getBrothers());
                                txtsisname.setText(pesonDetailsModel.getDetail().get(0).getSisters());
                                txtaddress.setText(pesonDetailsModel.getDetail().get(0).getAddress());
                                txtcontact1.setText(pesonDetailsModel.getDetail().get(0).getContact());
                                txtcontact2.setText(pesonDetailsModel.getDetail().get(0).getContact2());
                                txtmailid.setText(pesonDetailsModel.getDetail().get(0).getEmail());

                                Glide.with(PersonalDetails.this)
                                        .load(pesonDetailsModel.getDetail().get(0).getPhoto())
                                        // .apply(RequestOptions.circleCropTransform())
                                        .into(img);
                            }


                        } else {
                            Toast.makeText(PersonalDetails.this, "Details not found", Toast.LENGTH_LONG).show();
                            finish();
                        }


                    } else {
                        Toast.makeText(PersonalDetails.this, "Error", Toast.LENGTH_LONG).show();
                        finish();

                    }
                    progressDialog.dismiss();
                }

                @Override
                public void onFailure(Call<PesonDetailsModel> call, Throwable t) {
                    //swipeContainer.setRefreshing(false)
                    //
                    progressDialog.dismiss();
                    Toast.makeText(PersonalDetails.this, "Server Error", Toast.LENGTH_LONG).show();
                    finish();
                }
            });
        }

    }
}
