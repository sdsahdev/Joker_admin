package com.suguretaventure.mymarriagegroup;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.common.NetworkConnetionState;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;

import cz.msebera.android.httpclient.Header;

public class ChangePassword extends AppCompatActivity {
    private TextInputLayout input_layout_oldpassword, input_layout_newpassword, input_layout_newpassword1;
    private EditText txtoldpassword, txtnewpassword, txtnewpassword1;
    private TextView lblchangepwd;
    private boolean flag = true;
    private Context ctx = this;
    private String oldpassword, newpassword, newpassword1;
    private ProgressDialog pDialog;
    private String TAG = "CHANGE_PASSWORD";
    Object userid = null;
    ActionBar toolbar;
    private boolean isPass = true;
    private FirebaseAnalytics mFirebaseAnalytics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(getResources().getString(R.string.app_name_title));
//        setupToolbar();
        allocatememory();
        userid = Integer.parseInt(Utils.getString(ctx, Constants.USER_ID));
        setListener();

    }

    private void setListener() {
        lblchangepwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                input_layout_newpassword.setPasswordVisibilityToggleEnabled(false);
                input_layout_newpassword1.setPasswordVisibilityToggleEnabled(false);
                input_layout_oldpassword.setPasswordVisibilityToggleEnabled(false);
                if (NetworkConnetionState.isNetworkAvailable(ctx)) {
                    if (isPass) {
                        if (validateInfo()) // if true when all details is valid...
                        {
                            makechangepassrequest();
                        }
                    }
                } else {
                    input_layout_newpassword.setPasswordVisibilityToggleEnabled(true);
                    input_layout_newpassword1.setPasswordVisibilityToggleEnabled(true);
                    input_layout_oldpassword.setPasswordVisibilityToggleEnabled(true);
                    Toast.makeText(ctx, "No internet connection found. " +
                            "Please check your phone settings to turn on the internet.", Toast.LENGTH_LONG).show();
                }
            }
        });

        txtoldpassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if (s.length() > 0) {
                    input_layout_oldpassword.setPasswordVisibilityToggleEnabled(true);
                } else {
                    input_layout_oldpassword.setPasswordVisibilityToggleEnabled(false);
                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 0) {
                    input_layout_oldpassword.setPasswordVisibilityToggleEnabled(true);
                } else {
                    input_layout_oldpassword.setPasswordVisibilityToggleEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() > 0) {
                    input_layout_oldpassword.setPasswordVisibilityToggleEnabled(true);
                } else {
                    input_layout_oldpassword.setPasswordVisibilityToggleEnabled(false);
                }
            }
        });
        txtnewpassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if (s.length() > 0) {
                    input_layout_newpassword.setPasswordVisibilityToggleEnabled(true);
                } else {
                    input_layout_newpassword.setPasswordVisibilityToggleEnabled(false);
                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 0) {
                    input_layout_newpassword.setPasswordVisibilityToggleEnabled(true);
                } else {
                    input_layout_newpassword.setPasswordVisibilityToggleEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() > 0) {
                    input_layout_newpassword.setPasswordVisibilityToggleEnabled(true);
                } else {
                    input_layout_newpassword.setPasswordVisibilityToggleEnabled(false);
                }
            }
        });
        txtnewpassword.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    if (txtoldpassword.getText().toString().equals(txtnewpassword.getText().toString())) {
                        input_layout_newpassword.setPasswordVisibilityToggleEnabled(false);
                        txtnewpassword.setError("Different Password required");
                        isPass = false;
                    } else {
                        isPass = true;
                        input_layout_newpassword.setPasswordVisibilityToggleEnabled(true);
                    }
                }
            }
        });
        txtnewpassword1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if (s.length() > 0) {
                    input_layout_newpassword1.setPasswordVisibilityToggleEnabled(true);
                } else {
                    input_layout_newpassword1.setPasswordVisibilityToggleEnabled(false);
                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 0) {
                    input_layout_newpassword1.setPasswordVisibilityToggleEnabled(true);
                } else {
                    input_layout_newpassword1.setPasswordVisibilityToggleEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() > 0) {
                    input_layout_newpassword1.setPasswordVisibilityToggleEnabled(true);
                } else {
                    input_layout_newpassword1.setPasswordVisibilityToggleEnabled(false);
                }
            }
        });
    }

    private void makechangepassrequest() {
        this.pDialog = new ProgressDialog(this);
        this.pDialog.setMessage("Please  wait...");
        this.pDialog.setCancelable(false);
        showpDialog();

        String url = Common.GetWebServiceUrl() + "change_password.php";
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("rid", String.valueOf(userid));
        params.put("oldpwd", oldpassword);
        params.put("newpwd", newpassword);
        client.post(url, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                try {
                    JSONArray response = new JSONArray(res);
                    String error = response.getJSONObject(0).getString("error");
                    if (error.equals("no error") == false)
                        Common.showDialog(ctx, error);
                    else {
                        String success = response.getJSONObject(1).getString("success");
                        String message = response.getJSONObject(2).getString("message");
                        Toast.makeText(ctx, message, Toast.LENGTH_LONG).show();
                        if (success.equals("yes") == true)
                            finish();
                        hidePDialog();
                    }
                    hidePDialog();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                hidePDialog();
            }
        });
    }

    public void allocatememory() {
        txtoldpassword = (EditText) findViewById(R.id.txtoldpassword);
        txtnewpassword = (EditText) findViewById(R.id.txtnewpassword);
        txtnewpassword1 = (EditText) findViewById(R.id.txtnewpassword1);
        lblchangepwd = (TextView) findViewById(R.id.lblchangepwd);
        input_layout_oldpassword = findViewById(R.id.input_layout_oldpassword);
        input_layout_newpassword = findViewById(R.id.input_layout_newpassword);
        input_layout_newpassword1 = findViewById(R.id.input_layout_newpassword1);
    }

    private boolean validateInfo() {
        flag = true;
        String msg = "";
        oldpassword = txtoldpassword.getText().toString();
        newpassword = txtnewpassword.getText().toString();
        newpassword1 = txtnewpassword1.getText().toString();

        if (oldpassword.length() == 0) {
            txtoldpassword.requestFocus();
            txtoldpassword.setError("Current password required");
            flag = false;
        }

        if (newpassword.length() == 0) {
            txtnewpassword.requestFocus();
            txtnewpassword.setError("New password required");
            flag = false;
        }

        if (newpassword1.length() == 0) {
            txtnewpassword1.requestFocus();
            txtnewpassword1.setError("Confirm password required");
            flag = false;
        }

        if (newpassword.equals(newpassword1) == false) {
            txtnewpassword1.requestFocus();
            txtnewpassword1.setError("Both Password must be same");
            flag = false;
        }
        return flag;
    }

    private void showpDialog() {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }

    // hide process Dialog box
    private void hidePDialog() {
        if (this.pDialog != null) {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }

    public void setupToolbar() {
        toolbar = getSupportActionBar();
        assert toolbar != null;
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (android.R.id.home == item.getItemId()) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
