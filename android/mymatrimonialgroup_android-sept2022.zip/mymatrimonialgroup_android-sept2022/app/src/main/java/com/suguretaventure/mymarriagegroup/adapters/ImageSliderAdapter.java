package com.suguretaventure.mymarriagegroup.adapters;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.viewpager.widget.PagerAdapter;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.suguretaventure.mymarriagegroup.R;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.utils.ExifUtil;

import java.util.ArrayList;

import static com.suguretaventure.mymarriagegroup.utils.ExifUtil.rotate;

public class ImageSliderAdapter extends PagerAdapter {
    private Context context;
    private ArrayList<String> image;

    public ImageSliderAdapter(Context context, ArrayList<String> image) {
        this.context = context;
        this.image = image;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((View) object);
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull final ViewGroup container, final int position) {
        View view = LayoutInflater.from(context).inflate(R.layout.layout_slider, container, false);
        ImageView ivSlider = view.findViewById(R.id.ivSliderImage);


        /*StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);*/

      /*  Glide.with(context).load(image.get(position)).listener(new RequestListener<Drawable>() {
            @Override
            public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                return false;
            }

            @Override
            public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                return false;
            }
        }).into(ivSlider);*/

        Glide.with(context)
                .load(image.get(position))
                .placeholder(R.drawable.place_holder)
                .into(ivSlider);


        /*Bitmap imagee = null, rotatedBitmap = null;
        imagee = ExifUtil.getBitmapFromURL(image.get(position));
        int width = imagee.getWidth();
        int height = imagee.getHeight();

        if (width > height) {
            rotatedBitmap = rotate(imagee, 90);

            Glide.with(context).load(rotatedBitmap).listener(new RequestListener<Drawable>() {
                @Override
                public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                    return false;
                }

                @Override
                public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                    return false;
                }
            }).into(ivSlider);


        } else {
            Glide.with(context).load(image.get(position)).listener(new RequestListener<Drawable>() {
                @Override
                public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                    return false;
                }

                @Override
                public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                    return false;
                }
            }).into(ivSlider);
        }*/


        container.addView(view);

        ivSlider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LayoutInflater inflater;
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                View dialogLayout = inflater.inflate(R.layout.personimage_dialog, null);
                ImageView imgtabledesc = (ImageView) dialogLayout.findViewById(R.id.imgtabledesc);
                builder.setView(dialogLayout);
                Glide.with(context)
                        .load(image.get(position))
                        .into(imgtabledesc);
                Dialog dialog = builder.create();
                dialog.setCancelable(true);
                dialog.show();
            }
        });
        return view;
    }

    @Override
    public int getCount() {
        return image.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object o) {
        return view.equals(o);
    }
}
