package com.suguretaventure.mymarriagegroup;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.common.NetworkConnetionState;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;

import cz.msebera.android.httpclient.Header;

/**
 * Created by MOZAVI11 on img5/23/2016.
 */
public class Feedback extends AppCompatActivity {
    private EditText txtdesc /*txttitle, txtemail, txtname*/;
    private Button btnsendfb;
    private ProgressDialog pDialog;
    private String title, desc, email, name;
    private Context ctx = this;
    NetworkConnetionState connection;
    private String email_matcher_str = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+" + "(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
    ActionBar toolbar;
    private FirebaseAnalytics mFirebaseAnalytics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complaint);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(getResources().getString(R.string.app_name_title));
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE|WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        memoryallocation();
        txtdesc.requestFocus();
        listener();
    }

    private void listener() {
        btnsendfb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (NetworkConnetionState.isNetworkAvailable(ctx)) {
                    if (ValidateInput()) // if true when all details is valid...
                    {
                        makeRequest();
                    }
                } else {
                    Toast.makeText(ctx, "No internet connection found. Please check your phone settings to turn on the internet.", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void memoryallocation() {
        txtdesc = findViewById(R.id.txtfbdesc);
        /*txttitle = findViewById(R.id.txtfbtitle);
        txtemail = findViewById(R.id.txtfbemail);
        txtname = findViewById(R.id.txtfbname);*/
        btnsendfb = findViewById(R.id.btnsendfb);
        connection = new NetworkConnetionState();
    }

    public boolean ValidateInput() {
        boolean isvalid = true;
        desc = txtdesc.getText().toString().trim();
        name = Utils.getString(ctx, Constants.USER_NAME) + " " + Utils.getString(ctx, Constants.USER_SURNAME);
        email = Utils.getString(ctx, Constants.USER_EMAIL);
        title = "Title";
       /* name = txtname.getText().toString().trim();
        title = txttitle.getText().toString().trim();
        email = txtemail.getText().toString().trim().toLowerCase();*/
        if (desc.length() == 0) {
            isvalid = false;
            txtdesc.setError("Description required");
        }
        return isvalid;
    }

    public void makeRequest() {
        this.pDialog = new ProgressDialog(this);
        this.pDialog.setMessage("Sending...");
        this.pDialog.setCancelable(false);
        showpDialog();

        String url = Common.GetWebServiceUrl() + "feedback.php";
        Log.d("URL_FEEDBACK",url );
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("title", title);
        params.put("detail", desc);
        params.put("email", email);
        params.put("name", name);
        client.post(url, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                Log.d("RESPONSE_FEEDBACK", res);
                try {
                    JSONArray response = new JSONArray(res);
                    String error = response.getJSONObject(0).getString("error");
                    if (!error.equals("no error")) {
                        Common.showDialog(ctx, error);
                    } else {
                        String success = response.getJSONObject(1).getString("success");
                        String message = response.getJSONObject(2).getString("message");
                        if (success.equals("yes")) {
                            Toast.makeText(ctx, "Thank you for your feedback. We will certainly work on it and inform you.", Toast.LENGTH_LONG).show();
                            finish();
                        }
                    }
                    hidePDialog();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Log.d("Feedback_Error",error.getMessage());
                Common.showDialog(ctx);
                hidePDialog();
            }
        });
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    // show process Dialog box
    private void showpDialog() {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }

    // hide process Dialog box
    private void hidePDialog() {
        if (this.pDialog != null) {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }

    public void setupToolbar() {
        toolbar = getSupportActionBar();
        assert toolbar != null;
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_invitation, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        int id = item.getItemId();
        if (id == R.id.dashboard) {
            startActivity(new Intent(ctx, Dashboard.class));
        }else if (id == R.id.myGroup) {
            startActivity(new Intent(ctx, MyGroup.class));
        } else if (id == R.id.myPost) {
            startActivity(new Intent(ctx, MyPosts.class)
                    .putExtra("from", "dashboard")
                    .putExtra("gender", "-1"));
        } else if (id == R.id.MyFav_Arc) {
            startActivity(new Intent(ctx, MyFav_Arc.class)
                    .putExtra("from", "dashboard_fav"));
        }else if (id == R.id.logout) {
            final AlertDialog alertDialog = new AlertDialog.Builder(ctx).create();
            alertDialog.setMessage("Are you sure you want to logout ?");
            alertDialog.setButton(DialogInterface.BUTTON_POSITIVE, "Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    String FCM_KEY = "" + Utils.getString(ctx, Constants.TOKEN);
                    Utils.clearPreference(ctx);
                    Utils.setString(ctx, Constants.TOKEN, FCM_KEY);
                    startActivity(new Intent(ctx, Login.class));
                    finish();
                }
            });
            alertDialog.setButton(DialogInterface.BUTTON_NEGATIVE, "No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    alertDialog.dismiss();
                }
            });
            alertDialog.show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
