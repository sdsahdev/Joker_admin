package com.suguretaventure.mymarriagegroup;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.suguretaventure.mymarriagegroup.Model.BiodataDec;
import com.suguretaventure.mymarriagegroup.adapters.FavArcAdapter;
import com.suguretaventure.mymarriagegroup.adapters.MyDraftsAdapter;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.common.NetworkConnetionState;
import com.suguretaventure.mymarriagegroup.database.DBHelper;
import com.suguretaventure.mymarriagegroup.getsets.PersonGetSet;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;

public class MyDrafts extends AppCompatActivity {
    private Context ctx = this;
    private RecyclerView rcv_fav_arc;
    private TextView lbllistof, txtdefault, lblempty_fa;
    private ArrayList<BiodataDec> arr_adapter_list = new ArrayList<>();
    private MyDraftsAdapter myDraftsAdapter;
    private PersonGetSet personGetSet;
    private ProgressDialog pDialog;
    private String TAG = "MY_FAV_ARC";
    ActionBar toolbar;
    String groupId = "";
    private FirebaseAnalytics mFirebaseAnalytics;
    DBHelper dbHelper;
    String mgid, mgname, count, image_1, URL;
    boolean is_premium_flag = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_draft);
        dbHelper = new DBHelper(MyDrafts.this);
        mgid = getIntent().getExtras().getString("mg_id");
        mgname = getIntent().getExtras().getString("mgname");

        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(mgname);
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
//        setupToolbar();


        allocateMemory();


         /*URL = getIntent().getExtras().getString("URL");
        image_1 = getIntent().getExtras().getString("image");
        is_premium_flag = getIntent().getExtras().getBoolean("is_premium_flag");*/
        getAllBiodata();



    }

    private void getAllBiodata() {
     int userid = Integer.parseInt(Utils.getString(ctx, Constants.USER_ID));


        JSONArray biojsonarray = dbHelper.getBiodata(String.valueOf(userid),mgid);


        Log.d(TAG, "getAllBiodata: "+biojsonarray.length());


        for (int i=0;i<=biojsonarray.length();i++){
            try {
                BiodataDec biodataDec = new BiodataDec();
                JSONObject biodata_obj = biojsonarray.getJSONObject(i);
                Gson gson=new Gson();
                Log.d(TAG, "getAllBiodata: "+gson.fromJson(String.valueOf(biodata_obj),BiodataDec.class).getAnnual_income());
                if(biodata_obj.has("name")) {
                    if (!biodata_obj.getString("name").isEmpty()) {
                        biodataDec.setName(biodata_obj.getString("name"));
                    } else {
                        biodataDec.setName("");
                    }
                }

                if(biodata_obj.has("id")) {
                    if (!biodata_obj.getString("id").isEmpty()) {
                        biodataDec.setBid(biodata_obj.getString("id"));
                    }
                }

                if(biodata_obj.has("middlename"))
                    if (!biodata_obj.getString("middlename").isEmpty()) {
                        biodataDec.setMiddleName(biodata_obj.getString("middlename"));
                    }else {
                        biodataDec.setMiddleName("");

                    }

                if (biodata_obj.has("surname")) {
                    if (!biodata_obj.getString("surname").isEmpty()) {
                        biodataDec.setSurname(biodata_obj.getString("surname"));
                    } else {
                        biodataDec.setSurname("");
                    }
                }

                if (biodata_obj.has("age")) {
                    if (!biodata_obj.getString("age").isEmpty()) {
                        biodataDec.setAge(biodata_obj.getString("age"));
                    } else {
                        biodataDec.setAge("");
                    }
                }

                if (biodata_obj.has("education")) {
                    if (!biodata_obj.getString("education").isEmpty()) {
                        biodataDec.setEducation(biodata_obj.getString("education"));
                    } else {
                        biodataDec.setEducation("");
                    }
                }


                if (biodata_obj.has("degree")) {
                    if (!biodata_obj.getString("degree").isEmpty()) {
                        biodataDec.setSpecialization(biodata_obj.getString("degree"));
                    } else {
                        biodataDec.setSpecialization("");
                    }
                }

                if (biodata_obj.has("occupation")) {
                    if (!biodata_obj.getString("occupation").isEmpty()) {
                        biodataDec.setOccupation(biodata_obj.getString("occupation"));
                    } else {
                        biodataDec.setOccupation("");
                    }
                }

                if (biodata_obj.has("occupation_detail")) {
                    if (!biodata_obj.getString("occupation_detail").isEmpty()) {
                        biodataDec.setOccupation_detail(biodata_obj.getString("occupation_detail"));
                    } else {
                        biodataDec.setOccupation_detail("");
                    }
                }

                if (biodata_obj.has("annual_income")) {
                    if (!biodata_obj.getString("annual_income").isEmpty()) {
                        biodataDec.setAnnual_income(biodata_obj.getString("annual_income"));
                    } else {
                        biodataDec.setAnnual_income("");
                    }
                }
                if (biodata_obj.has("currency")) {
                    if (!biodata_obj.getString("currency").isEmpty()) {
                        biodataDec.setCurrency(biodata_obj.getString("currency"));
                    } else {
                        biodataDec.setCurrency("");
                    }
                }


                if (biodata_obj.has("city")) {
                    if (!biodata_obj.getString("city").isEmpty()) {
                        biodataDec.setCity(biodata_obj.getString("city"));
                    } else {
                        biodataDec.setCity("");
                    }
                }

                if (biodata_obj.has("date_of_birth")) {
                    if (!biodata_obj.getString("date_of_birth").isEmpty()) {
                        biodataDec.setDate_of_birth(biodata_obj.getString("date_of_birth"));
                    } else {
                        biodataDec.setDate_of_birth("");
                    }
                }

                if (biodata_obj.has("time_of_birth")) {
                    if (!biodata_obj.getString("time_of_birth").isEmpty()) {
                        biodataDec.setTime_of_birth(biodata_obj.getString("time_of_birth"));
                    } else {
                        biodataDec.setTime_of_birth("");
                    }
                }

                if (biodata_obj.has("place_of_birth")) {
                    if (!biodata_obj.getString("place_of_birth").isEmpty()) {
                        biodataDec.setPlace_of_birth(biodata_obj.getString("place_of_birth"));
                    } else {
                        biodataDec.setPlace_of_birth("");
                    }
                }

                if (biodata_obj.has("height")) {
                    if (!biodata_obj.getString("height").isEmpty()) {
                        biodataDec.setHeight(biodata_obj.getString("height"));
                    } else {
                        biodataDec.setHeight("");
                    }
                }

                if (biodata_obj.has("weight")) {
                    if (!biodata_obj.getString("weight").isEmpty()) {
                        biodataDec.setWeight(biodata_obj.getString("weight"));
                    } else {
                        biodataDec.setWeight("");
                    }
                }

                if (biodata_obj.has("blood_group")) {
                    if (!biodata_obj.getString("blood_group").isEmpty()) {
                        biodataDec.setBlood_group(biodata_obj.getString("blood_group"));
                    } else {
                        biodataDec.setBlood_group("");
                    }
                }

                if (biodata_obj.has("complexion")) {
                    if (!biodata_obj.getString("complexion").isEmpty()) {
                        biodataDec.setComplexion(biodata_obj.getString("complexion"));
                    } else {
                        biodataDec.setComplexion("");
                    }
                }

                if (biodata_obj.has("zodiac")) {
                    if (!biodata_obj.getString("zodiac").isEmpty()) {
                        biodataDec.setZodiac(biodata_obj.getString("zodiac"));
                    } else {
                        biodataDec.setZodiac("");
                    }
                }

                if (biodata_obj.has("fathers_name")) {
                    if (!biodata_obj.getString("fathers_name").isEmpty()) {
                        biodataDec.setFathers_name(biodata_obj.getString("fathers_name"));
                    } else {
                        biodataDec.setFathers_name("");
                    }
                }
              /*  if (biodata_obj.has("mother_name")) {
                    if (!biodata_obj.getString("mother_name").isEmpty()) {
                        biodataDec.setMother_name(biodata_obj.getString("mother_name"));
                    } else {
                        biodataDec.setMother_name("");
                    }
                }*/


                if (biodata_obj.has("fathers_occupation")) {
                    if (!biodata_obj.getString("fathers_occupation").isEmpty()) {
                        biodataDec.setFathers_occupation(biodata_obj.getString("fathers_occupation"));
                    } else {
                        biodataDec.setFathers_occupation("");
                    }
                }

                if (biodata_obj.has("mg_id")) {
                    if (!biodata_obj.getString("mg_id").isEmpty()) {
                          biodataDec.setMg_id(biodata_obj.getString("mg_id"));
                    } else {
                         biodataDec.setMg_id("");
                    }
                }

                if (biodata_obj.has("gender")) {
                    if (!biodata_obj.getString("gender").isEmpty()) {
                          biodataDec.setGender(biodata_obj.getString("gender"));
                    } else {
                         biodataDec.setGender("");
                    }
                }

                if (biodata_obj.has("mg_name")) {
                    if (!biodata_obj.getString("mg_name").isEmpty()) {
                          biodataDec.setMg_name(biodata_obj.getString("mg_name"));
                    } else {
                         biodataDec.setMg_name("");
                    }
                }

//                if (biodata_obj.has("image")) {
//                    if (!biodata_obj.getString("image").isEmpty()) {
//                          biodataDec.setEmail_id(biodata_obj.getString("mg_id"));
//                    } else {
//                         biodataDec.setEmail_id("");
//                    }
//                }

                if (biodata_obj.has("url")) {
                    if (!biodata_obj.getString("url").isEmpty()) {
                          biodataDec.setUrl(biodata_obj.getString("url"));
                    } else {
                         biodataDec.setUrl("");
                    }
                }

                if (biodata_obj.has("mother_name")) {
                    if (!biodata_obj.getString("mother_name").isEmpty()) {
                        biodataDec.setMother_name(biodata_obj.getString("mother_name"));
                    } else {
                        biodataDec.setMother_name("");
                    }
                }

                if (biodata_obj.has("mother_occupation")) {
                    if (!biodata_obj.getString("mother_occupation").isEmpty()) {
                        biodataDec.setMother_occupation(biodata_obj.getString("mother_occupation"));
                    } else {
                        biodataDec.setMother_occupation("");
                    }
                }

                if (biodata_obj.has("brothers_name_occupation")) {
                    if (!biodata_obj.getString("brothers_name_occupation").isEmpty()) {
                        biodataDec.setBrothers_name_occupation(biodata_obj.getString("brothers_name_occupation"));
                    } else {
                        biodataDec.setBrothers_name_occupation("");
                    }
                }


                if (biodata_obj.has("sisters_name_occupation")) {
                    if (!biodata_obj.getString("sisters_name_occupation").isEmpty()) {
                        biodataDec.setSisters_name_occupation(biodata_obj.getString("sisters_name_occupation"));
                    } else {
                        biodataDec.setSisters_name_occupation("");
                    }
                }

                if (biodata_obj.has("religion")) {
                    if (!biodata_obj.getString("religion").isEmpty()) {
                        biodataDec.setReligion(biodata_obj.getString("religion"));
                    } else {
                        biodataDec.setReligion("");
                    }
                }


                if (biodata_obj.has("maritial_status")) {
                    if (!biodata_obj.getString("maritial_status").isEmpty()) {
                        biodataDec.setMaritial_status(biodata_obj.getString("maritial_status"));
                    } else {
                        biodataDec.setMaritial_status("");
                    }
                }

                if (biodata_obj.has("mother_tongue")) {
                    if (!biodata_obj.getString("mother_tongue").isEmpty()) {
                        biodataDec.setMother_tongue(biodata_obj.getString("mother_tongue"));
                    } else {
                        biodataDec.setMother_tongue("");
                    }
                }

                if (biodata_obj.has("kul_daivat")) {
                    if (!biodata_obj.getString("kul_daivat").isEmpty()) {
                        biodataDec.setKul_daivat(biodata_obj.getString("kul_daivat"));
                    } else {
                        biodataDec.setKul_daivat("");
                    }
                }

                if (biodata_obj.has("close_relatives")) {
                    if (!biodata_obj.getString("close_relatives").isEmpty()) {
                        biodataDec.setClose_relatives(biodata_obj.getString("close_relatives"));
                    } else {
                        biodataDec.setClose_relatives("");
                    }
                }

                if (biodata_obj.has("address")) {
                    if (!biodata_obj.getString("address").isEmpty()) {
                        biodataDec.setAddress(biodata_obj.getString("address"));
                    } else {
                        biodataDec.setAddress("");
                    }
                }


                if (biodata_obj.has("native_place")) {
                    if (!biodata_obj.getString("native_place").isEmpty()) {
                        biodataDec.setNative_place(biodata_obj.getString("native_place"));
                    } else {
                        biodataDec.setNative_place("");
                    }
                }

                if (biodata_obj.has("hobbies")) {
                    if (!biodata_obj.getString("hobbies").isEmpty()) {
                        biodataDec.setHobbies(biodata_obj.getString("hobbies"));
                    } else {
                        biodataDec.setHobbies("");
                    }
                }

                if (biodata_obj.has("expectation")) {
                    if (!biodata_obj.getString("expectation").isEmpty()) {
                        biodataDec.setExpectation(biodata_obj.getString("expectation"));
                    } else {
                        biodataDec.setExpectation("");
                    }
                }

                if (biodata_obj.has("surname_community")) {
                    if (!biodata_obj.getString("surname_community").isEmpty()) {
                        biodataDec.setSurname_community(biodata_obj.getString("surname_community"));
                    } else {
                        biodataDec.setSurname_community("");
                    }
                }

                if (biodata_obj.has("drinking_habits")) {
                    if (!biodata_obj.getString("drinking_habits").isEmpty()) {
                        biodataDec.setDrinking_habits(biodata_obj.getString("drinking_habits"));
                    } else {
                        biodataDec.setDrinking_habits("");
                    }
                }

                if (biodata_obj.has("smoking_habits")) {
                    if (!biodata_obj.getString("smoking_habits").isEmpty()) {
                        biodataDec.setSmoking_habits(biodata_obj.getString("smoking_habits"));
                    } else {
                        biodataDec.setSmoking_habits("");
                    }
                }

                if (biodata_obj.has("dietary_habits")) {
                    if (!biodata_obj.getString("dietary_habits").isEmpty()) {
                        biodataDec.setDietary_habits(biodata_obj.getString("dietary_habits"));
                    } else {
                        biodataDec.setDietary_habits("");
                    }
                }

                if (biodata_obj.has("name_to_contact")) {
                    if (!biodata_obj.getString("name_to_contact").isEmpty()) {
                        biodataDec.setName_to_contact(biodata_obj.getString("name_to_contact"));
                    } else {
                        biodataDec.setName_to_contact("");
                    }
                }

                if (biodata_obj.has("its_relation")) {
                    if (!biodata_obj.getString("its_relation").isEmpty()) {
                        biodataDec.setIts_relation(biodata_obj.getString("its_relation"));
                    } else {
                        biodataDec.setIts_relation("");
                    }
                }

                if (biodata_obj.has("contact_no")) {
                    if (!biodata_obj.getString("contact_no").isEmpty()) {
                        biodataDec.setContact_no(biodata_obj.getString("contact_no"));
                    } else {
                        biodataDec.setContact_no("");
                    }
                }

                if (biodata_obj.has("email_id")) {
                    if (!biodata_obj.getString("email_id").isEmpty()) {
                        biodataDec.setEmail_id(biodata_obj.getString("email_id"));
                    } else {
                        biodataDec.setEmail_id("");
                    }
                }

                if (biodata_obj.has("sCitizen")) {
                    if (!biodata_obj.getString("sCitizen").isEmpty()) {
                        biodataDec.setsCitizen(biodata_obj.getString("sCitizen"));
                    } else {
                        biodataDec.setsCitizen("");
                    }
                }
                if (biodata_obj.has("pHandicap")) {
                    if (!biodata_obj.getString("pHandicap").isEmpty()) {
                        biodataDec.setpHandicap(biodata_obj.getString("pHandicap"));
                    } else {
                        biodataDec.setpHandicap("");
                    }
                }

                arr_adapter_list.add(biodataDec);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        myDraftsAdapter = new MyDraftsAdapter(ctx, arr_adapter_list);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        rcv_fav_arc.setLayoutManager(mLayoutManager);
        rcv_fav_arc.setAdapter(myDraftsAdapter);

        if (arr_adapter_list.size()>0){
            lblempty_fa.setVisibility(View.GONE);
        }else {
            lblempty_fa.setVisibility(View.VISIBLE);
        }
    }


    public void allocateMemory() {
        rcv_fav_arc = findViewById(R.id.rcv_draft_arc);
        lbllistof = findViewById(R.id.lbllistof);
        txtdefault = findViewById(R.id.txtdefault);
        lblempty_fa = findViewById(R.id.lblempty_fa);



        AdView adViewHome = findViewById(R.id.adViewHome);
        AdRequest adRequest = new AdRequest.Builder().build();

        adViewHome.loadAd(adRequest);
        adViewHome.setVisibility(View.VISIBLE);


    }


    // show process Dialog box
    private void showpDialog() {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }

    // hide process Dialog box
    private void hidePDialog() {
        if (this.pDialog != null) {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }

    public void setupToolbar() {
        toolbar = getSupportActionBar();
        assert toolbar != null;
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_posts, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        int id = item.getItemId();
        if (id == R.id.dashboard) {
            startActivity(new Intent(ctx, Dashboard.class));
        } else if (id == R.id.myGroup) {
            startActivity(new Intent(ctx, MyGroup.class));
        }/* else if (id == R.id.myDrafts) {
            startActivity(new Intent(ctx, MyDrafts.class));
        }*/ else if (id == R.id.myPost) {
            startActivity(new Intent(ctx, MyPosts.class)
                    .putExtra("from", "dashboard")
                    .putExtra("gender", "-1"));
        } else if (id == R.id.myFev) {
            startActivity(new Intent(ctx, MyFav_Arc.class)
                    .putExtra("from", "dashboard_fav"));
        } else if (id == R.id.myArchive) {
            startActivity(new Intent(ctx, MyFav_Arc.class)
                    .putExtra("from", "dashboard_arc"));
        } else if (id == R.id.myMarketing) {
            startActivity(new Intent(ctx, MyMarketActivity.class));
        }
        return super.onOptionsItemSelected(item);
    }

}