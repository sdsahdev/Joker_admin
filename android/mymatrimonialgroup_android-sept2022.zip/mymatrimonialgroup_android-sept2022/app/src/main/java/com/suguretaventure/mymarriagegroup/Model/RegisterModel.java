package com.suguretaventure.mymarriagegroup.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class RegisterModel {

    @SerializedName("success")
    @Expose

    private Boolean success;
    @SerializedName("msg")
    @Expose

    private String msg;
    @SerializedName("regid")
    @Expose

    private Integer regid;
    @SerializedName("email")
    @Expose

    private String email;
    @SerializedName("firstname")
    @Expose

    private String firstname;
    @SerializedName("surname")
    @Expose

    private String surname;
    @SerializedName("mobile")
    @Expose

    private String mobile;
    @SerializedName("password")
    @Expose

    private String password;
    @SerializedName("gender")
    @Expose
    private String gender;
    @SerializedName("photoid")
    @Expose
    private String photoid;
    @SerializedName("everify")
    @Expose
    private String everify;
    @SerializedName("mverify")
    @Expose
    private String mverify;

    @SerializedName("is_vip_member")
    @Expose
    private String is_vip_member;

    @SerializedName("is_premium_profile_added")
    @Expose
    private String is_premium_profile_added;

    @SerializedName("otp")
    @Expose
    private Integer otp;

    //if 0 then document submitted else document submitted.
    @SerializedName("active")
    @Expose
    private String active;

    @SerializedName("code")
    @Expose
    private String mobileCode;

    @SerializedName("isProfileUpdated")
    @Expose
    private boolean isProfileUpdated;

    public String getMobileCode() {
        return mobileCode;
    }

    public void setMobileCode(String mobileCode) {
        this.mobileCode = mobileCode;
    }

    public boolean isProfileUpdated() {
        return isProfileUpdated;
    }

    public void setProfileUpdated(boolean profileUpdated) {
        isProfileUpdated = profileUpdated;
    }

    public String getActive() {
        return active;
    }

    public void setActive(String active) {
        this.active = active;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Integer getRegid() {
        return regid;
    }

    public void setRegid(Integer regid) {
        this.regid = regid;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getPhotoid() {
        return photoid;
    }

    public void setPhotoid(String photoid) {
        this.photoid = photoid;
    }

    public String getEverify() {
        return everify;
    }

    public void setEverify(String everify) {
        this.everify = everify;
    }

    public String getMverify() {
        return mverify;
    }

    public void setMverify(String mverify) {
        this.mverify = mverify;
    }

    public Integer getOtp() {
        return otp;
    }

    public void setOtp(Integer otp) {
        this.otp = otp;
    }

    public String getIs_vip_member() {
        return is_vip_member;
    }

    public void setIs_vip_member(String is_vip_member) {
        this.is_vip_member = is_vip_member;
    }

    public String getIs_premium_profile_added() {
        return is_premium_profile_added;
    }

    public void setIs_premium_profile_added(String is_premium_profile_added) {
        this.is_premium_profile_added = is_premium_profile_added;
    }
}
