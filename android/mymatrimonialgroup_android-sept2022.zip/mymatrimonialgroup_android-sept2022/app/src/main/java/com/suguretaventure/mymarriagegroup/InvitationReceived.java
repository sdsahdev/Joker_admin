package com.suguretaventure.mymarriagegroup;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.suguretaventure.mymarriagegroup.adapters.InvitationAdapter;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.getsets.PersonGetSet;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;

public class InvitationReceived extends AppCompatActivity {
    RecyclerView rcvReq;
    TextView lblempty_biodata, lblemptygrp;
    private Context context = this;
    String TAG = "INVITATION_SENT", status;
    private InvitationAdapter invitationAdapter;
    private ArrayList<PersonGetSet> arr_adapter = new ArrayList<>();
    private PersonGetSet personGetSet;
    ProgressDialog progressDialog;
    RelativeLayout relNoDataMyMarket;
    String groupId = "";
    private FirebaseAnalytics mFirebaseAnalytics;
    LinearLayout deleteallLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Invitation Received");
        setContentView(R.layout.activity_invitation_received);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        findViewById();


        if (getIntent().getExtras().getString("from").equals("dashboard_invitation_receive_group")) {
            groupId = getIntent().getExtras().getString("groupId");
        } else {
            groupId = "";
        }

        progressDialog = new ProgressDialog(context);
        progressDialog.setMessage("Please Wait");
        progressDialog.show();
        lblemptygrp.setText(Html.fromHtml(Constants.INVITATION_RECEIVE));
        getSentRequest();
    }

    public void findViewById() {
        rcvReq = findViewById(R.id.rcvReq);
        lblempty_biodata = findViewById(R.id.lblempty_biodata);
        relNoDataMyMarket = findViewById(R.id.relNoDataMyMarket);
        lblemptygrp = findViewById(R.id.lblemptygrp);

        deleteallLayout = findViewById(R.id.deleteallLayout);

        deleteallLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //arr_adapter.clear();

                android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(context);
                builder.setTitle("Alert!");
                builder.setMessage("Are you sure you want to delete all?");
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        deleteAllRequest();
                        dialog.dismiss();
                    }
                });
                builder.show();
            }
        });
    }

    public void getSentRequest() {
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("rid", Utils.getString(context, Constants.USER_ID));
        params.put("receive", "1");
        params.put("iGroupID", groupId);
        Utils.log(TAG, "REQ_SEND_BIO-DATA_URL : " + Constants.BIO_REQ_VIEW + "?" + params);
        client.post(Constants.BIO_REQ_VIEW, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                progressDialog.dismiss();
                Utils.log(TAG, "REQ_SEND_BIO-DATA_RESPONSE : " + response);
                getData(response);
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Toast.makeText(context, "Something Went Wrong", Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
        });
    }

    public void deleteAllRequest() {
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please wait...");
        progressDialog.setCancelable(false);
        progressDialog.show();
//        AsyncHttpClient client = new AsyncHttpClient(true, 80, 433);
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("rid", Utils.getString(context, Constants.USER_ID));
        params.put("receive", "1");
        Utils.log(TAG, "REQ_RECEIVE_DELETE_ALL : " + Constants.DELETE_ALL_INVITATION + "?" + params);
        client.post(Constants.DELETE_ALL_INVITATION, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                progressDialog.dismiss();
                Utils.log(TAG, "REQ_SEND_BIO-DATA_RESPONSE : " + response);
                arr_adapter.clear();
                invitationAdapter.notifyDataSetChanged();
                rcvReq.setVisibility(View.GONE);
                deleteallLayout.setVisibility(View.GONE);
                lblempty_biodata.setVisibility(View.VISIBLE);
                relNoDataMyMarket.setVisibility(View.VISIBLE);
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Toast.makeText(context, "Something Went Wrong", Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
        });
    }


    public void getData(String response) {
        try {
            JSONArray object = new JSONArray(response);
            String error = object.getJSONObject(0).getString("error");
            Utils.log("SENT_RESPONSE", error);
            if (error.equals("no error") == false) {
                Common.showDialog(context);
            } else {
                arr_adapter.clear();
                int total = object.getJSONObject(1).getInt("total");
                if (total == 0) {
                    rcvReq.setVisibility(View.GONE);
                    lblempty_biodata.setVisibility(View.VISIBLE);
                    relNoDataMyMarket.setVisibility(View.VISIBLE);
                    deleteallLayout.setVisibility(View.GONE);
                } else {
                    deleteallLayout.setVisibility(View.VISIBLE);
                    lblempty_biodata.setVisibility(View.GONE);
                    relNoDataMyMarket.setVisibility(View.GONE);
                    int size = object.length();
                    for (int i = 2; i < size; i++) {
                        JSONObject object1 = object.getJSONObject(i);
                        personGetSet = new PersonGetSet();
                        personGetSet.setInv_id(object1.getString("inv_id"));
                        personGetSet.setId(object1.getString("id"));
                        personGetSet.setName(object1.getString("name"));
                        personGetSet.setPhone(object1.getString("phone"));
                        personGetSet.setImage(object1.getString("photo"));
                        personGetSet.setFrom_bio_id(object1.getString("from_bio_id"));
                        personGetSet.setFrom_name(object1.getString("from_name"));
                        personGetSet.setFrom_image(object1.getString("from_image"));
                        personGetSet.setTo_bio_id(object1.getString("to_bio_id"));
                        personGetSet.setTo_name(object1.getString("to_name"));
                        personGetSet.setTo_mobile(object1.getString("to_mobile"));
                        personGetSet.setTo_image(object1.getString("to_image"));
                        personGetSet.setStatus(object1.getString("status"));
                        arr_adapter.add(personGetSet);
                        Log.d(TAG, "from_bio_id: "+object1.getString("from_bio_id"));
                    }
                }
            }
            status = "receive";
            invitationAdapter = new InvitationAdapter(context, arr_adapter, status,groupId);
            RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
            rcvReq.setLayoutManager(mLayoutManager);
            rcvReq.setAdapter(invitationAdapter);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_invitation, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        int id = item.getItemId();
        if (id == R.id.dashboard) {
            startActivity(new Intent(context, Dashboard.class));
        } else if (id == R.id.myGroup) {
            startActivity(new Intent(context, MyGroup.class));
        } else if (id == R.id.myPost) {
            startActivity(new Intent(context, MyPosts.class)
                    .putExtra("from", "dashboard")
                    .putExtra("gender", "-1"));
        } else if (id == R.id.MyFav_Arc) {
            startActivity(new Intent(context, MyFav_Arc.class)
                    .putExtra("from", "dashboard_fav"));
        } else if (id == R.id.myarchieved) {
            startActivity(new Intent(context, MyFav_Arc.class)
                    .putExtra("from", "dashboard_arc"));
        } else if (id == R.id.logout) {
            final AlertDialog alertDialog = new AlertDialog.Builder(context).create();
            alertDialog.setMessage("Are you sure you want to logout ?");
            alertDialog.setButton(DialogInterface.BUTTON_POSITIVE, "Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    String FCM_KEY = "" + Utils.getString(context, Constants.TOKEN);
                    Utils.clearPreference(context);
                    Utils.setString(context, Constants.TOKEN, FCM_KEY);
                    startActivity(new Intent(context, Login.class));
                    finish();
                }
            });
            alertDialog.setButton(DialogInterface.BUTTON_NEGATIVE, "No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    alertDialog.dismiss();
                }
            });
            alertDialog.show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
