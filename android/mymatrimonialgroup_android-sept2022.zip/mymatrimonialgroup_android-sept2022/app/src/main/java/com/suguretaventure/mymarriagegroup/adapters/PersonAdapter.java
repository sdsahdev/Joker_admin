package com.suguretaventure.mymarriagegroup.adapters;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.StrictMode;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;
import com.suguretaventure.mymarriagegroup.AddBiodata;
import com.suguretaventure.mymarriagegroup.BioReqSentActivity;
import com.suguretaventure.mymarriagegroup.Occupations;
import com.suguretaventure.mymarriagegroup.PersonDesc;
import com.suguretaventure.mymarriagegroup.PrimiumBiodataActivity;
import com.suguretaventure.mymarriagegroup.ProfileUpdateActivity;
import com.suguretaventure.mymarriagegroup.R;
import com.suguretaventure.mymarriagegroup.UpdateBiodata;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.getsets.PersonGetSet;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;

import static com.suguretaventure.mymarriagegroup.utils.ExifUtil.rotate;

/**
 * Created by ankitpatel on 23/02/19.
 */
public class PersonAdapter extends RecyclerView.Adapter<PersonAdapter.MyViewHolder> implements PaymentResultListener {
    private Context context;
    private LayoutInflater inflater;
    private ArrayList<PersonGetSet> arr_adapter;
    private String TAG = "PERSON_ADAPTER";
    private String rid, pid,  faid, VisHide;
    private ProgressDialog pDialog;
    String Biodataid = "";
    Bitmap image = null, rotatedBitmap = null;
    int width, height;
    int type;
    boolean flag_my_post;
    private int checkedPosition = -1;

    public PersonAdapter(Context context, ArrayList<PersonGetSet> arr_adapter, String VisHide,int type, boolean flag_my_post) {
        this.context = context;
        this.arr_adapter = arr_adapter;
        this.VisHide = VisHide;
        this.type = type;
        this.flag_my_post = flag_my_post;
        rid = "" + Utils.getString(context, Constants.USER_ID);
    }

    public void updateList(ArrayList<PersonGetSet> arr_adapter1){
        arr_adapter = arr_adapter1;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_person, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder,  final int i) {

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        SimpleDateFormat fromUser = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat myFormat = new SimpleDateFormat("MMM dd, yyyy");
        String reformattedStr = "";
        try {

            reformattedStr = myFormat.format(fromUser.parse(arr_adapter.get(i).getPay_date()));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        if (checkedPosition==i){
            holder.cbkCheckList.setChecked(true);
        }else {
            holder.cbkCheckList.setChecked(false);

        }
        holder.cbkCheckList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Boolean isCheck= holder.cbkCheckList.isChecked();
                if (!isCheck){
                    holder.cbkCheckList.setChecked(true);
                }
                checkedPosition=i;
                notifyDataSetChanged();
            }
        });

        if(VisHide.equalsIgnoreCase("sendBioRequest"))
        {
            holder.add_arc.setVisibility(View.GONE);
            holder.add_fav.setVisibility(View.GONE);
            holder.cbkCheckList.setVisibility(View.VISIBLE);

            holder.buttonViewOption.setVisibility(View.GONE);
            holder.lay_pdesc.setOnClickListener(null);
        }else if (!VisHide.equals("biodatalist")) {
            holder.add_arc.setVisibility(View.GONE);
            holder.add_fav.setVisibility(View.GONE);
            holder.buttonViewOption.setVisibility(View.VISIBLE);
            holder.lblstatus.setVisibility(View.VISIBLE);
            PersonDesc.checkstatus = "1";
        }
        else {
            holder.add_arc.setVisibility(View.VISIBLE);
            holder.add_fav.setVisibility(View.VISIBLE);
            holder.buttonViewOption.setVisibility(View.GONE);
            PersonDesc.checkstatus = "0";
            //  holder.lblstatus.setText("Verified Profile");
//            holder.lblstatus.setText("Verified by " + arr_adapter.get(i).getVerifiedby());
            holder.lblstatus.setText("Published: " + reformattedStr);
//            holder.lblstatus.setTextColor(Color.parseColor("#ED8A19"));
        }

        holder.lblIsPaid.setText("Uploaded: "+arr_adapter.get(i).getRid_name());


      /*  if (arr_adapter.get(i).getIs_paid()==0){
            holder.lblIsPaid.setText("Payment verification not opted.");
            holder.lblIsPaid.setTextColor(Color.parseColor("#FC4136"));
            holder.lblstatus.setTextColor(Color.parseColor("#FC4136"));
        }
        if (arr_adapter.get(i).getIs_paid()==1){
            holder.lblIsPaid.setText("Payment verification opted.");
            holder.lblIsPaid.setTextColor(Color.parseColor("#71E158"));
            holder.lblstatus.setTextColor(Color.parseColor("#71E158"));
        }*/

        holder.lblpersonname.setText(arr_adapter.get(i).getName());
        holder.lblpersonedu.setText(arr_adapter.get(i).getEducation());
        holder.lblpersonocu.setText(arr_adapter.get(i).getOccupation() + " "+arr_adapter.get(i).getIncome());
        holder.lblpersonage.setText("Age : " + arr_adapter.get(i).getAge());
        holder.lblIncome.setText("Income : " + arr_adapter.get(i).getIncome());

        if (arr_adapter.get(i).getGender().equals("1")) {
            holder.lblGender.setVisibility(View.GONE);
            holder.lblGender.setText("Male");
        } else if (arr_adapter.get(i).getGender().equals("0")) {
            holder.lblGender.setVisibility(View.GONE);
            holder.lblGender.setText("Female");
        } else {
            holder.lblGender.setVisibility(View.GONE);
        }
        if (arr_adapter.get(i).getVerified().equals("1")) {
            holder.lblstatus.setText("Published: " + reformattedStr);
        }
        if (arr_adapter.get(i).getVerified().equals("0")) {
            holder.lblstatus.setText("Not Verified");
//            holder.lblIsPaid.setTextColor(Color.parseColor("#FC4136"));
            holder.lblstatus.setTextColor(Color.parseColor("#FC4136"));
        }
        if (arr_adapter.get(i).getVerified().equals("2")) {
            holder.lblstatus.setText("Block");
//            holder.lblIsPaid.setTextColor(Color.parseColor("#FC4136"));
            holder.lblstatus.setTextColor(Color.parseColor("#FC4136"));
        }

        Glide.with(context)
                .load(Common.GetProfileImageUrl() + arr_adapter.get(i).getImage())
                .apply(RequestOptions.circleCropTransform()).into(holder.imgperson);

        holder.lay_pdesc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int temp_type = type;
                if (arr_adapter.get(i).getIs_premium() != null && arr_adapter.get(i).getIs_premium().equals("1")) {
                    temp_type = 2;
                }

                if (type == 2) {
                    if (Utils.getString(context, Constants.USER_IS_VIP).equals("1")) {
                        Log.d(TAG, "gid: "+arr_adapter.get(i).getGroupId());
                        context.startActivity(new Intent(context, PersonDesc.class)
                                .putExtra("pid", arr_adapter.get(i).getId()).putExtra("type", temp_type).putExtra("flag_my_post", flag_my_post)
                                .putExtra("gid",arr_adapter.get(i).getGroupId())

                        );
                    } else {
                        final BottomSheetDialog bottomSheerDialog = new BottomSheetDialog(context);
                        View parentView = LayoutInflater.from(context).inflate(R.layout.layout_primium_dialog, null);
                        bottomSheerDialog.setContentView(parentView);
                        ImageView imageView = parentView.findViewById(R.id.imgLogo);
                        Button btnSubscription = parentView.findViewById(R.id.btnSubscription);
                        imageView.startAnimation(AnimationUtils.loadAnimation(parentView.getContext(), R.anim.zoom_in_zoom_out));
                        btnSubscription.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                startPayment("15");
                                bottomSheerDialog.dismiss();
                            }
                        });
                        bottomSheerDialog.show();
                    }

                }else {
                    context.startActivity(new Intent(context, PersonDesc.class)
                            .putExtra("pid", arr_adapter.get(i).getId()).putExtra("type", temp_type).putExtra("flag_my_post", flag_my_post).putExtra("gid",arr_adapter.get(i).getGroupId())
                    );
                }
            }
        });



        holder.imgperson.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                View dialogLayout = inflater.inflate(R.layout.personimage_dialog, null);
                ImageView imgtabledesc = (ImageView) dialogLayout.findViewById(R.id.imgtabledesc);
                builder.setView(dialogLayout);

                if (width > height) {
                    rotatedBitmap = rotate(image, 90);
                    Glide.with(context)
                            .load(rotatedBitmap)
                            .into(imgtabledesc);
                } else {
                    Glide.with(context)
                            .load(Common.GetProfileImageUrl() + arr_adapter.get(i).getImage())
                            .into(imgtabledesc);
                }

               /* Glide.with(context)
                        .load(Common.GetProfileImageUrl() + arr_adapter.get(i).getImage())
                        .into(imgtabledesc);*/
                Dialog dialog = builder.create();
                dialog.setCancelable(true);
                dialog.show();
            }
        });


        holder.add_fav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addFavArc(0, arr_adapter.get(i).getId(), i, arr_adapter.get(i).getGroupId());
            }
        });

        holder.add_arc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addFavArc(1, arr_adapter.get(i).getId(), i, arr_adapter.get(i).getGroupId());
            }
        });

        holder.buttonViewOption.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //creating a popup menu
                PopupMenu popup = new PopupMenu(context, holder.buttonViewOption);
                //inflating menu from xml resource
                popup.inflate(R.menu.menu_person_adapter);
                popup.getMenu().findItem(R.id.menu2).setTitle("Delete");
                popup.getMenu().findItem(R.id.menu1).setTitle("Edit");
                /*popup.getMenu().findItem(R.id.menu1).setVisible(false);*/
                //adding click listener
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.menu1:
                                Biodataid = arr_adapter.get(i).getId();
                                Intent intent = new Intent(context, UpdateBiodata.class);
                                intent.putExtra("bid", Biodataid);
                                intent.putExtra("rid", rid);
                                intent.putExtra("isPremium",false);
                                if (arr_adapter.get(i).getIs_premium()!=null && arr_adapter.get(i).getIs_premium().equals("1")){
                                    intent.putExtra("isPremium", true);
                                }
                                context.startActivity(intent);
                                break;

                            case R.id.menu3:
                                Biodataid = arr_adapter.get(i).getId();
                                Intent in = new Intent(context, BioReqSentActivity.class);
                                in.putExtra("bid", Biodataid);
                                in.putExtra("rid", rid);
                                context.startActivity(in);
                                break;

                            case R.id.menu2:
                                //handle menu2 click
                                final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(context);
                                builder.setIcon(R.drawable.ic_remove_blue);
                                builder.setTitle("Delete Bio-Data");
                                builder.setMessage("Do you want to Delete Bio-Data?");

                                builder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        Biodataid = arr_adapter.get(i).getId();
                                        deleteBiodata(i, Biodataid, rid);
                                    }
                                });
                                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.cancel();
                                        dialog.dismiss();
                                    }
                                });
                                builder.show();
                                break;
                        }
                        return false;
                    }
                });
                //displaying the popup
                popup.show();

            }
        });
    }

    private void addFavArc(final int fatype, final String pid, final int position, String groupId) {
        pDialog = new ProgressDialog(context);
        pDialog.setMessage("Please wait...");
        pDialog.setCancelable(false);
        //showpDialog();

        String WebServiceUrl = Common.GetWebServiceUrl() + "add_fav_arc.php";
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("rid", "" + rid);
        params.put("pid", "" + pid);
        params.put("type", "" + fatype);
        params.put("iGroupID", "" + groupId);
        client.post(WebServiceUrl, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                Log.e("trace res", res);
                try {
                    JSONArray response = new JSONArray(res);
                    String error = response.getJSONObject(0).getString("error");
                    if (error.equals("no error") == false) {
                        hidePDialog();
                        Common.showDialog(context, error);
                    } else {
                        String success = response.getJSONObject(1).getString("success");
                        if (success.equals("yes") == true) {
                            hidePDialog();
                            if (fatype == 1) {
                                arr_adapter.remove(position);
                                notifyDataSetChanged();
                                Toast.makeText(context, "Added to Archive", Toast.LENGTH_LONG).show();
                            } else
                                Toast.makeText(context, "Added to Favourite", Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(context, "" + response.getJSONObject(2)
                                    .getString("message"), Toast.LENGTH_LONG).show();
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                hidePDialog();
                Common.showDialog(context);
            }
        });
    }

    @Override
    public void onPaymentSuccess(String s) {
        try {
//            Toast.makeText(this, "Payment Successful. You are VIP member now. ", Toast.LENGTH_SHORT).show();
            subscribeUser(s);
        } catch (Exception e) {
            Utils.log(TAG, "Exception in onPaymentSuccess : " + e.getMessage());
        }
    }

    @Override
    public void onPaymentError(int i, String s) {
        try {
            Toast.makeText(context, "Payment failed: " + i + " " + s, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Utils.log(TAG, "Exception in onPaymentError : " + e.getMessage());
        }
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView lblpersonname, lblpersonedu, lblpersonage, lblGender, lblpersonocu, lblstatus,
                lblIsPaid,lblIncome;
        public ImageView imgperson, add_arc, add_fav, buttonViewOption;
        public LinearLayout lay_pdesc, lay_actions;
        public CheckBox cbkCheckList;

        public MyViewHolder(View view) {
            super(view);
            lay_pdesc = view.findViewById(R.id.lay_pdesc);
            lblpersonname = view.findViewById(R.id.lblpersonname);
            lblpersonedu = view.findViewById(R.id.lblpersonedu);
            lblpersonage = view.findViewById(R.id.lblpersonage);
            lblpersonocu = view.findViewById(R.id.lblpersonocu);
            imgperson = view.findViewById(R.id.imgperson);
            add_arc = view.findViewById(R.id.add_arc);
            add_fav = view.findViewById(R.id.add_fav);
            buttonViewOption = view.findViewById(R.id.buttonViewOption);
            lay_actions = view.findViewById(R.id.lay_actions);
            lblstatus = view.findViewById(R.id.lblstatus);
            lblGender = view.findViewById(R.id.lblGender);
            lblIsPaid = view.findViewById(R.id.lblIsPaid);
            lblIncome = view.findViewById(R.id.lblIncome);
            cbkCheckList = view.findViewById(R.id.cbkCheckList);
        }
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return arr_adapter.size();
    }

    // show process Dialog box
    private void showpDialog() {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }

    public String getSelectedValue(){
     return arr_adapter.get(checkedPosition).getId();
    }

    // hide process Dialog box
    private void hidePDialog() {
        if (this.pDialog != null) {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }

    public void deleteBiodata(final int i, String biodataid, String rid) {
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("rid", rid);
        params.put("biodataid", biodataid);
        Utils.log(TAG, "DELETE_BIO-DATA_URL : " + Constants.DELETE_BIODATA + "?" + params);
        client.post(Constants.DELETE_BIODATA, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                Utils.log(TAG, "DELETE_BIO-DATA_RESPONSE : " + response);
                Toast.makeText(context, "Bio Data Delete Successful", Toast.LENGTH_SHORT).show();
                arr_adapter.remove(i);
                notifyItemRemoved(i);
                notifyItemRangeChanged(i, arr_adapter.size());
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Toast.makeText(context, "Something Went Wrong", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showPremiumDialog() {
        final BottomSheetDialog bottomSheerDialog = new BottomSheetDialog(context);
        View parentView = inflater.inflate(R.layout.layout_primium_dialog, null);
        bottomSheerDialog.setContentView(parentView);
        ImageView imageView = parentView.findViewById(R.id.imgLogo);
        Button btnSubscription = parentView.findViewById(R.id.btnSubscription);
        imageView.startAnimation(AnimationUtils.loadAnimation(parentView.getContext(), R.anim.zoom_in_zoom_out));
        btnSubscription.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startPayment("15");
                bottomSheerDialog.dismiss();
            }
        });
        bottomSheerDialog.show();
    }

    public void startPayment(String amount) {
                Checkout.preload(context);
        final PersonAdapter personAdapter = this;
        final Activity activity=(Activity)context;
        String amount_ = String.valueOf(Integer.parseInt(amount) * 100*75);
        final Checkout co = new Checkout();
        co.setKeyID("rzp_live_rqh0DabOcTj5iZ");

        try {
            JSONObject options = new JSONObject();
            options.put("name", "" + Utils.getString(context, Constants.USER_NAME));
            options.put("description", "Add Bio Data Charge");
            options.put("image", "");
            options.put("currency", "INR");
            options.put("amount", amount_);

            JSONObject preFill = new JSONObject();
            preFill.put("email", "" + Utils.getString(context, Constants.USER_EMAIL));
            preFill.put("contact", "" + Utils.getString(context, Constants.USER_MOBILE));

            options.put("prefill", preFill);

            co.open(activity, options);
        } catch (Exception e) {
            Toast.makeText(personAdapter.context, "Error in payment: " + e.getMessage(), Toast.LENGTH_SHORT)
                    .show();
            e.printStackTrace();
        }
    }

    private void subscribeUser(final String razorPayId) {

        pDialog = new ProgressDialog(context);
        pDialog.setMessage("Please wait...");
        pDialog.setCancelable(false);
        showpDialog();

        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        RequestParams params = new RequestParams();
        params.put("rid", Utils.getString(context, Constants.USER_ID));
        Utils.log(TAG, "REQUEST_URL : " + Constants.SUBSCRIBE_USER + "?" + params);
        client.post(Constants.SUBSCRIBE_USER, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                Utils.log(TAG, "REQUEST_RESPONSE : " + response);
                Toast.makeText(context, "Congratulation!. You are VIP member now of My Marriage Group", Toast.LENGTH_SHORT).show();
                Utils.setString(context, Constants.USER_FIRST_PROFILE_PAYMENT_ID, razorPayId);
                Utils.setString(context, Constants.USER_IS_VIP, "1");
               /* context.startActivity(new Intent(context, PersonDesc.class)
                                .putExtra("pid", arr_adapter.get(i).getId()).putExtra("type", temp_type).putExtra("flag_my_post", flag_my_post)
                                .putExtra("gid",arr_adapter.get(i).getGroupId())*/
                hidePDialog();
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "REQUEST_ERROR : " + error.getMessage());
                hidePDialog();
            }
        });
    }

}
