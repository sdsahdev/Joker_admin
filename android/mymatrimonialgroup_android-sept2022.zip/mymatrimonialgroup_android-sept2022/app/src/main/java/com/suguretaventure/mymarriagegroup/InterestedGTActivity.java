package com.suguretaventure.mymarriagegroup;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.suguretaventure.mymarriagegroup.Model.Datum;
import com.suguretaventure.mymarriagegroup.adapters.GetTogetherAdapter;
import com.suguretaventure.mymarriagegroup.adapters.GetTogetherInterestedAdapter;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.common.NetworkConnetionState;
import com.suguretaventure.mymarriagegroup.getsets.GetTogetherGetSet;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import static com.suguretaventure.mymarriagegroup.GetTogether.isEdit;

public class InterestedGTActivity extends AppCompatActivity {

    private String TAG = "GET_TO_GETHER";
    public Context ctx = this;
    public static RecyclerView rcvgt;
    public static ArrayList<GetTogetherGetSet> arr_adapter = new ArrayList<>();
    public static GetTogetherAdapter gtAdapter;
    public static GetTogetherGetSet gtGetSet;
    public static ProgressDialog pDialog;
    ActionBar toolbar;
    RelativeLayout relNoDataMyMarket;
    public static TextView myTitle, lblemptygt;
    public static LinearLayout fabAddGetTogether;
    public static String mgid;
    public static String gtId;
    public static String date = "", time = "";
    public static Menu myMenu;
    private FirebaseAnalytics mFirebaseAnalytics;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interested_gt);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        getSupportActionBar().setTitle(getResources().getString(R.string.app_name_title));
        allocateMemory();

        lblemptygt.setText(Html.fromHtml(Constants.INVITATION_GET_TO_GATHER_INTERESTED));
        myTitle.setText("The following members are registered till now: ");


        if (new NetworkConnetionState().isNetworkAvailable(ctx)) {
            getGTInterestedList(ctx);
            setListener();
        } else {
            networkAlert();
        }
    }

    private void setListener() {
        fabAddGetTogether.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialog();
            }
        });
    }

    private void openDialog() {
        final Dialog alertDialog = new Dialog(InterestedGTActivity.this);
        alertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LayoutInflater inflater = getLayoutInflater();
        @SuppressLint("InflateParams") View alert = inflater.inflate(R.layout.dialog_gt_interested, null, false);
        // Setting Dialog Title

        alert.findViewById(R.id.btnGetTogetherRegister1);
        alert.findViewById(R.id.btnGetTogetherCancel1);
        alert.findViewById(R.id.txtName);
        alertDialog.setContentView(alert);

        final EditText txtName = alertDialog.findViewById(R.id.txtName);
        final TextView btnGetTogetherCancel1 = alertDialog.findViewById(R.id.btnGetTogetherCancel1);
        final TextView btnGetTogetherRegister1 = alertDialog.findViewById(R.id.btnGetTogetherRegister1);

        txtName.setText(Utils.getString(ctx, Constants.USER_NAME) + " " + Utils.getString(ctx, Constants.USER_SURNAME));

        btnGetTogetherRegister1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (txtName.getText().length() == 0) {
                    txtName.setError("Name required");
                } else {
                    getTogetherRegister(alertDialog, txtName.getText().toString());
                }
            }
        });

        btnGetTogetherCancel1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                alertDialog.cancel();
            }
        });

        final Window window = alertDialog.getWindow();
        assert window != null;
        alertDialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        window.setBackgroundDrawableResource(R.color.colorTransparent);
        window.setGravity(Gravity.CENTER);
        alertDialog.show();
    }

    private void networkAlert() {
        AlertDialog.Builder b1 = new AlertDialog.Builder(ctx);
        b1.setTitle("Network Error");
        b1.setMessage("No internet connection found. Please check your phone settings to turn on the internet.");
        b1.setPositiveButton("Retry", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (new NetworkConnetionState().isNetworkAvailable(ctx)) {
                    getGTInterestedList(ctx);
//                    rcvgt.setVisibility(View.GONE);
                } else {
                    networkAlert();
                }
            }
        });
        b1.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        b1.create().show();
    }

    public void getGTInterestedList(final Context ctx) {
        final ProgressDialog dialog = new ProgressDialog(ctx);
        dialog.setTitle("Please wait...");
        dialog.show();
        dialog.setCancelable(false);
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("gtid", gtId);

        client.post(Constants.APP_LIST_GET_TOGETHER_INTERESTED, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody) {

                String success = "", msg = "";
                try {
                    JSONObject object = new JSONObject(new String(responseBody));
                    success = object.getString("success");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (success.equals("")) {
                    try {
                        ArrayList<Datum> CategoryList = new ArrayList<>();
                        JSONObject response = new JSONObject(new String(responseBody));
                        JSONArray data = response.getJSONArray("data");
                        int size = data.length();
                        JSONObject current;
                        Datum cat;
                        String name, id;

                        if (size > 0) {

                            rcvgt.setVisibility(View.VISIBLE);
                            lblemptygt.setVisibility(View.GONE);
                            relNoDataMyMarket.setVisibility(View.GONE);
                            for (int i = 0; i < size; i++) {
                                current = data.getJSONObject(i);
                                name = current.getString("name");
                                id = current.getString("register_userid");
                                cat = new Datum(name, id);
                                CategoryList.add(cat);
                            }

                            rcvgt.setLayoutManager(new LinearLayoutManager(ctx));
                            GetTogetherInterestedAdapter adapter = new GetTogetherInterestedAdapter(ctx, CategoryList);
                            rcvgt.setAdapter(adapter);
                        } else {
                            rcvgt.setVisibility(View.GONE);
                            lblemptygt.setVisibility(View.VISIBLE);
                            relNoDataMyMarket.setVisibility(View.VISIBLE);
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                } else {
                    Utils.log(TAG, "ADD-GETTOGETHER-NO-DATA-FOUND");
                    rcvgt.setVisibility(View.GONE);
                    lblemptygt.setVisibility(View.VISIBLE);
                    relNoDataMyMarket.setVisibility(View.VISIBLE);
                }
                dialog.dismiss();
            }

            @Override
            public void onFailure(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "ADD-GETTOGETHER-ERROR : " + error.getMessage());
                dialog.dismiss();
            }
        });


    }

    public void allocateMemory() {
        fabAddGetTogether = findViewById(R.id.fabAddGetTogether);
        myTitle = findViewById(R.id.myTitle);
        rcvgt = findViewById(R.id.rcvgt);
        lblemptygt = findViewById(R.id.lblemptygt);
        relNoDataMyMarket = findViewById(R.id.relNoDataMyMarket);
        mgid = getIntent().getStringExtra("mgid");
        gtId = getIntent().getStringExtra("gtid");


    }

    // show process Dialog box
    private void showpDialog() {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }

    // hide process Dialog box
    private void hidePDialog() {
        if (this.pDialog != null) {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }

    public void setupToolbar() {
        toolbar = getSupportActionBar();
        assert toolbar != null;
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        this.myMenu = menu;
        getMenuInflater().inflate(R.menu.menu_interested_gt, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (android.R.id.home == item.getItemId()) {
            finish();
        } else {
            int id = item.getItemId();
            if (id == R.id.Gettogether) {
                isEdit = false;
                startActivity(new Intent(ctx, GetTogether.class));
            } else if (id == R.id.MyGettogether) {
                isEdit = true;
                startActivity(new Intent(ctx, GetTogether.class));
            }
        }

        return super.onOptionsItemSelected(item);
    }

    private void getTogetherRegister(final Dialog alertDialog, final String name) {
        final ProgressDialog dialog = new ProgressDialog(ctx);
        dialog.setTitle("Please wait...");
        dialog.show();
        dialog.setCancelable(false);
        final String url = Common.GetWebServiceUrl() + "gt_register.php";


        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("gtid", gtId);
        params.put("detail", name);
        params.put("regid", Utils.getString(ctx, Constants.USER_ID));

        client.post(url, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody) {

                String res = new String(responseBody);
                Utils.log(TAG, "MY_GET_TOGHER_RESPONSE : " + res);
                try {
                    JSONArray response = new JSONArray(res);
                    String error = response.getJSONObject(0).getString("error");
                    if (error.equals("no error") == false) {
                        Common.showDialog(ctx, error);
                    } else {
                        String success = response.getJSONObject(1).getString("success");
                        String message = response.getJSONObject(2).getString("message");
                        Toast.makeText(ctx, message, Toast.LENGTH_LONG).show();
                        if (success.equals("yes") == true) {
                            //  finish();
                            getGTInterestedList(ctx);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                getGTInterestedList(ctx);
                dialog.dismiss();
                alertDialog.dismiss();

            }

            @Override
            public void onFailure(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody, Throwable error) {

                Log.d("ERROR_RESPONSE", error.getMessage());
                AlertDialog.Builder b1 = new AlertDialog.Builder(ctx);
                b1.setMessage("Please Select Group to add Get-together");
                b1.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        startActivity(new Intent(InterestedGTActivity.this, Dashboard.class));
                    }
                });
                b1.create().show();
                hidePDialog();
                dialog.dismiss();

            }
        });

    }

    @Override
    public void onBackPressed() {

        super.onBackPressed();
    }
}
