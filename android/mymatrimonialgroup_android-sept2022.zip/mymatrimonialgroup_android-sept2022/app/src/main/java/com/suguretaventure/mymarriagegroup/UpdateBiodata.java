package com.suguretaventure.mymarriagegroup;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.poovam.pinedittextfield.SquarePinField;
import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;
import com.rilixtech.widget.countrycodepicker.Country;
import com.rilixtech.widget.countrycodepicker.CountryCodePicker;
import com.suguretaventure.mymarriagegroup.Model.Members;
import com.suguretaventure.mymarriagegroup.adapters.MemberRequestAdapter;
import com.suguretaventure.mymarriagegroup.common.AppController;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.common.LocationTrack;
import com.suguretaventure.mymarriagegroup.common.NetworkConnetionState;
import com.suguretaventure.mymarriagegroup.imageresize.core.ImageCompressTask;
import com.suguretaventure.mymarriagegroup.imageresize.listeners.IImageCompressTaskListener;
import com.suguretaventure.mymarriagegroup.imageresize.util.Util;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.ExifUtil;
import com.suguretaventure.mymarriagegroup.utils.Utils;
import com.yalantis.ucrop.UCrop;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import cz.msebera.android.httpclient.Header;

import static android.Manifest.permission.ACCESS_COARSE_LOCATION;
import static android.Manifest.permission.ACCESS_FINE_LOCATION;

public class UpdateBiodata extends AppCompatActivity implements PaymentResultListener {
    String bid, rid;
    private final static int ALL_PERMISSIONS_RESULT = 101;
    private static final int GALLARY = 1;
    private static final int CAMERA = 2;
    private static final int REQUEST_MULTIPLE_PERMISSION = 100;
    ProgressDialog pDialog;
    NetworkConnetionState connection;
    String id;
    ArrayList<String> OccupationId = new ArrayList<String>();
    ArrayList<String> OccupationTitle = new ArrayList<String>();
    ArrayAdapter<String> dataAdapter, bgroupAdapter, heightAdapter, weightAdapter;
    LocationTrack locationTrack;
    double latitude, longitude;
    ActionBar toolbar;
    private SquarePinField etAddOTP;
    private FirebaseAuth auth;
    private String CodeSend;
    private String contact_person_number;
    private String TAG = "ADD_BIO_DATA";
    private Context ctx = this;
    private ArrayList<String> imgArray;
    private boolean isMobileVerified = true;
    private Uri photoUri;
    private FirebaseAnalytics mFirebaseAnalytics;

    private EditText txtfullname, txtcontactNo, txtRelation, txtcontactSurname, txtcontact2, txtOtherRelatives, txtcity, txtNative, txtMiddleName, txtSpecialization,
            txtmotherOccupation, txtfatherOccupation, txtsurname, txtincome, txtblood, txtdobplace, txthobbies, txtexpectation,
            txtfathername, txtmothername, txtbroname, txtsisname, txtaddress, txtcontact1, txtmailid, txtbgphotoid, txtReligion, txtMotherTongue, txtKulDevta,txtincomeCurrency,txtOccDetails;

    private TextView lblskip, linResend;
    private RadioGroup rdogrpgender;
    private RadioButton rdomale, rdofemale;
    //private Spinner spnoccupation;

    private String fullname, mgid, rel_surname, surname, relative, fatherOccup, motherOccup, nativePlace, person_name, relation,
            contactNo, city, education, occupation, income, height, weight, blood, dobdate, dobtime, dobplace, hobbies, expectation,
            fathername, mothername, brothers, sisters, address, contact, contact2, age, email, Specialization, middle, gender, complexion,
            ras_tithi, religion, marital, motherTongue, kulDevta = "", bgphoto, smokingHabits = "", drinkingHabits="",diataryHabits="",occDetails ="";


    private Button btngroupnext1;
    private int mYear, mMonth, mDay, mHour, mMinute, mAmPm;
    private ArrayList permissionsToRequest;
    private ArrayList permissionsRejected = new ArrayList();
    private ArrayList permissions = new ArrayList();
    private ImageView imgbridegroom, imgselect_br_gr, imgbridegroomfull1, imgselect_br_grfull1, imgbridegroomfull2, imgselect_br_grfull2;
    private ExecutorService mExecutorService = Executors.newFixedThreadPool(1);
    private ImageCompressTask imageCompressTask;
    private Bitmap image = null, image1 = null, image2 = null;
    private String CameraFileAbsolutePath = "", CameraFileAbsolutePath1="", CameraFileAbsolutePath2="";
    private Members myData;
    private ArrayList<String> MemberList;
    private CountryCodePicker txtAddmobileCode;
    private TextView txtGenderTitle;
    private Toolbar toolbar_top;
    private LinearLayout LinAddOTP;
    private int temp = 0;
    private int counter = 60;
    private TextView tvDate, tvTime;
    private LinearLayout linDate, linTime;
    private String CountryCode = "";
    private String fullname1;
    private String middlename;
    private String age1;
    private String education1;
    private String occupation1;
    private String income1;
    private String height1;
    private String weight1;
    private String blood1;
    private String bdate;
    private String date;
    private String btime;
    private String bplace;
    private String father;
    private String mother;
    private String imgname;
    private String brother;
    private String sister;
    private String address1;
    private Date finaldate;
    private String contact_person;
    private String relation1;
    private String mobile;
    private String mobile2;
    private String hobbies1;
    private String expect;
    private String photo1;
    private String photo2;
    private String degree;
    private String complexion1, ras_tithi1, religion1, marital1, motherTongue1, kulDevta1;

    String[] currency_list = {"Select Currency", "INR", "EUR", "USD"};
    String[] salary_list = {"Yearly Income", "1Lac -2.5Lac", "2.5Lac-5Lac", "5Lac-7.5Lac", "7.5Lac-10Lac", "10Lac+"};

    String[] complexionList = {"Select Complexion", "Very fair", "Fair", "whitish", "Wheatish-Brown", "Semi- Dark (Savala)", "Dark"};
    String[] maritialStatusList1 = {"Select Maritial Status", "Never married (un-married)", "Divorced", "Widowed", "Awaiting Divorce", "Annulled"};
    String[] rashiList = {"Select Zodiac", "Aries (Mesh)", "Taurus (Vrushabh) ", "Gemini (Mithun)", "Cancer (Kark)", "Leo (Sinh)", "Virgo (Kanya)", "Libra (Tula)", "Scorpius (Vrushchik)", "Sagittarius (Dhanu)", " Capricornus (Makar)", "Aquarius (Kumbha)", "Pisces (Meen)"};
    String[] educationList = {"Select Education", "SSC", "HSC", "Diploma", "Under Graduate", "Graduate", "Post Graduate", "Masters"};


    RadioGroup rgDrinkingHabbits,rgSmokingHabits,rgDietaryHabits;
    RadioButton rbtnDrinkYes,rbtnDrinkNo,rbtnDrinkOccasional,rbtnSmokeYes,rbtnSmokeNo,rbtnSmokeOccasional,rbtnDietaryVeg,rbtnDietaryNonVeg,rbtnDietaryNonVegOccasional,rbtnDietaryEggetarian;


    private Spinner spnoccupation1, spnblood, spnHeight, spnWeight, spinnerComplexion, spinnerRashi, spinnerAge, spinnerMarital, spinnerEducation, spnCurrency, spnSalary;
    ;

    private IImageCompressTaskListener iImageCompressTaskListener = new IImageCompressTaskListener() {
        @Override
        public void onComplete(List<File> compressed) {
            switch (temp) {
                case 0:
                    File file = compressed.get(0);
                    txtbgphotoid.setText(file.getName());
                    imgbridegroom.setImageBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()));
                    break;
                case 1:
                    File file1 = compressed.get(0);
                    txtbgphotoid.setText(file1.getName());
                    imgbridegroomfull1.setImageBitmap(BitmapFactory.decodeFile(file1.getAbsolutePath()));
                    break;
                case 2:
                    File file2 = compressed.get(0);
                    txtbgphotoid.setText(file2.getName());
                    imgbridegroomfull2.setImageBitmap(BitmapFactory.decodeFile(file2.getAbsolutePath()));
                    break;

            }            //UPloadImageToServer();
        }

        @Override
        public void onError(Throwable error) {
            Log.e("trace error", "Error occurred: " + error);
        }
    };
    private RadioGroup rgPaymentOption;
    private RadioButton rbtnYes, rbtnNo;

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_biodata);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        rid = getIntent().getStringExtra("rid");
        bid = getIntent().getStringExtra("bid");
        allocateMemory();

        if (connection.isNetworkAvailable(ctx)) {
            setData();


        } else {
            Toast.makeText(ctx, "No internet connection found. Please check your phone settings to turn on the internet.", Toast.LENGTH_LONG).show();
        }
        setListeners();
        Checkout.preload(ctx);



        permissions.add(ACCESS_FINE_LOCATION);
        permissions.add(ACCESS_COARSE_LOCATION);
        permissionsToRequest = findUnAskedPermissions(permissions);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (permissionsToRequest.size() > 0)
                requestPermissions((String[]) permissionsToRequest.toArray(new String[permissionsToRequest.size()]), ALL_PERMISSIONS_RESULT);
        }

        locationTrack = new LocationTrack(ctx);
        if (locationTrack.canGetLocation()) {
            latitude = locationTrack.getLatitude();
            longitude = locationTrack.getLongitude();
            if (longitude == 0.0 && latitude == 0.0) {
            } else {
                Geocoder geocoder;
                List<Address> addresses;
                geocoder = new Geocoder(ctx, Locale.getDefault());

                try {
                    addresses = geocoder.getFromLocation(latitude, longitude, 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5
                    /*String address = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
                    String city = addresses.get(0).getLocality();
                    String area = addresses.get(0).getThoroughfare();
                    String state = addresses.get(0).getAdminArea();
                    String country = addresses.get(0).getCountryName();
                    String postalCode = addresses.get(0).getPostalCode();
                    String knownName = addresses.get(0).getFeatureName(); // Only if available else return NULL*/
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } else {
            //locationTrack.showSettingsAlert("Do you want to turn on GPS?");
            //Toast.makeText(ctx, "Make sure that your GPS is On.", Toast.LENGTH_LONG).show();
        }
    }

    public void allocateMemory() {
        auth = FirebaseAuth.getInstance();
        connection = new NetworkConnetionState();
        rgPaymentOption = findViewById(R.id.rgPaymentOption);
        rbtnYes = findViewById(R.id.rbtnYes);
        rbtnNo = findViewById(R.id.rbtnNo);


        lblskip = findViewById(R.id.lblskip);
        imgbridegroom = findViewById(R.id.imgbridegroom);
        imgselect_br_gr = findViewById(R.id.imgselect_br_gr);
        txtbgphotoid = findViewById(R.id.txtbgphotoid);
        txtfullname = findViewById(R.id.txtfullname);
        txtMiddleName = findViewById(R.id.txtMiddleName);
        txtSpecialization = findViewById(R.id.txtSpecialization);
        txtsurname = findViewById(R.id.txtsurname);
        txtincome = findViewById(R.id.txtincome);
        txtincomeCurrency = findViewById(R.id.txtincomeCurrency);
        txtblood = findViewById(R.id.txtblood);
        txtdobplace = findViewById(R.id.txtdobplace);
        txthobbies = findViewById(R.id.txthobbies);
        txtexpectation = findViewById(R.id.txtexpectation);
        txtfathername = findViewById(R.id.txtfathername);
        txtmothername = findViewById(R.id.txtmothername);
        txtbroname = findViewById(R.id.txtbroname);
        txtsisname = findViewById(R.id.txtsisname);
        txtaddress = findViewById(R.id.txtaddress);
        txtcontact1 = findViewById(R.id.txtcontact1);
        txtcontact2 = findViewById(R.id.txtcontact2);
        txtmailid = findViewById(R.id.txtmailid);

        spnoccupation1 = findViewById(R.id.spnoccupation1);
        spinnerComplexion = findViewById(R.id.spinnerComplexion);
        spinnerRashi = findViewById(R.id.spinnerRashi);
        spinnerAge = findViewById(R.id.spinnerAge);
        spinnerMarital = findViewById(R.id.spinnerMarital);
        spinnerEducation = findViewById(R.id.spinnerEducation);
        spnblood = findViewById(R.id.spnblood);
        spnHeight = findViewById(R.id.spnHeight);
        spnWeight = findViewById(R.id.spnWeight);

        rdogrpgender = findViewById(R.id.rdogrpgender);
        rdomale = findViewById(R.id.rdomale);
        rdofemale = findViewById(R.id.rdofemale);
        btngroupnext1 = findViewById(R.id.btngroupnext1);
        txtfatherOccupation = findViewById(R.id.txtfatherOccupation);
        txtmotherOccupation = findViewById(R.id.txtmotherOccupation);
        txtOtherRelatives = findViewById(R.id.txtOtherRelatives);
        txtNative = findViewById(R.id.txtNative);
        txtRelation = findViewById(R.id.txtRelation);
        txtcontact2 = findViewById(R.id.txtcontact2);
        txtcity = findViewById(R.id.txtcity);
        txtcontactSurname = findViewById(R.id.txtcontactSurname);
        txtcontactNo = findViewById(R.id.txtcontactNo);
        txtAddmobileCode = findViewById(R.id.txtAddmobileCode);
        LinAddOTP = findViewById(R.id.LinAddOTP);
        etAddOTP = findViewById(R.id.etAddOTP);
        imgbridegroomfull2 = findViewById(R.id.imgbridegroomfull2);
        imgselect_br_grfull2 = findViewById(R.id.imgselect_br_grfull2);
        imgbridegroomfull1 = findViewById(R.id.imgbridegroomfull1);
        imgselect_br_grfull1 = findViewById(R.id.imgselect_br_grfull1);
        linResend = findViewById(R.id.linResend);
        tvDate = findViewById(R.id.tvDate);
        tvTime = findViewById(R.id.tvTime);
        linDate = findViewById(R.id.linDate);
        linTime = findViewById(R.id.linTime);
        txtReligion = findViewById(R.id.txtReligion);
        txtMotherTongue = findViewById(R.id.txtMotherTongue);
        txtKulDevta = findViewById(R.id.txtKulDevta);
        txtOccDetails = findViewById(R.id.txtOccDetails);

        spnCurrency = findViewById(R.id.spnCurrency);
        spnSalary = findViewById(R.id.spnSalary);



        rgDrinkingHabbits = findViewById(R.id.rgDrinkingHabbits);
        rgSmokingHabits = findViewById(R.id.rgSmokingHabits);
        rgDietaryHabits = findViewById(R.id.rgDietaryHabits);
        rbtnDrinkYes = findViewById(R.id.rbtnDrinkYes);
        rbtnDrinkNo = findViewById(R.id.rbtnDrinkNo);
        rbtnDrinkOccasional = findViewById(R.id.rbtnDrinkOccasional);
        rbtnSmokeYes = findViewById(R.id.rbtnSmokeYes);
        rbtnSmokeNo = findViewById(R.id.rbtnSmokeNo);
        rbtnSmokeOccasional = findViewById(R.id.rbtnSmokeOccasional);
        rbtnDietaryVeg = findViewById(R.id.rbtnDietaryVeg);
        rbtnDietaryNonVeg = findViewById(R.id.rbtnDietaryNonVeg);
        rbtnDietaryNonVegOccasional = findViewById(R.id.rbtnDietaryNonVegOccasional);
        rbtnDietaryEggetarian = findViewById(R.id.rbtnDietaryEggetarian);

        id = Utils.getString(ctx, Constants.USER_ID);


        setComplexionSpinnerAdapter();
        setRashiSpinnerAdapter();
        setAgeSpinnerAdapter();
        setMaritialSpinnerAdapter();
        setEducationSpinnerAdapter();
        /*setCurrencySpinner();
        setSalarySpinner()*/;

        bgroupAdapter = new ArrayAdapter<String>(ctx,
                android.R.layout.simple_spinner_item,
                ctx.getResources().getStringArray(R.array.blood));
        bgroupAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnblood.setAdapter(bgroupAdapter);


        weightAdapter = new ArrayAdapter<String>(ctx,
                android.R.layout.simple_spinner_item,
                ctx.getResources().getStringArray(R.array.weight));
        weightAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnWeight.setAdapter(weightAdapter);

        heightAdapter = new ArrayAdapter<String>(ctx,
                android.R.layout.simple_spinner_item,
                ctx.getResources().getStringArray(R.array.height));
        heightAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnHeight.setAdapter(heightAdapter);

        toolbar_top = findViewById(R.id.toolbar_top);
    }

    public void setListeners() {


        rbtnNo.setChecked(true);
        rgPaymentOption.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                if (radioGroup.getCheckedRadioButtonId() == R.id.rbtnYes) {
                    btngroupnext1.setText("Proceed to Pay");

                }
                if (radioGroup.getCheckedRadioButtonId() == R.id.rbtnNo)  {
                    btngroupnext1.setText("Update Bio-Data");
                }
            }
        });


        etAddOTP.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    if (etAddOTP.getText().length() == 6 && CodeSend != null) {
                        ProgressDialog dialog = new ProgressDialog(ctx);
                        dialog.setTitle("OTP Verification");
                        dialog.setMessage("OTP Verifying");
                        dialog.setCancelable(false);
                        dialog.show();
                        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(CodeSend, etAddOTP.getText().toString());
                        signInWithPhoneAuthCredential(credential, dialog);
                    } else {
                        Toast.makeText(ctx, "Please enter valid OTP", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
        linResend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                linResend.setVisibility(View.GONE);
                if (CountryCode.equalsIgnoreCase("")) {
                    Toast.makeText(ctx, "enter country code", Toast.LENGTH_LONG).show();
                } else if (txtcontactNo.getText().length() < 9) {
                    txtcontactNo.setError("Contact number required");
                    LinAddOTP.setVisibility(View.GONE);
                } else {
                    LinAddOTP.setVisibility(View.VISIBLE);
                    sendSMS(CountryCode, txtcontactNo.getText().toString());
                }
            }
        });
        txtcontactNo.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    if (contact_person_number.equals(txtcontactNo.getText().toString().trim())) {
                        isMobileVerified = true;
                    } else {
                        isMobileVerified = false;
                        if (CountryCode.equalsIgnoreCase("")) {
                            Toast.makeText(ctx, "enter country code", Toast.LENGTH_LONG).show();
                        } else if (txtcontactNo.getText().length() < 9) {
                            txtcontactNo.setError("Contact number required");
                            LinAddOTP.setVisibility(View.GONE);
                        } else {
                            LinAddOTP.setVisibility(View.VISIBLE);
                            sendSMS(CountryCode, txtcontactNo.getText().toString());
                        }
                    }
                }
            }
        });

        txtAddmobileCode.setOnCountryChangeListener(new CountryCodePicker.OnCountryChangeListener() {
            @Override
            public void onCountrySelected(Country selectedCountry) {
                CountryCode = "+" + selectedCountry.getPhoneCode();
            }
        });
        imgselect_br_gr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                temp = 0;
                requestPermission(0);
            }
        });
        imgselect_br_grfull1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                temp = 1;
                requestPermission(1);
            }
        });
        imgselect_br_grfull2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                temp = 2;
                requestPermission(2);
            }
        });

        rdogrpgender.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.rdomale:
                        gender = "1";
                        rdomale.setTextColor(Color.parseColor("#FFFFFF"));
                        rdofemale.setTextColor(Color.parseColor("#000000"));
                        break;
                    case R.id.rdofemale:
                        gender = "0";
                        rdofemale.setTextColor(Color.parseColor("#FFFFFF"));
                        rdomale.setTextColor(Color.parseColor("#000000"));
                        break;
                }
            }
        });



        rgDrinkingHabbits.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.rbtnDrinkYes:
                        drinkingHabits = rbtnDrinkYes.getText().toString();
                        break;
                    case R.id.rbtnDrinkNo:
                        drinkingHabits = rbtnDrinkNo.getText().toString();
                        break;
                    case R.id.rbtnDrinkOccasional:
                        drinkingHabits = rbtnDrinkOccasional.getText().toString();
                        break;
                }
            }
        });



        rgSmokingHabits.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.rbtnSmokeYes:
                        smokingHabits = rbtnSmokeYes.getText().toString();
                        break;
                    case R.id.rbtnSmokeNo:
                        smokingHabits = rbtnSmokeNo.getText().toString();
                        break;
                    case R.id.rbtnSmokeOccasional:
                        smokingHabits = rbtnSmokeOccasional.getText().toString();
                        break;
                }
            }
        });


        rgDietaryHabits.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.rbtnDietaryVeg:
                        diataryHabits = rbtnDietaryVeg.getText().toString();
                        break;
                    case R.id.rbtnDietaryNonVeg:
                        diataryHabits = rbtnDietaryNonVeg.getText().toString();
                        break;
                    case R.id.rbtnDietaryNonVegOccasional:
                        diataryHabits = rbtnDietaryNonVegOccasional.getText().toString();
                        break;
                    case R.id.rbtnDietaryEggetarian:
                        diataryHabits = rbtnDietaryEggetarian.getText().toString();
                        break;
                }
            }
        });




        spnoccupation1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) {
                    occupation = OccupationId.get(position);
                } else {
                    occupation = "";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spinnerComplexion.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) {
                    complexion = spinnerComplexion.getSelectedItem().toString();
                } else {
                    complexion = "";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        spinnerRashi.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) {
                    ras_tithi = spinnerRashi.getSelectedItem().toString();
                } else {
                    ras_tithi = "";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        spinnerAge.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) {
                    age = spinnerAge.getSelectedItem().toString();
                } else {
                    age = "";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        spinnerMarital.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) {
                    marital = spinnerMarital.getSelectedItem().toString();
                } else {
                    marital = "";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spnHeight.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                if (position != 0) {
                    height = spnHeight.getSelectedItem().toString();
                } else {
                    height = "";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        spnWeight.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                if (position != 0) {
                    weight = spnWeight.getSelectedItem().toString();
                } else {
                    weight = "";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        spinnerEducation.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) {
                    education = spinnerEducation.getSelectedItem().toString();
                } else {
                    education = "";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spnblood.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) {
                    blood = bgroupAdapter.getItem(position).toString();
                } else {
                    blood = "-";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        linDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(ctx, android.app.AlertDialog.THEME_HOLO_LIGHT, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {
                        monthOfYear = monthOfYear + 1;
                        String mnth = (monthOfYear < 10) ? "0" + monthOfYear : "" + monthOfYear;
                        String day = (dayOfMonth < 10) ? "0" + dayOfMonth : "" + dayOfMonth;
                        tvDate.setText(day + "-" + mnth + "-" + year);
                    }
                }, mYear, mMonth, mDay);
                datePickerDialog.setCancelable(false);
                datePickerDialog.show();
            }
        });
        linTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                mHour = c.get(Calendar.HOUR);
                mMinute = c.get(Calendar.MINUTE);
                mAmPm = c.get(Calendar.AM_PM);
                TimePickerDialog timePickerDialog = new TimePickerDialog(ctx,
                        new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay,
                                                  int minute) {
                                String am_pm = (hourOfDay < 12) ? "AM" : "PM";
                                String hourOfDay1 = (hourOfDay < 10) ? "0" + hourOfDay : "" + hourOfDay;
                                String minute1 = (minute < 10) ? "0" + minute : "" + minute;
                                tvTime.setText(hourOfDay1 + ":" + minute1 + " " + am_pm);
                            }
                        }, mHour, mMinute, false);
                timePickerDialog.setCancelable(false);
                timePickerDialog.show();
            }
        });

        btngroupnext1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ValidateInput() == true) {
                    if (imgbridegroom.getDrawable() != null) {
                        if (connection.isNetworkAvailable(ctx)) {
                            if (isMobileVerified) {
                                if (rbtnYes.isChecked()) {
                                    startPayment("1");
                                } else {
                                    addBiodata("0");
                                }

                                //addBiodata();
                            } else {
                                Toast.makeText(ctx, "Verify mobile number to add bio-data", Toast.LENGTH_LONG).show();
                            }
                        } else {
                            Toast.makeText(ctx, "No internet connection found. Please check your phone settings to turn on the internet.", Toast.LENGTH_LONG).show();
                        }
                    } else {
                        Toast.makeText(ctx, "Photos required", Toast.LENGTH_LONG).show();
                    }
                }
                //sendVerified("5");
            }
        });



    }


    // set  spinner list
    public void setComplexionSpinnerAdapter() {
        ArrayAdapter aa = new ArrayAdapter(UpdateBiodata.this, android.R.layout.simple_spinner_item, complexionList);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerComplexion.setAdapter(aa);

    }

    // set  spinner list
    public void setRashiSpinnerAdapter() {
        ArrayAdapter aa = new ArrayAdapter(UpdateBiodata.this, android.R.layout.simple_spinner_item, rashiList);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerRashi.setAdapter(aa);

    }


    // set  spinner list
    public void setMaritialSpinnerAdapter() {
        ArrayAdapter aa = new ArrayAdapter(UpdateBiodata.this, android.R.layout.simple_spinner_item, maritialStatusList1);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerMarital.setAdapter(aa);

    }

    // set  spinner list
    public void setCurrencySpinner() {
        ArrayAdapter aa = new ArrayAdapter(UpdateBiodata.this, android.R.layout.simple_spinner_item, currency_list);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnCurrency.setAdapter(aa);

    }

    public void setSalarySpinner() {
        ArrayAdapter aa = new ArrayAdapter(UpdateBiodata.this, android.R.layout.simple_spinner_item, salary_list);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnSalary.setAdapter(aa);

    }


    // set  spinner list
    public void setEducationSpinnerAdapter() {
        ArrayAdapter aa = new ArrayAdapter(UpdateBiodata.this, android.R.layout.simple_spinner_item, educationList);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerEducation.setAdapter(aa);

    }


    // set  spinner list
    public void setAgeSpinnerAdapter() {
        ArrayAdapter ageAdapter = new ArrayAdapter<String>(ctx,
                android.R.layout.simple_spinner_item,
                ctx.getResources().getStringArray(R.array.age));
        ageAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerAge.setAdapter(ageAdapter);

    }


    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential, final ProgressDialog dialog) {
        auth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d(TAG, "signInWithCredential:success");
                            /*sendDataToServer();*/
                            dialog.dismiss();
                            linResend.setVisibility(View.GONE);
                            isMobileVerified = true;
                            txtcontactNo.setEnabled(false);
                            txtcontactNo.setCompoundDrawables(null, null, getResources().getDrawable(R.drawable.ic_done_green), null);
                            etAddOTP.setEnabled(false);
                        } else {
                            // Sign in failed, display a message and update the UI
                            Log.w(TAG, "signInWithCredential:failure", task.getException());
                            dialog.dismiss();

                            if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {
                                // The verification code entered was invalid
                                Toast.makeText(ctx, "The verification code entered was invalid", Toast.LENGTH_LONG).show();
                            }

                        }
                    }
                });
    }

    private void sendSMS(String countryCode, String mobile) {
        counter = 60;
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                countryCode + "" + mobile,        // Phone number to verify
                60,                 // Timeout duration
                TimeUnit.SECONDS,   // Unit of timeout
                this,               // Activity (for callback binding)
                mCallbacks);        // OnVerificationStateChangedCallbacks
        linResend.setVisibility(View.VISIBLE);
        new CountDownTimer(60000, 1000) {
            public void onTick(long millisUntilFinished) {
                linResend.setText("Resend OTP within " + counter + " seconds.");
                linResend.setClickable(false);
                if (counter > 0) {
                    counter--;
                } else {
                    linResend.setClickable(true);
                    linResend.setText("Resend OTP?");
                }
            }

            public void onFinish() {
                counter = 0;
                linResend.setClickable(true);
                linResend.setText("Resend OTP?");
            }
        }.start();
    }

    public void setOccupation() {
        String WebServiceUrl = Common.GetWebServiceUrl() + "occupation_list.php?gender=-1";
        JsonArrayRequest request = new JsonArrayRequest(WebServiceUrl, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                Utils.log(TAG, response.toString());
                try {
                    String error = response.getJSONObject(0).getString("error");
                    if (error.equals("no error") == false) {
                        Common.showDialog(ctx);
                    } else {
                        //no error
                        int total = response.getJSONObject(1).getInt("total");
                        if (total == 0)
                            Toast.makeText(ctx, "No Occupation Found", Toast.LENGTH_LONG).show();
                        else {
                            int size = response.length();
                            OccupationId.add("0");
                            OccupationTitle.add("Select Occupation");
                            for (int i = 2; i < (size-4); i++) //3
                            {
                                JSONObject object = response.getJSONObject(i);
                                OccupationId.add(object.getString("id"));
                                OccupationTitle.add(object.getString("ot"));
                            }
                            dataAdapter = new ArrayAdapter<String>(ctx,
                                    android.R.layout.simple_spinner_item, OccupationTitle);
                            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                            spnoccupation1.setAdapter(dataAdapter);
                            for (int i = 0; i < OccupationTitle.size(); i++) {
                                if (OccupationTitle.get(i).equalsIgnoreCase(occupation1)) {
                                    spnoccupation1.setSelection(i);
                                }
                            }
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Common.showDialog(ctx);
            }
        });
        request.setRetryPolicy(new DefaultRetryPolicy(2000, 3, 1));
        AppController.getInstance().addToRequestQueue(request);
    }

    public void addBiodata(String razorpayPaymentID) {
        pDialog = new ProgressDialog(ctx);
        pDialog.setMessage("Uploading Please Wait....");
        pDialog.setCancelable(false);
        showpDialog();

        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("register_userid", "" + rid);
        params.put("bid", "" + bid);
        params.put("name", fullname);
        params.put("middle", middle);
        params.put("surname", surname);
        params.put("gender", gender);
        params.put("age", "" + age);
        params.put("city", "" + city);
        params.put("education", education);
        params.put("occupationid", occupation);
        params.put("address", address);

        income = txtincomeCurrency.getText().toString() + " " + txtincome.getText().toString();
        params.put("income", income);

        if (weight.length()==0){
            weight="";
        }

        params.put("height", height);
        params.put("weight", weight);
        params.put("blood", blood);
        params.put("degree", Specialization);
        params.put("birthdate", dobdate);
        params.put("birthtime", dobtime);
        params.put("birthplace", dobplace);
        params.put("hobbies", hobbies);
        params.put("expectation", expectation);
//        params.put("photo", "img1.png");
        params.put("fathername", fathername);
        params.put("fatheroccup", fatherOccup);
        params.put("mothername", mothername);
        params.put("motheroccup", motherOccup);
        params.put("brothers", brothers);
        params.put("sisters", sisters);
        params.put("relatives", relative);
        params.put("nativeplace", nativePlace);
        params.put("contact", contact);
        params.put("contact_person_number", contactNo);
        params.put("contact2", contact2);
        params.put("email", email);
        params.put("saved", "0");
        params.put("latitude", "" + latitude);
        params.put("longitude", "" + longitude);
        params.put("relation", relation);
        params.put("contact_person", person_name);
        params.put("relative_who_knows", contact2);
        params.put("rel_surname", rel_surname);
        params.put("complexion", complexion);
        params.put("rastithi", ras_tithi);
        params.put("religion", religion);
        params.put("marital", marital);
        params.put("mothertongue", motherTongue);
        params.put("kuldaivat", kulDevta);
        params.put("occDetails", occDetails);

        params.put("drinking_habits", drinkingHabits);
        params.put("smoking_habits", smokingHabits);
        params.put("diatary_habits", diataryHabits);

        params.put("pay_id", razorpayPaymentID);


        Utils.log(TAG, "UPDATE_BIO_DATA_URL : " + Constants.UPDATE_BIODATA + "?" + params);
        client.post(Constants.UPDATE_BIODATA, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                Utils.log(TAG, "UPDATE_BIO_DATA_RESPONSE : " + response);

                if (!CameraFileAbsolutePath.equals("")){
                    UPloadImageToServer(bid, 3);
                }
                if (!CameraFileAbsolutePath1.equals("")){
                    UPloadImageToServer(bid, 4);
                }
                if (!CameraFileAbsolutePath2.equals("")){
                    UPloadImageToServer(bid, 5);
                }
                /*for (int i = 3; i <= 5; i++) {
                    UPloadImageToServer(bid, i);
                }*/
                MyPosts.onBackPressFlag = true;
                Toast.makeText(UpdateBiodata.this, "Bio-Data Update Successful", Toast.LENGTH_SHORT).show();
                if (CameraFileAbsolutePath.equals("") && CameraFileAbsolutePath1.equals("") && CameraFileAbsolutePath2.equals("")){
                    onBackPressed();
                }

                /*Intent intent = new Intent(UpdateBiodata.this, MyPosts.class);
                intent.putExtra("from", "dashboard");
                intent.putExtra("gender", "-1");
                startActivity(intent);*/
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "UPDATE_BIO_DATA_ERROR : " + error.getMessage());
                Toast.makeText(UpdateBiodata.this, "Something Went Wrong", Toast.LENGTH_SHORT).show();
                hidePDialog();
                Common.showDialog(ctx);
            }
        });
    }

    /*private void sendVerified(final String id) {
        final AlertDialog.Builder alertDialog = new AlertDialog.Builder(ctx);
        LayoutInflater inflater = getLayoutInflater();
        View convertView = (View) inflater.inflate(R.layout.layout_bio_request, null);
        alertDialog.setView(convertView);
        alertDialog.setTitle("Send request to :");
        RecyclerView recyclerView = convertView.findViewById(R.id.rcvMemberList);
        LinearLayout LinSendRequest = convertView.findViewById(R.id.LinSendRequest);
        alertDialog.setPositiveButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        LinSendRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StringBuffer string = new StringBuffer();
                for (int i = 0; i < myData.members.size(); i++) {
                    if (myData.members.get(i).isSelected()) {
                        string.append(myData.members.get(i).id + ",");
                    }
                }
                sendRequest(id, string);

            }
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(ctx));
        recyclerView.setAdapter(new MemberRequestAdapter(ctx, myData, LinSendRequest,myData.aid));
        alertDialog.setCancelable(false);
        alertDialog.show();
    }*/

    private void sendRequest(String id, StringBuffer string) {
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("bid", id);
        params.put("ids", string);
        Utils.log(TAG, Constants.APP_SEND_REQUEST + "?" + params);
        client.post(Constants.APP_SEND_REQUEST, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                String success = "", message = "";
                Utils.log(TAG, "SEND_REQUEST_RESPONSE : " + res);
                try {
                    JSONObject object = new JSONObject(res);
                    success = object.getString("success");
                    message = object.getString("msg");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                Toast.makeText(UpdateBiodata.this, "" + message, Toast.LENGTH_LONG).show();
                if (success.equalsIgnoreCase("true")) {
                    UpdateBiodata.super.onBackPressed();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "SEND_REQUEST_ERROR : " + error.getMessage());
            }
        });
    }

    public boolean ValidateInput() {
        boolean isvalid = true;
        fullname = txtfullname.getText().toString().trim();
        surname = txtsurname.getText().toString().trim();
        // education = txteducation.getText().toString().trim();
        //occupation = txtoccupation.getText().toString().trim();
//        income = txtincome.getText().toString().trim();
        //  height = txtheight.getText().toString().trim();
        //   weight = txtweight.getText().toString().trim();
        //blood = txtblood.getText().toString();


        bgphoto = txtbgphotoid.getText().toString();
        dobdate = tvDate.getText().toString();
        dobtime = tvTime.getText().toString();
        dobplace = txtdobplace.getText().toString();
        hobbies = txthobbies.getText().toString();
        expectation = txtexpectation.getText().toString();
        fathername = txtfathername.getText().toString();
        mothername = txtmothername.getText().toString();
        brothers = txtbroname.getText().toString();
        sisters = txtsisname.getText().toString();
        address = txtaddress.getText().toString();
        contact = txtcontactNo.getText().toString();
        contactNo = txtcontactNo.getText().toString();
        contact2 = txtcontact2.getText().toString();
        //  age = txtAge.getText().toString();
        middle = txtMiddleName.getText().toString();
        Specialization = txtSpecialization.getText().toString();
        fatherOccup = txtfatherOccupation.getText().toString();
        motherOccup = txtmotherOccupation.getText().toString();
        relative = txtOtherRelatives.getText().toString();
        nativePlace = txtNative.getText().toString();
        city = txtcity.getText().toString();
        relation = txtRelation.getText().toString();
        person_name = txtcontact1.getText().toString();
        rel_surname = txtcontactSurname.getText().toString();
        email = txtmailid.getText().toString().trim().toLowerCase();

        //  complexion = txtComplexion.getText().toString();
        //   ras_tithi = txtRasTithi.getText().toString();
        religion = txtReligion.getText().toString();
        //   marital = txtMarital.getText().toString();
        motherTongue = txtMotherTongue.getText().toString();
        kulDevta = txtKulDevta.getText().toString();
        occDetails = txtOccDetails.getText().toString();


        if (email.equalsIgnoreCase("")) {
            isvalid = false;
            email = "-";
        }
        if (gender.equals("")) {
            isvalid = false;
            Toast.makeText(ctx, "Select Bride or Groom First", Toast.LENGTH_SHORT).show();
        }
        if (occupation.equals("")) {
            isvalid = false;
            Toast.makeText(ctx, "Select Occupation First", Toast.LENGTH_SHORT).show();
        }
        if (fullname.length() == 0) {
            isvalid = false;
            txtfullname.setError("First name required");
        }
        if (middle.length() == 0) {
            isvalid = false;
            Toast.makeText(ctx, "Middle name required", Toast.LENGTH_SHORT).show();
            txtMiddleName.setError("Middle name required");
        }
        if (txtsurname.getText().length() == 0) {
            isvalid = false;
            txtsurname.setError("Surname required");
        }
        if (age.length() == 0) {
            isvalid = false;
            Toast.makeText(ctx, "Age required", Toast.LENGTH_SHORT).show();
        }

        if (city.length() == 0) {
            isvalid = false;
            txtcity.setError("Present residing city required");
        }
        if (height.length() == 0) {
            isvalid = false;
            Toast.makeText(ctx, "Height required", Toast.LENGTH_SHORT).show();

        }
       /* if (weight.length() == 0) {
            isvalid = false;
            Toast.makeText(ctx, "Weight required", Toast.LENGTH_SHORT).show();

        }*/
        if (complexion.length() == 0) {
            isvalid = false;
            Toast.makeText(ctx, "Complexion required", Toast.LENGTH_SHORT).show();

        }
        if (dobdate.length() == 0) {
            dobdate = "-";
        }
        if (dobtime.length() == 0) {
            dobtime = "-";
        }
        if (dobplace.length() == 0) {
            dobplace = "-";
        }
        /*if (hobbies.length() == 0) {
            isvalid = false;
            txthobbies.setError("hobbies required");
        }*/
        /*if (expectation.length() == 0) {
            isvalid = false;
            txtexpectation.setError("expectation required");
        }*/
        if (fathername.length() == 0) {
            isvalid = false;
            txtfathername.setError("Father's name required");
        }
        if (mothername.length() == 0) {
            mother = "-";
        }
        if (address.length() == 0) {
            isvalid = false;
            txtaddress.setError("Address required");
        }
        if (contact.length() == 0) {
            isvalid = false;
            txtcontact1.setError("Person name required");
        }
        if (contactNo.length() == 0) {
            isvalid = false;
            txtcontactNo.setError("Contact number required");
        }


        if (txtincome.getText().toString().equals("")) {
            isvalid = false;
            txtincome.setError("Annual income required");
        }

        if(!txtincome.getText().toString().equals("") && txtincomeCurrency.getText().toString().equals("")){
            isvalid = false;
            Toast.makeText(ctx, "Currency required", Toast.LENGTH_SHORT).show();
            txtincomeCurrency.setError("Currency required");
        }

       /* if (!spnSalary.getSelectedItem().toString().equals("Yearly Income") && spnCurrency.getSelectedItem().toString().equals("Select Currency")) {
            isvalid = false;
            Toast.makeText(ctx, "Select currency", Toast.LENGTH_SHORT).show();
        }*/

        /*if (email.length() == 0) {
            isvalid = false;
            txtmailid.setError("email required");
        }*/
       /* if (txtMiddleName.getText().length() == 0) {
            isvalid = false;
            txtMiddleName.setError("Middle required");
        }*/

        if (spinnerMarital.getSelectedItemPosition() == 0) {
            isvalid = false;
            Toast.makeText(ctx, "Marital status required", Toast.LENGTH_SHORT).show();
        }
        if (education.length() == 0) {
            isvalid = false;
            Toast.makeText(ctx, "education required", Toast.LENGTH_SHORT).show();

        }
        if (txtNative.getText().length() == 0) {
            nativePlace = "-";
        }
        if (txtcontact1.getText().length() == 0) {
            isvalid = false;
            txtcontact1.setError("Name of contact person required");
        }
        if (txtRelation.getText().length() == 0) {
            relation = "-";
        }
        return isvalid;
    }

    // show process Dialog box
    private void showpDialog() {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }

    // hide process Dialog box
    private void hidePDialog() {
        if (this.pDialog != null) {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }

    public long getMaxDate() {
        long l = new Date().getTime();
        l = l + 172800000;
        return l;
    }

    public long getMinDate() {
        long l = new Date().getTime();
        return l;
    }

    private ArrayList findUnAskedPermissions(ArrayList wanted) {
        ArrayList result = new ArrayList();
        for (Object perm : wanted) {
            if (!hasPermission(perm)) {
                result.add(perm);
            }
        }
        return result;
    }

    private boolean hasPermission(Object permission) {
        if (canMakeSmores()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                return (checkSelfPermission((String) permission) == PackageManager.PERMISSION_GRANTED);
            }
        }
        return true;
    }

    private boolean canMakeSmores() {
        return (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP_MR1);
    }

    @TargetApi(Build.VERSION_CODES.M)
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case ALL_PERMISSIONS_RESULT:
                for (Object perms : permissionsToRequest) {
                    if (!hasPermission(perms)) {
                        permissionsRejected.add(perms);
                    }
                }
                if (permissionsRejected.size() > 0) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (shouldShowRequestPermissionRationale(String.valueOf(permissionsRejected.get(0)))) {
                            showMessageOKCancel("These permissions are mandatory for the application. Please allow access.",
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                                requestPermissions((String[]) permissionsRejected.toArray(new String[permissionsRejected.size()]), ALL_PERMISSIONS_RESULT);
                                            }
                                        }
                                    });
                            return;
                        }
                    }

                }
                break;
        }
    }

    private void showMessageOKCancel(String message, DialogInterface.OnClickListener okListener) {
        new AlertDialog.Builder(ctx)
                .setMessage(message)
                .setPositiveButton("OK", okListener)
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }

    void requestPermission(int i) {
        if (PackageManager.PERMISSION_GRANTED !=
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ||
                PackageManager.PERMISSION_GRANTED != ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)) {
            String[] PermissionList = {Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.CAMERA};
            if (ActivityCompat.shouldShowRequestPermissionRationale
                    (this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ||
                    ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA)) {

                ActivityCompat.requestPermissions(this, PermissionList,
                        REQUEST_MULTIPLE_PERMISSION);
            } else {
                ActivityCompat.requestPermissions(this, PermissionList,
                        REQUEST_MULTIPLE_PERMISSION);
            }
        } else {
            showDialogBox();
        }
    }

    private void showDialogBox() {
        AlertDialog.Builder b1 = new AlertDialog.Builder(ctx);
        b1.setTitle("Select Photo");
        b1.setIcon(R.mipmap.logo1);
        b1.setMessage("I want to select photo");
        b1.setPositiveButton("Using CAMERA", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                File image = null;
                try {
                    image = Util.CreteFileWithUniqueName(ctx);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                switch (temp) {
                    case 0:
                        CameraFileAbsolutePath = image.getAbsolutePath();
                        break;
                    case 1:
                        CameraFileAbsolutePath1 = image.getAbsolutePath();
                        break;
                    case 2:
                        CameraFileAbsolutePath2 = image.getAbsolutePath();
                }
                Uri photoURI = FileProvider.getUriForFile(ctx,
                        BuildConfig.APPLICATION_ID + ".provider", image);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(intent, CAMERA);
            }
        });
        b1.setNegativeButton("using Gallery", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent = new Intent(Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, GALLARY);
            }
        });

        b1.create().show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GALLARY && resultCode == RESULT_OK &&
                data != null) {

            Uri uri = data.getData();
            Cursor cursor = MediaStore.Images.Media.query(getContentResolver(),
                    uri, new String[]{MediaStore.Images.Media.DATA});
            if (cursor != null && cursor.moveToFirst()) {
                switch (temp) {
                    case 0:
                        CameraFileAbsolutePath = cursor.getString(cursor.getColumnIndexOrThrow
                                (MediaStore.Images.Media.DATA));
                        photoUri = Uri.parse("file:"+CameraFileAbsolutePath);
                        break;
                    case 1:
                        CameraFileAbsolutePath1 = cursor.getString(cursor.getColumnIndexOrThrow
                                (MediaStore.Images.Media.DATA));

                        photoUri = Uri.parse("file:"+CameraFileAbsolutePath1);

                        break;
                    case 2:
                        CameraFileAbsolutePath2 = cursor.getString(cursor.getColumnIndexOrThrow
                                (MediaStore.Images.Media.DATA));
                        photoUri = Uri.parse("file:"+CameraFileAbsolutePath2);
                        break;
                }

            }
            if (photoUri!=null){

                File destimage = null;
                try {
                    destimage = Util.CreteFileWithUniqueName(this);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                File file = new File(uri.getPath());
                UCrop.of(photoUri, Uri.fromFile(destimage))
                        .withAspectRatio(10f, 10f)
                        .withMaxResultSize(1024, 1024)
                        .start(UpdateBiodata.this);
            }

        } else if (requestCode == CAMERA) {
            switch (temp){
                case 0:
                    photoUri = Uri.parse("file:"+CameraFileAbsolutePath);
                    break;
                case 1:
                    photoUri = Uri.parse("file:"+CameraFileAbsolutePath1);
                    break;
                case 2:
                    photoUri = Uri.parse("file:"+CameraFileAbsolutePath2);
                    break;
            }
            if (photoUri!=null){
                File destimage = null;
                try {
                    destimage = Util.CreteFileWithUniqueName(this);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                UCrop.of(photoUri, Uri.fromFile(destimage))
                        .withAspectRatio(10f, 10f)
                        .withMaxResultSize(1024, 1024)
                        .start(UpdateBiodata.this);
            }
        }else if (resultCode == RESULT_OK && requestCode == UCrop.REQUEST_CROP) {
            final Uri resultUri = UCrop.getOutput(data);

            Log.e("CROP IMAGE PATH", resultUri.toString());

            Bitmap cursor = null;
            try {
                cursor = MediaStore.Images.Media.getBitmap(getContentResolver(),
                        resultUri);
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (temp == 0) {
                imgbridegroom.setImageBitmap(cursor);
            } else if (temp == 1) {
                imgbridegroomfull1.setImageBitmap(cursor);
            } else if (temp == 2) {
                imgbridegroomfull2.setImageBitmap(cursor);
            }

        }
    }

    //3 == photo (Face Bio-data
    //4 == full photo photo1
    //5 == full photo photo2
    private void UPloadImageToServer(final String bgid, Integer type) {
//        String Pageurl = Common.GetWebServiceUrl() + "upload_image.php?bgid=" + bgid + "&type=" + type;
        String Pageurl = "https://mymarriagegroup.com/ws/upload_image.php?bgid=" + bgid + "&type=" + type;
        Log.e("trace pageurl", Pageurl);
        JSONObject object = new JSONObject();
        String myimage = "";
        if (imgbridegroom.getDrawable() != null) {
            try {
                switch (type) {
                    case 3:
                        BitmapDrawable image = (BitmapDrawable) imgbridegroom.getDrawable();
                        Bitmap ImageCompresser = image.getBitmap();
                        ByteArrayOutputStream ba = new ByteArrayOutputStream();
                        ImageCompresser.compress(Bitmap.CompressFormat.JPEG, 100, ba);
                        myimage = Base64.encodeToString(ba.toByteArray(), Base64.DEFAULT);
                        break;
                    case 4:
                        if (imgbridegroomfull1.getDrawable() != null) {
                            BitmapDrawable image1 = (BitmapDrawable) imgbridegroomfull1.getDrawable();
                            Bitmap ImageCompresser1 = image1.getBitmap();
                            ByteArrayOutputStream ba1 = new ByteArrayOutputStream();
                            ImageCompresser1.compress(Bitmap.CompressFormat.JPEG, 100, ba1);
                            myimage = Base64.encodeToString(ba1.toByteArray(), Base64.DEFAULT);
                        }
                        break;
                    case 5:
                        if (imgbridegroomfull2.getDrawable() != null) {
                            BitmapDrawable image2 = (BitmapDrawable) imgbridegroomfull2.getDrawable();
                            Bitmap ImageCompresser2 = image2.getBitmap();
                            ByteArrayOutputStream ba2 = new ByteArrayOutputStream();
                            ImageCompresser2.compress(Bitmap.CompressFormat.JPEG, 100, ba2);
                            myimage = Base64.encodeToString(ba2.toByteArray(), Base64.DEFAULT);
                        }
                        break;


                }
                object.put("image", myimage);
            } catch (JSONException e) {
                Log.d("trace error", e.getMessage());
            }

            Log.e("trace object", object.toString());
            final JsonObjectRequest request = new JsonObjectRequest(Pageurl, object, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject result) {
                    Log.d("trace result", result.toString());
                    try
                    {
                        if (result.getString("error").equals("no")) {

                        } else {
                            // Toast.makeText(ctx, result.getString("message"), Toast.LENGTH_LONG).show();

                        }

                    } catch (JSONException e) {
                        Log.d("trace error", "upload error" + e.getMessage());
                    }

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError e) {
                    Log.d("trace error", "upload error" + e.getMessage());
                }
            });
            request.setRetryPolicy(new DefaultRetryPolicy(100000, 5, 5));
            AppController.getInstance().addToRequestQueue(request);
            onBackPressed();
        } else {
            Toast.makeText(ctx, "Photos required", Toast.LENGTH_LONG).show();
        }
        hidePDialog();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mExecutorService.shutdown();
        mExecutorService = null;
        imageCompressTask = null;
    }

    public void setupToolbar() {
        toolbar = getSupportActionBar();
        assert toolbar != null;
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (android.R.id.home == item.getItemId()) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
        @Override
        public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {
            Log.d(TAG, "onVerificationCompleted");
        }

        @Override
        public void onVerificationFailed(FirebaseException e) {
            Log.d(TAG, "onVerificationFailed  : " + e.getMessage());
            Toast.makeText(ctx, "OTP invalid", Toast.LENGTH_LONG).show();
        }

        @Override
        public void onCodeSent(String code, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
            super.onCodeSent(code, forceResendingToken);
            CodeSend = code;
            Toast.makeText(ctx, "You will get OTP soon...", Toast.LENGTH_LONG).show();
            Log.d(TAG, "onCodeSent  : " + code);
        }
    };

    public void setData() {
        pDialog = new ProgressDialog(ctx);
        pDialog.setMessage("Please wait...");
        pDialog.setCancelable(false);
        showpDialog();
        imgArray = new ArrayList<>();
        String WebServiceUrl = Common.GetWebServiceUrl() + "person_list.php";
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("pid", bid);
        params.put("rid", Utils.getString(ctx, Constants.USER_ID));
        params.put("gid", String.valueOf(0));
        if (getIntent().getBooleanExtra("isPremium",false)){
            params.put("is_premium", "1");
        }
        Utils.log(TAG, WebServiceUrl.toString());
        client.post(WebServiceUrl, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                Utils.log(TAG, res.toString());
                try {
                    JSONArray response = new JSONArray(res);
                    String error = response.getJSONObject(0).getString("error");
                    if (error.equals("no error") == false) {
                        hidePDialog();
                        Common.showDialog(ctx);
                    } else {
                        int total = response.getJSONObject(1).getInt("total");
                        if (total == 0) {
                            hidePDialog();
                            Toast.makeText(ctx, "No Occupation Found", Toast.LENGTH_LONG).show();
                        } else {
                            int size = response.length();
                            for (int i = 2; i < size; i++) //3
                            {
                                JSONObject object = response.getJSONObject(i);
                                fullname1 = object.getString("name");
                                age1 = object.getString("age");
                                imgname = object.getString("img");
                                photo1 = object.getString("photo1");
                                photo2 = object.getString("photo2");
                                education1 = object.getString("edu");
                                occupation1 = object.getString("occu");
                                income1 = object.getString("ic");
                                height1 = object.getString("ht");
                                weight1 = object.getString("wt");
                                blood1 = object.getString("blood");
                                bdate = object.getString("bdate");
                                degree = object.getString("degree");

                                complexion1 = object.getString("complexion");
                                ras_tithi1 = object.getString("rastithi");
                                religion1 = object.getString("religion");
                                marital1 = object.getString("marital");
                                kulDevta1 = object.getString("kuldaivat");
                                motherTongue1 = object.getString("mothertongue");
                                String updateDate;
                                SimpleDateFormat input = new SimpleDateFormat("yyyy-MM-dd");
                                SimpleDateFormat output = new SimpleDateFormat("dd-MM-yyyy");
                                try {
                                    finaldate = input.parse(bdate);
                                } catch (ParseException e) {
                                    e.printStackTrace();
                                }
                                updateDate = output.format(finaldate);
                                btime = object.getString("btime");

                                bplace = object.getString("bplace");
                                father = object.getString("fname");
                                mother = object.getString("mname");
                                brother = object.getString("bro");
                                sister = object.getString("sis");
                                address1 = object.getString("addr");
                                contact_person = object.getString("contact_person");
                                relation1 = object.getString("relatio");
                                mobile = object.getString("mob");
                                contact_person_number = object.getString("contact_person_number");
                                mobile2 = object.getString("mob2");
                                String mail = object.getString("mail");
                                String gen = object.getString("gen");
                                hobbies1 = object.getString("hb");
                                expect = object.getString("exp");
                                String firstname = object.getString("firstname");
                                String middle = object.getString("middle");
                                String surname = object.getString("surname");
                                String city = object.getString("city");
                                String fatheroccup = object.getString("fatheroccup");
                                String motheroccup = object.getString("motheroccup");
                                String relatives = object.getString("relatives");
                                String nativeplace = object.getString("nativeplace");
                                String contact_person = object.getString("contact_person");
                                String rel_surname = object.getString("rel_surname");
                                String relative_who_knows = object.getString("relative_who_knows");
                                String is_paid = object.getString("is_paid");

                                for (int j = 0; j < complexionList.length; j++) {
                                    if (complexionList[j].equalsIgnoreCase(complexion1)) {
                                        spinnerComplexion.setSelection(j);
                                    }
                                }




                                if (is_paid.equals("0")){
                                    rgPaymentOption.setVisibility(View.VISIBLE);
                                }else{
                                    rgPaymentOption.setVisibility(View.GONE);
                                }


                                drinkingHabits = object.getString("drinking_habits");
                                smokingHabits = object.getString("smoking_habits");
                                diataryHabits = object.getString("diatary_habits");
                                try {
                                    occDetails = object.getString("occDetails");
                                    txtOccDetails.setText(occDetails);
                                }catch (Exception e){
                                    e.printStackTrace();
                                }

                                if (drinkingHabits.equals(getString(R.string.str_yes))){
                                    rbtnDrinkYes.setChecked(true);
                                }else if (drinkingHabits.equals(getString(R.string.str_no))){
                                    rbtnDrinkNo.setChecked(true);
                                }else if (drinkingHabits.equals(getString(R.string.str_occasional))){
                                    rbtnDrinkOccasional.setChecked(true);
                                }

                                if (smokingHabits.equals(getString(R.string.str_yes))){
                                    rbtnSmokeYes.setChecked(true);
                                }else if (smokingHabits.equals(getString(R.string.str_no))){
                                    rbtnSmokeNo.setChecked(true);
                                }else if (smokingHabits.equals(getString(R.string.str_occasional))){
                                    rbtnSmokeOccasional.setChecked(true);
                                }

                                if (diataryHabits.equals(getString(R.string.str_vegetarian))){
                                    rbtnDietaryVeg.setChecked(true);
                                }else if (diataryHabits.equals(getString(R.string.str_non_vegetarian))){
                                    rbtnDietaryNonVeg.setChecked(true);
                                }else if (diataryHabits.equals(getString(R.string.str_occasional_non_vegetarian))){
                                    rbtnDietaryNonVegOccasional.setChecked(true);
                                }else if (diataryHabits.equals(getString(R.string.str_eggetarian))){
                                    rbtnDietaryEggetarian.setChecked(true);
                                }



                                try {
                                    txtfullname.setText(firstname);
                                    txtMiddleName.setText(middle);
                                    txtsurname.setText(surname);
                                    txtcity.setText(city);
                                    txtOtherRelatives.setText(relatives);
                                    txtNative.setText(nativeplace);
                                    txtcontact1.setText(contact_person);
                                    txtcontact2.setText(relative_who_knows);
                                    txtcontactSurname.setText(rel_surname);
                                    txtSpecialization.setText(degree);
                                }catch (Exception e){
                                    e.printStackTrace();
                                }

                                try {
                                    String[] income1Split = income1.split(" ");
                                    txtincomeCurrency.setText(income1Split[0]);
                                    txtincome.setText(income1Split[1]);
                                    /*for (i=0;i<currency_list.length;i++){
                                        if(currency_list[i].equals(income1Split[0])){
//                                            spnCurrency.setSelection(i);

                                        }
                                    }*/
                                   /* for (i=0;i<salary_list.length;i++){
                                        if(salary_list[i].equals(income1Split[1])){
                                            spnSalary.setSelection(i);
                                        }
                                    }*/

                                } catch (Exception e){
                                    txtincome.setText(income1);
                                    e.printStackTrace();
                                }


                                try {
                                    if (!bdate.equals("0000-00-00")) {
                                        tvDate.setText(updateDate);
                                    }
                                    if (!btime.equals("00:00 AM")) {
                                        tvTime.setText(btime);
                                    }
                                    txtdobplace.setText(bplace);
                                    txtfathername.setText(father);
                                    txtmothername.setText(mother);
                                    txtfatherOccupation.setText(fatheroccup);
                                    txtmotherOccupation.setText(motheroccup);
                                    txtbroname.setText(brother);
                                    txtsisname.setText(sister);
                                    txtaddress.setText(address1);
                                    txthobbies.setText(hobbies1);
                                    txtexpectation.setText(expect);
                                    txtcontactNo.setText(contact_person_number);
                                    txtRelation.setText(relation1);
                                    txtmailid.setText(mail);
                                    txtReligion.setText(religion1);
                                    txtMotherTongue.setText(motherTongue1);
                                    txtKulDevta.setText(kulDevta1);

                                    if (gen.equals("0")) {
                                        rdogrpgender.check(R.id.rdofemale);
                                    }
                                    if (gen.equals("1")) {
                                        rdogrpgender.check(R.id.rdomale);
                                    }

                                }catch (Exception e){
                                    e.printStackTrace();
                                }




                                for (int j = 0; j < getResources().getStringArray(R.array.blood).length; j++) {
                                    if (getResources().getStringArray(R.array.blood)[j].equalsIgnoreCase(blood1)) {
                                        spnblood.setSelection(j);
                                    }
                                }

                                for (int j = 0; j < getResources().getStringArray(R.array.height).length; j++) {
                                    if (getResources().getStringArray(R.array.height)[j].equalsIgnoreCase(height1)) {
                                        spnHeight.setSelection(j);
                                    }
                                }

                                for (int j = 0; j < getResources().getStringArray(R.array.weight).length; j++) {
                                    if (getResources().getStringArray(R.array.weight)[j].equalsIgnoreCase(weight1)) {
                                        spnWeight.setSelection(j);
                                    }
                                }

                                for (int j = 0; j < getResources().getStringArray(R.array.age).length; j++) {
                                    if (getResources().getStringArray(R.array.age)[j].equalsIgnoreCase(age1)) {
                                        spinnerAge.setSelection(j);
                                    }
                                }



                                for (int j = 0; j < rashiList.length; j++) {
                                    if (rashiList[j].equalsIgnoreCase(ras_tithi1)) {
                                        spinnerRashi.setSelection(j);
                                    }
                                }

                                for (int j = 0; j < maritialStatusList1.length; j++) {
                                    if (maritialStatusList1[j].equalsIgnoreCase(marital1)) {
                                        spinnerMarital.setSelection(j);
                                    }
                                }

                                for (int j = 0; j < educationList.length; j++) {
                                    if (educationList[j].equalsIgnoreCase(education1)) {
                                        spinnerEducation.setSelection(j);
                                    }
                                }


                                imgArray.add(Common.GetProfileImageUrl() + imgname);
                                imgArray.add(Common.GetProfileImageUrl() + photo1);
                                imgArray.add(Common.GetProfileImageUrl() + photo2);
                                if (!imgname.equals("")) {
                                    Glide.with(ctx).load(Common.GetProfileImageUrl() + imgname).into(imgbridegroom);
                                }
                                if (!photo1.equals("")) {
                                    if (!photo2.equals("img1.png")) {
                                        Glide.with(ctx).load(Common.GetProfileImageUrl() + photo1).into(imgbridegroomfull1);
                                    }
                                }
                                if (!photo2.equals("")) {
                                    if (!photo2.equals("img1.png")) {
                                        Glide.with(ctx).load(Common.GetProfileImageUrl() + photo2).into(imgbridegroomfull2);
                                    }
                                }

                                setOccupation();
                                MemberList = new ArrayList<>();
                                CountryCode = "+" + txtAddmobileCode.getSelectedCountryCode();

                                hidePDialog();
                            }
                            hidePDialog();
                        }
                        hidePDialog();
                    }
                } catch (JSONException e) {
                    hidePDialog();
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                hidePDialog();
                Common.showDialog(ctx);
            }
        });
    }

    public void startPayment() {
        final Activity activity = this;

        final Checkout co = new Checkout();

        try {
            JSONObject options = new JSONObject();
            options.put("name", "" + Utils.getString(ctx, Constants.USER_NAME));
            options.put("description", "Update Bio Data Charge");
            //You can omit the image option to fetch the image from dashboard
            options.put("image", "");
            options.put("currency", "USD");
            options.put("amount", "100");

            JSONObject preFill = new JSONObject();
            preFill.put("email", "" + Utils.getString(ctx, Constants.USER_EMAIL));
            preFill.put("contact", "" + Utils.getString(ctx, Constants.USER_MOBILE));

            options.put("prefill", preFill);

            co.open(activity, options);
        } catch (Exception e) {
            Toast.makeText(activity, "Error in payment: " + e.getMessage(), Toast.LENGTH_SHORT)
                    .show();
            e.printStackTrace();
        }
    }



    public void startPayment(String amount) {
        Checkout.preload(getApplicationContext());
        final Activity activity = this;
        String amount_ = String.valueOf(Integer.parseInt(amount) * 100*75);
        final Checkout co = new Checkout();
        co.setKeyID("rzp_live_rqh0DabOcTj5iZ");
        try {
            JSONObject options = new JSONObject();
            options.put("name", "" + Utils.getString(ctx, Constants.USER_NAME));
            options.put("description", "Update Bio Data Charge");
            //You can omit the image option to fetch the image from dashboard
            options.put("image", "");
            options.put("currency", "INR");
            options.put("amount", amount_);

            JSONObject preFill = new JSONObject();
            preFill.put("email", "" + Utils.getString(ctx, Constants.USER_EMAIL));
            preFill.put("contact", "" + Utils.getString(ctx, Constants.USER_MOBILE));

            options.put("prefill", preFill);

            co.open(activity, options);
        } catch (Exception e) {
            Toast.makeText(activity, "Error in payment: " + e.getMessage(), Toast.LENGTH_SHORT)
                    .show();
            e.printStackTrace();
        }
    }



    /**
     * The name of the function has to be
     * onPaymentSuccess
     * Wrap your code in try catch, as shown, to ensure that this method runs correctly
     */
    @SuppressWarnings("unused")
    @Override
    public void onPaymentSuccess(String razorpayPaymentID) {
        try {
//            Toast.makeText(this, "Payment Successful: " + razorpayPaymentID, Toast.LENGTH_SHORT).show();
            addBiodata(razorpayPaymentID);
        } catch (Exception e) {
            Utils.log(TAG, "Exception in onPaymentSuccess : " + e.getMessage());
        }
    }

    /**
     * The name of the function has to be
     * onPaymentError
     * Wrap your code in try catch, as shown, to ensure that this method runs correctly
     */
    @SuppressWarnings("unused")
    @Override
    public void onPaymentError(int code, String response) {
        try {
            Toast.makeText(this, "Payment failed: " + code + " " + response, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Utils.log(TAG, "Exception in onPaymentError : " + e.getMessage());
        }
    }

}

