package com.suguretaventure.mymarriagegroup.Model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

public class BioData implements Serializable {

    @SerializedName("success")
    public String success;

    @SerializedName("message")
    public String message;

    @SerializedName("totalRequest")
    public String totalRequest;

    @SerializedName("data")
    public ArrayList<Data> detail;

    public class Data implements Serializable {
        @SerializedName("bid")
        public String bid;

        @SerializedName("register_userid")
        public String register_userid;


        /*
        * thi req_id used for pending member list id
        */
        @SerializedName("req_id")
        public String req_id;


        @SerializedName("mobile")
        public String mobile;


        @SerializedName("name")
        public String name;

        @SerializedName("surname")
        public String surname;

        @SerializedName("gender")
        public String gender;

        @SerializedName("education")
        public String education;

        @SerializedName("occupationid")
        public String occupationid;

        @SerializedName("income")
        public String income;

        @SerializedName("height")
        public String height;

        @SerializedName("weight")
        public String weight;

        @SerializedName("blood")
        public String blood;

        @SerializedName("birthdate")
        public String birthdate;

        @SerializedName("birthtime")
        public String birthtime;

        @SerializedName("birthplace")
        public String birthplace;

        @SerializedName("hobbies")
        public String hobbies;

        @SerializedName("expectation")
        public String expectation;

        @SerializedName("photo")
        public String photo;

        @SerializedName("fathername")
        public String fathername;

        @SerializedName("mothername")
        public String mothername;

        @SerializedName("brothers")
        public String brothers;

        @SerializedName("sisters")
        public String sisters;

        @SerializedName("address")
        public String address;

        @SerializedName("contact")
        public String contact;

        @SerializedName("contact2")
        public String contact2;

        @SerializedName("email")
        public String email;

        @SerializedName("datatime")
        public String datatime;

        @SerializedName("saved")
        public String saved;

        @SerializedName("verified")
        public String verified;

        @SerializedName("latitude")
        public String latitude;

        @SerializedName("longitude")
        public String longitude;

        @SerializedName("age")
        public String age;

        @SerializedName("occupation")
        public String occupation;

        @SerializedName("rid_full_name")
        public String rid_full_name;


    }
}
