package com.suguretaventure.mymarriagegroup.adapters;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.suguretaventure.mymarriagegroup.GetTogether;
import com.suguretaventure.mymarriagegroup.Model.Datum;
import com.suguretaventure.mymarriagegroup.PersonDesc;
import com.suguretaventure.mymarriagegroup.R;

import java.util.ArrayList;

public class GetTogetherInterestedAdapter extends RecyclerView.Adapter<GetTogetherInterestedAdapter.MyViewHolder> {
    private String TAG = "GET_TOGETHER_ADAPTER";
    private Context context;
    private LayoutInflater inflater;
    private ArrayList<Datum> arr_adapter;
    private ProgressDialog pDialog;
    private GetTogether activity;

    public GetTogetherInterestedAdapter(Context context, ArrayList<Datum> arr_adapter) {
        this.context = context;
        this.arr_adapter = arr_adapter;
        activity = new GetTogether();
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_gettogether_interested, parent, false);
        return new MyViewHolder(itemView);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int i) {


        holder.tvName.setText(arr_adapter.get(i).getName());
        holder.id.setText(String.valueOf(i+1));

       /* holder.cardGetTO.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                context.startActivity(new Intent(context, PersonDesc.class)
                        .putExtra("pid", arr_adapter.get(i).getRegister_userid()));
            }
        });*/


    }


    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return arr_adapter.size();
    }


    // show process Dialog box
    private void showpDialog() {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }

    // hide process Dialog box
    private void hidePDialog() {
        if (this.pDialog != null) {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }


    class MyViewHolder extends RecyclerView.ViewHolder {

        private TextView tvName,id;
        private CardView cardGetTO;

        MyViewHolder(View view) {
            super(view);
            tvName = view.findViewById(R.id.tvName);
            id = view.findViewById(R.id.id);
            cardGetTO = view.findViewById(R.id.cardGetTO);

        }
    }
}

