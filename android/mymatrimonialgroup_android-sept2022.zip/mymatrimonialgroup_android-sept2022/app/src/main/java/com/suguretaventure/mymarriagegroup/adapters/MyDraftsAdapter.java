package com.suguretaventure.mymarriagegroup.adapters;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ComponentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.suguretaventure.mymarriagegroup.AddBiodata;
import com.suguretaventure.mymarriagegroup.BioReqSentActivity;
import com.suguretaventure.mymarriagegroup.Model.BiodataDec;
import com.suguretaventure.mymarriagegroup.MyDrafts;
import com.suguretaventure.mymarriagegroup.PersonDesc;
import com.suguretaventure.mymarriagegroup.R;
import com.suguretaventure.mymarriagegroup.UpdateBiodata;
import com.suguretaventure.mymarriagegroup.UpdateGroupActivity;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.database.DBHelper;
import com.suguretaventure.mymarriagegroup.getsets.PersonGetSet;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utils;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;

import java.util.ArrayList;

public class MyDraftsAdapter extends RecyclerView.Adapter<MyDraftsAdapter.MyViewHolder> {
    private String TAG = "DRAFT_ADAPTER";
    private Context context;
    private LayoutInflater inflater;
    ArrayList<BiodataDec> arr_adapter_list;
    private String rid, pid, type, faid, fatype;
    private ProgressDialog pDialog;
    private int mnu;
    DBHelper dbHelper;
    String Biodataid;
    String mgid, mgname;

    public MyDraftsAdapter(Context context, ArrayList<BiodataDec> arr_adapter_list) {
        this.context = context;
        this.arr_adapter_list = arr_adapter_list;
       // rid = "" + Utils.getString(context, Constants.USER_ID);
    }

    @NonNull
    @NotNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_draft, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull final MyViewHolder holder, final int i) {
       /* holder.lblpersonname.setText(arr_adapter.get(i).getName());
        holder.lblpersonedu.setText("Education: " + arr_adapter.get(i).getEducation());
        holder.lblpersonocu.setText("Occupation: " + arr_adapter.get(i).getOccupation());
        holder.lblpersonage.setText("Age: " + arr_adapter.get(i).getAge());
*/

        dbHelper = new DBHelper(context);

        holder.lblpersonname.setText(arr_adapter_list.get(i).getName());
        holder.lblpersonedu.setText("Education: " + arr_adapter_list.get(i).getMiddleName());
        holder.lblpersonocu.setText("Occupation: " + arr_adapter_list.get(i).getOccupation());
        holder.lblpersonage.setText("Age: " + arr_adapter_list.get(i).getAge());
        holder.lay_pdesc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               /* context.startActivity(new Intent(context, AddBiodata.class)
                        .putExtra("action", "update")
                );*/

                context.startActivity(new Intent(context, AddBiodata.class).putExtra("from","drafts").putExtra("mgid",arr_adapter_list.get(i).getMg_id())
                        .putExtra(String.valueOf(AddBiodata.ExtraData),arr_adapter_list.get(i)));

              /*  Intent intent = new Intent(context,AddBiodata.class);
                intent.putExtra(ComponentActivity.ExtraData,arr_adapter_list);*/
            }
        });

       /* holder.remove_dr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                removeFavArc(arr_adapter.get(i).getFaid(), 0, i);
            }
        });
*/


        holder.remove_draft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              //  final int userid = Integer.parseInt(Utils.getString(context, Constants.USER_ID));
               /* dbHelper.deleteBiodata();*/
                itemRemoved(i);
            }
        });

       holder.buttonViewOption.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               //creating a popup menu
               PopupMenu popup = new PopupMenu(context, holder.buttonViewOption);
               //inflating menu from xml resource
               popup.inflate(R.menu.menu_drafts_adapter);
               popup.getMenu().findItem(R.id.menu2).setTitle("Delete");
               popup.getMenu().findItem(R.id.menu1).setTitle("Edit");

               popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                   @Override
                   public boolean onMenuItemClick(MenuItem item) {
                       switch (item.getItemId()) {
                           case R.id.menu1:
                               Biodataid = arr_adapter_list.get(i).getBid();
                               context.startActivity(new Intent(context, AddBiodata.class).putExtra("from","drafts").putExtra("mgid",arr_adapter_list.get(i).getMg_id())
                                       .putExtra(String.valueOf(AddBiodata.ExtraData),arr_adapter_list.get(i)));
                               break;


                           case R.id.menu2:
                               //handle menu2 click
                               final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(context);
                               builder.setIcon(R.drawable.ic_remove_blue);
                               builder.setTitle("Delete Bio-Data");
                               builder.setMessage("Do you want to Delete Bio-Data?");

                               builder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                                   @Override
                                   public void onClick(DialogInterface dialog, int which) {
                                       Biodataid = arr_adapter_list.get(i).getBid();
                                       itemRemoved(i);
                                   }
                               });
                               builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                   @Override
                                   public void onClick(DialogInterface dialog, int which) {
                                       dialog.cancel();
                                       dialog.dismiss();
                                   }
                               });
                               builder.show();
                               break;
                       }
                       return false;
                   }
               });
               //displaying the popup
               popup.show();

           }
       });
    }


    public void itemRemoved(int position) {
        DBHelper dbHelper = new DBHelper(context);
//        dbHelper.deleteItem(position);
        dbHelper.deleteBiodata(Integer.valueOf(arr_adapter_list.get(position).getBid()));
        arr_adapter_list.remove(position);
        notifyItemRemoved(position);


    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView lblpersonname, lblpersonedu, lblpersonage, lblpersonocu;
        ImageView imgperson, remove_draft, remove_fav,buttonViewOption;
        LinearLayout lay_pdesc;

        MyViewHolder(View view) {
            super(view);
            lay_pdesc = view.findViewById(R.id.lay_pdesc1);
            lblpersonname = view.findViewById(R.id.lblpersonname1);
            lblpersonedu = view.findViewById(R.id.lblpersonedu1);
            lblpersonage = view.findViewById(R.id.lblpersonage1);
            lblpersonocu = view.findViewById(R.id.lblpersonocu1);
            imgperson = view.findViewById(R.id.imgperson1);
            remove_draft = view.findViewById(R.id.remove_daft);
            remove_fav = view.findViewById(R.id.save_draft);
            buttonViewOption = view.findViewById(R.id.buttonViewOption);



          /*  if (fatype.equals("0"))
                remove_arc.setVisibility(View.GONE);
            else
                remove_fav.setVisibility(View.GONE);*/
        }
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return arr_adapter_list.size();
    }

    // show process Dialog box
    private void showpDialog() {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }

    // hide process Dialog box
    private void hidePDialog() {
        if (this.pDialog != null) {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }

}
