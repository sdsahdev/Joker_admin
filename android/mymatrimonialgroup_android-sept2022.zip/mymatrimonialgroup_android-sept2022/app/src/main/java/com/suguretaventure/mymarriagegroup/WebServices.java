package com.suguretaventure.mymarriagegroup;

import android.content.Context;
import android.os.Build;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;


public class WebServices {
    public static String response = "";

    public static void registerFcm(final String TAG, final Context ctx, String mobile) {
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("imei", "" + Utils.getString(ctx, Constants.IMEI));
        params.put("apiver", "" + Build.VERSION.SDK_INT);
        params.put("device_key", "" + Utils.getString(ctx, Constants.TOKEN));
        params.put("mobile", "" + mobile);
        Utils.log(TAG, Constants.REGISTER_FCM + "?" + params);
        client.post(Constants.REGISTER_FCM, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                String success = "";
                Utils.log(TAG, "FCM_RESPONSE : " + res);
                /*{"success":true,"msg":"Record Updated Sucesfully"}*/
                try {
                    JSONObject response = new JSONObject(res);
                    success = response.getString("success");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (success.equalsIgnoreCase("success")) {
                    Utils.setBoolean(ctx, Constants.TOKEN_REGISTER, true);
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "FCM_ERROR : " + error.getMessage());
            }
        });
    }

    public static ArrayList<String> getMemberList(final String TAG, String g_id, final ArrayList<String> isCorrect) {
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("gid", g_id);
        Utils.log(TAG, Constants.APP_MEMBER_LIST + "?" + params);
        client.post(Constants.APP_MEMBER_LIST, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                response = new String(responseBody);
                Utils.log(TAG, "RESPONSE : " + response);
                isCorrect.add(0, "Success");
                isCorrect.add(1, response);
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "ERROR : " + error.getMessage());
                isCorrect.add(0, "Error");
                isCorrect.add(1, error.getMessage());
            }
        });
        return isCorrect;
    }
}
