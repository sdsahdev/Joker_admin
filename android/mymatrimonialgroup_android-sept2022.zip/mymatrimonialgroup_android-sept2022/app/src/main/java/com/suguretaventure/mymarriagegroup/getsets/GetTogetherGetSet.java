package com.suguretaventure.mymarriagegroup.getsets;

/**
 * Created by ankitpatel on 26/03/19.
 */

public class GetTogetherGetSet {
    String gttitle,gtdetail,gtdatetime,gtvenue,gtid,gtrcount;

    public String getGtdatetime() {
        return gtdatetime;
    }

    public void setGtdatetime(String gtdatetime) {
        this.gtdatetime = gtdatetime;
    }

    public String getGtrcount() {
        return gtrcount;
    }

    public void setGtrcount(String gtrcount) {
        this.gtrcount = gtrcount;
    }

    public String getGtid() {
        return gtid;
    }

    public void setGtid(String gtid) {
        this.gtid = gtid;
    }

    public String getGttitle() {
        return gttitle;
    }

    public void setGttitle(String gttitle) {
        this.gttitle = gttitle;
    }

    public String getGtdetail() {
        return gtdetail;
    }

    public void setGtdetail(String gtdetail) {
        this.gtdetail = gtdetail;
    }

    public String getGtvenue() {
        return gtvenue;
    }

    public void setGtvenue(String gtvenue) {
        this.gtvenue = gtvenue;
    }
}
