package com.suguretaventure.mymarriagegroup.common;

import android.util.Log;

public class MyLog
{
    public static final String TAG = "trace marriage";
    private static final boolean ISDEBUG = true;
    public static final int INFO = 1;
    public static final int DEBUG = 2;
    public static final int WARNING = 3;
    public static final int ERROR = 4;
    public static final int VERBOSE = 5;

    public static void p(String msg,int type)
    {
        if(ISDEBUG==true)
        {
            if(type==DEBUG)
                Log.d(TAG,msg);
            else if(type==WARNING)
                Log.w(TAG,msg);
            else if(type==ERROR)
                Log.e(TAG,msg);
            else if(type==VERBOSE)
                Log.v(TAG,msg);
            else
                Log.i(TAG,msg);
        }
    }
}
