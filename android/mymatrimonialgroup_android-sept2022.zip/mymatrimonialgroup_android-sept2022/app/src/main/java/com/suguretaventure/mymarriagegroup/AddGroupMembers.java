package com.suguretaventure.mymarriagegroup;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.suguretaventure.mymarriagegroup.adapters.RegMemberListAdapter;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.common.NetworkConnetionState;
import com.suguretaventure.mymarriagegroup.getsets.MyGrpRegListGetSet;
import com.wafflecopter.multicontactpicker.ContactResult;
import com.wafflecopter.multicontactpicker.LimitColumn;
import com.wafflecopter.multicontactpicker.MultiContactPicker;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;
/*import mx.com.quiin.contactpicker.Contact;
import mx.com.quiin.contactpicker.SimpleContact;
import mx.com.quiin.contactpicker.adapters.ContactAdapter;
import mx.com.quiin.contactpicker.interfaces.ContactSelectionListener;
import mx.com.quiin.contactpicker.ui.ContactPickerActivity;*/

public class AddGroupMembers extends AppCompatActivity {
    private Context ctx = this;
    private RecyclerView allregusers;
    private ArrayList<MyGrpRegListGetSet> arr_adapter = new ArrayList<>();
    private RegMemberListAdapter myGrpRegAdapter;
    private MyGrpRegListGetSet myGrpRegGetSet;
    private ProgressDialog pDialog;
    private EditText txt_search_rg_member;
    private String mgid;
    ActionBar toolbar;
    private static final int READ_CONTACT_REQUEST = 1;
    private static final int CONTACT_PICKER_REQUEST = 2;
    private List<ContactResult> mContacts = new ArrayList<>();
    private FirebaseAnalytics mFirebaseAnalytics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_group_members);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(getResources().getString(R.string.app_name_title));
        allocateMemory();

        if (new NetworkConnetionState().isNetworkAvailable(ctx)) {
            int permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS);
            if (permissionCheck == PackageManager.PERMISSION_GRANTED) {


                new MultiContactPicker.Builder(AddGroupMembers.this) //Activity/fragment context
                        .hideScrollbar(false) //Optional - default: false
                        .showTrack(true) //Optional - default: true
                        .searchIconColor(Color.WHITE) //Option - default: White
                        .setChoiceMode(MultiContactPicker.CHOICE_MODE_MULTIPLE) //Optional - default: CHOICE_MODE_MULTIPLE
                        .handleColor(ContextCompat.getColor(AddGroupMembers.this, R.color.colorPrimary)) //Optional - default: Azure Blue
                        .bubbleColor(ContextCompat.getColor(AddGroupMembers.this, R.color.colorPrimary)) //Optional - default: Azure Blue
                        .bubbleTextColor(Color.WHITE) //Optional - default: White
                        .setTitleText("Select Contacts") //Optional - default: Select Contacts

                        .setLoadingType(MultiContactPicker.LOAD_ASYNC) //Optional - default LOAD_ASYNC (wait till all loaded vs stream results)
                        .limitToColumn(LimitColumn.PHONE) //Optional - default NONE (Include phone + email, limiting to one can improve loading time)
                        .setActivityAnimations(android.R.anim.fade_in, android.R.anim.fade_out,
                                android.R.anim.fade_in,
                                android.R.anim.fade_out) //Optional - default: No animation overrides
                        .showPickerForResult(CONTACT_PICKER_REQUEST);


                // Intent contactPicker = new Intent(this, ContactPickerActivity.class);
                // startActivityForResult(contactPicker, CONTACT_PICKER_REQUEST);

            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_CONTACTS},
                        READ_CONTACT_REQUEST);
            }
        } else {
            networkAlert();
        }

        txt_search_rg_member.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() != 0)
                    getData(s.toString());
                else
                    getData("");
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void networkAlert() {
        AlertDialog.Builder b1 = new AlertDialog.Builder(ctx);
        b1.setTitle("Network Error");
        b1.setMessage("No internet connection found. Please check your phone settings to turn on the internet.");
        b1.setPositiveButton("Retry", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (new NetworkConnetionState().isNetworkAvailable(ctx)) {
                    getData("");
                } else {
                    networkAlert();
                }
            }
        });
        b1.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        b1.create().show();
    }

    public void allocateMemory() {
        allregusers = findViewById(R.id.allregusers);
        mgid = getIntent().getExtras().getString("mgid");
        txt_search_rg_member = findViewById(R.id.txt_search_rg_member);
    }

    private void getData(final String str) {
        this.pDialog = new ProgressDialog(this);
        this.pDialog.setMessage("Please wait...");
        this.pDialog.setCancelable(false);
        showpDialog();

        String url;
        if (str.equals(""))
            url = Common.GetWebServiceUrl() + "allregulist.php";
        else
            url = Common.GetWebServiceUrl() + "search_reg_users.php";

        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("mgid", mgid);
        params.put("str", str);
        Log.d("PERSON_LIST_URL", url + "?" + params);
        client.post(url, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                Log.d("RESPONSE_PERSON", res);
                try {
                    arr_adapter.clear();
                    JSONArray response = new JSONArray(res);
                    String error = response.getJSONObject(0).getString("error");
                    if (error.equals("no error") == false) {
                        Common.showDialog(ctx, error);
                    } else {
                        Integer total = response.getJSONObject(1).getInt("total");
                        if (total == 0) {
                            allregusers.setVisibility(View.GONE);
                        } else {
                            int co = 1;
                            for (int i = 2; i < response.length(); i++) {
                                JSONObject ob = response.getJSONObject(i);
                                myGrpRegGetSet = new MyGrpRegListGetSet();
                                myGrpRegGetSet.setRid(ob.getString("rid"));
                                myGrpRegGetSet.setFullname(ob.getString("name"));
                                myGrpRegGetSet.setMobile(ob.getString("mob"));
                                myGrpRegGetSet.setPhoto(ob.getString("photo"));
                                arr_adapter.add(myGrpRegGetSet);
                                co++;
                            }
                        }
                        hidePDialog();
                        myGrpRegAdapter = new RegMemberListAdapter(ctx, arr_adapter, mgid);
                        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
                        allregusers.setLayoutManager(mLayoutManager);
                        allregusers.setAdapter(myGrpRegAdapter);
                    }
                    hidePDialog();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

            }
        });
    }

    // show process Dialog box
    private void showpDialog() {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }

    // hide process Dialog box
    private void hidePDialog() {
        if (this.pDialog != null) {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        // startActivity(new Intent(ctx,MyGroupMembers.class)
        //               .putExtra("mgid",mgid));
    }

    public void setupToolbar() {
        toolbar = getSupportActionBar();
        assert toolbar != null;
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (android.R.id.home == item.getItemId()) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    private void setRecyclerView() {
       // ContactAdapter adapter = new ContactAdapter(this, mContacts, this, null, null);
     //   allregusers.setAdapter(adapter);
        allregusers.setItemAnimator(new DefaultItemAnimator());
        allregusers.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));
        allregusers.setLayoutManager(new LinearLayoutManager(this));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case CONTACT_PICKER_REQUEST:
                //contacts were selected

                if (resultCode == RESULT_OK) {
                    if (data != null) {
                        List<ContactResult> results = MultiContactPicker.obtainResult(data);
                        Log.d("MyTag", results.get(0).getDisplayName());

                        if (results != null) {
                            for (ContactResult selectedContact : results) {
                                List<String> list = new ArrayList<>();
                                list.add(selectedContact.getPhoneNumbers() + "|" + selectedContact.getDisplayName());
                                mContacts.add(selectedContact);

                            }
                        }

                        setRecyclerView();
                    }
                } else if (resultCode == RESULT_CANCELED) {
                    System.out.println("User closed the picker without selecting items.");
                }

               /* if (resultCode == RESULT_OK) {
                    if (data != null) {
                        TreeSet<SimpleContact> selectedContacts = (TreeSet<SimpleContact>) data.getSerializableExtra(ContactPickerActivity.CP_SELECTED_CONTACTS);
                        if (selectedContacts != null) {
                            for (SimpleContact selectedContact : selectedContacts) {
                                List<String> list = new ArrayList<>();
                                list.add(selectedContact.getCommunication());
                                mContacts.add(new Contact(selectedContact.getDisplayName(), list));
                            }
                        }
                    }
                    setRecyclerView();
                }*/
                break;
            default:
                super.onActivityResult(requestCode, resultCode, data);
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case READ_CONTACT_REQUEST:
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    launchContactPicker(null);
                }
        }
    }

    public void launchContactPicker(View view) {
        int permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS);
        if (permissionCheck == PackageManager.PERMISSION_GRANTED) {


            new MultiContactPicker.Builder(AddGroupMembers.this) //Activity/fragment context
                    .hideScrollbar(false) //Optional - default: false
                    .showTrack(true) //Optional - default: true
                    .searchIconColor(Color.WHITE) //Option - default: White
                    .setChoiceMode(MultiContactPicker.CHOICE_MODE_MULTIPLE) //Optional - default: CHOICE_MODE_MULTIPLE
                    .handleColor(ContextCompat.getColor(AddGroupMembers.this, R.color.colorPrimary)) //Optional - default: Azure Blue
                    .bubbleColor(ContextCompat.getColor(AddGroupMembers.this, R.color.colorPrimary)) //Optional - default: Azure Blue
                    .bubbleTextColor(Color.WHITE) //Optional - default: White
                    .setTitleText("Select Contacts") //Optional - default: Select Contacts

                    .setLoadingType(MultiContactPicker.LOAD_ASYNC) //Optional - default LOAD_ASYNC (wait till all loaded vs stream results)
                    .limitToColumn(LimitColumn.PHONE) //Optional - default NONE (Include phone + email, limiting to one can improve loading time)
                    .setActivityAnimations(android.R.anim.fade_in, android.R.anim.fade_out,
                            android.R.anim.fade_in,
                            android.R.anim.fade_out) //Optional - default: No animation overrides
                    .showPickerForResult(CONTACT_PICKER_REQUEST);


            // Intent contactPicker = new Intent(this, ContactPickerActivity.class);
            // startActivityForResult(contactPicker, CONTACT_PICKER_REQUEST);
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_CONTACTS},
                    READ_CONTACT_REQUEST);
        }
    }

}
