package com.suguretaventure.mymarriagegroup;

public interface PremiumInterface {
    void showPremiumDialog(int temp_type, boolean flag_my_post, String id);

}
