package com.suguretaventure.mymarriagegroup;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.bumptech.glide.Glide;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.suguretaventure.mymarriagegroup.Model.AddGroupModel;
import com.suguretaventure.mymarriagegroup.imageresize.core.ImageCompressTask;
import com.suguretaventure.mymarriagegroup.imageresize.listeners.IImageCompressTaskListener;
import com.suguretaventure.mymarriagegroup.imageresize.util.Util;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.ExifUtil;
import com.suguretaventure.mymarriagegroup.utils.Utility;
import com.suguretaventure.mymarriagegroup.utils.Utils;
import com.suguretaventure.mymarriagegroup.utils.WebServiceCaller;
import com.yalantis.ucrop.UCrop;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import cz.msebera.android.httpclient.Header;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;

public class ProfileUpdateActivity extends AppCompatActivity {
    private Context context = this;
    private String TAG = "PROFILE_UPDATE_ACTIVITY";
    private EditText etMobile, etfname, etsname, etEmail;
    private ImageView imgAddressId, imgPhotoId, imgSelectAddressId, imgSelectPhotoID;
    private final static int ALL_PERMISSIONS_RESULT = 101;
    private static final int GALLARY = 1;
    private static final int CAMERA = 2;
    private static final int REQUEST_MULTIPLE_PERMISSION = 100;
    private Bitmap image = null;
    private String CameraFileAbsolutePath;
    private ImageCompressTask imageCompressTask;
    private ExecutorService mExecutorService = Executors.newFixedThreadPool(1);
    private int temp = 0;
    private File PhotoId, AddressId;
    private Button btnUpdateProfile;
    String URL = "", URL1 = "", pimage = "", aimage = "";
    private FirebaseAnalytics mFirebaseAnalytics;

    Bundle bundle;

    private  Uri photoUri;

    private IImageCompressTaskListener iImageCompressTaskListener = new IImageCompressTaskListener() {
        @Override
        public void onComplete(List<File> compressed) {
            if (temp == 1) {
                File file = compressed.get(0);
                Glide.with(context).load(file.getAbsolutePath()).into(imgPhotoId);
            } else if (temp == 2) {
                File file1 = compressed.get(0);
                Glide.with(context).load(file1.getAbsolutePath()).into(imgAddressId);
            }
            //UPloadImageToServer();
        }

        @Override
        public void onError(Throwable error) {
            Log.e("trace error", "Error occurred: " + error);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(getResources().getString(R.string.app_name_title));
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        setContentView(R.layout.activity_profile_update);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        /*bundle  = getIntent().getExtras();*/
        allocateMemory();
        getDataFromServer();
        setListener();
    }

    private void getDataFromServer() {
        final ProgressDialog dialog = new ProgressDialog(context);
        dialog.setTitle("Detail");
        dialog.setMessage("Please wait...");
        dialog.setCancelable(false);
        dialog.show();
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();


        params.put("rid", Utils.getString(context, Constants.USER_ID));
        Utils.log(TAG, "GET_PROFILE_URL : " + Constants.APP_GET_PROFILE + "?" + params);
        client.post(Constants.APP_GET_PROFILE, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                Utils.log(TAG, "GET_PROFILE_RESPONSE : " + res);
                JSONArray response = null;
                try {
                    response = new JSONArray(res);

                    for (int i = 0; i < response.length(); i++) {
                        try {
                            JSONObject obj = response.getJSONObject(i);
                            etMobile.setText(obj.getString("mob"));
                            etfname.setText(obj.getString("name"));
                            etsname.setText(obj.getString("sname"));
                            etEmail.setText(obj.getString("email"));
                            URL = obj.getString("url");
                            URL1 = obj.getString("url1");
                            pimage = obj.getString("photo");
                            aimage = obj.getString("addr");
                            if (pimage.equalsIgnoreCase("img1.png")) {
                                Glide.with(context).load(URL1 + aimage)
                                        .into(imgPhotoId);
                            } else {
                                Glide.with(context).load(URL + pimage)
                                        .into(imgPhotoId);
                            }
                            Glide.with(context).load(URL1 + aimage)
                                    .into(imgAddressId);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    dialog.dismiss();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "GET_PROFILE_ERROR : " + error.getMessage());
            }
        });
    }

    private void setListener() {
        imgSelectAddressId.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestPermission(2);
            }
        });

        imgSelectPhotoID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestPermission(1);
            }
        });

        btnUpdateProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (etEmail.getText().length() == 0) {
                    etEmail.setError("Email required");
                } else if (!etEmail.getText().toString().contains("@")) {
                    etEmail.setError("Invalid email");
                } else if (etfname.getText().length() == 0) {
                    etfname.setError("First name required");
                } else if (etsname.getText().length() == 0) {
                    etsname.setError("Surname required");
                } else if (pimage.equals("")) {
//                    etsname.setError("Profile pic required");
                    Toast.makeText(ProfileUpdateActivity.this, "Profile pic required", Toast.LENGTH_SHORT).show();
                } else {
                    sendDataToServer();
                }
            }
        });
    }

    private void sendDataToServer() {
        if (!Utility.isNetworkAvailable(context)) {
            Toast.makeText(context, "Check internet connection...", Toast.LENGTH_LONG).show();
        } else {
            final ProgressDialog progressDialog = new ProgressDialog(context);
            progressDialog.setTitle("Please wait...");
            progressDialog.show();
            progressDialog.setCancelable(false);
            RequestBody fileReqBody, fileReqBody1;
            MultipartBody.Part part, part1;
            if (PhotoId != null) {
                try {
                    Bitmap bitmap1 = BitmapFactory.decodeFile(PhotoId.getPath());
                    bitmap1.compress(Bitmap.CompressFormat.JPEG, 70, new FileOutputStream(PhotoId));
                } catch (Throwable t) {
                    Log.e("ERROR", "Error compressing file." + t.toString());
                    t.printStackTrace();
                }
                // Create a request body with file and image media type
                fileReqBody = RequestBody.create(MediaType.parse("image/*"), PhotoId);
                // Create MultipartBody.Part using file request-body,file name and part name
                part = MultipartBody.Part.createFormData("image", PhotoId.getName(), fileReqBody);
            } else {
                // Create a request body with file and image media type
                fileReqBody = RequestBody.create(MediaType.parse("image/*"), "");
                // Create MultipartBody.Part using file request-body,file name and part name
                part = MultipartBody.Part.createFormData("image", "" + "");
            }
            if (AddressId != null) {
                try {
                    Bitmap bitmap = BitmapFactory.decodeFile(AddressId.getPath());
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 70, new FileOutputStream(AddressId));
                } catch (Throwable t) {
                    Log.e("ERROR", "Error compressing file." + t.toString());
                    t.printStackTrace();
                }
                // Create a request body with file and image media type
                fileReqBody1 = RequestBody.create(MediaType.parse("image/*"), AddressId);
                // Create MultipartBody.Part using file request-body,file name and part name
                part1 = MultipartBody.Part.createFormData("aimage", AddressId.getName(), fileReqBody1);
            } else {
                fileReqBody1 = RequestBody.create(MediaType.parse("image/*"), "");
                // Create MultipartBody.Part using file request-body,file name and part name
                part1 = MultipartBody.Part.createFormData("aimage", "" + "");
            }

            //Create request body with text description and text media type
            RequestBody description1 = RequestBody.create(MediaType.parse("text/plain"), Utils.getString(context, Constants.USER_ID));
            RequestBody description2 = RequestBody.create(MediaType.parse("text/plain"), etfname.getText().toString().trim());
            RequestBody description3 = RequestBody.create(MediaType.parse("text/plain"), etsname.getText().toString().trim());
            RequestBody description4 = RequestBody.create(MediaType.parse("text/plain"), etEmail.getText().toString().trim());//etEmail.getText().toString().trim());
            RequestBody description5 = RequestBody.create(MediaType.parse("text/plain"), pimage);
            RequestBody description6 = RequestBody.create(MediaType.parse("text/plain"), aimage);

            WebServiceCaller.getClient().updateProfileCall(part, part1, description1, description2, description3, description4, description5, description6).enqueue(new Callback<AddGroupModel>() {
                @Override
                public void onResponse(Call<AddGroupModel> call, retrofit2.Response<AddGroupModel> response) {
                    Utils.log(TAG, response.body().toString());
                    if (response.isSuccessful()) {
                        AddGroupModel model = response.body();
                        Utils.setString(context, Constants.USER_DOCUMENT, "1");
                        Utils.setString(context, Constants.USER_PHOTO, model.getPhotoid());
                        Utils.setString(context, Constants.USER_NAME, etfname.getText().toString().trim());
                        Utils.setString(context, Constants.USER_SURNAME, etsname.getText().toString().trim());
                        Utils.setString(context, Constants.USER_EMAIL, etEmail.getText().toString().trim());
                        Toast.makeText(context, response.body().getMsg(), Toast.LENGTH_LONG).show();
                        ProfileUpdateActivity.super.onBackPressed();
                    } else {
                        Toast.makeText(context, "Error api", Toast.LENGTH_LONG).show();
                    }
                    progressDialog.dismiss();
                }

                @Override
                public void onFailure(Call<AddGroupModel> call, Throwable t) {
                    //swipeContainer.setRefreshing(false)
                    //
                    progressDialog.dismiss();
                    Toast.makeText(context, "Server Error " + t.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    void requestPermission(int i) {
        temp = i;
        if (PackageManager.PERMISSION_GRANTED !=
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ||
                PackageManager.PERMISSION_GRANTED != ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)) {
            String[] PermissionList = {Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.CAMERA};
            if (ActivityCompat.shouldShowRequestPermissionRationale
                    (this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ||
                    ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA)) {

                ActivityCompat.requestPermissions(this, PermissionList,
                        REQUEST_MULTIPLE_PERMISSION);
            } else {
                ActivityCompat.requestPermissions(this, PermissionList,
                        REQUEST_MULTIPLE_PERMISSION);
            }
        } else {
            showDialogBox();
        }
    }

    private void showDialogBox() {
        AlertDialog.Builder b1 = new AlertDialog.Builder(context);
        b1.setTitle("Select Photo");
        b1.setIcon(R.mipmap.logo1);
        b1.setMessage("I want to select photo");
        b1.setPositiveButton("Using CAMERA", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                File image = null;
                try {
                    image = Util.CreteFileWithUniqueName(context);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                CameraFileAbsolutePath = image.getAbsolutePath();
                Uri photoURI = FileProvider.getUriForFile(context,
                        BuildConfig.APPLICATION_ID + ".provider", image);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(intent, CAMERA);
            }
        });
        b1.setNegativeButton("using Gallery", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent = new Intent(Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, GALLARY);
            }
        });

        b1.create().show();
    }

    private void allocateMemory() {
        etMobile = findViewById(R.id.etMobile);
        etMobile.setEnabled(false);
        etfname = findViewById(R.id.etfname);
        etsname = findViewById(R.id.etsname);
        etEmail = findViewById(R.id.etEmail);
        imgAddressId = findViewById(R.id.imgAddressId);
        imgPhotoId = findViewById(R.id.imgPhotoId);
        imgSelectAddressId = findViewById(R.id.imgSelectAddressId);
        imgSelectPhotoID = findViewById(R.id.imgSelectPhotoID);
        btnUpdateProfile = findViewById(R.id.btnUpdateProfile);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GALLARY && resultCode == RESULT_OK &&
                data != null) {

            Uri uri = data.getData();
            Cursor cursor = MediaStore.Images.Media.query(getContentResolver(),
                    uri, new String[]{MediaStore.Images.Media.DATA});
            if (cursor != null && cursor.moveToFirst()) {
                switch (temp) {

                    case 1:
                        CameraFileAbsolutePath = cursor.getString(cursor.getColumnIndexOrThrow
                                (MediaStore.Images.Media.DATA));
                        PhotoId = new File(CameraFileAbsolutePath);
                        photoUri = Uri.parse("file:"+CameraFileAbsolutePath);
                        File destimage = null;
                        try {
                            destimage = Util.CreteFileWithUniqueName(this);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        if (photoUri!=null){
                            File file = new File(uri.getPath());
                            UCrop.of(photoUri, Uri.fromFile(destimage))
                                    .withAspectRatio(10f, 10f)
                                    .withMaxResultSize(1024, 1024)
                                    .start(ProfileUpdateActivity.this);
                        }

                        break;
                    case 2:
                        CameraFileAbsolutePath = cursor.getString(cursor.getColumnIndexOrThrow
                                (MediaStore.Images.Media.DATA));
                        AddressId = new File(CameraFileAbsolutePath);
                        photoUri = Uri.parse("file:"+CameraFileAbsolutePath);

                        if (photoUri!=null){
                            File destimage1 = null;
                            try {
                                destimage = Util.CreteFileWithUniqueName(this);
                                UCrop.of(photoUri, Uri.fromFile(destimage))
                                        .start(ProfileUpdateActivity.this);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }

                        }
                        break;
                }

            }


            /*Uri uri = data.getData();
            Cursor cursor = MediaStore.Images.Media.query(getContentResolver(),
                    uri, new String[]{MediaStore.Images.Media.DATA});
            if (cursor != null && cursor.moveToFirst()) {

                CameraFileAbsolutePath = cursor.getString(cursor.getColumnIndexOrThrow
                        (MediaStore.Images.Media.DATA));
                imageCompressTask = new ImageCompressTask(this, CameraFileAbsolutePath,
                        iImageCompressTaskListener);
                mExecutorService.execute(imageCompressTask);
                if (temp == 1) {
                    PhotoId = new File(CameraFileAbsolutePath);
                    Bitmap bmp = BitmapFactory.decodeFile(CameraFileAbsolutePath);
                    imgPhotoId.setRotation(ExifUtil.getCameraPhotoOrientation(CameraFileAbsolutePath));
                    imgPhotoId.setImageBitmap(bmp);
                } else if (temp == 2) {
                    AddressId = new File(CameraFileAbsolutePath);
                    Bitmap bmp = BitmapFactory.decodeFile(CameraFileAbsolutePath);
                    imgAddressId.setRotation(ExifUtil.getCameraPhotoOrientation(CameraFileAbsolutePath));
                    imgAddressId.setImageBitmap(bmp);
                }
            }*/

        } else if (requestCode == CAMERA) {

            switch (temp){

                case 1:
                    photoUri = Uri.parse("file:"+CameraFileAbsolutePath);
                    PhotoId = new File(CameraFileAbsolutePath);
                    if (photoUri!=null){

                        File destimage = null;
                        try {
                            destimage = Util.CreteFileWithUniqueName(this);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        UCrop.of(photoUri, Uri.fromFile(destimage))
                                .withAspectRatio(10f, 10f)
                                .withMaxResultSize(1024, 1024)
                                .start(ProfileUpdateActivity.this);
                    }
                    break;
                case 2:
                    photoUri = Uri.parse("file:"+CameraFileAbsolutePath);
                    AddressId = new File(CameraFileAbsolutePath);


                    if (photoUri!=null){

                        File destimage = null;
                        try {
                            destimage = Util.CreteFileWithUniqueName(this);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        UCrop.of(photoUri, Uri.fromFile(destimage))
                                .start(ProfileUpdateActivity.this);
                    }
                    break;
            }

            /*if (temp == 1) {
                imgPhotoId.setImageBitmap(image);
                PhotoId = new File(CameraFileAbsolutePath);
                if (PhotoId.exists()) {
                    imageCompressTask = new ImageCompressTask(this, CameraFileAbsolutePath,
                            iImageCompressTaskListener);
                    mExecutorService.execute(imageCompressTask);
                    Bitmap bmp = BitmapFactory.decodeFile(CameraFileAbsolutePath);
                    imgPhotoId.setRotation(ExifUtil.getCameraPhotoOrientation(CameraFileAbsolutePath));
                    imgPhotoId.setImageBitmap(bmp);
                    Toast.makeText(context, "Photo Saved", Toast.LENGTH_LONG).show();
                }
            } else {
              //  imgAddressId.setImageBitmap(image);
                AddressId = new File(CameraFileAbsolutePath);
                if (AddressId.exists()) {
                    imageCompressTask = new ImageCompressTask(this, CameraFileAbsolutePath,
                            iImageCompressTaskListener);
                    mExecutorService.execute(imageCompressTask);
                    Bitmap bmp = BitmapFactory.decodeFile(CameraFileAbsolutePath);
                    imgAddressId.setRotation(ExifUtil.getCameraPhotoOrientation(CameraFileAbsolutePath));
                    imgAddressId.setImageBitmap(bmp);
                    Toast.makeText(context, "Photo Saved", Toast.LENGTH_LONG).show();
                }
            }*/
        }else if (resultCode == RESULT_OK && requestCode == UCrop.REQUEST_CROP) {
            final Uri resultUri = UCrop.getOutput(data);

            Log.e("CROP IMAGE PATH", resultUri.toString());

            Bitmap cursor = null;
            try {
                cursor = MediaStore.Images.Media.getBitmap(getContentResolver(),
                        resultUri);
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (temp == 1) {
                imgPhotoId.setImageBitmap(cursor);
            } else if (temp == 2) {
                imgAddressId.setImageBitmap(cursor);
            }

        }
    }
}
