package com.suguretaventure.mymarriagegroup;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.suguretaventure.mymarriagegroup.Model.GetTogetherModel;
import com.suguretaventure.mymarriagegroup.adapters.GetTogetherAdapter;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.common.NetworkConnetionState;
import com.suguretaventure.mymarriagegroup.getsets.GetTogetherGetSet;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;

import cz.msebera.android.httpclient.Header;

public class GetTogether extends AppCompatActivity {
    private String TAG = "GET_TO_GETHER";
    public Context ctx = this;
    public static RecyclerView rcvgt;
    public static ArrayList<GetTogetherGetSet> arr_adapter = new ArrayList<>();
    public static GetTogetherAdapter gtAdapter;
    public static GetTogetherGetSet gtGetSet;
    public static ProgressDialog pDialog;
    ActionBar toolbar;
    RelativeLayout relNoDataMyMarket;
    public static TextView myTitle, lblemptygt;
    public static LinearLayout fabAddGetTogether;
    public static String mgid;
    public static int mYear, mMonth, mDay, mHour, mMinute, mAmPm;
    public static String date = "", time = "";
    public static boolean isEdit = false;
    public static Menu myMenu;

    private TextView txtGenderTitle;
    private ImageView  imgGenderBack;
    private Toolbar toolbar_top;
    private FirebaseAnalytics mFirebaseAnalytics;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_together);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);

//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
//        getSupportActionBar().setTitle(getResources().getString(R.string.app_name_title));

        txtGenderTitle = findViewById(R.id.txtGenderTitle);
        txtGenderTitle.setText(getResources().getString(R.string.app_name_title));
        toolbar_top = findViewById(R.id.toolbar_top);
        imgGenderBack = findViewById(R.id.imgGenderBack);
        setSupportActionBar(toolbar_top);
        imgGenderBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        AdView mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
        allocateMemory();

        lblemptygt.setText(Html.fromHtml(Constants.INVITATION_GET_TO_GATHER));
        if (!isEdit) {
            myTitle.setText("Get-together List");
        } else {
            myTitle.setText("My Get-together List");
        }
//        setupToolbar();
        if (new NetworkConnetionState().isNetworkAvailable(ctx)) {
            getGTList(isEdit, ctx);
            setListener();
//            rcvgt.setVisibility(View.GONE);
        } else {
            networkAlert();
        }
    }

    private void setListener() {
        fabAddGetTogether.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialog();
            }
        });
    }

    private void openDialog() {
        final Dialog alertDialog = new Dialog(ctx);
        alertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LayoutInflater inflater = getLayoutInflater();
        @SuppressLint("InflateParams") View alert = inflater.inflate(R.layout.dailog_get_together, null, false);
        // Setting Dialog Title
        alert.findViewById(R.id.txtGetTogetherTitle);
        alert.findViewById(R.id.txtGetTogethermsg);
        alert.findViewById(R.id.btnGetTogetherCancel);
        alert.findViewById(R.id.btnGetTogetherRegister);
        alert.findViewById(R.id.tvDate);
        alert.findViewById(R.id.tvTime);
        alert.findViewById(R.id.linDate1);
        alert.findViewById(R.id.linTime1);
        alertDialog.setContentView(alert);

        final EditText Title = alertDialog.findViewById(R.id.txtGetTogetherTitle);
        final EditText Detail = alertDialog.findViewById(R.id.txtGetTogethermsg);
        final TextView btnGetTogetherCancel = alertDialog.findViewById(R.id.btnGetTogetherCancel);
        final TextView btnGetTogetherRegister = alertDialog.findViewById(R.id.btnGetTogetherRegister);
        final TextView tvDate = alertDialog.findViewById(R.id.tvDate);
        final TextView tvTime = alertDialog.findViewById(R.id.tvTime);
        final LinearLayout linDate = alertDialog.findViewById(R.id.linDate1);
        final LinearLayout linTime = alertDialog.findViewById(R.id.linTime1);
        linDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(ctx, AlertDialog.THEME_HOLO_LIGHT, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {
                        monthOfYear = monthOfYear + 1;
                        String mnth = (monthOfYear < 10) ? "0" + monthOfYear : "" + monthOfYear;
                        String day = (dayOfMonth < 10) ? "0" + dayOfMonth : "" + dayOfMonth;
                        tvDate.setText(day + "-" + mnth + "-" + year);
                        date = year + "-" + mnth + "-" + day;
                    }
                }, mYear, mMonth, mDay);
                datePickerDialog.show();
            }
        });
        linTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                mHour = c.get(Calendar.HOUR);
                mMinute = c.get(Calendar.MINUTE);
                mAmPm = c.get(Calendar.AM_PM);
                TimePickerDialog timePickerDialog = new TimePickerDialog(ctx,
                        new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay,
                                                  int minute) {
                                String am_pm = (hourOfDay < 12) ? "AM" : "PM";
                                tvTime.setText(hourOfDay + ":" + minute + " " + am_pm);
                                time = hourOfDay + ":" + minute;
                            }
                        }, mHour, mMinute, false);
                timePickerDialog.show();
            }
        });


        btnGetTogetherRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Title.getText().length() == 0) {
                    Title.setError("Title required");
                } else if (Detail.getText().length() == 0) {
                    Detail.setError("Detail required");
                } else if (tvTime.getText().toString().length() == 0 && tvDate.getText().toString().length() == 0) {
                    Toast.makeText(ctx, "Time of birth and Date of birth required", Toast.LENGTH_SHORT).show();
                } else if (tvTime.getText().toString().length() == 0) {
                    Toast.makeText(ctx, "Time of birth required", Toast.LENGTH_SHORT).show();
                } else if (tvDate.getText().toString().length() == 0) {
                    Toast.makeText(ctx, "Date of birth required", Toast.LENGTH_SHORT).show();
                } else {
                    String tempDate = mYear + "-" + mMonth + "-" + mDay + " " + mHour + ":" + mMinute;
                    getTogetherRegister(alertDialog, Title, Detail, tempDate);
                }
            }
        });

        btnGetTogetherCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                alertDialog.cancel();
            }
        });
        // Showing Alert Message
        final Window window = alertDialog.getWindow();
        assert window != null;
        alertDialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        window.setBackgroundDrawableResource(R.color.colorTransparent);
        window.setGravity(Gravity.CENTER);
        alertDialog.show();
    }

    private void networkAlert() {
        AlertDialog.Builder b1 = new AlertDialog.Builder(ctx);
        b1.setTitle("Network Error");
        b1.setMessage("No internet connection found. Please check your phone settings to turn on the internet.");
        b1.setPositiveButton("Retry", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (new NetworkConnetionState().isNetworkAvailable(ctx)) {
                    getGTList(isEdit, ctx);
//                    rcvgt.setVisibility(View.GONE);
                } else {
                    networkAlert();
                }
            }
        });
        b1.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        b1.create().show();
    }

    public void getGTList(final boolean isEditable, final Context ctx) {
        final ProgressDialog dialog = new ProgressDialog(ctx);
        dialog.setTitle("Please wait...");
        dialog.show();
        dialog.setCancelable(false);
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("gid", mgid);
        Utils.log(TAG, "ADD-GETTOGETHER-URL : " + Constants.APP_LIST_GET_TOGETHER + "?" + params);
        client.post(Constants.APP_LIST_GET_TOGETHER, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                Utils.log(TAG, "ADD-GETTOGETHER-RESPONSE : " + new String(responseBody));
                String success = "", msg = "";
                try {
                    JSONObject object = new JSONObject(new String(responseBody));
                    success = object.getString("success");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (success.equals("")) {
                    try {
                        ArrayList<GetTogetherModel> CategoryList = new ArrayList<>();
                        JSONArray response = new JSONArray(new String(responseBody));
                        int size = response.length();
                        JSONObject current;
                        GetTogetherModel cat;
                        String id, gid, title, gdatetime, venue, register_userid;
                        Utils.log(TAG, "ADD-GETTOGETHER-COUNT" + size);
                        if (size > 0) {
                            rcvgt.setVisibility(View.VISIBLE);
                            lblemptygt.setVisibility(View.GONE);
                            relNoDataMyMarket.setVisibility(View.GONE);
                            for (int i = 0; i < size; i++) {
                                current = response.getJSONObject(i);
                                id = current.getString("id");
                                gid = current.getString("gid");
                                title = current.getString("title");
                                gdatetime = current.getString("gdatetime");
                                venue = current.getString("venue");
                                register_userid = current.getString("register_userid");
                                cat = new GetTogetherModel(id, gid, title, gdatetime, venue, register_userid);
                                CategoryList.add(cat);
                            }

                            rcvgt.setLayoutManager(new LinearLayoutManager(ctx));
                            GetTogetherAdapter adapter = new GetTogetherAdapter(ctx, CategoryList, isEditable);
                            rcvgt.setAdapter(adapter);

                        } else {
                            rcvgt.setVisibility(View.GONE);
                            lblemptygt.setVisibility(View.VISIBLE);
                            relNoDataMyMarket.setVisibility(View.VISIBLE);
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                } else {
                    Utils.log(TAG, "ADD-GETTOGETHER-NO-DATA-FOUND");
                    rcvgt.setVisibility(View.GONE);
                    lblemptygt.setVisibility(View.VISIBLE);
                    relNoDataMyMarket.setVisibility(View.VISIBLE);
                }
                dialog.dismiss();
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "ADD-GETTOGETHER-ERROR : " + error.getMessage());
                dialog.dismiss();
            }
        });
    }

    public void allocateMemory() {
        fabAddGetTogether = findViewById(R.id.fabAddGetTogether);
        myTitle = findViewById(R.id.myTitle);
        rcvgt = findViewById(R.id.rcvgt);
        lblemptygt = findViewById(R.id.lblemptygt);
        relNoDataMyMarket = findViewById(R.id.relNoDataMyMarket);
        mgid = getIntent().getStringExtra("mgid");
    }

    // show process Dialog box
    private void showpDialog() {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }

    // hide process Dialog box
    private void hidePDialog() {
        if (this.pDialog != null) {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }

    public void setupToolbar() {
        toolbar = getSupportActionBar();
        assert toolbar != null;
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setDisplayHomeAsUpEnabled(true);
        toolbar.setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (android.R.id.home == item.getItemId()) {
            if (isEdit) {
                isEdit = false;
                myTitle.setText("Get-together List");
                getGTList(isEdit, ctx);
                myMenu.findItem(R.id.MyGettogether).setVisible(true);
            } else {
                finish();
            }
        } else if (R.id.MyGettogether == item.getItemId()) {
            myMenu.findItem(R.id.MyGettogether).setVisible(true);
            //  myMenu.findItem(R.id.MyGettogether).setTitle("Get-Together List");
            if (myTitle.getText().toString().equalsIgnoreCase("My Get-together List")) {
                myMenu.findItem(R.id.MyGettogether).setTitle("My Get-together List");
                isEdit = false;
                getGTList(isEdit, ctx);
                myTitle.setText("Get-together List");

            } else {
                myMenu.findItem(R.id.MyGettogether).setTitle("Get-together List");

                isEdit = true;
                getGTList(isEdit, ctx);
                myTitle.setText("My Get-together List");
            }

          /*  isEdit = true;
            getGTList(isEdit, ctx);
            myTitle.setText("My Get-Together List");*/
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        this.myMenu = menu;
        getMenuInflater().inflate(R.menu.menu_get_together, menu);
        return true;
    }

    private void getTogetherRegister(final Dialog alertDialog, final EditText title, final EditText detail, final String tempDate) {
        final ProgressDialog dialog = new ProgressDialog(ctx);
        dialog.setTitle("Please wait...");
        dialog.show();
        dialog.setCancelable(false);
        final String url = Common.GetWebServiceUrl() + "add-gettogether.php";
        Utils.log(TAG, "MY_GET_TOGHER_RESPONSE : " + url + "?gid=" + mgid + "&title=" + title.getText().toString() + "&datetime=" + date + " " + time + "&venue=" + detail.getText().toString() + "&regid=" + Utils.getString(ctx, Constants.USER_ID));
//        String url = Common.GetWebServiceUrl() + "gt_register.php";

        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("gid", mgid);
        params.put("title", title.getText().toString());
        params.put("datetime", date + " " + time);
        params.put("venue", detail.getText().toString());
        params.put("regid", Utils.getString(ctx, Constants.USER_ID));
        client.post(url, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                Utils.log(TAG, "MY_GET_TOGHER_RESPONSE : " + res);
                try {
                    JSONArray response = new JSONArray(res);
                    String error = response.getJSONObject(0).getString("error");
                    if (error.equals("no error") == false) {
                        Common.showDialog(ctx, error);
                    } else {
                        String success = response.getJSONObject(1).getString("success");
                        String message = response.getJSONObject(2).getString("message");
                        Toast.makeText(ctx, message, Toast.LENGTH_LONG).show();
                        if (success.equals("yes") == true) {
                            finish();
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                getGTList(isEdit, ctx);
                dialog.dismiss();
                alertDialog.dismiss();
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Log.d("ERROR_RESPONSE", error.getMessage());
                AlertDialog.Builder b1 = new AlertDialog.Builder(ctx);
                b1.setMessage("Please Select Group to add GetTogether");
                b1.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        startActivity(new Intent(GetTogether.this, Dashboard.class));
                    }
                });
                b1.create().show();
                hidePDialog();
                dialog.dismiss();
            }
        });
    }


    public void openDialogRegister(final String gtid) {
        final Dialog alertDialog = new Dialog(GetTogether.this);
        alertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LayoutInflater inflater = getLayoutInflater();
        @SuppressLint("InflateParams") View alert = inflater.inflate(R.layout.dialog_gt_interested, null, false);
        // Setting Dialog Title

        alert.findViewById(R.id.btnGetTogetherRegister1);
        alert.findViewById(R.id.btnGetTogetherCancel1);
        alert.findViewById(R.id.txtName);
        alertDialog.setContentView(alert);

        final EditText txtName = alertDialog.findViewById(R.id.txtName);
        final TextView btnGetTogetherCancel1 = alertDialog.findViewById(R.id.btnGetTogetherCancel1);
        final TextView btnGetTogetherRegister1 = alertDialog.findViewById(R.id.btnGetTogetherRegister1);

        txtName.setText(Utils.getString(ctx, Constants.USER_NAME) + " " + Utils.getString(ctx, Constants.USER_SURNAME));

        btnGetTogetherRegister1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (txtName.getText().length() == 0) {
                    txtName.setError("Name required");
                } else {
                    getTogetherRegister(alertDialog, txtName.getText().toString(),gtid);
                }
            }
        });

        btnGetTogetherCancel1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                alertDialog.cancel();
            }
        });

        final Window window = alertDialog.getWindow();
        assert window != null;
        alertDialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        window.setBackgroundDrawableResource(R.color.colorTransparent);
        window.setGravity(Gravity.CENTER);
        alertDialog.show();
    }

    public void getTogetherRegister(final Dialog alertDialog, final String name,final String gtid) {
        final ProgressDialog dialog = new ProgressDialog(ctx);
        dialog.setTitle("Please wait...");
        dialog.show();
        dialog.setCancelable(false);
        final String url = Common.GetWebServiceUrl() + "gt_register.php";


        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("gtid", gtid);
        params.put("detail", name);
        params.put("regid", Utils.getString(ctx, Constants.USER_ID));

        client.post(url, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody) {

                String res = new String(responseBody);
                Utils.log(TAG, "MY_GET_TOGHER_RESPONSE : " + res);
                try {
                    JSONArray response = new JSONArray(res);
                    String error = response.getJSONObject(0).getString("error");
                    if (error.equals("no error") == false) {
                        Common.showDialog(ctx, error);
                    } else {
                        String success = response.getJSONObject(1).getString("success");
                        String message = response.getJSONObject(2).getString("message");
                        Toast.makeText(ctx, "Registered successfully", Toast.LENGTH_LONG).show();

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                dialog.dismiss();
                alertDialog.dismiss();

            }

            @Override
            public void onFailure(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody, Throwable error) {

                Log.d("ERROR_RESPONSE", error.getMessage());
                AlertDialog.Builder b1 = new AlertDialog.Builder(ctx);
                b1.setMessage("Please Select Group to add GetTogether");
                b1.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        startActivity(new Intent(GetTogether.this, Dashboard.class));
                    }
                });
                b1.create().show();
                hidePDialog();
                dialog.dismiss();

            }
        });

    }


    @Override
    public void onBackPressed() {
        if (isEdit) {
            isEdit = false;
            myTitle.setText("Get-together List");
            getGTList(isEdit, ctx);
            myMenu.findItem(R.id.MyGettogether).setVisible(true);
        } else {
            super.onBackPressed();
        }
    }
}
