package com.suguretaventure.mymarriagegroup.adapters;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.suguretaventure.mymarriagegroup.InvitationReceived;
import com.suguretaventure.mymarriagegroup.PersonDesc;
import com.suguretaventure.mymarriagegroup.ProfileUpdateActivity;
import com.suguretaventure.mymarriagegroup.R;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.getsets.PersonGetSet;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utils;

import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;

public class InvitationAdapter extends RecyclerView.Adapter<InvitationAdapter.MyViewHolder> {
    private Context context;
    private String status;
    private ArrayList<PersonGetSet> arr_adapter;
    private LayoutInflater inflater;
    private String groupId = "";

    public InvitationAdapter(Context context, ArrayList<PersonGetSet> arr_adapter, String status, String groupId) {
        this.context = context;
        this.arr_adapter = arr_adapter;
        this.status = status;
        this.groupId = groupId;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_invitation, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int i) {
        if (status.equals("sent")) {
            holder.btnReqAccept.setVisibility(View.GONE);
            holder.btnReqReject.setVisibility(View.GONE);
        } else if (arr_adapter.get(i).getStatus().equals("1")) {
            holder.btnReqAccept.setVisibility(View.GONE);
            holder.btnReqReject.setVisibility(View.GONE);
        } else if (arr_adapter.get(i).getStatus().equals("0")) {
            holder.btnReqAccept.setVisibility(View.VISIBLE);
            holder.btnReqReject.setVisibility(View.VISIBLE);
        }

        if (status.equals("sent")) {
            holder.invitation_from.setText("From: "+ arr_adapter.get(i).getTo_name());
            holder.invitation_to.setText("To: "+ arr_adapter.get(i).getFrom_name());
            holder.lblStatus.setVisibility(View.GONE);
            holder.btnViewBio.setText("View Biodata: " + arr_adapter.get(i).getFrom_name());
           // holder.btnViewBio.setVisibility(View.GONE);
           /* holder.rlParent.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, PersonDesc.class);
                    intent.putExtra("pid", arr_adapter.get(i).getTo_bio_id());
                    intent.putExtra("request", "-");
                    context.startActivity(intent);
                }
            });*/
           /* if (arr_adapter.get(i).getStatus().equals("1")) {

            } else {
                holder.btnViewBio.setVisibility(View.GONE);
            }*/
        } else {
            holder.invitation_from.setText("From: "+ arr_adapter.get(i).getFrom_name());
            holder.invitation_to.setText("To: "+ arr_adapter.get(i).getTo_name());
            holder.lblStatus.setVisibility(View.VISIBLE);
            holder.btnViewBio.setText("View Biodata: " + arr_adapter.get(i).getFrom_name());

            if (arr_adapter.get(i).getStatus().equals("1")) {
                holder.lblStatus.setText("Accepted");
                holder.lblStatus.setTextColor(Color.parseColor("#FFFFFF"));
                holder.lblStatus.setBackground(context.getDrawable(R.drawable.rounded_button_background_red));
            } else {
                holder.lblStatus.setVisibility(View.GONE);
            }

//            if(arr_adapter.get(i).getTo_bio_id().equals("0")){
//                holder.btnViewBio.setVisibility(View.GONE);
//            }else{
//                holder.btnViewBio.setVisibility(View.VISIBLE);
//            }
        }
        setClick(holder.btnViewBio, i);

        Glide.with(context)
                .load(Common.GetRegUserIDImageUrl() + arr_adapter.get(i).getImage())
                .apply(RequestOptions.circleCropTransform())
                .into(holder.imgReqBio);


         holder.lblPhone.setText(arr_adapter.get(i).getPhone());
 /*        holder.invitation_from.setText("From: "+ arr_adapter.get(i).getFrom_name());
         holder.invitation_to.setText("To: "+ arr_adapter.get(i).getTo_name());*/

        String phoneNumber = arr_adapter.get(i).getPhone();
       String strLastFourDi = phoneNumber.length() >= 4 ? phoneNumber.substring(phoneNumber.length() - 4): "";
        Log.d("TAG", "MyViewHolder: "+strLastFourDi);
        holder.lblPhone.setText("******"+strLastFourDi );

        holder.lblReqNameSur.setText(arr_adapter.get(i).getName());



        holder.imgReqBio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                View dialogLayout = inflater.inflate(R.layout.personimage_dialog, null);
                ImageView imgtabledesc = (ImageView) dialogLayout.findViewById(R.id.imgtabledesc);
                builder.setView(dialogLayout);
                Glide.with(context)
                        .load(Common.GetRegUserIDImageUrl() + arr_adapter.get(i).getImage())
                        .into(imgtabledesc);
                Dialog dialog = builder.create();
                dialog.setCancelable(true);
                dialog.show();
            }
        });

        holder.btnReqAccept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("TAG", "onClick1: " +v);
                String status = "1";
                String toast = "Request Accepted";
                String id = arr_adapter.get(i).getInv_id();
                Log.d("TAG", "onClick: "+status + id +toast);
                setAction(status, toast, id, i);
            }
        });

        holder.btnReqReject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which){
                            case DialogInterface.BUTTON_POSITIVE:
                                String status = "0";
                                String id = arr_adapter.get(i).getId();
                                String toast = "Request Rejected";
                                setAction(status, toast, id, i);
                                break;

                            case DialogInterface.BUTTON_NEGATIVE:
                                //No button clicked
                                break;
                        }
                    }
                };

                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setMessage("Do you want to reject invitation?").setPositiveButton("Yes", dialogClickListener)
                        .setNegativeButton("No", dialogClickListener).show();

            }
        });

        holder.ivRemoveRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(context);
                builder.setTitle("Alert!");
                builder.setMessage("Are you sure you want to remove?");
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String status = "0";
                        String id = arr_adapter.get(i).getId();
                        String toast = "Removed successfully.";
                        setAction(status, toast, id, i);
                    }
                });
                builder.show();


            }
        });
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView lblReqNameSur, lblPhone, btnReqAccept, btnReqReject, btnViewBio, lblStatus,invitation_from,invitation_to;
        public ImageView imgReqBio,ivRemoveRequest;
        public RelativeLayout rlParent;

        public MyViewHolder(View view) {
            super(view);
            imgReqBio = view.findViewById(R.id.imgReqBio);
            lblReqNameSur = view.findViewById(R.id.lblReqNameSur);
            lblPhone = view.findViewById(R.id.lblPhone);
            btnReqAccept = view.findViewById(R.id.btnReqAccept);
            btnReqReject = view.findViewById(R.id.btnReqReject);
            lblStatus = view.findViewById(R.id.lblStatus);
            btnViewBio = view.findViewById(R.id.btnViewBio);
            rlParent = view.findViewById(R.id.rlParent);
            ivRemoveRequest = view.findViewById(R.id.ivRemoveRequest);
            invitation_from = view.findViewById(R.id.invitation_from);
            invitation_to = view.findViewById(R.id.invitation_to);

            String phoneNumber = lblPhone.getText().toString();
            String strLastFourDi = phoneNumber.length() >= 4 ? phoneNumber.substring(phoneNumber.length() - 4): "";
            Log.d("TAG", "MyViewHolder: "+strLastFourDi);
        }

    }

    @Override
    public int getItemCount() {
        return arr_adapter.size();
    }

    public void setAction(final String status, final String toast, String id, final int i) {
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("rid", Utils.getString(context, Constants.USER_ID));
        params.put("status", status);
        params.put("inv_id", id);
        Log.d("TAG", "setAction: "+id);
        Utils.log("INVITATION_ACTION", "REQ_SEND_BIO-DATA_URL : " + Constants.BIO_REQ_ACCEPT + "?" + params);
        client.post(Constants.BIO_REQ_ACCEPT, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                Utils.log("INVITATION_ACTION", "REQ_SEND_BIO-DATA_RESPONSE : " + response);
                Log.d("TAG", "rec: "+response);
                Toast.makeText(context, toast, Toast.LENGTH_SHORT).show();
                if (status.equals("0")) {
                    arr_adapter.remove(i);
                    notifyItemRemoved(i);
                    notifyItemRangeChanged(i, arr_adapter.size());
                } else {
                    if (groupId != null) {
                        if (!groupId.equalsIgnoreCase("")) {
                            context.startActivity(new Intent(context, InvitationReceived.class)
                                    .putExtra("from", "dashboard_invitation_receive_group")
                                    .putExtra("groupId", groupId));
                        } else {
                            context.startActivity(new Intent(context, InvitationReceived.class)
                                    .putExtra("from", "dashboard_invitation_receive"));
                        }
                    } else {
                        context.startActivity(new Intent(context, InvitationReceived.class)
                                .putExtra("from", "dashboard_invitation_receive"));
                    }

                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Toast.makeText(context, "Something Went Wrong", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void setClick(TextView btnViewBio, final int i) {
        btnViewBio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, PersonDesc.class);
                if(status.equals("sent")){
                  //  intent.putExtra("pid", arr_adapter.get(i).getFrom_bio_id());
                    intent.putExtra("pid", arr_adapter.get(i).getTo_bio_id());

                }else {
                  //  intent.putExtra("pid", arr_adapter.get(i).getTo_bio_id());
                    intent.putExtra("pid", arr_adapter.get(i).getFrom_bio_id());
                    Log.d("TAG", "pid: "+arr_adapter.get(i).getFrom_bio_id());

                }
                intent.putExtra("request", "-");
                context.startActivity(intent);
            }
        });
    }
}
