package com.suguretaventure.mymarriagegroup;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.FirebaseException;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.rilixtech.widget.countrycodepicker.Country;
import com.rilixtech.widget.countrycodepicker.CountryCodePicker;
import com.suguretaventure.mymarriagegroup.Model.PreForgotResponse;
import com.suguretaventure.mymarriagegroup.Model.RegisterModel;
import com.suguretaventure.mymarriagegroup.common.Common;
import com.suguretaventure.mymarriagegroup.common.NetworkConnetionState;
import com.suguretaventure.mymarriagegroup.imageresize.util.Util;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Prefs;
import com.suguretaventure.mymarriagegroup.utils.Utility;
import com.suguretaventure.mymarriagegroup.utils.Utils;
import com.suguretaventure.mymarriagegroup.utils.WebServiceCaller;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.TimeUnit;

import cz.msebera.android.httpclient.Header;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class Login extends AppCompatActivity {
    NetworkConnetionState connection;
    private Context ctx = this;
    private TextView btnlogin, btnregister;
    private TextView btnforgetpwd, btnfeedback, btnwork;
    private RelativeLayout lay_mkt;
    private TextView llHowAppWork;
    private String email, password, surname, name;
    private EditText txtemail, txtpassword;
    private ProgressDialog pDialog;
    private ImageView imgClear;
    private EditText txtfgtemail;
    private EditText txtfgtmobno;
    private TextView btnsendpwd, btncancel, lblemptygt;
    private TextInputLayout tilLogin;
    private String pwdemail;
    private String pwdmobno;
    private String isCheck;
    private String CountryCode = "";
    private FirebaseAuth auth;
    private String CodeSend;
    private String TAG = "LOGIN_ACTIVITY";
    public static EditText etOTPRegister;
    private LinearLayout lay_mkt_login;
    public int counter = 60;
    public EditText txtmobileno;
    private boolean isLogin = false;
    private boolean isForgot = false;
    boolean isRegistered = false;
    Dialog dialog;
    private String forgotMobile = "", forgotId = "";
    private FirebaseAnalytics mFirebaseAnalytics;

    PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
        @Override
        public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {
            Log.d(TAG, "onVerificationCompleted");
            Toast.makeText(ctx, "Your mobile number has been successfully verified.", Toast.LENGTH_LONG).show();

            if (!isRegistered && !isForgot) {
                startActivity(new Intent(ctx, Register.class).putExtra("from", "register")
                        .putExtra("MY_MOBILE", txtmobileno.getText().toString()).putExtra("MY_CODE", CountryCode));
                finish();
            } else if (isLogin) {
                Utils.setLogin(ctx);
                startActivity(new Intent(ctx, Dashboard.class));
                finish();
            } else if (isForgot) {
                isForgot = false;
                Utils.setLogin(ctx);
                Prefs.setValue(Login.this, Constants.LOGIN, "1");
                Utils.setString(ctx, Constants.USER_ID, forgotId + "");
                startActivity(new Intent(ctx, Register.class).putExtra("from", "login")
                        .putExtra("MY_MOBILE", txtmobileno.getText().toString()).putExtra("MY_CODE", CountryCode).putExtra("email", email).putExtra("name", name).putExtra("surname", surname));
                finish();
            } else {
                Utils.setLogin(ctx);
                startActivity(new Intent(ctx, Dashboard.class));
                finish();
            }
        }

        @Override
        public void onVerificationFailed(FirebaseException e) {
            Log.d(TAG, "onVerificationFailed  : " + e.getMessage());
            Utils.setString(ctx, Constants.USER_ID, "");
            Toast.makeText(ctx, "OTP invalid", Toast.LENGTH_LONG).show();
        }

        @Override
        public void onCodeSent(String code, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
            super.onCodeSent(code, forceResendingToken);
            CodeSend = code;
            Toast.makeText(ctx, "You will get OTP soon...", Toast.LENGTH_LONG).show();
            Log.d(TAG, "onCodeSent  : " + code);
        }
    };

    private ProgressDialog pwdpDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        /*getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);*/
        allocateMemory();
        setListeners();

        lblemptygt.setText(Constants.INVITATION_LOGIN);

    }

    private void allocateMemory() {
        connection = new NetworkConnetionState();
        txtemail = findViewById(R.id.txtemail);
        txtpassword = findViewById(R.id.txtpassword);
        btnlogin = findViewById(R.id.btnlogin);
        btnregister = findViewById(R.id.btnregister);
        btnforgetpwd = findViewById(R.id.btnforgetpwd);
        lay_mkt = findViewById(R.id.lay_mkt);
        btnfeedback = findViewById(R.id.btnfeedback);
        btnwork = findViewById(R.id.btnwork);
        imgClear = findViewById(R.id.imgClear);
        tilLogin = findViewById(R.id.pwdInputLayout);
        lay_mkt_login = findViewById(R.id.temp);
        lblemptygt = findViewById(R.id.lblemptygt);
        llHowAppWork = findViewById(R.id.llHowAppWork);

        AdView adViewHome = findViewById(R.id.adViewHome);
        AdRequest adRequest = new AdRequest.Builder().build();

        adViewHome.loadAd(adRequest);
        adViewHome.setVisibility(View.VISIBLE);

    }

    private boolean ValidateInput() {
        boolean isvalid = true;
        email = txtemail.getText().toString().trim().toLowerCase();
        password = txtpassword.getText().toString().trim();
        /*if (email.matches(Common.emailPattern)) {
            isvalid = false;
            txtemail.setError("Invalid email");
        }*/
        if (password.length() == 0) {
            isvalid = false;
            txtemail.setFocusable(false);
            txtpassword.setError("Password required");
            // Toast.makeText(Login.this, "Mobile and Password required", Toast.LENGTH_LONG).show();
            txtpassword.setFocusable(true);
        }
        return isvalid;
    }

    public void setListeners() {
        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                email = txtemail.getText().toString().trim().toLowerCase();
                password = txtpassword.getText().toString().trim();
                if (txtemail.getText().toString().equalsIgnoreCase("") && txtpassword.getText().toString().equalsIgnoreCase("")) {
//                    Toast.makeText(ctx, "Mobile number & Password required", Toast.LENGTH_LONG).show();
                    txtpassword.setError("Password required");
                    txtemail.setError("Mobile number required");
                } else if (txtemail.getText().toString().length() < 9) {
                    txtemail.setError("Mobile number required");
                } else if (txtpassword.getText().toString().length() == 0) {
                    txtpassword.setError("Password required");
                } else /*if (ValidateInput())*/ {
                    if (NetworkConnetionState.isNetworkAvailable(ctx)) {
                        loginToApp();
//                        openRegisterDialog(true);
                    } else {
                        Toast.makeText(ctx, "No internet connection found. Please check your phone settings to turn on the internet.", Toast.LENGTH_LONG).show();
                    }
                }
//                Intent intent = new Intent(Login.this,MyProfile.class);
//                startActivity(intent);
            }
        });
        txtemail.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if (s.length() > 0) {
                    imgClear.setVisibility(View.VISIBLE);
                } else {
                    imgClear.setVisibility(View.GONE);
                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 0) {
                    imgClear.setVisibility(View.VISIBLE);
                } else {
                    imgClear.setVisibility(View.GONE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() > 0) {
                    imgClear.setVisibility(View.VISIBLE);
                } else {
                    imgClear.setVisibility(View.GONE);
                }
            }
        });

        txtpassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if (s.length() > 0) {
                    tilLogin.setPasswordVisibilityToggleEnabled(true);
                } else {
                    tilLogin.setPasswordVisibilityToggleEnabled(false);
                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 0) {
                    tilLogin.setPasswordVisibilityToggleEnabled(true);
                } else {
                    tilLogin.setPasswordVisibilityToggleEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() > 0) {
                    tilLogin.setPasswordVisibilityToggleEnabled(true);
                } else {
                    tilLogin.setPasswordVisibilityToggleEnabled(false);
                }
            }
        });

        imgClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtemail.setText("");
                imgClear.setVisibility(View.GONE);
            }
        });
        lay_mkt_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ctx, MarketActivity.class));
            }
        });

        btnregister.setText(Util.getUnderlinedText(getResources().getString(R.string.register)));
        btnregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openRegisterDialog(false);
            }
        });

        btnfeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ctx, Feedback.class));
            }
        });

        btnforgetpwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //startActivity(new Intent(ctx,ForgetPassword.class));
                final Dialog alertDialog = new Dialog(ctx);
                alertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                alertDialog.setContentView(R.layout.dailog_password);
                // Setting Dialog Title
                txtfgtmobno = alertDialog.findViewById(R.id.txtmobileno);
                btnsendpwd = alertDialog.findViewById(R.id.btnsendpwd);
                btncancel = alertDialog.findViewById(R.id.btncancel);
                final CountryCodePicker txtmobileCode = alertDialog.findViewById(R.id.txtmobileCode);
                CountryCode = "+" + txtmobileCode.getSelectedCountryCode();

                btnsendpwd.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (txtfgtmobno.getText().toString().length() >= 10) {
                            if (NetworkConnetionState.isNetworkAvailable(ctx)) {
                                forgotMobile = txtfgtmobno.getText().toString();
                                getDetailApi(alertDialog);
//                                    sendEmail(alertDialog);
                            } else {
                                Toast.makeText(ctx, "No internet connection found. Please check your phone settings to turn on the internet.", Toast.LENGTH_LONG).show();
                            }
                        } else {
                            txtfgtmobno.setError("Invalid mobile");
                        }
                    }
                });

                btncancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        alertDialog.cancel();
                    }
                });
                // Showing Alert Message
                final Window window = alertDialog.getWindow();
                assert window != null;
                alertDialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                window.setBackgroundDrawableResource(R.color.colorTransparent);
                window.setGravity(Gravity.CENTER);
                alertDialog.show();
            }
        });

      /*  btnforgetpwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                //startActivity(new Intent(ctx,ForgetPassword.class));
                final Dialog alertDialog = new Dialog(ctx);
                alertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                alertDialog.setContentView(R.layout.dailog_password);
                // Setting Dialog Title
                txtfgtmobno = alertDialog.findViewById(R.id.txtmobileno);
                btnsendpwd = alertDialog.findViewById(R.id.btnsendpwd);
                btncancel = alertDialog.findViewById(R.id.btncancel);
                final CountryCodePicker txtmobileCode = alertDialog.findViewById(R.id.txtmobileCode);
                CountryCode = "+" + txtmobileCode.getSelectedCountryCode();

                btnsendpwd.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                            if (txtfgtmobno.getText().toString().length()>=10) {
                                if (NetworkConnetionState.isNetworkAvailable(ctx)) {
                                    forgotMobile=txtfgtmobno.getText().toString();
                                    getDetailApi(alertDialog);
//                                    sendEmail(alertDialog);
                                } else {
                                    Toast.makeText(ctx, "No internet connection found. Please check your phone settings to turn on the internet.", Toast.LENGTH_LONG).show();
                                }
                            } else {
                            txtfgtmobno.setError("Invalid mobile");
                        }
                    }
                });

                btncancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        alertDialog.cancel();
                    }
                });
                // Showing Alert Message
                final Window window = alertDialog.getWindow();
                assert window != null;
                alertDialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                window.setBackgroundDrawableResource(R.color.colorTransparent);
                window.setGravity(Gravity.CENTER);
                alertDialog.show();
            }
        });*/

        lay_mkt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ctx, MarketActivity.class));
//                Toast.makeText(ctx, "Please Login to check this", Toast.LENGTH_LONG).show();
            }
        });

        btnwork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ctx, HowWorks.class));
            }
        });
        llHowAppWork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ctx, HowWorks.class));
            }
        });


    }

    private void openSelectionDialogForForget(String email) {
        {
            //startActivity(new Intent(ctx,ForgetPassword.class));
            final Dialog alertDialog = new Dialog(ctx);
            alertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            alertDialog.setContentView(R.layout.dialog_select_forget_layout);
            // Setting Dialog Title
            final CheckBox mobileCb = alertDialog.findViewById(R.id.mobile_cb);
            final CheckBox emailCb = alertDialog.findViewById(R.id.email_cb);
            btncancel = alertDialog.findViewById(R.id.btncancel);
            TextView btnsendpwd = alertDialog.findViewById(R.id.btnsendpwd);
            mobileCb.setText("OTP On : " + forgotMobile);
            if (email.equals("")) {
                emailCb.setText("Email id :   -  ");
            } else {
                emailCb.setText("Email id : " + email);

            }


            mobileCb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked) {
                        emailCb.setChecked(false);
                        isCheck = "Mobile";
                    } else {
                        isCheck = "";
                    }
                }
            });

            emailCb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked) {
                        mobileCb.setChecked(false);
                        isCheck = "Email";
                    } else {
                        isCheck = "";
                    }
                }
            });

            btnsendpwd.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (isCheck.equals("")) {
                        Toast.makeText(Login.this, "Please select one option", Toast.LENGTH_SHORT).show();
                    } else {
                        if (isCheck.equals("Mobile")) {
                            openForgetOtpDialog(forgotMobile);
                            alertDialog.dismiss();
//                                openRegisterDialog(false);
                        } else {
                            sendEmail(alertDialog);
                        }
                    }
                       /* if (pwdValidateInput()) {
                            if (NetworkConnetionState.isNetworkAvailable(ctx)) {
                                getDetailApi(alertDialog);
                                sendEmail(alertDialog);
                            } else {
                                Toast.makeText(ctx, "No internet connection found. Please check your phone settings to turn on the internet.", Toast.LENGTH_LONG).show();
                            }
                        }*/

                }
            });

            btncancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    alertDialog.cancel();
                }
            });
            // Showing Alert Message
            final Window window = alertDialog.getWindow();
            assert window != null;
            alertDialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            window.setBackgroundDrawableResource(R.color.colorTransparent);
            window.setGravity(Gravity.CENTER);
            alertDialog.show();
        }
    }

    private void getDetailApi(final Dialog alertDialog) {
        pDialog = new ProgressDialog(ctx);
        pDialog.setMessage("Please wait...");
        pDialog.setCancelable(false);
        showpDialog();

        WebServiceCaller.getClient().getPreForgotCall(forgotMobile).enqueue(new Callback<PreForgotResponse>() {
            @Override
            public void onResponse(Call<PreForgotResponse> call, Response<PreForgotResponse> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(ctx, response.body().getMsg(), Toast.LENGTH_LONG).show();
                    if (response.body().isSuccess()) {
                        forgotId = response.body().getRegid();
                        email = response.body().getEmail();
                        name = response.body().getFirstname();
                        surname = response.body().getSurname();
                        openSelectionDialogForForget(email);
                        alertDialog.dismiss();
                    }
                    hidePDialog();
                }
            }

            @Override
            public void onFailure(Call<PreForgotResponse> call, Throwable t) {
                hidePDialog();
                Common.showforgotDialog(ctx);
            }
        });
 /*       String WebServiceUrl = Common.GetWebServiceUrl() + "preforgotpassword.php";
        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        RequestParams params = new RequestParams();
        params.put("mobile", forgotMobile);
        // params.put("mobileno",pwdmobno);
        client.post(Constants.PRE_FORGOT_API, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                Utils.log("Pre_Forget_Response", res);
                try {
                    JSONArray response = new JSONArray(res);
                    String error = response.getJSONObject(0).getString("error");
                    if (!error.equals("no error")) {
                        hidePDialog();
                        Common.showDialog(ctx, error);
                    } else {
                        //no error
                        boolean success = response.getJSONObject(1).getBoolean("success");
                        String message = response.getJSONObject(2).getString("message");
                        Toast.makeText(ctx, message, Toast.LENGTH_LONG).show();
                        if (success) {
                            openSelectionDialogForForget();
                            alertDialog.dismiss();
                        }
                        hidePDialog();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                hidePDialog();
                Common.showDialog(ctx);
            }
        });*/
    }


    public boolean pwdValidateInput() {
        boolean isvalid = true;
        pwdemail = txtfgtemail.getText().toString().trim().toLowerCase();
        pwdmobno = txtfgtmobno.getText().toString().trim();
        if (pwdemail.length() == 0) {
            isvalid = false;
            txtfgtemail.setError("Email required");
        }/*else if(pwdmobno.length() == 0){
            isvalid = false;
            txtfgtmobno.setError("Password required");
        }*/
        return isvalid;
    }

    private void openForgetOtpDialog(String forgotMobile) {
        dialog = new Dialog(ctx);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LayoutInflater inflater = getLayoutInflater();
        @SuppressLint("InflateParams") View alert = inflater.inflate(R.layout.layout_mobile_verify, null, false);
        alert.findViewById(R.id.LinMobile);
        alert.findViewById(R.id.LinOTP);
        alert.findViewById(R.id.btnRegisterLogin);
        alert.findViewById(R.id.txtmobileno);
        alert.findViewById(R.id.etOTPRegister);
        alert.findViewById(R.id.txtmobileCode);
        alert.findViewById(R.id.tvChangeMobile);
        alert.findViewById(R.id.tvMobileNumber);
        alert.findViewById(R.id.tvResendOTP);
        alert.findViewById(R.id.lblregisterwithus);
        alert.findViewById(R.id.btnRegisterClose);
        dialog.setContentView(alert);

        final TextView tvChangeMobile = dialog.findViewById(R.id.tvChangeMobile);
        final TextView lblregisterwithus = dialog.findViewById(R.id.lblregisterwithus);
        lblregisterwithus.setText("Provide OTP");

        final TextView tvResendOTP = dialog.findViewById(R.id.tvResendOTP);
        final TextView tvMobileNumber = dialog.findViewById(R.id.tvMobileNumber);
        final CountryCodePicker txtmobileCode = dialog.findViewById(R.id.txtmobileCode);
        txtmobileno = dialog.findViewById(R.id.txtmobileno);
        txtmobileno.setText(forgotMobile);
        final LinearLayout LinMobile = dialog.findViewById(R.id.LinMobile);
        LinMobile.setVisibility(View.GONE);
        final LinearLayout LinOTP = dialog.findViewById(R.id.LinOTP);
        LinOTP.setVisibility(View.VISIBLE);
        final TextView btnRegisterLogin = dialog.findViewById(R.id.btnRegisterLogin);
        final TextView btnRegisterClose = dialog.findViewById(R.id.btnRegisterClose);
        etOTPRegister = dialog.findViewById(R.id.etOTPRegister);
        //OtpReader.bind(Login.this, "50360011");
        auth = FirebaseAuth.getInstance();
        CountryCode = "+" + txtmobileCode.getSelectedCountryCode();
        btnRegisterLogin.setText("Submit OTP");
        tvMobileNumber.setText(CountryCode + " " + forgotMobile);
        isForgot = true;
        callSendVerificationCall(txtmobileno, tvResendOTP);

        txtmobileCode.setOnCountryChangeListener(new CountryCodePicker.OnCountryChangeListener() {
            @Override
            public void onCountrySelected(Country selectedCountry) {
                CountryCode = "+" + selectedCountry.getPhoneCode();
            }
        });
        tvChangeMobile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LinMobile.setVisibility(View.VISIBLE);
                LinOTP.setVisibility(View.GONE);
                lblregisterwithus.setText("Verify your mobile number");
                btnRegisterLogin.setText("Request OTP");
                dialog.setCancelable(true);
            }
        });
        tvResendOTP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                counter = 60;
                if (tvResendOTP.isEnabled()) {
                    tvResendOTP.setEnabled(true);
                    callSendVerificationCall(txtmobileno, tvResendOTP);
                }
            }
        });
        btnRegisterClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });


        btnRegisterLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (etOTPRegister.getText().toString().length() == 6) {
                    PhoneAuthCredential credential = PhoneAuthProvider.getCredential(CodeSend, etOTPRegister.getText().toString());
                    signInWithPhoneAuthCredential(credential, etOTPRegister.getText().toString(), dialog, CountryCode, txtmobileno);
                } else {
                    Toast.makeText(Login.this, "OTP require", Toast.LENGTH_LONG).show();
                }
                dialog.show();

            }
        });
        dialog.setContentView(alert);
        final Window window = dialog.getWindow();
        assert window != null;
        dialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        window.setBackgroundDrawableResource(R.color.colorTransparent);
        window.setGravity(Gravity.CENTER);
        if (isLogin) {
            LinMobile.setVisibility(View.GONE);
            LinOTP.setVisibility(View.VISIBLE);
            checkMobile(txtemail, LinMobile, LinOTP, btnRegisterLogin, dialog, tvMobileNumber, tvResendOTP, lblregisterwithus, isLogin);
          /*  Intent intent = new Intent(Login.this,MyProfile.class);
            intent.putExtra("flagDetail", false);
            startActivity(intent);*/
        } else {
            if (dialog != null)
                dialog.show();
        }
       /* Intent intent = new Intent(Login.this,MyProfile.class);
        intent.putExtra("flagDetail", false);
        startActivity(intent);*/
    }


    private void openRegisterDialog(final boolean isLogin) {

        this.isLogin = isLogin;
        dialog = new Dialog(ctx);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LayoutInflater inflater = getLayoutInflater();
        @SuppressLint("InflateParams") View alert = inflater.inflate(R.layout.layout_mobile_verify, null, false);
        alert.findViewById(R.id.LinMobile);
        alert.findViewById(R.id.LinOTP);
        alert.findViewById(R.id.btnRegisterLogin);
        alert.findViewById(R.id.txtmobileno);
        alert.findViewById(R.id.etOTPRegister);
        alert.findViewById(R.id.txtmobileCode);
        alert.findViewById(R.id.tvChangeMobile);
        alert.findViewById(R.id.tvMobileNumber);
        alert.findViewById(R.id.tvResendOTP);
        alert.findViewById(R.id.lblregisterwithus);
        alert.findViewById(R.id.btnRegisterClose);
        dialog.setContentView(alert);

        final TextView tvChangeMobile = dialog.findViewById(R.id.tvChangeMobile);
        final TextView lblregisterwithus = dialog.findViewById(R.id.lblregisterwithus);
        final TextView tvResendOTP = dialog.findViewById(R.id.tvResendOTP);
        final TextView tvMobileNumber = dialog.findViewById(R.id.tvMobileNumber);
        final CountryCodePicker txtmobileCode = dialog.findViewById(R.id.txtmobileCode);
        txtmobileno = dialog.findViewById(R.id.txtmobileno);
        final LinearLayout LinMobile = dialog.findViewById(R.id.LinMobile);
        final LinearLayout LinOTP = dialog.findViewById(R.id.LinOTP);
        final TextView btnRegisterLogin = dialog.findViewById(R.id.btnRegisterLogin);
        final TextView btnRegisterClose = dialog.findViewById(R.id.btnRegisterClose);
        etOTPRegister = dialog.findViewById(R.id.etOTPRegister);
        //OtpReader.bind(Login.this, "50360011");
        auth = FirebaseAuth.getInstance();
        CountryCode = "+" + txtmobileCode.getSelectedCountryCode();
        txtmobileCode.setOnCountryChangeListener(new CountryCodePicker.OnCountryChangeListener() {
            @Override
            public void onCountrySelected(Country selectedCountry) {
                CountryCode = "+" + selectedCountry.getPhoneCode();
            }
        });
        tvChangeMobile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LinMobile.setVisibility(View.VISIBLE);
                LinOTP.setVisibility(View.GONE);
                lblregisterwithus.setText("Verify your mobile number");
                btnRegisterLogin.setText("Request OTP");
                dialog.setCancelable(true);
            }
        });
        tvResendOTP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                counter = 60;
                if (tvResendOTP.isEnabled()) {
                    tvResendOTP.setEnabled(true);
                    if (isLogin)
                        checkMobile(txtemail, LinMobile, LinOTP, btnRegisterLogin, dialog, tvMobileNumber, tvResendOTP, lblregisterwithus, isLogin);
                    else
                        checkMobile(txtmobileno, LinMobile, LinOTP, btnRegisterLogin, dialog, tvMobileNumber, tvResendOTP, lblregisterwithus, isLogin);
                }
            }
        });
        btnRegisterClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });


        btnRegisterLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (btnRegisterLogin.getText().toString().toLowerCase().equalsIgnoreCase("Request OTP")) {
                    if (txtmobileno.getText().toString().length() < 9) {
                        txtmobileno.setError("Mobile number required");
                    } else {
                        counter = 60;
                        checkMobile(txtmobileno, LinMobile, LinOTP, btnRegisterLogin, dialog, tvMobileNumber, tvResendOTP, lblregisterwithus, isLogin);
                    }
                } else {
                    if (etOTPRegister.getText().toString().length() == 6) {
                        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(CodeSend, etOTPRegister.getText().toString());
                        signInWithPhoneAuthCredential(credential, etOTPRegister.getText().toString(), dialog, CountryCode, txtmobileno);
                    } else {
                        Toast.makeText(Login.this, "OTP require", Toast.LENGTH_LONG).show();
                    }
                    dialog.show();
                }
            }
        });
        dialog.setContentView(alert);
        final Window window = dialog.getWindow();
        assert window != null;
        dialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        window.setBackgroundDrawableResource(R.color.colorTransparent);
        window.setGravity(Gravity.CENTER);
        if (isLogin) {
            LinMobile.setVisibility(View.GONE);
            LinOTP.setVisibility(View.VISIBLE);
            checkMobile(txtemail, LinMobile, LinOTP, btnRegisterLogin, dialog, tvMobileNumber, tvResendOTP, lblregisterwithus, isLogin);
          /*  Intent intent = new Intent(Login.this,MyProfile.class);
            intent.putExtra("flagDetail", false);
            startActivity(intent);*/
        } else {
            if (dialog != null)
                dialog.show();
        }
       /* Intent intent = new Intent(Login.this,MyProfile.class);
        intent.putExtra("flagDetail", false);
        startActivity(intent);*/
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dialog != null)
            dialog.dismiss();
    }

    public void loginToApp() {

        if (!Utility.isNetworkAvailable(Login.this)) {
           /* Snackbar.make(txtemail, "Internet connection is not available", Snackbar.LENGTH_INDEFINITE).setAction("RETRY", new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    loginToApp();
                }
            }).setActionTextColor(getResources().getColor(R.color.colorPrimary)).show();*/
        } else {
            final ProgressDialog progressDialog = new ProgressDialog(Login.this);
            progressDialog.setTitle("Please wait...");
            progressDialog.show();
            progressDialog.setCancelable(false);

            WebServiceCaller.getClient().getlogin(email, password).enqueue(new Callback<RegisterModel>() {
                @Override
                public void onResponse(Call<RegisterModel> call, retrofit2.Response<RegisterModel> response) {
                    if (response.isSuccessful()) {
                        String res = new String(String.valueOf(response));
                        Utils.log(TAG, "RESPONSE  : " + res);
                        RegisterModel registerModel;
                        registerModel = response.body();
                        if (registerModel.getSuccess()) {
                            Prefs.setObject(Login.this, Constants.LOGINDATA, registerModel);
                            Prefs.setValue(Login.this, Constants.LOGIN, "1");
                            String id = registerModel.getRegid() + "";
                            Utils.setLogin(ctx);
                            Utils.setString(ctx, Constants.USER_ID, id);
                            Utils.setString(ctx, Constants.USER_NAME, registerModel.getFirstname());
                            Utils.setString(ctx, Constants.USER_SURNAME, registerModel.getSurname());
                            Utils.setString(ctx, Constants.USER_EMAIL, registerModel.getEmail());
                            Utils.setString(ctx, Constants.USER_MOBILE, registerModel.getMobile());
                            Utils.setString(ctx, Constants.USER_DOCUMENT, registerModel.getActive());
                            Utils.setString(ctx, Constants.USER_PHOTO, registerModel.getPhotoid());
                            Utils.setString(ctx, Constants.USER_IS_VIP, registerModel.getIs_vip_member());
                            Utils.setString(ctx, Constants.USER_IS_FIRST_PROFILE_UPLOADED, registerModel.getIs_premium_profile_added());
                            Utils.setBoolean(ctx, Constants.USER_PROFILE_UPDATED, registerModel.isProfileUpdated());
                            Utils.log(TAG, registerModel.getPhotoid());
                            //WebServices.registerFcm(TAG, ctx, registerModel.getMobile());
                            if (registerModel.isProfileUpdated()) {
                                startActivity(new Intent(ctx, Dashboard.class));
                            } else {
                                startActivity(new Intent(ctx, Register.class)
                                        .putExtra("from", "login").putExtra("MY_MOBILE", registerModel.getMobile()).putExtra("MY_CODE", registerModel.getMobileCode()).putExtra("email", registerModel.getEmail()).putExtra("name", registerModel.getFirstname()).putExtra("surname", registerModel.getSurname()));
                            }
                            finish();
                        } else {
                            Toast.makeText(Login.this, registerModel.getMsg(), Toast.LENGTH_LONG).show();
                        }
                    }
                    progressDialog.dismiss();
                }

                @Override
                public void onFailure(Call<RegisterModel> call, Throwable t) {
                    //swipeContainer.setRefreshing(false)
                    //
                    Log.d("Error_Message", t.getMessage());
                    progressDialog.dismiss();
                    Toast.makeText(Login.this, "Server Error  :   " + t.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }

    }

    // show process Dialog box
    private void showpDialog() {
        if (!this.pDialog.isShowing())
            this.pDialog.show();
    }

    // hide process Dialog box
    private void hidePDialog() {
        if (this.pDialog != null) {
            this.pDialog.dismiss();
            this.pDialog = null;
        }
    }

    private void sendEmail(final Dialog dialog) {
        pDialog = new ProgressDialog(ctx);
        pDialog.setMessage("Please wait...");
        pDialog.setCancelable(false);
        showpDialog();

        String WebServiceUrl = Common.GetWebServiceUrl() + "forgotpassword.php";
        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        RequestParams params = new RequestParams();
        params.put("email", email);
        // params.put("mobileno",pwdmobno);
        client.post(WebServiceUrl, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String res = new String(responseBody);
                Utils.log("Login_Response", res);
                try {
                    JSONArray response = new JSONArray(res);
                    String error = response.getJSONObject(0).getString("error");
                    if (!error.equals("no error")) {
                        hidePDialog();
                        Common.showDialog(ctx, error);
                    } else {
                        //no error
                        String success = response.getJSONObject(1).getString("success");
                        String message = response.getJSONObject(2).getString("message");
                        Toast.makeText(ctx, message, Toast.LENGTH_LONG).show();
                        if (success.equals("yes")) {
                            dialog.dismiss();
                        }
                        hidePDialog();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                hidePDialog();
                Common.showforgotDialog(ctx);
            }
        });
    }

    private void checkMobile(final EditText mobile, final LinearLayout LinMobile, final LinearLayout LinOTP, final TextView btnRegisterLogin, final Dialog dialog,
                             final TextView tvMobileNumber, final TextView tvResendOTP, final TextView lblregisterwithus, final boolean isLogin) {
        if (!Utility.isNetworkAvailable(this)) {
            /*Snackbar.make(txtpwd, "Internet connection is not available", Snackbar.LENGTH_INDEFINITE).setAction("RETRY", new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    submitRegistrationDetails();
                }
            }).setActionTextColor(getResources().getColor(R.color.colorPrimary)).show();*/
        } else {
            final ProgressDialog progressDialog = new ProgressDialog(ctx);
            progressDialog.setTitle("Verifying mobile number...");
            progressDialog.show();
            progressDialog.setCancelable(false);

            AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
            RequestParams params = new RequestParams();
            params.put("mobile", mobile.getText().toString());
            Log.d("params", mobile.getText().toString());
//            client.post(Constants.APP_CHECK_MOBILE, params, new AsyncHttpResponseHandler() {
            client.get(Constants.APP_LOGIN_NEW, params, new AsyncHttpResponseHandler() {
                @Override
                public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                    String response = new String(responseBody);
                    Log.d("RESPONSE_CHECHNUMBER", response);

                    String MESSAGE = "";
                    String regid = "";
                    try {
                        JSONObject res = new JSONObject(response);
                        isRegistered = res.getBoolean("success");
                        MESSAGE = res.getString("msg");
                        regid = res.getString("regid");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    progressDialog.dismiss();

                    if ((isRegistered && isLogin) || (!isRegistered && !isLogin) || ((isRegistered && !isLogin))) {
                        Utils.setString(ctx, Constants.USER_ID, regid);
                        callSendVerificationCall(mobile, tvResendOTP);
                        dialog.setCancelable(false);
                        LinMobile.setVisibility(View.GONE);
                        LinOTP.setVisibility(View.VISIBLE);
                        lblregisterwithus.setText("Provide OTP");
                        btnRegisterLogin.setText("Submit OTP");
                        tvMobileNumber.setText(CountryCode + " " + mobile.getText().toString());
                        dialog.show();
                    } else if ((!isRegistered && isLogin)) {
                        mobile.setError("" + MESSAGE);
                    }

                }

                @Override
                public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                    Utils.log(TAG, error.getMessage());
                    progressDialog.dismiss();
                }
            });
        }
    }

    private void callSendVerificationCall(TextView mobile, final TextView tvResendOTP) {
        sendVerificationCode(CountryCode, mobile.getText().toString());
        new CountDownTimer(60000, 1000) {
            public void onTick(long millisUntilFinished) {
                tvResendOTP.setClickable(false);
                tvResendOTP.setText("Resend OTP within " + counter + " seconds.");
                if (counter > 0) {
                    counter--;
                } else if (counter == 0) {
                    tvResendOTP.setClickable(true);
                }
            }

            public void onFinish() {
                tvResendOTP.setClickable(true);
                tvResendOTP.setText("Resend OTP?");
            }
        }.start();
    }

    private void sendVerificationCode(String countryCode, String mobile) {

//        PhoneAuthProvider.getInstance().verifyPhoneNumber(
//                countryCode + "" + mobile,        // Phone number to verify
//                60,                 // Timeout duration
//                TimeUnit.SECONDS,   // Unit of timeout
//                this,               // Activity (for callback binding)
//                mCallbacks);        // OnVerificationStateChangedCallbacks


        PhoneAuthOptions options = PhoneAuthOptions.newBuilder(FirebaseAuth.getInstance())
                .setPhoneNumber(countryCode + "" + mobile)       // Phone number to verify
                .setTimeout(60L, TimeUnit.SECONDS) // Timeout and unit
                .setActivity(this)                 // Activity (for callback binding)
                .setCallbacks(mCallbacks)          // OnVerificationStateChangedCallbacks
                .build();
        PhoneAuthProvider.verifyPhoneNumber(options);
    }

    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential, final String mobile, final Dialog dialog, final String countryCode, final EditText txtmobileno) {
        auth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d(TAG, "signInWithCredential:success");
                            /*sendDataToServer();*/
                            Toast.makeText(ctx, "Your mobile number has been successfully verified.", Toast.LENGTH_LONG).show();
                            if (isForgot) {
                                isForgot = false;
                                Prefs.setValue(Login.this, Constants.LOGIN, "1");
                                Utils.setLogin(ctx);
                                Utils.setString(ctx, Constants.USER_ID, forgotId + "");
                                Log.d(TAG, "signInWithCredential:success");
                                startActivity(new Intent(ctx, Register.class).putExtra("from", "login")
                                        .putExtra("MY_MOBILE", txtmobileno.getText().toString()).putExtra("MY_CODE", CountryCode).putExtra("email", email).putExtra("name", name).putExtra("surname", surname));
                            } else {
                                Utils.setLogin(ctx);
                                startActivity(new Intent(ctx, Register.class)
                                        .putExtra("from", "register").putExtra("MY_MOBILE", txtmobileno.getText().toString()).putExtra("MY_CODE", countryCode));
                            }
                            finish();
                        } else {
                            // Sign in failed, display a message and update the UI
                            Log.w(TAG, "signInWithCredential:failure", task.getException());
                            dialog.setCancelable(true);
                            if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {
                                // The verification code entered was invalid
                                Toast.makeText(ctx, "The verification code entered was invalid", Toast.LENGTH_LONG).show();
                            }

                        }
                    }
                });
    }

/*
    @Override
    public void otpReceived(String messageText) {
        Utils.log(TAG, messageText);
        */
/*if (etOTPRegister != null) {
            etOTPRegister = findViewById(R.id.etOTPRegister);
            etOTPRegister.setText(messageText.substring(0, 6));
        }*//*

    }
*/
}
