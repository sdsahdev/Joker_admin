package com.suguretaventure.mymarriagegroup;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.gson.Gson;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.suguretaventure.mymarriagegroup.Model.BioData;
import com.suguretaventure.mymarriagegroup.adapters.MemberListAdapter;
import com.suguretaventure.mymarriagegroup.adapters.RequestAdapter;
import com.suguretaventure.mymarriagegroup.common.NetworkConnetionState;
import com.suguretaventure.mymarriagegroup.utils.Constants;
import com.suguretaventure.mymarriagegroup.utils.Utils;

import java.util.Objects;

import cz.msebera.android.httpclient.Header;

public class MyRequestActivity extends AppCompatActivity {
    private String TAG = "MY_REQUEST_ACTIVITY";
    private Context context = this;
    private RecyclerView rcvGroupRequest;
    private TextView lblRequestEmpty, lblemptygrp,myTitle;
    RelativeLayout relNoDataMyMarket;
    String groupId = "";
    String premiumId = "";
    private FirebaseAnalytics mFirebaseAnalytics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_request);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(getResources().getString(R.string.app_name_title));
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        allocateMemory();
        lblemptygrp.setText(Html.fromHtml(Constants.INVITATION_RECEIVED_BIO));


        if (getIntent().getExtras().getString("from").equals("group_req")) {
            groupId = getIntent().getExtras().getString("groupId");
            premiumId = String.valueOf(getIntent().getExtras().getInt("is_premium"));
        } else {
            groupId = "";
        }


        if (new NetworkConnetionState().isNetworkAvailable(context)) {
            if (getIntent().hasExtra("isFor") &&getIntent().getExtras().getString("isFor").equals("member")){
                getMemberFromServer();
            }else {
                getDataFromServer();
            }
        } else {
            networkAlert();
        }
    }

    private void getMemberFromServer() {
        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        RequestParams params = new RequestParams();
        params.put("rid", Utils.getString(this, Constants.USER_ID));
        params.put("gid", groupId);
        Utils.log(TAG, "REQUEST_URL : " + Constants.GROUP_ALL_REQUEST + "?" + params);
        client.post(Constants.GROUP_ALL_REQUEST, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                Utils.log(TAG, "REQUEST_RESPONSE Member: " + response.replace("[\\]",""));
                BioData data = new Gson().fromJson(response, BioData.class);
                Utils.log("REQ_RESPONSE", data.totalRequest);
                int count = data.detail.size();
                if (count == 0) {
                    lblRequestEmpty.setVisibility(View.VISIBLE);
                    relNoDataMyMarket.setVisibility(View.VISIBLE);
                    rcvGroupRequest.setVisibility(View.GONE);
                } else {
                    lblRequestEmpty.setVisibility(View.GONE);
                    relNoDataMyMarket.setVisibility(View.GONE);
                    rcvGroupRequest.setVisibility(View.VISIBLE);
                    rcvGroupRequest.setLayoutManager(new LinearLayoutManager(context));
                    rcvGroupRequest.setAdapter(new MemberListAdapter(context, data, groupId));

                }

            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "REQUEST_ERROR : " + error.getMessage());
            }
        });
    }

    private void getDataFromServer() {
        AsyncHttpClient client = new AsyncHttpClient(true,80,443);
        RequestParams params = new RequestParams();
        params.put("rid", Utils.getString(context, Constants.USER_ID));
        params.put("iGroupID", groupId);
        params.put("is_premium", premiumId);
        params.put("show_flag", Objects.requireNonNull(getIntent().getExtras()).getInt("showFlag"));
        Utils.log(TAG, "REQUEST_URL : " + Constants.APP_BIODATA_REQUEST + "?" + params);
        client.post(Constants.APP_BIODATA_REQUEST, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String response = new String(responseBody);
                Utils.log(TAG, "REQUEST_RESPONSE : " + response);
                BioData data = new Gson().fromJson(response, BioData.class);
                if (data.success.equalsIgnoreCase("true")) {
                    if (data.detail.size() > 0) {
                        lblRequestEmpty.setVisibility(View.GONE);
                        relNoDataMyMarket.setVisibility(View.GONE);
                        rcvGroupRequest.setVisibility(View.VISIBLE);
                        rcvGroupRequest.setLayoutManager(new LinearLayoutManager(context));
                        if (Objects.requireNonNull(getIntent().getExtras()).getInt("showFlag") == 2) {
                            rcvGroupRequest.setAdapter(new RequestAdapter(context, data, 2));
                        }else{
                            rcvGroupRequest.setAdapter(new RequestAdapter(context, data, 0));
                        }
                    } else {
                        lblRequestEmpty.setVisibility(View.VISIBLE);
                        relNoDataMyMarket.setVisibility(View.VISIBLE);
                        rcvGroupRequest.setVisibility(View.GONE);
                    }
                } else {
                    lblRequestEmpty.setVisibility(View.VISIBLE);
                    relNoDataMyMarket.setVisibility(View.VISIBLE);
                    rcvGroupRequest.setVisibility(View.GONE);
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Utils.log(TAG, "REQUEST_ERROR : " + error.getMessage());
            }
        });
    }

    private void allocateMemory() {
        rcvGroupRequest = findViewById(R.id.rcvGroupRequest);
        lblRequestEmpty = findViewById(R.id.lblRequestEmpty);
        relNoDataMyMarket = findViewById(R.id.relNoDataMyMarket);
        lblemptygrp = findViewById(R.id.lblemptygrp);
        myTitle = findViewById(R.id.myTitle);
        if (getIntent().hasExtra("isFor")&&getIntent().getExtras().getString("isFor").equals("member")){
            myTitle.setText("Member Request List");
        }
    }

    private void networkAlert() {
        AlertDialog.Builder b1 = new AlertDialog.Builder(context);
        b1.setTitle("Network Error");
        b1.setMessage("No internet connection found. Please check your phone settings to turn on the internet.");
        b1.setPositiveButton("Retry", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (new NetworkConnetionState().isNetworkAvailable(context)) {
                    getDataFromServer();
                } else {
                    networkAlert();
                }
            }
        });
        b1.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        b1.create().show();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        if (new NetworkConnetionState().isNetworkAvailable(context)) {
            if (getIntent().hasExtra("isFor") &&getIntent().getExtras().getString("isFor").equals("member")){
                getMemberFromServer();
            }else {
                getDataFromServer();
            }
        } else {
            networkAlert();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_posts, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        int id = item.getItemId();
        if (id == R.id.dashboard) {
            startActivity(new Intent(context, Dashboard.class));
        } else if (id == R.id.myGroup) {
            startActivity(new Intent(context, MyGroup.class));
        } else if (id == R.id.myPost) {
            startActivity(new Intent(context, MyPosts.class)
                    .putExtra("from", "dashboard")
                    .putExtra("gender", "-1"));
        } else if (id == R.id.myFev) {
            startActivity(new Intent(context, MyFav_Arc.class)
                    .putExtra("from", "dashboard_fav"));
        } else if (id == R.id.myArchive) {
            startActivity(new Intent(context, MyFav_Arc.class)
                    .putExtra("from", "dashboard_arc"));
        } else if (id == R.id.myMarketing) {
            startActivity(new Intent(context, MyMarketActivity.class));
        }
        return super.onOptionsItemSelected(item);
    }
}
